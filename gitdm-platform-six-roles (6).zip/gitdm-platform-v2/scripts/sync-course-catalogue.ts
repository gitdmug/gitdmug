import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "../src/generated/prisma/client";
import { ACTIVE_COURSE_CODES, ACTIVE_PROGRAMME_CODES } from "../src/lib/current-catalogue";

const connectionString = process.env.DATABASE_URL;
if (!connectionString) throw new Error("DATABASE_URL is required for course catalogue sync.");
const db = new PrismaClient({ adapter: new PrismaPg({ connectionString }) });

type Duration = 1 | 3 | 12;

const oneMonthCodes = new Set(["TA101"]);
const threeMonthCodes = new Set(["FX3M"]);
const twelveMonthCodes = new Set(["FFM-101", "FFM-102", "FFM-103", "FFM-104", "FFM-105", "FFM-106", "FFM-107", "FFM-108", "FFM-109", "FFM-110", "FFM-111", "FFM-112", "FFM-113", "FFM-114", "FFM-115"]);
const flagshipCourseCodes = Array.from(twelveMonthCodes);

const moduleTemplates: Record<Duration, string[]> = {
  1: ["Foundations & Orientation", "Core Concepts", "Practical Application", "Assessment & Review"],
  3: ["Foundations & Market Context", "Core Concepts & Frameworks", "Tools & Methods", "Guided Practical Work", "Strategy & Decision Making", "Assessment & Applied Review"],
  12: ["Academic Orientation & Market Foundations", "Financial Markets & Global Systems", "Market Participants & Instruments", "Trading Principles & Market Structure", "Technical Analysis & Price Action", "Fundamental Analysis & Macroeconomics", "Trade Planning & Execution", "Derivatives & Hedging", "Advanced Trading Strategies", "Portfolio & Risk Management", "Research & Strategy Development", "Capstone, Professional Practice & Review"],
};

async function main() {
  const courses = await db.course.findMany({ select: { id: true, code: true, title: true, programmeId: true } });
  let updated = 0;
  let modulesCreated = 0;
  let lessonsCreated = 0;
  let retiredDeleted = 0;
  let retiredHidden = 0;

  const publicHolidays = [
    ["2026-12-25", "Christmas Day"], ["2026-12-26", "Boxing Day"],
    ["2027-01-01", "New Year's Day"], ["2027-01-26", "Liberation Day"],
    ["2027-02-16", "Archbishop Janani Luwum Day"], ["2027-03-08", "International Women's Day"],
    ["2027-05-01", "Labour Day"], ["2027-06-03", "Uganda Martyrs' Day"], ["2027-06-09", "National Heroes' Day"], ["2027-10-09", "Independence Day"], ["2027-12-25", "Christmas Day"], ["2027-12-26", "Boxing Day"],
  ] as const;
  for (const [date, name] of publicHolidays) {
    await db.academicHoliday.upsert({ where: { date: new Date(`${date}T00:00:00.000Z`) }, update: { name, countryCode: "UG", source: "Uganda public holiday calendar", isObserved: true }, create: { date: new Date(`${date}T00:00:00.000Z`), name, countryCode: "UG", source: "Uganda public holiday calendar", isObserved: true } });
  }

  // The three-month Beginner Forex programme is one course with modules, not three courses.
  // Build the canonical FX3M course first, then retire the legacy FX101-FX103 rows safely.
  const fxProgramme = await db.programme.findUnique({ where: { code: "GITDM-FX3M" }, select: { id: true } });
  const fxFaculty = await db.faculty.findUnique({ where: { code: "FFM" }, select: { id: true } });
  if (fxProgramme) {
    const fxCourse = await db.course.upsert({
      where: { code: "FX3M" },
      update: { programmeId: fxProgramme.id, title: "Certificate in Beginner Forex Trading", description: "The complete three-month Beginner Forex Trading course, organised into modules and practical classes.", facultyId: fxFaculty?.id, durationMonths: 3, sessionsPerWeek: 2, catalogueVisible: true, published: true, studentSelectable: true },
      create: { programmeId: fxProgramme.id, facultyId: fxFaculty?.id, code: "FX3M", title: "Certificate in Beginner Forex Trading", description: "The complete three-month Beginner Forex Trading course, organised into modules and practical classes.", orderIndex: 1, durationMonths: 3, sessionsPerWeek: 2, catalogueVisible: true, published: true, studentSelectable: true },
    });
    const fxCurriculum: Array<{ module: string; lessons: string[] }> = [
      { module: "Forex Market Foundations", lessons: ["What forex is and how the market works", "Currency pairs, pips and spreads", "Lots, leverage and margin", "Trading sessions and liquidity"] },
      { module: "Market Drivers", lessons: ["Interest rates and central banks", "Inflation, employment and major releases", "DXY, yields and risk sentiment", "Building a weekly fundamental watchlist"] },
      { module: "Responsible Trading", lessons: ["Risk before reward", "Leverage and account protection", "Common beginner mistakes", "Trading plan and discipline"] },
      { module: "Technical Analysis Foundations", lessons: ["Market structure and trend", "Support and resistance", "Trendlines and channels", "Supply and demand"] },
      { module: "Trade Setups", lessons: ["Break and retest continuation", "Pushback into a zone", "Confluence without indicator dependence", "Entry confirmation"] },
      { module: "Trade Planning Lab", lessons: ["Pre-trade checklist", "Chart case studies", "Backtesting and review", "Writing a complete trade plan"] },
      { module: "Risk Management", lessons: ["Position sizing", "Stop-loss placement", "Risk per trade and daily limits", "Drawdown control"] },
      { module: "Execution Practice", lessons: ["Order execution and trade management", "Managing open positions", "When not to trade", "News and volatility management"] },
      { module: "Professional Practice", lessons: ["Trading journal", "20-day trade review", "Performance metrics", "Final practical trading plan"] },
    ];
    for (const [mi, row] of fxCurriculum.entries()) {
      const existingModule = await db.courseModule.findFirst({ where: { courseId: fxCourse.id, title: row.module } });
      const mod = existingModule
        ? await db.courseModule.update({ where: { id: existingModule.id }, data: { description: `Certificate in Beginner Forex Trading — ${row.module}`, orderIndex: mi + 1, published: true, approvalStatus: "APPROVED" } })
        : await db.courseModule.create({ data: { courseId: fxCourse.id, title: row.module, description: `Certificate in Beginner Forex Trading — ${row.module}`, orderIndex: mi + 1, published: true, approvalStatus: "APPROVED" } });
      for (const [li, lessonTitle] of row.lessons.entries()) {
        const existingLesson = await db.lesson.findFirst({ where: { moduleId: mod.id, title: lessonTitle } });
        if (existingLesson) await db.lesson.update({ where: { id: existingLesson.id }, data: { orderIndex: li + 1, published: true, required: true } });
        else await db.lesson.create({ data: { moduleId: mod.id, title: lessonTitle, type: "LIVE_SESSION", content: `${lessonTitle} — scheduled GITDM class within the ${row.module} module.`, orderIndex: li + 1, required: true, published: true } });
      }
    }
    const fxPeriod = await db.academicPeriod.findUnique({ where: { programmeId_sequence: { programmeId: fxProgramme.id, sequence: 1 } }, select: { id: true } });
    if (fxPeriod) await db.periodCourse.upsert({ where: { periodId_courseId: { periodId: fxPeriod.id, courseId: fxCourse.id } }, update: { required: true }, create: { periodId: fxPeriod.id, courseId: fxCourse.id, required: true } });

    // Move active/repeating learners onto the canonical course. Legacy rows with history are hidden later;
    // no learner record is deleted by this migration.
    const activeFxEnrollments = await db.enrollment.findMany({ where: { programmeId: fxProgramme.id, status: { in: ["ACTIVE", "REPEATING"] } }, select: { id: true } });
    for (const enrollment of activeFxEnrollments) {
      await db.courseEnrollment.upsert({ where: { enrollmentId_courseId_attempt: { enrollmentId: enrollment.id, courseId: fxCourse.id, attempt: 1 } }, update: { status: "ACTIVE" }, create: { enrollmentId: enrollment.id, courseId: fxCourse.id, status: "ACTIVE", attempt: 1 } });
    }
  }

  // Canonical one-month Technical Analysis certificate curriculum. Idempotent so deploys update the catalogue without duplicating lessons.
  const taProgramme = await db.programme.findUnique({ where: { code: "GITDM-TA1M" }, select: { id: true } });
  const taFaculty = await db.faculty.findUnique({ where: { code: "FFM" }, select: { id: true } });
  if (taProgramme) {
    const taCourse = await db.course.upsert({
      where: { code: "TA101" },
      update: { programmeId: taProgramme.id, facultyId: taFaculty?.id, title: "Certificate in Technical Analysis", description: "A practical one-month certificate in chart reading, market structure, levels, confirmation and risk-aware trade planning.", durationMonths: 1, sessionsPerWeek: 3, catalogueVisible: true, published: true, studentSelectable: true },
      create: { programmeId: taProgramme.id, facultyId: taFaculty?.id, code: "TA101", title: "Certificate in Technical Analysis", description: "A practical one-month certificate in chart reading, market structure, levels, confirmation and risk-aware trade planning.", orderIndex: 2, durationMonths: 1, sessionsPerWeek: 3, catalogueVisible: true, published: true, studentSelectable: true },
    });
    const genericTaModuleTitles = ["Foundations & Orientation", "Core Concepts", "Practical Application", "Assessment & Review"];
    for (const genericTitle of genericTaModuleTitles) {
      const genericModule = await db.courseModule.findFirst({ where: { courseId: taCourse.id, title: genericTitle } });
      if (genericModule) await db.courseModule.update({ where: { id: genericModule.id }, data: { published: false } });
    }
    const taCurriculum: Array<{module:string;lessons:string[]}> = [
      { module: "Chart Reading & Market Structure", lessons: ["Candlesticks, chart types and timeframe selection", "Swing highs, swing lows and trend structure", "Trend, range and transition conditions"] },
      { module: "Levels & Price Behaviour", lessons: ["Support and resistance zones", "Trendlines, channels and confluence", "Supply and demand zones and zone quality"] },
      { module: "Confirmation & Trade Planning", lessons: ["Breakout, retest and failed-breakout cases", "Candlestick confirmation and entry triggers", "Invalidation, stop placement and position sizing"] },
      { module: "Practical Assessment & Review", lessons: ["Annotating a clean chart without hindsight", "Backtesting a repeatable setup", "Building a complete technical trade plan"] },
    ];
    for (const [mi,row] of taCurriculum.entries()) {
      const found = await db.courseModule.findFirst({ where: { courseId: taCourse.id, title: row.module } });
      const mod = found ? await db.courseModule.update({ where: { id: found.id }, data: { description: `Certificate in Technical Analysis — ${row.module}`, orderIndex: mi+1, published: true, approvalStatus: "APPROVED" } }) : await db.courseModule.create({ data: { courseId: taCourse.id, title: row.module, description: `Certificate in Technical Analysis — ${row.module}`, orderIndex: mi+1, published: true, approvalStatus: "APPROVED" } });
      for (const [li,title] of row.lessons.entries()) {
        const content = `CLASS NOTES — ${title}\n\nLearning outcomes\n• Define the concept and explain its purpose in technical analysis.\n• Identify the evidence on a live or historical chart without hindsight.\n• State a confirmation condition and an invalidation condition before forming a view.\n\nCore lesson\n${title}. Describe what price has actually done, distinguish a confirmed swing from an unconfirmed one, and mark zones rather than claiming an exact level must hold. Higher-timeframe context can inform a hypothesis, but the entry timeframe still needs a clear trigger.\n\nGuided practical\n1. Select one liquid instrument and label the chart timeframe.\n2. Mark the relevant swings or zones and write why each mark is meaningful.\n3. Record an alternative interpretation and what price behaviour would invalidate the first view.\n4. Plan risk before considering a possible entry; do not move a stop merely to avoid a loss.\n\nIndependent work\nSave a clean annotated chart, explain the setup in 150–250 words, and record one limitation or uncertainty. Do not use hindsight to choose the example.`;
        const lesson = await db.lesson.findFirst({ where: { moduleId: mod.id, title } });
        if (lesson) await db.lesson.update({ where: { id: lesson.id }, data: { orderIndex: li+1, type: "LIVE_SESSION", content, published: true, required: true, durationMinutes: 120 } });
        else await db.lesson.create({ data: { moduleId: mod.id, title, type: "LIVE_SESSION", content, orderIndex: li+1, published: true, required: true, durationMinutes: 120 } });
      }
    }
    const period = await db.academicPeriod.findUnique({ where: { programmeId_sequence: { programmeId: taProgramme.id, sequence: 1 } }, select: { id: true } });
    if (period) await db.periodCourse.upsert({ where: { periodId_courseId: { periodId: period.id, courseId: taCourse.id } }, update: { required: true }, create: { periodId: period.id, courseId: taCourse.id, required: true } });
  }

  // Only the current intake catalogue is active. Retired course rows are
  // removed when they have no academic/learner history; if history exists,
  // they are retained but made completely invisible and non-selectable so
  // deployment never destroys existing records.
  for (const retired of courses.filter((course) => !ACTIVE_COURSE_CODES.includes(course.code as any))) {
    const existing = await db.course.findUnique({
      where: { id: retired.id },
      select: { _count: { select: { enrollments: true, assignments: true, quizzes: true, exams: true, timetableEvents: true, tutorials: true, grades: true, transcriptEntries: true, attendance: true, classAttendance: true, periodLinks: true, faculty: true } } },
    });
    const counts = existing?._count;
    const hasHistory = !!counts && Object.values(counts).some((value) => Number(value) > 0);
    if (!hasHistory) {
      await db.course.delete({ where: { id: retired.id } });
      retiredDeleted += 1;
    } else {
      await db.course.update({ where: { id: retired.id }, data: { catalogueVisible: false, published: false, studentSelectable: false } });
      retiredHidden += 1;
    }
  }

  // Keep the three current programme options visible on the public admissions page.
  // This only changes catalogue/application visibility; it does not alter enrolments or payments.
  const certificate = await db.programme.findUnique({ where: { code: "GITDM-CFMTD" }, select: { id: true } });
  if (certificate) {
    await db.programme.update({
      where: { id: certificate.id },
      data: { applicationsOpen: true, status: "PUBLISHED", nextStartDate: new Date("2026-11-02T00:00:00+03:00"), intakeLabel: "2026 intake · 3 trimesters · 100% online" },
    });
  }

  const programmes = await db.programme.findMany({ select: { id: true, durationMonths: true } });
  const programmeDuration = new Map(programmes.map(p => [p.id, p.durationMonths]));

  // The public catalogue and the internal academic system must use the same
  // programme graph. The 12-month CFMTD programme owns FFM-101..FFM-115.
  // Existing course rows are linked in place; nothing is deleted or recreated.
  const flagshipProgramme = await db.programme.findUnique({ where: { code: "GITDM-CFMTD" }, select: { id: true } });
  if (flagshipProgramme) {
    const flagshipPeriods = await db.academicPeriod.findMany({
      where: { programmeId: flagshipProgramme.id },
      orderBy: { sequence: "asc" },
      select: { id: true, sequence: true },
    });
    const flagshipCourses = await db.course.findMany({
      where: { code: { in: flagshipCourseCodes } },
      select: { id: true, code: true },
    });
    const byCode = new Map(flagshipCourses.map((course) => [course.code, course.id]));
    for (const [index, code] of flagshipCourseCodes.entries()) {
      const courseId = byCode.get(code);
      if (!courseId) continue;
      await db.course.update({
        where: { id: courseId },
        data: { programmeId: flagshipProgramme.id, durationMonths: 12, sessionsPerWeek: 0, published: true, studentSelectable: true, catalogueVisible: true },
      });
      // Five courses per trimester/academic period for the 12-month pathway.
      const period = flagshipPeriods[Math.floor(index / 5)];
      if (period) {
        await db.periodCourse.upsert({
          where: { periodId_courseId: { periodId: period.id, courseId } },
          update: { required: true },
          create: { periodId: period.id, courseId, required: true },
        });
      }
    }
  }

  // Repair missing course-enrolment rows for already-admitted students.
  // Existing rows are never removed, even if an old deployment created a stale
  // cross-programme row. Student-facing queries now use the authoritative
  // programme/period graph, while these upserts make assessment/notification
  // workflows complete for existing students too.
  const activeEnrollments = await db.enrollment.findMany({
    where: { status: { in: ["ACTIVE", "REPEATING"] } },
    select: { id: true, programmeId: true, periodId: true },
  });
  for (const enrollment of activeEnrollments) {
    let courseIds: string[] = [];
    if (enrollment.periodId) {
      const periodLinks = await db.periodCourse.findMany({ where: { periodId: enrollment.periodId }, select: { courseId: true } });
      courseIds = periodLinks.map((link) => link.courseId);
    }
    if (!courseIds.length) {
      const programmeCourses = await db.course.findMany({ where: { programmeId: enrollment.programmeId, published: true }, select: { id: true } });
      courseIds = programmeCourses.map((course) => course.id);
    }
    for (const courseId of courseIds) {
      await db.courseEnrollment.upsert({
        where: { enrollmentId_courseId_attempt: { enrollmentId: enrollment.id, courseId, attempt: 1 } },
        update: { status: "ACTIVE" },
        create: { enrollmentId: enrollment.id, courseId, status: "ACTIVE", attempt: 1 },
      });
    }
  }

  for (const course of courses.filter((item) => ACTIVE_COURSE_CODES.includes(item.code as any))) {
    const linkedDuration = course.programmeId ? programmeDuration.get(course.programmeId) : undefined;
    // Programme duration wins. This is critical for the 12-month flagship: its
    // individual FFM courses are not separate 1- or 3-month programmes.
    const linkedProgrammeDuration: Duration | undefined = linkedDuration === 1 || linkedDuration === 3 || linkedDuration === 12
      ? linkedDuration
      : undefined;
    const duration: Duration = linkedProgrammeDuration
      ?? (oneMonthCodes.has(course.code) ? 1 : threeMonthCodes.has(course.code) ? 3 : twelveMonthCodes.has(course.code) ? 12 : 1);
    const sessionsPerWeek = duration === 12 ? 0 : duration === 1 ? 3 : 2;

    await db.course.update({
      where: { id: course.id },
      data: { durationMonths: duration, sessionsPerWeek, catalogueVisible: true, published: true, studentSelectable: true },
    });
    updated++;

    const existingModules = await db.courseModule.findMany({ where: { courseId: course.id }, select: { id: true, title: true, orderIndex: true } });
    const existingTitles = new Set(existingModules.map(m => m.title.trim().toLowerCase()));
    let nextOrder = existingModules.reduce((max, m) => Math.max(max, m.orderIndex), 0);

    const titlesToEnsure = course.code === "TA101" ? [] : moduleTemplates[duration];
    for (const title of titlesToEnsure) {
      if (existingTitles.has(title.toLowerCase())) continue;
      nextOrder += 1;
      const module = await db.courseModule.create({
        data: {
          courseId: course.id,
          title,
          description: `${course.title} — ${title}. This curriculum entry can be edited by the Academic Director before the course delivery plan is finalised.`,
          orderIndex: nextOrder,
          published: true,
          approvalStatus: "APPROVED",
        },
      });
      modulesCreated++;
      await db.lesson.create({
        data: {
          moduleId: module.id,
          title: `${title} — Course lesson`,
          type: "ARTICLE",
          content: `Starter learning activity for ${course.title}. The Academic Director and assigned lecturer can expand this with the approved teaching notes, examples, exercises and resources.`,
          orderIndex: 1,
          required: true,
          published: true,
        },
      });
      lessonsCreated++;
    }
  }

  const oldFaculty = await db.faculty.findUnique({ where: { code: "FFE" }, select: { id: true } });
  if (oldFaculty) {
    const remaining = await db.course.count({ where: { facultyId: oldFaculty.id } });
    if (remaining === 0) await db.faculty.delete({ where: { id: oldFaculty.id } });
  }

  await db.programme.updateMany({
    where: { code: { notIn: [...ACTIVE_PROGRAMME_CODES] } },
    data: { applicationsOpen: false, status: "ARCHIVED" },
  });

  console.log(`Course catalogue sync complete: ${updated} active courses normalised, ${modulesCreated} modules created, ${lessonsCreated} starter lessons created. Retired courses deleted safely: ${retiredDeleted}; retired courses with history hidden: ${retiredHidden}. Active programmes: ${ACTIVE_PROGRAMME_CODES.join(", ")}.`);
}

main().catch(error => {
  console.error(error);
  process.exitCode = 1;
}).finally(async () => {
  await db.$disconnect();
});
