import { getDb } from "@/lib/db";
import { ensureInstitutionalRoles } from "@/lib/role-provisioning";

const db = getDb();
if (!db) throw new Error("Database is unavailable. DATABASE_URL must be configured.");
await ensureInstitutionalRoles(db);
console.log("Institutional access normalisation complete. Historical audit logs retained; Principal authority is exclusive and outside all departments.");
await db.$disconnect();
