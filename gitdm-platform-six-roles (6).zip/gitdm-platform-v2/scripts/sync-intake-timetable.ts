import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "../src/generated/prisma/client";
const connectionString=process.env.DATABASE_URL;
if(!connectionString)throw new Error("DATABASE_URL is required for timetable sync.");
const db=new PrismaClient({adapter:new PrismaPg({connectionString})});
const startDate=new Date("2026-11-02T00:00:00.000Z");
// Kampala is UTC+3 year-round: 09:00 local = 06:00 UTC.
function localDate(date:Date,hour=6){return new Date(Date.UTC(date.getUTCFullYear(),date.getUTCMonth(),date.getUTCDate(),hour,0,0));}
function plusDays(date:Date,n:number){const d=new Date(date);d.setUTCDate(d.getUTCDate()+n);return d;}
const safeResources=(title:string)=>{
 const t=title.toLowerCase();
 if(t.includes("pip")||t.includes("pair")||t.includes("spread")||t.includes("lot"))return [{title:"GITDM free Market Basics guide",url:"/store/free-market-basics",fileType:"WEB"}];
 if(t.includes("support")||t.includes("trend")||t.includes("supply")||t.includes("technical")||t.includes("chart"))return [{title:"GITDM Market Insights and chart practice",url:"/insights",fileType:"WEB"}];
 if(t.includes("risk")||t.includes("position")||t.includes("drawdown"))return [{title:"GITDM trading journal and risk review",url:"/insights",fileType:"WEB"}];
 return [{title:"GITDM free Market Basics guide",url:"/store/free-market-basics",fileType:"WEB"},{title:"Market Insights practice workspace",url:"/insights",fileType:"WEB"}];
};
async function ensureCourse(code:string,days:number[],weeks:number,examTitle:string,examQuestions:{prompt:string;options:string[];correct:number}[]){
 const course=await db.course.findUnique({where:{code},include:{modules:{orderBy:{orderIndex:"asc"},include:{lessons:{orderBy:{orderIndex:"asc"},include:{resources:true}}}}}});
 if(!course){console.warn(`Course ${code} not found; skipping its timetable.`);return;}
 const genericTitles=new Set(["Foundations & Orientation","Core Concepts","Practical Application","Assessment & Review"]);
 const lessons=course.modules.filter(m=>!genericTitles.has(m.title)).flatMap(m=>m.lessons.map(l=>({module:m,lesson:l}))).filter(x=>x.lesson.published);
 if(!lessons.length)console.warn(`Course ${code} has no published lessons; creating classes with study notes from module titles.`);
 let lessonIndex=0, classCount=0;
 for(let week=0;week<weeks;week++){
  for(const dayOffset of days){const date=plusDays(startDate,week*7+dayOffset);const startAt=localDate(date),endAt=new Date(startAt.getTime()+2*60*60*1000);const picked=lessons.length?lessons[lessonIndex%lessons.length]:null;lessonIndex++;
   const title=picked?`${picked.module.title}: ${picked.lesson.title}`:`${course.title} — guided class ${lessonIndex}`;
   const existing=await db.timetableEvent.findFirst({where:{courseId:course.id,startAt,title},select:{id:true}});
   if(!existing)await db.timetableEvent.create({data:{courseId:course.id,moduleId:picked?.module.id,title,type:"CLASS",startAt,endAt,deliveryMode:"HYBRID",venue:"GITDM Trading & Learning Office / Online classroom",notes:`Class begins at 9:00 am East Africa Time (device-local display).\n\nLearning outcomes: understand ${picked?.lesson.title||course.title}; explain the key concept in your own words; complete a worked example; submit a short reflection or chart-markup task.\n\nPreparation: read the linked learning material before class. Bring questions and a chart/notebook.\n\nAfter class: complete the practical exercise and review the lesson notes in your student portal.`,prepMinutes:30}});
   if(picked){for(const resource of safeResources(picked.lesson.title)){const already=await db.learningResource.findFirst({where:{lessonId:picked.lesson.id,title:resource.title}});if(!already)await db.learningResource.create({data:{lessonId:picked.lesson.id,...resource}});}
    if(!picked.lesson.content||picked.lesson.content.length<180)await db.lesson.update({where:{id:picked.lesson.id},data:{content:`CLASS NOTES — ${picked.lesson.title}\n\nLearning outcomes\n• Define the central concept and explain why it matters in market analysis.\n• Identify the concept on a real or historical chart/data example.\n• Explain the assumptions, limitations and risk involved.\n\nLesson framework\n1. Core definition: ${picked.lesson.title}.\n2. Context: how this concept fits into ${picked.module.title}.\n3. Guided practice: annotate a chart or work through a numerical example; write down the evidence before reaching a conclusion.\n4. Common mistakes: confusing an observation with a prediction, ignoring costs and risk, and changing a rule after seeing the outcome.\n5. Reflection: record what you observed, what would invalidate your interpretation, and what you need to learn next.\n\nPreparation: read the linked resource in the student portal. After class, complete a short practice task and add a reflection to your learning journal.`,published:true}});
   }
   classCount++;
  }
  // A visible weekly checkpoint for students and academic staff.
  if((week+1)%4===0){const date=plusDays(startDate,week*7+6);const startAt=localDate(date,7);const title=`${course.title} — Week ${week+1} knowledge check`;const exists=await db.timetableEvent.findFirst({where:{courseId:course.id,title,startAt},select:{id:true}});if(!exists)await db.timetableEvent.create({data:{courseId:course.id,title,type:"ASSESSMENT",startAt,endAt:new Date(startAt.getTime()+60*60*1000),deliveryMode:"ONLINE",venue:"Student portal",notes:"Published assessment checkpoint. Rules: complete independently; use only permitted course notes; do not share answers; submit before the deadline; contact the Academic Department immediately if an accessibility or technical issue prevents submission. Results and feedback are released through the student portal after review."}});}
 }
 const examStart=localDate(plusDays(startDate,days[0]===0?weeks*7+1:weeks*7+1),6);const examEnd=new Date(examStart.getTime()+90*60*1000);const existingExam=await db.exam.findFirst({where:{courseId:course.id,title:examTitle},select:{id:true}});
 if(!existingExam){const exam=await db.exam.create({data:{courseId:course.id,title:examTitle,instructions:"Online final assessment. Read every question carefully. Complete independently. No collaboration or sharing of answers. You may use a calculator for numerical questions; external AI tools and answer-sharing are not permitted. Submit before the timer ends. Contact the Academic Department immediately for documented technical or accessibility issues. Pass mark: 60%. Results are scheduled for release through the student portal after marking and academic review.",passMarkPercent:60,attemptsAllowed:1,timeLimitMinutes:90,opensAt:examStart,closesAt:examEnd,resultsReleaseAt:new Date(examStart.getTime()+72*60*60*1000),status:"PUBLISHED",deliveryMode:"ONLINE",submissionMode:"ONLINE_FORM",publishedAt:new Date(examStart.getTime()-24*60*60*1000),formatDescription:"Timed online exam; 90 minutes; one attempt; 60% pass mark."}});
  for(let i=0;i<examQuestions.length;i++){const q=examQuestions[i];await db.examQuestion.create({data:{examId:exam.id,type:"SINGLE_CHOICE",prompt:q.prompt,optionsJson:JSON.stringify(q.options),correctJson:JSON.stringify([q.correct]),marks:1,orderIndex:i+1}});}
 }
 const examEventTitle=`${course.title} — final examination`;const examEvent=await db.timetableEvent.findFirst({where:{courseId:course.id,title:examEventTitle},select:{id:true}});if(!examEvent)await db.timetableEvent.create({data:{courseId:course.id,title:examEventTitle,type:"EXAM",startAt:examStart,endAt:examEnd,deliveryMode:"ONLINE",venue:"Student portal",notes:`Final examination: ${examTitle}. Published to students 24 hours before opening. Time limit 90 minutes, one attempt, 60% pass mark. Results are scheduled for release within 72 hours, subject to academic review. Device-local time is displayed in the portal.`}});
 console.log(`${code}: ${classCount} class sessions synchronised; existing sessions retained.`);
}
async function main(){
 await ensureCourse("FX3M",[0,2],12,"Certificate in Beginner Forex Trading — Final Examination",[
 {prompt:"What does a pip represent?",options:["A standardised price movement unit for a currency pair","The amount deposited in an account","A guaranteed profit unit","The broker's commission only"],correct:0},
 {prompt:"Why should a trader calculate position size before entry?",options:["To remove all market risk","To align potential loss with a defined risk limit","To guarantee a winning trade","To avoid using a stop loss"],correct:1},
 {prompt:"Which statement best describes leverage?",options:["It eliminates losses","It magnifies exposure relative to account equity and can magnify losses","It guarantees execution at the displayed price","It is the same as a spread"],correct:1},
 {prompt:"A support level breaks and price returns to test it from below. What is the disciplined next step?",options:["Enter immediately without a plan","Observe confirmation and invalidation conditions before deciding","Increase size to recover losses","Assume the level must hold"],correct:1},
 {prompt:"What should a useful trading journal record?",options:["Only winning trades","Entry rationale, risk, execution, outcome and lessons","Only account balance","Predictions without outcomes"],correct:1}
 ]);
 await ensureCourse("TA101",[1,3,4],4,"Certificate in Technical Analysis — Final Examination",[
 {prompt:"What is market structure primarily used to assess?",options:["The sequence of swings and directional context","The broker's withdrawal policy","The trader's internet speed","A guaranteed future price"],correct:0},
 {prompt:"A support zone is best treated as:",options:["A guaranteed reversal point","An area of potential reaction requiring evidence and risk control","A reason to omit a stop plan","A signal that works on every instrument"],correct:1},
 {prompt:"What is a break-and-retest setup?",options:["Price breaks a level and later revisits it for possible confirmation","Any two candles of the same colour","A method to recover a losing trade","A guaranteed trend reversal"],correct:0},
 {prompt:"Why is timeframe context important?",options:["It changes the broker's spread to zero","The same price move can have different significance across timeframes","It makes analysis certain","It removes the need for risk management"],correct:1},
 {prompt:"Which evidence should support a technical conclusion?",options:["A single prediction from social media","Observable structure, levels, confirmation and invalidation conditions","A desire to enter a trade","A guaranteed win-rate claim"],correct:1}
 ]);
}
main().catch(e=>{console.error(e);process.exitCode=1}).finally(async()=>db.$disconnect());
