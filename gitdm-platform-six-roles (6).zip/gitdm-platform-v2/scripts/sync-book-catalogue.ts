import { PrismaPg } from "@prisma/adapter-pg";
import { PrismaClient } from "../src/generated/prisma/client";

const connectionString = process.env.DATABASE_URL;
if (!connectionString) throw new Error("DATABASE_URL is required for book catalogue sync.");
const db = new PrismaClient({ adapter: new PrismaPg({ connectionString }) });

const books = [
  { id: "public-gitdm-market-basics-free-guide", name: "GITDM Market Basics — Free Guide", price: 0, stock: 0, fulfillment: "DIGITAL" as const, onlineReadable: true, digitalUrl: null, description: "Free GITDM branded introductory book. Read online; no download is provided." },
  { id: "public-gitdm-financial-markets-handbook", name: "GITDM Financial Markets Handbook", price: 25000, stock: 100, fulfillment: "BOTH" as const, onlineReadable: true, digitalUrl: "gitdmbook:financial-markets-handbook.pdf", description: "Original GITDM professional handbook: financial-market structure, instruments, macroeconomics, valuation, portfolio risk and case-based learning. Branded, watermarked PDF download and protected online reader." },
  { id: "public-gitdm-trading-derivatives-handbook", name: "GITDM Trading & Derivatives Handbook", price: 35000, stock: 100, fulfillment: "BOTH" as const, onlineReadable: true, digitalUrl: "gitdmbook:trading-derivatives-handbook.pdf", description: "Original GITDM professional handbook: derivative contracts, options, futures, hedging, execution, leverage, stress testing and risk controls. Branded, watermarked PDF download and protected online reader." },
];

async function main() {
  for (const book of books) {
    await db.storeProduct.upsert({
      where: { id: book.id },
      update: {
        name: book.name, price: book.price, stock: book.stock, currency: "UGX", status: "ACTIVE",
        audience: "PUBLIC", fulfillment: book.fulfillment, onlineReadable: book.onlineReadable,
        digitalUrl: book.digitalUrl, description: book.description,
      },
      create: {
        id: book.id, name: book.name, price: book.price, stock: book.stock, currency: "UGX", status: "ACTIVE",
        audience: "PUBLIC", fulfillment: book.fulfillment, onlineReadable: book.onlineReadable,
        digitalUrl: book.digitalUrl, description: book.description,
      },
    });
  }
  console.log(`Synchronized ${books.length} GITDM book products.`);
}

main().catch((error) => { console.error(error); process.exitCode = 1; }).finally(async () => { await db.$disconnect(); });
