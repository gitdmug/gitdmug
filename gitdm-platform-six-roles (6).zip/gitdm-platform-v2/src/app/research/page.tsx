import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { GITDM } from "@/lib/branding";
import { MarketInsightsDashboard } from "@/components/MarketInsightsDashboard";
import { getCurrentUser } from "@/lib/access";
import Link from "next/link";

export const dynamic = "force-dynamic";
export const metadata = {
  title: `Market Insights | ${GITDM.shortName}`,
  description:
    "Market movement monitor, news updates, AI-assisted educational scenario analysis, economic calendar and institutional performance journal.",
};

export default async function ResearchPage() {
  const user = await getCurrentUser();
  return (
    <>
      <Header active="/research" />
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">GITDM Insights</div>
            <h1>Market intelligence, with context.</h1>
            <p>
              Monitor selected instruments, review market headlines and build a structured view of technical
              and fundamental scenarios. Market data availability and freshness can vary by instrument and
              market hours.
            </p>
            <div style={{ display: "flex", gap: 12, flexWrap: "wrap", marginTop: 16 }}>
              <Link className="btn btn-outline-dark btn-sm" href="/research/economic-calendar">
                Economic calendar
              </Link>
              <Link className="btn btn-outline-dark btn-sm" href="/research/journal">
                Performance journal
              </Link>
              <Link className="btn btn-outline-dark btn-sm" href="/research/analysis">
                Last detailed analysis
              </Link>
            </div>
          </div>
        </section>
        <section className="section">
          <div className="container">
            <MarketInsightsDashboard canAnalyse={!!user} />
            <p className="muted" style={{ marginTop: 24 }}>
              Market commentary is educational information, not investment advice. Prices can be delayed or
              incomplete. Verify market data and news from primary sources before making financial decisions.
            </p>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
