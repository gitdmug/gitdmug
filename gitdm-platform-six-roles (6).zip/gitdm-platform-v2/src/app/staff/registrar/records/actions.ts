"use server";
import { revalidatePath } from "next/cache";
import { randomUUID } from "node:crypto";
import { requireOperationalStaffUser } from "@/lib/control-centre";


export async function completeProgramme(formData: FormData) {
  const { db, user } = await requireOperationalStaffUser("results.moderate");
  const enrollmentId = String(formData.get("enrollmentId") || "");
  const enrollment = await db.enrollment.findUnique({ where: { id: enrollmentId }, include: { programme: { include: { rules: true, periods: { include: { courseLinks: true } } } }, user: true } });
  if (!enrollment) throw new Error("Enrollment not found.");
  if (!["ACTIVE", "REPEATING"].includes(enrollment.status)) throw new Error("Only an active or repeating enrollment can be completed.");
  const grades = await db.grade.findMany({ where: { userId: enrollment.userId, status: "FINAL", period: { programmeId: enrollment.programmeId } }, include: { course: true } });
  const requiredCourseIds = enrollment.programme.periods.flatMap((p) => p.courseLinks.map((c) => c.courseId));
  const uniqueRequired = [...new Set(requiredCourseIds)];
  const finalIds = new Set(grades.map((g) => g.courseId));
  const missing = uniqueRequired.filter((id) => !finalIds.has(id));
  if (missing.length) throw new Error(`${missing.length} programme course result(s) are still awaiting final publication.`);
  const passMark = Number(enrollment.programme.rules?.passMarkPercent ?? 50);
  if (grades.some((g) => Number(g.totalPercent) < passMark)) throw new Error(`The programme cannot be completed while a final course result is below ${passMark}%.`);
  await db.enrollment.update({ where: { id: enrollmentId }, data: { status: "COMPLETED", completedAt: new Date(), accessLevel: "FULL" } });
  await db.auditLog.create({ data: { userId: user.id, action: "PROGRAMME_COMPLETED", entity: "Enrollment", entityId: enrollmentId, metadataJson: JSON.stringify({ studentId: enrollment.userId, programmeId: enrollment.programmeId }) } });
  await db.notification.create({ data: { userId: enrollment.userId, type: "ACADEMIC", title: "Programme completed", body: `Your ${enrollment.programme.name} programme has been academically completed. Registry can now prepare your official transcript and certificate.` } });
  revalidatePath("/staff/registrar/records"); revalidatePath("/campus/academic"); revalidatePath("/campus");
}

export async function generateOfficialTranscript(formData: FormData) {
  const { db, user } = await requireOperationalStaffUser("transcripts.view");
  const userId = String(formData.get("userId") || ""); const programmeId = String(formData.get("programmeId") || "");
  if (!userId || !programmeId) throw new Error("Student and programme are required.");
  const enrollment = await db.enrollment.findFirst({ where: { userId, programmeId, status: "COMPLETED" }, include: { programme: { include: { rules: true } } } });
  if (!enrollment) throw new Error("The programme must be completed before an official transcript is generated.");
  const grades = await db.grade.findMany({ where: { userId, status: "FINAL", period: { programmeId } }, orderBy: [{ period: { sequence: "asc" } }, { course: { orderIndex: "asc" } }] });
  if (!grades.length) throw new Error("No final results are available for this programme.");
  const existing = await db.transcript.findFirst({ where: { userId, programmeId }, orderBy: { generatedAt: "desc" } });
  const transcript = existing ?? await db.transcript.create({ data: { userId, programmeId, number: `GITDM-TRN-${new Date().getFullYear()}-${randomUUID().replaceAll("-", "").slice(0, 10).toUpperCase()}` } });
  if (existing) await db.transcriptEntry.deleteMany({ where: { transcriptId: transcript.id } });
  await db.transcriptEntry.createMany({ data: grades.map((g) => ({ transcriptId: transcript.id, courseId: g.courseId, periodId: g.periodId, gradeId: g.id, score: g.totalPercent, gradeLabel: Number(g.totalPercent) >= Number(enrollment.programme.rules?.passMarkPercent ?? 50) ? "PASS" : "FAIL" })) });
  await db.auditLog.create({ data: { userId: user.id, action: "OFFICIAL_TRANSCRIPT_GENERATED", entity: "Transcript", entityId: transcript.id, metadataJson: JSON.stringify({ studentId: userId, programmeId, number: transcript.number }) } });
  await db.notification.create({ data: { userId, type: "ACADEMIC", title: "Official transcript prepared", body: `Your official transcript ${transcript.number} is now available in your Academic record.` } });
  revalidatePath("/staff/registrar/records"); revalidatePath("/campus/academic"); revalidatePath("/campus/academic/transcript");
}

export async function issueCertificate(formData: FormData) {
  const { db, user } = await requireOperationalStaffUser("certificates.manage");
  const userId=String(formData.get("userId")||""); const programmeId=String(formData.get("programmeId")||"");
  const enrollment=await db.enrollment.findFirst({where:{userId,programmeId,status:"COMPLETED"},include:{programme:{include:{rules:true}}}});
  if(!enrollment) throw new Error("Student must have a completed enrolment before certificate issue.");
  const grades=await db.grade.findMany({where:{userId,period:{programmeId},status:"FINAL"}});
  if(!grades.length) throw new Error("No final academic results are available for this programme.");
  const transcript = await db.transcript.findFirst({ where: { userId, programmeId } });
  if(!transcript) throw new Error("Prepare the official transcript before issuing the certificate.");
  const pass=Number(enrollment.programme.rules?.passMarkPercent??50); if(grades.some(g=>Number(g.totalPercent)<pass)) throw new Error(`Certificate cannot be issued while a final result is below ${pass}%.`);
  const existing=await db.certificate.findFirst({where:{userId,programmeId,status:{not:"REVOKED"}}});
  if(existing) return;
  const number=`GITDM-CERT-${new Date().getFullYear()}-${randomUUID().replaceAll("-","").slice(0,10).toUpperCase()}`;
  const certificate=await db.certificate.create({data:{userId,programmeId,number,status:"ISSUED",issuedAt:new Date()}});
  await db.certificateVerification.create({data:{certificateId:certificate.id,verifiedAt:new Date()}});
  await db.auditLog.create({data:{userId:user.id,action:"CERTIFICATE_ISSUED",entity:"Certificate",entityId:certificate.id,metadataJson:JSON.stringify({studentId:userId,programmeId,number})}});
  revalidatePath("/staff/registrar/records"); revalidatePath("/campus/academic"); revalidatePath("/verify-certificate");
}
