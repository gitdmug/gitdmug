import Link from "next/link";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { requireOperationalStaffUser } from "@/lib/control-centre";

export const dynamic = "force-dynamic";

export default async function RegistrarStudentsPage() {
  const { db } = await requireOperationalStaffUser("students.view");
  const enrollments = await db.enrollment.findMany({ where: { status: { in: ["PENDING","ACTIVE","REPEATING","COMPLETED"] } }, orderBy: { createdAt: "desc" }, take: 300, include: { user: true, programme: true, period: true, courses: { include: { course: true } }, invoices: true } });
  const active = enrollments.filter(e => e.status === "ACTIVE" || e.status === "REPEATING").length;
  return <StaffPageShell activeHref="/staff/registrar/students" title="Student register" description="The registrar's authoritative view of admitted learners, programme enrolments, academic standing and completion status.">
    <div className="grid grid-3" style={{marginBottom:24}}><div className="panel"><div className="eyebrow">Records loaded</div><h2>{enrollments.length}</h2></div><div className="panel"><div className="eyebrow">Active / repeating</div><h2>{active}</h2></div><div className="panel"><div className="eyebrow">Completed</div><h2>{enrollments.filter(e=>e.status==="COMPLETED").length}</h2></div></div>
    <div className="table-wrap"><table className="data"><thead><tr><th>Student</th><th>Programme</th><th>Intake</th><th>Status</th><th>Access</th><th>Courses</th><th>Finance</th><th></th></tr></thead><tbody>{enrollments.map(e=><tr key={e.id}><td><strong>{[e.user.firstName,e.user.lastName].filter(Boolean).join(" ")||e.user.email}</strong><div className="tile-meta">{e.user.email}</div></td><td>{e.programme.shortName || e.programme.name}</td><td>{e.period?.name || "—"}</td><td>{e.status}</td><td>{e.accessLevel}</td><td>{e.courses.length}</td><td>{e.invoices.filter(i=>i.status!=="VOID").reduce((n,i)=>n+Math.max(0,Number(i.amount)-Number(i.amountPaid)),0).toLocaleString("en-UG")} {e.invoices[0]?.currency || "UGX"} outstanding</td><td><Link className="btn btn-outline-dark btn-sm" href={`/staff/registrar/students/${e.userId}`}>Open record</Link></td></tr>)}</tbody></table></div>
  </StaffPageShell>;
}
