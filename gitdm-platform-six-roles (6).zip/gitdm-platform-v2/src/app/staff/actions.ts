"use server";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/access";
import { getDb } from "@/lib/db";
import type { RoleCode } from "@/lib/permissions";
import { setActiveStaffRole } from "@/lib/staff-role-context";

const routes: Record<string,string> = {
  PRINCIPAL:"/staff/principal", ACADEMIC_DIRECTOR:"/staff/academic-director", REGISTRAR:"/staff/registrar", FACULTY:"/staff/faculty", LECTURER:"/staff/lecturer", ADMISSIONS:"/staff/admissions", FINANCE:"/staff/finance", EXAM_OFFICER:"/staff/exam-officer", STUDENT_AFFAIRS:"/staff/student-affairs", LIBRARY:"/staff/library", IT:"/staff/it", MARKETING:"/staff/marketing", PARTNER_SUPPORT:"/staff/partner-support",
CURRICULUM_DEVELOPER:"/staff/faculty", ONLINE_INSTRUCTOR:"/staff/lecturer", DIFFERENTIATED_LEARNING_COORDINATOR:"/staff/academic-director", STUDENT_SUCCESS_COACH:"/staff/student-affairs", ACADEMIC_ADVISOR_REGISTRAR:"/staff/registrar", SCHOOL_COUNSELOR:"/staff/student-affairs", CTO_IT_DIRECTOR:"/staff/it", LMS_ADMINISTRATOR:"/staff/it", HELPDESK_TECHNICIAN:"/staff/it", OPERATIONS_COMPLIANCE_MANAGER:"/staff/principal", BURSAR_BILLING_SPECIALIST:"/staff/finance",
};

export async function chooseStaffRole(formData: FormData) {
  const user = await getCurrentUser(); if (!user) redirect("/auth/login");
  const code = String(formData.get("roleCode") || "") as RoleCode;
  const owned = user.roles.some((r) => r.role.code === code && r.role.isActive);
  if (!owned) throw new Error("You do not hold that role.");
  await setActiveStaffRole(code);
  redirect(routes[code] || "/staff");
}

export async function acceptStaffRole(formData: FormData) {
  const user = await getCurrentUser(); if (!user) redirect("/auth/login");
  const db = getDb(); if (!db) throw new Error("Database unavailable");
  const id = String(formData.get("assignmentId") || "");
  const assignment = await db.staffRoleAssignment.findFirst({ where: { id, userId: user.id, status: "PENDING" }, include: { role: true, department: true } });
  if (!assignment) throw new Error("This role invitation is no longer available.");
  if (assignment.role.code === "PRINCIPAL") throw new Error("Principal authority is exclusive and cannot be assigned through a staff invitation.");
  if (user.roles.some((r) => r.role.code === "PRINCIPAL")) throw new Error("The Principal cannot accept departmental staff roles.");
  await db.$transaction([
    db.userRole.upsert({ where: { userId_roleId: { userId: user.id, roleId: assignment.roleId } }, update: {}, create: { userId: user.id, roleId: assignment.roleId, assignedBy: assignment.assignedById } }),
    db.userDepartment.upsert({ where: { userId_departmentId: { userId: user.id, departmentId: assignment.departmentId } }, update: {}, create: { userId: user.id, departmentId: assignment.departmentId } }),
    db.staffRoleAssignment.update({ where: { id }, data: { status: "ACCEPTED", acceptedAt: new Date() } }),
    db.auditLog.create({ data: { userId: user.id, action: "STAFF_ROLE_ACCEPTED", entity: "StaffRoleAssignment", entityId: id, metadataJson: JSON.stringify({ role: assignment.role.code, department: assignment.department.name }) } }),
  ]);
  await setActiveStaffRole(assignment.role.code as RoleCode);
  redirect(routes[assignment.role.code] || "/staff");
}
