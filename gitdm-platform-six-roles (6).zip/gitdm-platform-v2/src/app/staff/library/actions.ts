"use server";
import { revalidatePath } from "next/cache";
import { requireOperationalStaffUser } from "@/lib/control-centre";

export async function createLibraryResource(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("library.manage");
  const title=String(fd.get("title")||"").trim(); const author=String(fd.get("author")||"").trim(); const type=String(fd.get("type")||""); const url=String(fd.get("url")||"").trim();
  if(!title||!type) throw new Error("Resource title and type are required.");
  const row=await db.libraryResource.create({data:{title,author:author||null,type:type as any,url:url||null,description:String(fd.get("description")||"").trim()||null,available:true}});
  await db.auditLog.create({data:{userId:user.id,action:"LIBRARY_RESOURCE_CREATED",entity:"LibraryResource",entityId:row.id}});
  revalidatePath("/staff/library/resources"); revalidatePath("/campus/resources");
}

export async function issueLibraryLoan(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("library.manage");
  const resourceId=String(fd.get("resourceId")||""); const studentId=String(fd.get("studentId")||""); const due=String(fd.get("dueAt")||"");
  if(!resourceId||!studentId) throw new Error("Resource and student are required.");
  const resource=await db.libraryResource.findUnique({where:{id:resourceId}}); if(!resource||!resource.available) throw new Error("Resource is not available.");
  const student=await db.user.findUnique({where:{id:studentId}}); if(!student) throw new Error("Student not found.");
  await db.libraryLoan.create({data:{resourceId,userId:studentId,dueAt:due?new Date(due):null}});
  await db.libraryResource.update({where:{id:resourceId},data:{available:false}});
  await db.notification.create({data:{userId:studentId,type:"ACADEMIC",title:"Library loan issued",body:`Library resource “${resource.title}” has been issued to your account.`}});
  await db.auditLog.create({data:{userId:user.id,action:"LIBRARY_LOAN_ISSUED",entity:"LibraryResource",entityId:resourceId,metadataJson:JSON.stringify({studentId})}});
  revalidatePath("/staff/library/resources"); revalidatePath("/campus/resources");
}

export async function returnLibraryLoan(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("library.manage");
  const id=String(fd.get("loanId")||""); const loan=await db.libraryLoan.findUnique({where:{id},include:{resource:true}}); if(!loan) throw new Error("Loan not found.");
  await db.libraryLoan.update({where:{id},data:{returnedAt:new Date()}}); await db.libraryResource.update({where:{id:loan.resourceId},data:{available:true}});
  await db.auditLog.create({data:{userId:user.id,action:"LIBRARY_LOAN_RETURNED",entity:"LibraryLoan",entityId:id}});
  revalidatePath("/staff/library/resources"); revalidatePath("/campus/resources");
}
