import { GITDM } from "@/lib/branding";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { AdmissionsQueue } from "./AdmissionsQueue";

export const dynamic = "force-dynamic";
export const metadata = { title: `Admissions Applications | ${GITDM.shortName}` };

type StageKey = "NEW" | "REVIEW" | "INFO" | "INTERVIEW" | "ACCEPTED" | "FINANCE" | "PAID" | "ACADEMIC" | "REJECTED";

const STAGES: Record<StageKey, { label: string; where: any }> = {
  NEW: { label: "New applicants", where: { status: "SUBMITTED" } },
  REVIEW: { label: "Under review", where: { status: "UNDER_REVIEW" } },
  INFO: { label: "Additional information", where: { status: "ADDITIONAL_INFORMATION" } },
  INTERVIEW: { label: "Interview", where: { status: "INTERVIEW_REQUIRED" } },
  ACCEPTED: { label: "Accepted / admitted", where: { status: "ACCEPTED" } },
  FINANCE: { label: "Awaiting Finance", where: {
    status: "ACCEPTED",
    applicant: { enrollments: { some: { status: { in: ["ACTIVE", "REPEATING"] }, accessLevel: "LIMITED" } } },
  } },
  PAID: { label: "Paid / cleared", where: {
    status: "ACCEPTED",
    applicant: { enrollments: { some: { status: { in: ["ACTIVE", "REPEATING"] }, accessLevel: "FULL" } } },
  } },
  ACADEMIC: { label: "Academic handover", where: {
    status: "ACCEPTED",
    applicant: { enrollments: { some: { status: { in: ["ACTIVE", "REPEATING"] }, accessLevel: "FULL" } } },
  } },
  REJECTED: { label: "Rejected", where: { status: "REJECTED" } },
};

const VALID_STAGES = Object.keys(STAGES) as StageKey[];

export default async function AdmissionsApplicationsPage({
  searchParams,
}: {
  searchParams: Promise<{ stage?: string; q?: string; programme?: string }>;
}) {
  const { db } = await requireOperationalStaffUser("applications.view");
  const params = await searchParams;
  const requestedStage = params.stage as StageKey | undefined;
  const stage: StageKey = requestedStage && VALID_STAGES.includes(requestedStage) ? requestedStage : "NEW";
  const config = STAGES[stage];

  const apps = await db.application.findMany({
    where: config.where,
    orderBy: { submittedAt: "desc" },
    take: 10,
    include: {
      applicant: { include: { enrollments: { where: { status: { in: ["ACTIVE", "REPEATING"] } }, select: { accessLevel: true } } } },
      programme: true,
      documents: true,
      interviews: { orderBy: { scheduledAt: "desc" }, take: 1 },
      feeInvoice: { select: { amount: true, amountPaid: true, status: true } },
    },
  });

  const rows = apps.map((a) => {
    const enrollmentAccess = a.applicant.enrollments.find(
      (e: any) => e.accessLevel === "FULL" || e.accessLevel === "LIMITED"
    )?.accessLevel;
    const access: "FULL" | "LIMITED" | "NONE" =
      enrollmentAccess === "FULL" || enrollmentAccess === "LIMITED"
        ? enrollmentAccess
        : "NONE";
    const fee: "PAID" | "OUTSTANDING" | "NONE" = a.feeInvoice
      ? (Number(a.feeInvoice.amountPaid) >= Number(a.feeInvoice.amount) - 0.001 && a.feeInvoice.status === "PAID" ? "PAID" : "OUTSTANDING")
      : "NONE";
    const interview = a.interviews[0];
    return {
      id: a.id,
      name: a.legalName || [a.applicant.firstName, a.applicant.lastName].filter(Boolean).join(" ") || a.applicant.email,
      email: a.applicant.email,
      phone: a.phone || a.applicant.phone || "",
      programme: a.programme.name,
      code: a.programme.code,
      status: a.status.replaceAll("_", " "),
      submittedAt: a.submittedAt ? new Date(a.submittedAt).toLocaleDateString("en-UG") : "—",
      documents: a.documents.length,
      fee,
      access,
      interview: interview ? `${interview.status.toLowerCase()}${interview.mode ? ` · ${interview.mode.toLowerCase()}` : ""}` : "Not scheduled",
    };
  });

  const programmes = Array.from(new Set(rows.map((r) => r.programme))).sort();
  const q = (params.q || "").trim().toLowerCase();
  const selectedProgramme = params.programme || "ALL";
  const filteredRows = rows.filter((r) => {
    const matchesSearch = !q || [r.name, r.email, r.phone, r.programme, r.code, r.id].join(" ").toLowerCase().includes(q);
    const matchesProgramme = selectedProgramme === "ALL" || r.programme === selectedProgramme;
    return matchesSearch && matchesProgramme;
  });

  const queryString = (updates: Record<string, string | undefined>) => {
    const next = new URLSearchParams();
    next.set("stage", stage);
    const values = { q: params.q, programme: params.programme, ...updates };
    if (values.q) next.set("q", values.q);
    if (values.programme && values.programme !== "ALL") next.set("programme", values.programme);
    return `/staff/admissions/applications?${next.toString()}`;
  };

  return <StaffPageShell
    activeHref={`/staff/admissions/applications?stage=${stage}`}
    title={config.label}
    description={`Admissions queue · ${config.label}. Only applications belonging to this stage are loaded, with the latest 10 shown for focused operational work.`}
  >
    <div className="panel" style={{ marginBottom: 22 }}>
      <strong>{config.label}</strong>
      <p style={{ marginBottom: 0, marginTop: 6 }}>
        This workspace contains only the applications currently represented by this stage. Search and programme filters operate within this queue.
      </p>
    </div>

    <div className="panel" style={{ marginBottom: 22 }}>
      <form className="grid grid-2" method="get">
        <input type="hidden" name="stage" value={stage} />
        <label className="form-row" style={{ margin: 0 }}>Search student
          <input name="q" defaultValue={params.q || ""} placeholder="Name, email, phone, programme or application ID" />
        </label>
        <label className="form-row" style={{ margin: 0 }}>Filter programme
          <select name="programme" defaultValue={selectedProgramme}>
            <option value="ALL">All programmes</option>
            {programmes.map((programme) => <option key={programme} value={programme}>{programme}</option>)}
          </select>
        </label>
        <div className="actions" style={{ gridColumn: "1 / -1" }}>
          <button className="btn btn-primary btn-sm" type="submit">Apply filters</button>
          <a className="btn btn-outline-dark btn-sm" href={`/staff/admissions/applications?stage=${stage}`}>Clear filters</a>
        </div>
      </form>
    </div>

    <AdmissionsQueue stage={stage} label={config.label} rows={filteredRows} totalLoaded={rows.length} />
  </StaffPageShell>;
}
