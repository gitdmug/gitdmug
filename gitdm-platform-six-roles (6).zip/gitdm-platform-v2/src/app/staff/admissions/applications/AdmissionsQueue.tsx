"use client";

import Link from "next/link";

type Row = {
  id: string;
  name: string;
  email: string;
  phone: string;
  programme: string;
  code: string;
  status: string;
  submittedAt: string;
  documents: number;
  fee: "PAID" | "OUTSTANDING" | "NONE";
  access: "FULL" | "LIMITED" | "NONE";
  interview: string;
};

export function AdmissionsQueue({
  stage,
  label,
  rows,
  totalLoaded,
}: {
  stage: string;
  label: string;
  rows: Row[];
  totalLoaded: number;
}) {
  return <div className="stack">
    <div className="table-wrap">
      <table className="data">
        <thead><tr><th>Applicant</th><th>Programme</th><th>Stage</th><th>Documents</th><th>Interview</th><th>Finance</th><th>Access</th><th>Submitted</th><th>Action</th></tr></thead>
        <tbody>
          {rows.map((r) => <tr key={r.id}>
            <td><strong>{r.name}</strong><div className="tile-meta">{r.email}{r.phone ? ` · ${r.phone}` : ""}</div></td>
            <td><strong>{r.code}</strong><div className="tile-meta">{r.programme}</div></td>
            <td><span className="badge">{r.status}</span></td>
            <td>{r.documents}</td>
            <td>{r.interview}</td>
            <td>{r.fee === "PAID" ? <span className="badge success">Paid</span> : r.fee === "OUTSTANDING" ? <span className="badge warn">Outstanding</span> : <span className="badge">—</span>}</td>
            <td>{r.access === "FULL" ? <span className="badge success">Full</span> : r.access === "LIMITED" ? <span className="badge warn">Limited</span> : <span className="badge">—</span>}</td>
            <td>{r.submittedAt}</td>
            <td><Link className="btn btn-outline-dark btn-sm" href={`/staff/admissions/applications/${r.id}`}>Open case</Link></td>
          </tr>)}
        </tbody>
      </table>
      {!rows.length ? <div className="panel" style={{ borderTop: 0 }}><p>No applications match the <strong>{label}</strong> queue and current filters.</p></div> : null}
    </div>
    <p className="tile-meta">{label} · showing {rows.length} of the latest {Math.min(totalLoaded, 10)} loaded applications for this stage.</p>
  </div>;
}
