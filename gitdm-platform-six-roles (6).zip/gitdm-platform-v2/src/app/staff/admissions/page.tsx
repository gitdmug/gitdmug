import Link from "next/link";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { DepartmentWorkflow } from "@/components/staff/DepartmentWorkflow";
import { getCurrentUser } from "@/lib/access";
import { requireOperationalStaffUser } from "@/lib/control-centre";
export const dynamic="force-dynamic";
export default async function AdmissionsWorkspacePage(){
  const {db}=await requireOperationalStaffUser("applications.view");
  const [review, interviews, accepted, financePending, cleared, rejected] = await Promise.all([
    db.application.count({where:{status:{in:["SUBMITTED","UNDER_REVIEW","ADDITIONAL_INFORMATION"]}}}),
    db.application.count({where:{status:"INTERVIEW_REQUIRED"}}),
    db.application.count({where:{status:"ACCEPTED"}}),
    db.application.count({where:{status:"ACCEPTED",applicant:{enrollments:{some:{status:{in:["ACTIVE","REPEATING"]},accessLevel:"LIMITED"}}}}}),
    db.application.count({where:{status:"ACCEPTED",applicant:{enrollments:{some:{status:{in:["ACTIVE","REPEATING"]},accessLevel:"FULL"}}}}}),
    db.application.count({where:{status:"REJECTED"}}),
  ]);
  return <StaffPageShell activeHref="/staff/admissions" title="Admissions & enrollment" description="A controlled applicant pipeline from intake to admission, Finance handover and learner activation.">
    <div className="grid grid-4">
      <div className="panel"><div className="eyebrow">Open cases</div><h2>{review}</h2><p>New, review or information</p></div>
      <div className="panel"><div className="eyebrow">Interviews</div><h2>{interviews}</h2><p>Interview stage</p></div>
      <div className="panel"><div className="eyebrow">Finance pending</div><h2>{financePending}</h2><p>Accepted · limited access</p></div>
      <div className="panel"><div className="eyebrow">Fully cleared</div><h2>{cleared}</h2><p>Accepted · full access</p></div>
    </div>
    <div className="panel" style={{marginTop:24}}><div className="eyebrow">Department operating floor</div><h2>One case, one controlled route</h2><p>Admissions owns the applicant case through eligibility, document review, additional-information loops, interview and the final Continue/Reject decision. Accepted cases move to Finance; Finance verification controls learning access.</p><div className="table-wrap" style={{marginTop:16}}><table className="data"><thead><tr><th>Stage</th><th>Owner</th><th>Action</th><th>Next destination</th></tr></thead><tbody>
      <tr><td>New applicant</td><td>Admissions</td><td>Check submission and completeness</td><td>Review / additional information</td></tr>
      <tr><td>Review</td><td>Admissions</td><td>Verify eligibility and evidence</td><td>Interview / additional information</td></tr>
      <tr><td>Interview</td><td>Admissions</td><td>Physical or online interview; log Continue or Reject</td><td>Final decision / rejection</td></tr>
      <tr><td>Accepted</td><td>Admissions → Finance</td><td>Create enrolment and tuition obligation</td><td>Finance verification</td></tr>
      <tr><td>Finance cleared</td><td>Finance / system</td><td>Verified payment meets programme activation rule</td><td>Full learning access</td></tr>
    </tbody></table></div></div>
    <div className="grid grid-2" style={{marginTop:24}}>
      <article className="card"><div className="eyebrow">Applications desk</div><h2>Work the queue</h2><p>Use stage buttons, search and programme filters. Each queue shows only its latest 10 cases to keep the operational floor uncluttered.</p><Link className="btn btn-primary btn-sm" href="/staff/admissions/applications">Open applications</Link></article>
      <article className="card"><div className="eyebrow">Closed outcomes</div><h2>{rejected} rejected · {accepted} accepted</h2><p>All decisions remain auditable. Applicant communication is recorded against the case.</p></article>
    </div>
  </StaffPageShell>;
}
