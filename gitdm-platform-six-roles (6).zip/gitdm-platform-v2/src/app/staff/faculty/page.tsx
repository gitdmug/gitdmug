import { StaffWorkspace } from "@/components/staff/StaffWorkspace";
export const dynamic = "force-dynamic";
export default function Page() { return <StaffWorkspace workspace="faculty" />; }
