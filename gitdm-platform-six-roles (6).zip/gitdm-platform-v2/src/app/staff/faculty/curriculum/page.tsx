import { redirect } from "next/navigation";
export default function FacultyCurriculumPage(){ redirect("/staff/lecturer/courses"); }
