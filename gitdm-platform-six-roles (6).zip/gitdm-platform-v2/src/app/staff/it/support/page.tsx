import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { humanStatus } from "@/lib/status";
import Link from "next/link";
import { updateSupportTicket } from "@/app/staff/support/actions";

export const dynamic="force-dynamic";
export default async function ITSupportPage(){
 const {db}=await requireOperationalStaffUser("support.manage");
 const tickets=await db.supportTicket.findMany({where:{status:{in:["OPEN","IN_PROGRESS","WAITING"]}},orderBy:{createdAt:"asc"},take:200,include:{requester:true,assignee:true}});
 return <StaffPageShell activeHref="/staff/it/support" title="IT help desk" description="Resolve account, access, LMS and technical issues that can block a learner from studying.">
  <div className="panel" style={{marginBottom:24}}><strong>Operational rule:</strong> every technical case should end in either a documented resolution or a clear escalation. Staff should never tell a learner to start a second account just because access is broken.</div>
  <div className="stack">{tickets.map(t=><article className="card" key={t.id}><div style={{display:"flex",justifyContent:"space-between",gap:12}}><div><span className="chip">{t.priority}</span><h2 style={{marginTop:8}}>{t.subject}</h2><p>{t.description}</p></div><span className="badge">{humanStatus(t.status)}</span></div><p className="tile-meta">Requester: {t.requester.email} · Opened {t.createdAt.toLocaleString("en-UG")}{t.assignee?` · Assigned ${t.assignee.email}`:""}</p><form action={updateSupportTicket} className="actions"><input type="hidden" name="id" value={t.id}/><select name="status" defaultValue={t.status}><option value="OPEN">Open</option><option value="IN_PROGRESS">In progress</option><option value="WAITING">Waiting</option><option value="RESOLVED">Resolved</option><option value="CLOSED">Closed</option></select><button className="btn btn-primary btn-sm">Save case</button><Link className="btn btn-outline-dark btn-sm" href="/staff/it/users">Open requester account</Link></form></article>)}{!tickets.length?<div className="panel">No open technical cases.</div>:null}</div>
 </StaffPageShell>
}
