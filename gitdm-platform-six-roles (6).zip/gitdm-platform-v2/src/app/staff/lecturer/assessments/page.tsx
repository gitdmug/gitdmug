import Link from "next/link";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { createAssignment, publishAssignment, gradeAssignmentSubmission, createQuiz, addQuizQuestion, publishQuiz } from "@/app/control-centre/courses/actions";

export const dynamic = "force-dynamic";

export default async function LecturerAssessmentsPage() {
  const { db, user, roleCodes } = await requireOperationalStaffUser("assignments.grade");
  const isAcademicLead = roleCodes.some((r) =>
    ["ACADEMIC_DIRECTOR", "PRINCIPAL", "LECTURER", "ONLINE_INSTRUCTOR", "FACULTY", "CURRICULUM_DEVELOPER"].includes(r)
  );
  // Only the three public active courses — never Capstone or retired codes
  const { ACTIVE_COURSE_CODES } = await import("@/lib/current-catalogue");
  const courses = await db.course.findMany({
    where: {
      code: { in: [...ACTIVE_COURSE_CODES] },
      published: true,
      ...(isAcademicLead ? {} : { faculty: { some: { userId: user.id } } }),
    },
    orderBy: [{ orderIndex: "asc" }, { title: "asc" }],
    include: {
      assignments: { orderBy: { dueAt: "asc" }, include: { submissions: { orderBy: { submittedAt: "desc" }, include: { user: true } } } },
      quizzes: { orderBy: { title: "asc" }, include: { questions: true, attempts: { include: { user: true }, orderBy: { submittedAt: "desc" }, take: 20 } } },
    },
  });
  const canManageQuiz = isAcademicLead;
  return <StaffPageShell activeHref="/staff/lecturer/assessments" title="Coursework & assessments" description="Create, publish, mark and monitor the assessments that feed each student's academic record.">
    <div className="panel" style={{marginBottom:24}}><strong>Student learning pipeline:</strong> lesson delivery → coursework/quiz → marking → verified examination → provisional grade → published academic result. Every assessment action below writes to the same records used by the learner portal.</div>
    <div className="stack">
      {courses.map((course) => <article className="card" key={course.id}>
        <div style={{display:"flex",justifyContent:"space-between",gap:12,flexWrap:"wrap"}}><div><span className="chip chip-accent">{course.code}</span><h2 style={{marginTop:8}}>{course.title}</h2></div><Link className="btn btn-outline-dark btn-sm" href={`/staff/lecturer/courses/${course.id}`}>Open course workspace</Link></div>
        <div className="grid grid-2" style={{marginTop:18,alignItems:"start"}}>
          <div><div className="eyebrow">Assignments</div><h3>{course.assignments.length}</h3>
            <form action={createAssignment} className="stack" style={{marginTop:12}}><input type="hidden" name="courseId" value={course.id}/><input name="title" required placeholder="Assignment title"/><textarea name="instructions" required placeholder="Instructions and submission requirements"/><div className="grid grid-2"><input name="maxMarks" type="number" min="1" step="0.5" placeholder="Max marks" required/><input name="dueAt" type="datetime-local"/></div><button className="btn btn-primary btn-sm">Create draft assignment</button></form>
            <div className="stack" style={{marginTop:14}}>{course.assignments.map(a=><div className="staff-notice" key={a.id}><div style={{display:"flex",justifyContent:"space-between",gap:8}}><div><strong>{a.title}</strong><p>{a.status} · {a.submissions.length} submission(s) · {Number(a.maxMarks)} marks</p></div>{a.status === "DRAFT" ? <form action={publishAssignment}><input type="hidden" name="assignmentId" value={a.id}/><button className="btn btn-primary btn-sm">Publish</button></form> : null}</div>{a.submissions.map(s=><div className="staff-notice" style={{marginTop:8}} key={s.id}><strong>{[s.user.firstName,s.user.lastName].filter(Boolean).join(" ")||s.user.email}</strong><p>{s.status} {s.score != null ? `· ${Number(s.score)}/${Number(a.maxMarks)}` : "· Awaiting mark"}</p>{["SUBMITTED","LATE","RETURNED"].includes(s.status) ? <form action={gradeAssignmentSubmission} className="actions"><input type="hidden" name="submissionId" value={s.id}/><input name="score" type="number" min="0" max={Number(a.maxMarks)} step="0.1" placeholder="Score" required/><input name="feedback" placeholder="Feedback"/><button className="btn btn-outline-dark btn-sm">Save mark</button></form> : null}</div>)}</div>)}</div>
          </div>
          <div><div className="eyebrow">Quizzes</div><h3>{course.quizzes.length}</h3>{canManageQuiz ? <form action={createQuiz} className="stack" style={{marginTop:12}}><input type="hidden" name="courseId" value={course.id}/><input name="title" required placeholder="Quiz title"/><textarea name="instructions" placeholder="Instructions"/><div className="grid grid-3"><input name="passMarkPercent" type="number" min="0" max="100" defaultValue="50"/><input name="attemptsAllowed" type="number" min="1" defaultValue="1"/><input name="timeLimitMinutes" type="number" min="0" placeholder="Minutes"/></div><button className="btn btn-primary btn-sm">Create quiz</button></form> : null}
            <div className="stack" style={{marginTop:14}}>{course.quizzes.map(q=><div className="staff-notice" key={q.id}><div><strong>{q.title}</strong><p>{q.status} · {q.questions.length} question(s) · {q.attempts.length} recent attempt(s)</p></div>{q.status === "DRAFT" && canManageQuiz ? <><form action={addQuizQuestion} className="stack" style={{marginTop:10}}><input type="hidden" name="quizId" value={q.id}/><textarea name="prompt" required placeholder="Question"/><textarea name="options" placeholder="One option per line"/><input name="correct" placeholder="Correct answer"/><input name="marks" type="number" min="0.5" step="0.5" defaultValue="1"/><button className="btn btn-outline-dark btn-sm">Add question</button></form>{q.questions.length ? <form action={publishQuiz} style={{marginTop:8}}><input type="hidden" name="quizId" value={q.id}/><button className="btn btn-primary btn-sm">Publish quiz</button></form> : null}</> : null}</div>)}</div>
          </div>
        </div>
      </article>)}
      {!courses.length ? <div className="panel"><h2>No assigned courses</h2><p>Academic Affairs must allocate a course to your staff account before you can manage its learning and assessments.</p></div> : null}
    </div>
  </StaffPageShell>;
}
