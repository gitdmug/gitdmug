import Link from "next/link";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { ACTIVE_COURSE_CODES } from "@/lib/current-catalogue";
import { courseDisplayTitle } from "@/lib/course-display";

export const dynamic = "force-dynamic";

export default async function LecturerCoursesPage() {
  const { db, user, roleCodes } = await requireOperationalStaffUser("courses.view");
  const leadership = roleCodes.some((r) => ["ACADEMIC_DIRECTOR", "CURRICULUM_DEVELOPER", "REGISTRAR", "PRINCIPAL"].includes(r));
  const courses = await db.course.findMany({
    where: { code: { in: [...ACTIVE_COURSE_CODES] }, ...(leadership ? {} : { faculty: { some: { userId: user.id } } }) },
    orderBy: [{ orderIndex: "asc" }, { title: "asc" }],
    include: { programme: true, facultyUnit: true, faculty: { include: { user: true } }, modules: { include: { lessons: true } }, _count: { select: { enrollments: true, assignments: true, quizzes: true, exams: true } } },
  });
  return <StaffPageShell activeHref="/staff/lecturer/courses" title={leadership ? "Course curriculum & delivery" : "My teaching courses"} description="This is the working academic record behind what students see in My Learning. Build content, delivery plans, assessments and student-facing access from here.">
    <div className="grid grid-4" style={{marginBottom:24}}>{[
      ["Courses", courses.length], ["Modules", courses.reduce((n,c)=>n+c.modules.length,0)], ["Lessons", courses.reduce((n,c)=>n+c.modules.reduce((m,x)=>m+x.lessons.length,0),0)], ["Enrolments", courses.reduce((n,c)=>n+c._count.enrollments,0)]
    ].map(([label,value])=><div className="panel" key={String(label)}><div className="eyebrow">{label}</div><h2>{value}</h2></div>)}</div>
    <div className="stack">{courses.map(c=><article className="card" key={c.id}><div style={{display:"flex",justifyContent:"space-between",gap:16,flexWrap:"wrap"}}><div><span className="chip chip-accent">{c.code}</span><h2 style={{marginTop:8}}>{courseDisplayTitle(c.code, c.title)}</h2><p>{c.programme?.name || "Independent course"} · {c.facultyUnit?.name || "Faculty"}</p></div><span className={`badge ${c.published && c.studentSelectable && c.faculty.length ? "success" : "warn"}`}>{c.published && c.studentSelectable && c.faculty.length ? "Student-facing" : "Preparing"}</span></div><div className="meta" style={{marginTop:14}}><span className="chip">{c.modules.length} modules</span><span className="chip">{c.modules.reduce((n,m)=>n+m.lessons.length,0)} lessons</span><span className="chip">{c._count.enrollments} enrolments</span><span className="chip">{c._count.assignments} assignments</span><span className="chip">{c._count.quizzes} quizzes</span><span className="chip">{c._count.exams} exams</span></div><div className="actions" style={{marginTop:16}}><Link className="btn btn-primary btn-sm" href={`/staff/lecturer/courses/${c.id}`}>Open full course workspace</Link><Link className="btn btn-outline-dark btn-sm" href="/staff/lecturer/classes">Classes & timetable</Link><Link className="btn btn-outline-dark btn-sm" href="/staff/lecturer/assessments">Assessments</Link></div></article>)}{!courses.length?<div className="panel"><h2>No course assignment</h2><p>Your role is active, but no current intake course is allocated to this staff account.</p></div>:null}</div>
  </StaffPageShell>;
}
