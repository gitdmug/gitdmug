import Link from "next/link";
import { GITDM } from "@/lib/branding";
import { ACTIVE_COURSE_CODES } from "@/lib/current-catalogue";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { generateAutomaticShortCourseTimetable } from "@/app/control-centre/timetable/actions";

export const dynamic = "force-dynamic";
export const metadata = { title: `Class Scheduling | ${GITDM.shortName}` };

/**
 * Sequential academic flow (congestion fix):
 * 1. Lessons already exist from the generated timetable.
 * 2. Lecturer sees the next upcoming class prominently.
 * 3. Opens a focused page to add Meet link + materials.
 * 4. After class, confirms attendance on that session page.
 * 5. System surfaces the next lesson automatically.
 */
export default async function TimetableAdmin() {
  const { db, user, roleCodes } = await requireOperationalStaffUser("attendance.manage");
  const isLeadership = roleCodes.some((r) =>
    ["PRINCIPAL", "ACADEMIC_DIRECTOR", "REGISTRAR"].includes(r)
  );
  const now = new Date();

  const events = await db.timetableEvent.findMany({
    where: {
      course: { code: { in: [...ACTIVE_COURSE_CODES] } },
      ...(isLeadership ? {} : { lecturerUserId: user.id }),
    },
    orderBy: { startAt: "asc" },
    take: 120,
    include: {
      course: { include: { facultyUnit: true } },
      period: true,
      lecturerUser: true,
      department: true,
      attendance: true,
    },
  });

  const upcoming = events.filter((e) => new Date(e.endAt) >= now);
  const next = upcoming[0] || null;
  const later = upcoming.slice(1, 12);
  const past = events.filter((e) => new Date(e.endAt) < now).slice(-8).reverse();

  return (
    <StaffPageShell activeHref="/staff/lecturer/classes" title="Classes & timetable">
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">GITDM live teaching</div>
            <h1>Class delivery</h1>
            <p>
              Academic Affairs publishes the timetable. You add the live-class link and materials
              for the next session, teach, then confirm attendance. The next lesson appears
              automatically — no long congested list of forms.
            </p>
          </div>
        </section>

        <section className="section">
          <div className="container">
            {isLeadership ? (
              <div className="card" style={{ marginBottom: 24 }}>
                <div className="eyebrow">Automatic timetable</div>
                <h2>Set the intake start date</h2>
                <p>
                  Choose the start date and session. GITDM creates the timetable from the fixed
                  teaching pattern.
                </p>
                <form
                  action={generateAutomaticShortCourseTimetable}
                  className="grid grid-3"
                  style={{ marginTop: 18, alignItems: "end" }}
                >
                  <label>
                    Course
                    <select name="courseCode" required>
                      <option value="TA101">Certificate in Technical Analysis</option>
                      <option value="FX3M">Certificate in Beginner Forex Trading</option>
                    </select>
                  </label>
                  <label>
                    Start date
                    <input name="startDate" type="date" defaultValue="2026-11-02" required />
                  </label>
                  <label>
                    Session
                    <select name="session" defaultValue="MORNING">
                      <option value="MORNING">Morning · 9:00am–12:00pm</option>
                      <option value="EVENING">Evening · 5:00pm–8:00pm</option>
                    </select>
                  </label>
                  <div>
                    <button className="btn btn-primary">Generate timetable automatically</button>
                  </div>
                </form>
              </div>
            ) : null}

            {next ? (
              <div className="panel" style={{ marginBottom: 28, border: "2px solid var(--primary, #2563eb)" }}>
                <div className="eyebrow">Next session</div>
                <h2 style={{ margin: "4px 0 8px" }}>
                  {next.title || next.course?.title || "Class session"}
                </h2>
                <p className="muted" style={{ margin: 0 }}>
                  {next.course?.code} ·{" "}
                  {new Date(next.startAt).toLocaleString(undefined, {
                    dateStyle: "medium",
                    timeStyle: "short",
                  })}{" "}
                  –{" "}
                  {new Date(next.endAt).toLocaleTimeString(undefined, {
                    hour: "2-digit",
                    minute: "2-digit",
                  })}
                </p>
                <p style={{ marginTop: 8 }}>
                  Delivery: {next.deliveryMode || "HYBRID"} · Meet:{" "}
                  {(next.googleMeetUrl || next.joinUrl) ? "Connected" : "Not connected"}
                </p>
                <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 14 }}>
                  <Link className="btn btn-primary" href={`/staff/lecturer/classes/${next.id}`}>
                    Open session · link, materials & attendance
                  </Link>
                </div>
              </div>
            ) : (
              <div className="panel" style={{ marginBottom: 28 }}>
                <h2>No upcoming classes</h2>
                <p className="muted">
                  When Academic Affairs publishes the next intake timetable, your next session will
                  appear here.
                </p>
              </div>
            )}

            {later.length ? (
              <div className="panel" style={{ marginBottom: 28 }}>
                <div className="eyebrow">Coming up</div>
                <h2>Later sessions</h2>
                <div className="table-wrap" style={{ marginTop: 12 }}>
                  <table className="data">
                    <thead>
                      <tr>
                        <th>When</th>
                        <th>Course</th>
                        <th>Title</th>
                        <th>Meet</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      {later.map((e) => (
                        <tr key={e.id}>
                          <td>
                            {new Date(e.startAt).toLocaleString(undefined, {
                              dateStyle: "short",
                              timeStyle: "short",
                            })}
                          </td>
                          <td>{e.course?.code}</td>
                          <td>{e.title || e.course?.title}</td>
                          <td>{(e.googleMeetUrl || e.joinUrl) ? "Yes" : "—"}</td>
                          <td>
                            <Link
                              className="btn btn-outline-dark btn-sm"
                              href={`/staff/lecturer/classes/${e.id}`}
                            >
                              Open
                            </Link>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : null}

            {past.length ? (
              <div className="panel">
                <div className="eyebrow">Recent</div>
                <h2>Past sessions</h2>
                <div className="table-wrap" style={{ marginTop: 12 }}>
                  <table className="data">
                    <thead>
                      <tr>
                        <th>When</th>
                        <th>Course</th>
                        <th>Attendance records</th>
                        <th></th>
                      </tr>
                    </thead>
                    <tbody>
                      {past.map((e) => (
                        <tr key={e.id}>
                          <td>
                            {new Date(e.startAt).toLocaleString(undefined, {
                              dateStyle: "short",
                              timeStyle: "short",
                            })}
                          </td>
                          <td>{e.course?.code}</td>
                          <td>{e.attendance?.length ?? 0}</td>
                          <td>
                            <Link
                              className="btn btn-outline-dark btn-sm"
                              href={`/staff/lecturer/classes/${e.id}`}
                            >
                              Review
                            </Link>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : null}
          </div>
        </section>
      </main>
    </StaffPageShell>
  );
}
