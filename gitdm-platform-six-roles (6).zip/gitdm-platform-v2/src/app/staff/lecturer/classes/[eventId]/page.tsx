import Link from "next/link";
import { notFound } from "next/navigation";
import { GITDM } from "@/lib/branding";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { setClassLink, endOnlineClass, syncOnlineAttendance } from "@/app/control-centre/courses/actions";

export const dynamic = "force-dynamic";
export const metadata = { title: `Class session | ${GITDM.shortName}` };

export default async function ClassSessionPage({
  params,
}: {
  params: Promise<{ eventId: string }>;
}) {
  const { eventId } = await params;
  const { db } = await requireOperationalStaffUser("attendance.manage");
  const event = await db.timetableEvent.findUnique({
    where: { id: eventId },
    include: {
      course: true,
      period: true,
      lecturerUser: true,
      attendance: { include: { user: true }, orderBy: { minutesAttended: "desc" } },
    },
  });
  if (!event) notFound();

  const meetUrl = event.googleMeetUrl || event.joinUrl || "";

  return (
    <StaffPageShell activeHref="/staff/lecturer/classes" title="Class session">
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">{event.course?.code || "Class"}</div>
            <h1>{event.title || event.course?.title || "Session"}</h1>
            <p>
              {new Date(event.startAt).toLocaleString(undefined, {
                dateStyle: "full",
                timeStyle: "short",
              })}{" "}
              –{" "}
              {new Date(event.endAt).toLocaleTimeString(undefined, {
                hour: "2-digit",
                minute: "2-digit",
              })}
            </p>
            <Link className="btn btn-outline-dark btn-sm" href="/staff/lecturer/classes">
              ← Back to next session
            </Link>
          </div>
        </section>

        <section className="section">
          <div className="container" style={{ maxWidth: 640 }}>
            <div className="panel" style={{ marginBottom: 20 }}>
              <div className="eyebrow">Step 1</div>
              <h2>Add class link</h2>
              <p className="muted">
                Paste the Google Meet (or other) join URL for this session. Students see it on
                Campus once saved.
              </p>
              <form action={setClassLink} style={{ display: "grid", gap: 10, marginTop: 12 }}>
                <input type="hidden" name="eventId" value={event.id} />
                <label>
                  Join URL
                  <input
                    name="joinUrl"
                    type="url"
                    placeholder="https://meet.google.com/..."
                    defaultValue={meetUrl}
                    required
                  />
                </label>
                <button type="submit" className="btn btn-primary">
                  Save class link
                </button>
              </form>
            </div>

            <div className="panel" style={{ marginBottom: 20 }}>
              <div className="eyebrow">Step 2</div>
              <h2>After class · attendance</h2>
              <p className="muted">
                Current records: {event.attendance?.length ?? 0}. Sync from Meet when Workspace is
                configured, or confirm browser attendance from Campus.
              </p>
              <div style={{ display: "flex", gap: 10, flexWrap: "wrap", marginTop: 12 }}>
                <form action={syncOnlineAttendance}>
                  <input type="hidden" name="eventId" value={event.id} />
                  <button type="submit" className="btn btn-outline-dark">
                    Sync Meet attendance
                  </button>
                </form>
                <form action={endOnlineClass}>
                  <input type="hidden" name="eventId" value={event.id} />
                  <button type="submit" className="btn btn-outline-dark">
                    Mark session ended
                  </button>
                </form>
              </div>
              {event.attendance?.length ? (
                <div className="table-wrap" style={{ marginTop: 16 }}>
                  <table className="data">
                    <thead>
                      <tr>
                        <th>Learner</th>
                        <th>Minutes</th>
                      </tr>
                    </thead>
                    <tbody>
                      {event.attendance.slice(0, 40).map((a) => (
                        <tr key={a.id}>
                          <td>
                            {[a.user?.firstName, a.user?.lastName].filter(Boolean).join(" ") ||
                              a.user?.email}
                          </td>
                          <td>{a.minutesAttended ?? "—"}</td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              ) : null}
            </div>
          </div>
        </section>
      </main>
    </StaffPageShell>
  );
}
