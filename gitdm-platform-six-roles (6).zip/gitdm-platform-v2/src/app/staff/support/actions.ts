"use server";
import { revalidatePath } from "next/cache";
import { requireOperationalStaffUser } from "@/lib/control-centre";

export async function updateSupportTicket(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("support.manage");
  const id = String(fd.get("id") || "");
  const status = String(fd.get("status") || "") as any;
  const assigneeId = String(fd.get("assigneeId") || "") || null;
  if (!id || !["OPEN","IN_PROGRESS","WAITING","RESOLVED","CLOSED"].includes(status)) throw new Error("Choose a valid support status.");
  const ticket = await db.supportTicket.findUnique({ where: { id } });
  if (!ticket) throw new Error("Support ticket not found.");
  await db.supportTicket.update({ where: { id }, data: { status, assigneeId } });
  await db.notification.create({ data: { userId: ticket.requesterId, type: "SUPPORT", title: "Support case updated", body: `Your support case “${ticket.subject}” is now ${status.replaceAll("_", " ")}.` } });
  await db.auditLog.create({ data: { userId: user.id, action: "SUPPORT_TICKET_UPDATED", entity: "SupportTicket", entityId: id, metadataJson: JSON.stringify({ status, assigneeId }) } });
  revalidatePath("/staff/student-affairs/support");
  revalidatePath("/staff/it/support");
  revalidatePath("/staff/partner-support/support");
  revalidatePath("/campus/support");
}
