import Link from "next/link";
import { notFound } from "next/navigation";
import { GITDM } from "@/lib/branding";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { humanStatus } from "@/lib/status";
import {
  addExamQuestion,
  closeExam,
  finalizeExamAttempt,
  submitExamForApproval,
  reviewExam,
  confirmExamMark,
  uploadExamDocument,
} from "@/app/control-centre/exams/actions";

export const dynamic = "force-dynamic";
export const metadata = { title: `Examination | ${GITDM.shortName}` };

export default async function ExamDetailPage({ params }: { params: Promise<{ examId: string }> }) {
  const { examId } = await params;
  const { db } = await requireOperationalStaffUser("exams.manage");
  const exam = await db.exam.findUnique({
    where: { id: examId },
    include: {
      course: true,
      period: true,
      documents: true,
      questions: { orderBy: { orderIndex: "asc" } },
      attempts: {
        orderBy: { submittedAt: "desc" },
        include: { user: true, submissionFiles: true },
      },
    },
  });
  if (!exam) notFound();

  const isDraft = exam.status === "DRAFT" || exam.status === "REJECTED";

  return (
    <StaffPageShell activeHref="/staff/exam-officer/exams" title="Examination paper">
      <div className="container" style={{ maxWidth: 960, margin: "0 auto", padding: "20px 16px" }}>
        <div className="eyebrow">
          {exam.course.code} · {exam.period?.name || "Period"}
        </div>
        <h1>{exam.title}</h1>
        <p className="muted">
          {exam.deliveryMode} · {exam.submissionMode.replaceAll("_", " ")}
        </p>

        <div className="actions" style={{ margin: "16px 0 28px" }}>
          <span className="badge">{humanStatus(exam.status)}</span>
          {exam.status === "PUBLISHED" ? (
            <span className="badge success">Visible to fee-cleared enrolled students</span>
          ) : null}
          {isDraft ? (
            <form action={submitExamForApproval}>
              <input type="hidden" name="examId" value={exam.id} />
              <button className="btn btn-primary btn-sm" type="submit">
                Submit for approval &amp; publish path
              </button>
            </form>
          ) : null}
          {exam.status === "PENDING_APPROVAL" ? (
            <>
              <form action={reviewExam}>
                <input type="hidden" name="examId" value={exam.id} />
                <input type="hidden" name="decision" value="APPROVE" />
                <button className="btn btn-primary btn-sm" type="submit">
                  Approve &amp; publish to students
                </button>
              </form>
              <form action={reviewExam} className="actions">
                <input type="hidden" name="examId" value={exam.id} />
                <input type="hidden" name="decision" value="REJECT" />
                <input name="reason" placeholder="Revision feedback" required />
                <button className="btn btn-outline-dark btn-sm" type="submit">
                  Return for revision
                </button>
              </form>
            </>
          ) : null}
          {exam.status === "PUBLISHED" ? (
            <form action={closeExam}>
              <input type="hidden" name="examId" value={exam.id} />
              <button className="btn btn-outline-dark btn-sm" type="submit">
                Close examination
              </button>
            </form>
          ) : null}
          <Link className="btn btn-outline-dark btn-sm" href="/staff/exam-officer/exams">
            ← All exams
          </Link>
        </div>

        {/* Google Forms–style question builder */}
        {isDraft ? (
          <div className="card" style={{ marginBottom: 28 }}>
            <div className="eyebrow">Build paper · like a form</div>
            <h2>Add a question</h2>
            <p className="muted">
              Choose Multiple choice or Essay. For multiple choice, put one option per line and type the
              exact correct option text (or comma-separated for multi-select).
            </p>
            <form action={addExamQuestion} className="stack" style={{ marginTop: 16 }}>
              <input type="hidden" name="examId" value={exam.id} />
              <label>
                Question type
                <select name="type" defaultValue="SINGLE_CHOICE" required>
                  <option value="SINGLE_CHOICE">Multiple choice (one answer)</option>
                  <option value="MULTIPLE_CHOICE">Multiple choice (several answers)</option>
                  <option value="TRUE_FALSE">True / False</option>
                  <option value="SHORT_ANSWER">Short answer</option>
                  <option value="ESSAY">Essay</option>
                  <option value="NUMERICAL">Numerical</option>
                </select>
              </label>
              <label>
                Question text
                <textarea name="prompt" required rows={3} placeholder="Type the question…" />
              </label>
              <label>
                Options (one per line — leave empty for essay / short answer)
                <textarea
                  name="options"
                  rows={4}
                  placeholder={"Option A\nOption B\nOption C\nOption D"}
                />
              </label>
              <label>
                Correct answer
                <input
                  name="correct"
                  placeholder="Exact option text, or TRUE/FALSE, or key words for short answer"
                />
              </label>
              <label>
                Marks
                <input name="marks" type="number" min="0.5" step="0.5" defaultValue="1" required />
              </label>
              <button type="submit" className="btn btn-primary">
                Add question to paper
              </button>
            </form>
          </div>
        ) : null}

        <div className="card" style={{ marginBottom: 28 }}>
          <div className="eyebrow">Questions on this paper</div>
          <h2>{exam.questions.length} question(s)</h2>
          {!exam.questions.length ? (
            <p className="muted">No questions yet. Add them while the exam is in draft.</p>
          ) : (
            <div className="stack" style={{ marginTop: 12 }}>
              {exam.questions.map((q, i) => {
                let options: string[] = [];
                try {
                  options = q.optionsJson ? JSON.parse(q.optionsJson) : [];
                } catch {
                  options = [];
                }
                return (
                  <div className="panel" key={q.id}>
                    <strong>
                      Q{i + 1}. [{q.type.replaceAll("_", " ")}] · {Number(q.marks)} mark(s)
                    </strong>
                    <p style={{ marginTop: 8 }}>{q.prompt}</p>
                    {options.length ? (
                      <ul style={{ marginTop: 8 }}>
                        {options.map((o) => (
                          <li key={o}>{o}</li>
                        ))}
                      </ul>
                    ) : null}
                  </div>
                );
              })}
            </div>
          )}
        </div>

        {isDraft ? (
          <div className="card" style={{ marginBottom: 28 }}>
            <div className="eyebrow">Documents</div>
            <h2>Upload paper / answer template</h2>
            <form action={uploadExamDocument} encType="multipart/form-data" className="actions">
              <input type="hidden" name="examId" value={exam.id} />
              <input type="file" name="file" required />
              <input name="title" placeholder="Document title" required />
              <select name="type" defaultValue="QUESTION_PAPER">
                <option value="QUESTION_PAPER">Question paper</option>
                <option value="ANSWER_TEMPLATE">Answer template</option>
                <option value="INSTRUCTIONS">Instructions</option>
                <option value="REFERENCE">Reference</option>
              </select>
              <button type="submit" className="btn btn-outline-dark">
                Upload
              </button>
            </form>
          </div>
        ) : null}

        <div className="eyebrow">Attempts &amp; marking</div>
        <h2>{exam.attempts.length} attempt(s)</h2>
        <p className="muted">Open attached files, read essays, then record marks. Confirmed marks feed Registrar.</p>
        {exam.attempts.length ? (
          <div className="table-wrap sheet-table" style={{ marginTop: 12 }}>
            <table className="data">
              <thead>
                <tr>
                  <th>Student</th>
                  <th>#</th>
                  <th>Submitted</th>
                  <th>Auto</th>
                  <th>Final</th>
                  <th>Status</th>
                  <th>Files</th>
                  <th>Mark</th>
                </tr>
              </thead>
              <tbody>
                {exam.attempts.map((a) => (
                  <tr key={a.id}>
                    <td>
                      {[a.user.firstName, a.user.lastName].filter(Boolean).join(" ") || a.user.email}
                    </td>
                    <td>{a.attemptNo}</td>
                    <td>{a.submittedAt ? a.submittedAt.toLocaleString("en-UG") : "—"}</td>
                    <td>{a.autoScore == null ? "—" : `${Number(a.autoScore).toFixed(1)}%`}</td>
                    <td>{a.finalScore == null ? "—" : `${Number(a.finalScore).toFixed(1)}%`}</td>
                    <td>{humanStatus(a.status)}</td>
                    <td>
                      {a.submissionFiles.length
                        ? a.submissionFiles.map((f) => (
                            <a
                              key={f.id}
                              href={`/api/campus/files/exam-submission/${f.id}`}
                              target="_blank"
                              rel="noreferrer"
                            >
                              {f.originalName}
                            </a>
                          ))
                        : "—"}
                    </td>
                    <td>
                      {a.status === "MARKED_PENDING_CONFIRMATION" ? (
                        <form action={confirmExamMark}>
                          <input type="hidden" name="attemptId" value={a.id} />
                          <button className="btn btn-primary btn-sm" type="submit">
                            Confirm
                          </button>
                        </form>
                      ) : a.status !== "FINALIZED" ? (
                        <form action={finalizeExamAttempt} className="actions">
                          <input type="hidden" name="attemptId" value={a.id} />
                          <input
                            name="finalScore"
                            type="number"
                            min="0"
                            max="100"
                            step="0.1"
                            placeholder="%"
                            style={{ maxWidth: 80 }}
                            defaultValue={
                              a.finalScore != null
                                ? Number(a.finalScore)
                                : a.autoScore != null
                                  ? Number(a.autoScore)
                                  : ""
                            }
                          />
                          <button className="btn btn-primary btn-sm" type="submit">
                            Save mark
                          </button>
                        </form>
                      ) : (
                        <span className="badge">Confirmed</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        ) : (
          <div className="panel">
            <p>No student attempts yet. After publish, eligible students see this exam on Campus.</p>
          </div>
        )}
      </div>
    </StaffPageShell>
  );
}
