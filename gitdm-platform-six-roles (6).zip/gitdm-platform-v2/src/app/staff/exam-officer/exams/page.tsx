import Link from "next/link";



import { GITDM } from "@/lib/branding";
import { ACTIVE_COURSE_CODES } from "@/lib/current-catalogue";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { humanStatus } from "@/lib/status";
import { createExam } from "@/app/control-centre/exams/actions";

export const dynamic = "force-dynamic";
export const metadata = { title: `Examinations | ${GITDM.shortName}` };

export default async function ExamsPage() {
  const { db } = await requireOperationalStaffUser("academic.view");
  const [exams, courses, periods, attempts] = await Promise.all([
    db.exam.findMany({ where: { course: { code: { in: [...ACTIVE_COURSE_CODES] } } }, orderBy: { title: "asc" }, take: 200, include: { course: true, period: true, _count: { select: { questions: true, attempts: true } } } }),
    db.course.findMany({ where: { code: { in: [...ACTIVE_COURSE_CODES] } }, orderBy: [{ orderIndex: "asc" }, { title: "asc" }] }),
    db.academicPeriod.findMany({ orderBy: { startsAt: "desc" }, take: 20 }),
    db.examAttempt.count({ where: { status: { in: ["SUBMITTED", "AUTO_MARKED", "MANUAL_REVIEW", "MARKED_PENDING_CONFIRMATION"] } } }),
  ]);
  return <StaffPageShell activeHref="/staff/exam-officer/exams" title="Staff operations"><main>
    <section className="page-hero"><div className="container"><div className="eyebrow">Assessment · Examinations</div><h1>Examination office</h1><p>Create formal examinations, control publication, monitor attempts and process marking before results are released.</p></div></section>
    <section className="section"><div className="container">
      <div className="grid grid-4" style={{marginBottom:28}}>
        <div className="panel"><div className="eyebrow">Examinations</div><h2>{exams.length}</h2><p>All examinations</p></div>
        <div className="panel"><div className="eyebrow">Published</div><h2>{exams.filter(e=>e.status==="PUBLISHED").length}</h2><p>Currently available</p></div>
        <div className="panel"><div className="eyebrow">Drafts</div><h2>{exams.filter(e=>e.status==="DRAFT").length}</h2><p>Awaiting publication</p></div>
        <div className="panel"><div className="eyebrow">Attempts</div><h2>{attempts}</h2><p>Awaiting processing</p></div>
      </div>
      <div className="grid grid-2" style={{marginBottom:32}}>
        <div className="card"><div className="eyebrow">Create</div><h2>New examination</h2><form action={createExam} className="stack">
          <label>Course<select name="courseId" required><option value="">Select course</option>{courses.map(c=><option key={c.id} value={c.id}>{c.code} — {c.title}</option>)}</select></label>
          <label>Academic period<select name="periodId"><option value="">No period / general</option>{periods.map(p=><option key={p.id} value={p.id}>{p.name}</option>)}</select></label>
          <label>Title<input name="title" placeholder="Final Examination" required /></label>
          <div className="grid grid-2"><label>Attempts allowed<input name="attemptsAllowed" type="number" min="1" max="10" defaultValue="3" /></label><label>Time limit (minutes)<input name="timeLimitMinutes" type="number" min="0" placeholder="Optional" /></label></div>
          <div className="grid grid-2"><label>Opens<input name="opensAt" type="datetime-local" /></label><label>Closes<input name="closesAt" type="datetime-local" /></label></div>
          <div className="grid grid-2"><label>Delivery<select name="deliveryMode"><option value="ONLINE">Online</option><option value="ONSITE">On-site</option><option value="HYBRID">Hybrid</option></select></label><label>Submission<select name="submissionMode"><option value="ONLINE_FORM">Online form</option><option value="FILE_UPLOAD">File upload</option><option value="ONLINE_AND_FILE">Online + file</option></select></label></div>
          <div className="grid grid-2"><label>Venue<input name="venue" placeholder="Online examination room / venue" /></label><label>Room<input name="room" placeholder="Room 2" /></label></div>
          <label>Format description<input name="formatDescription" placeholder="MCQ + short answer + essay" /></label>
          <label>Instructions<textarea name="instructions" placeholder="What students must do before, during and after the examination." /></label>
          <div className="grid grid-2"><label>Results release<input name="resultsReleaseAt" type="datetime-local" /></label><label style={{display:"flex",alignItems:"center",gap:8}}><input name="permitRequired" type="checkbox" /> Require exam permit</label></div>
          <button className="btn btn-primary" type="submit">Create draft examination</button>
        </form></div>
        <div className="card"><div className="eyebrow">Rules</div><h2>Academic control</h2><p>Final examination carries 50% of the course grade. Students are configured for up to 3 attempts, and final examination access remains subject to the institutional fee-clearance gate.</p><p style={{marginBottom:0}}>Drafts can be edited; once published, the examination enters the student assessment workflow.</p></div>
      </div>
      <div className="eyebrow">Register</div><h2>Examinations</h2>
      <div className="table-wrap"><table className="data"><thead><tr><th>Examination</th><th>Course</th><th>Period</th><th>Questions</th><th>Attempts</th><th>Status</th><th></th></tr></thead><tbody>{exams.map(e=><tr key={e.id}><td><strong>{e.title}</strong></td><td>{e.course.code}</td><td>{e.period?.name||"—"}</td><td>{e._count.questions}</td><td>{e._count.attempts}</td><td>{humanStatus(e.status)}</td><td><Link className="btn btn-outline-dark btn-sm" href={`/staff/exam-officer/exams/${e.id}`}>Open</Link></td></tr>)}</tbody></table></div>
    </div></section></main></StaffPageShell>;
}
