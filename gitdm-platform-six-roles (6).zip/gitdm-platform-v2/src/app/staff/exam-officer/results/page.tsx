


import { GITDM } from "@/lib/branding";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { humanStatus } from "@/lib/status";
import { publishGrade, syncProvisionalGrades } from "@/app/control-centre/results/actions";

export const dynamic = "force-dynamic";
export const metadata = { title: `Results | ${GITDM.shortName}` };

export default async function ResultsPage() {
  const { db } = await requireOperationalStaffUser("results.moderate");
  const [grades, finalCount, provisionalCount] = await Promise.all([
    db.grade.findMany({ orderBy: { finalizedAt: "desc" }, take: 300, include: { user: true, course: true, period: true } }),
    db.grade.count({ where: { status: "FINAL" } }),
    db.grade.count({ where: { status: "PROVISIONAL" } }),
  ]);
  return <StaffPageShell activeHref="/staff/exam-officer/results" title="Results publication"><main><section className="page-hero"><div className="container"><div className="eyebrow">Academic records · Results</div><h1>Results and grade publication</h1><p>Build provisional course grades from the 30% assignment, 20% quiz and 50% examination model, then publish verified results.</p></div></section><section className="section"><div className="container">
    <div className="actions" style={{marginBottom:24}}><form action={syncProvisionalGrades}><button className="btn btn-primary btn-sm">Synchronize provisional grades</button></form><a href="/staff/exam-officer/exams" className="btn btn-outline-dark btn-sm">Examination office</a></div>
    <div className="grid grid-3" style={{marginBottom:28}}><div className="panel"><div className="eyebrow">Total records</div><h2>{grades.length}</h2><p>Grade records loaded</p></div><div className="panel"><div className="eyebrow">Provisional</div><h2>{provisionalCount}</h2><p>Awaiting publication</p></div><div className="panel"><div className="eyebrow">Final</div><h2>{finalCount}</h2><p>Published academic results</p></div></div>
    <div className="panel" style={{marginBottom:28}}><strong>Publication controls:</strong> attendance must be at least 70%. A finalized examination result is required for a completed course grade. Published results become visible in the student's Academic and Assessments areas.</div>
    <div className="table-wrap"><table className="data"><thead><tr><th>Student</th><th>Course</th><th>Period</th><th>Assignment 30%</th><th>Quiz 20%</th><th>Exam 50%</th><th>Total</th><th>Status</th><th></th></tr></thead><tbody>{grades.map(g=><tr key={g.id}><td>{[g.user.firstName,g.user.lastName].filter(Boolean).join(" ")||g.user.email}</td><td>{g.course.code}</td><td>{g.period?.name||"—"}</td><td>{Number(g.assignmentPercent).toFixed(1)}%</td><td>{Number(g.quizPercent).toFixed(1)}%</td><td>{Number(g.examPercent).toFixed(1)}%</td><td><strong>{Number(g.totalPercent).toFixed(1)}%</strong></td><td>{humanStatus(g.status)}</td><td>{g.status==="PROVISIONAL"?<form action={publishGrade}><input type="hidden" name="gradeId" value={g.id}/><button className="btn btn-primary btn-sm">Publish</button></form>:<span className="badge">Final</span>}</td></tr>)}</tbody></table></div>
  </div></section></main></StaffPageShell>;
}
