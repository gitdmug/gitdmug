import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/access";
import { routeForRoles } from "@/lib/staff-workspaces";
import { normalizeRoleCode } from "@/lib/permissions";

export const dynamic = "force-dynamic";

const STAFF_ROLES = ["PRINCIPAL", "ADMISSIONS", "FINANCE", "ACADEMIC_DIRECTOR", "EXAM_OFFICER", "REGISTRAR"] as const;

export default async function StaffRouterPage() {
  const user = await getCurrentUser();
  if (!user) redirect("/auth/login?returnTo=/staff");

  const roleCodes = user.roles.map((r) => r.role.code);
  const normalized = roleCodes.map(normalizeRoleCode).filter(Boolean) as string[];

  const destination = routeForRoles(roleCodes);
  if (destination) redirect(destination);

  if (!normalized.some((role) => (STAFF_ROLES as readonly string[]).includes(role))) {
    redirect("/campus");
  }
  redirect("/campus/error?code=staff-workspace");
}
