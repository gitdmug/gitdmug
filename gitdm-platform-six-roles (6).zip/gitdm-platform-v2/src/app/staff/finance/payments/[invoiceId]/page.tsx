import Link from "next/link";
import { notFound } from "next/navigation";
import { GITDM } from "@/lib/branding";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { money } from "@/lib/status";
import { recordOfflinePayment } from "@/app/control-centre/finance/actions";

export const dynamic = "force-dynamic";
export const metadata = { title: `Record payment | ${GITDM.shortName}` };

export default async function RecordPaymentPage({
  params,
}: {
  params: Promise<{ invoiceId: string }>;
}) {
  const { invoiceId } = await params;
  const { db } = await requireOperationalStaffUser("finance.view");
  const invoice = await db.invoice.findUnique({
    where: { id: invoiceId },
    include: { enrollment: { include: { user: true } } },
  });
  if (!invoice) notFound();

  const outstanding = Number(invoice.amount) - Number(invoice.amountPaid);
  const name =
    [invoice.enrollment?.user?.firstName, invoice.enrollment?.user?.lastName]
      .filter(Boolean)
      .join(" ") ||
    invoice.enrollment?.user?.email ||
    "—";

  return (
    <StaffPageShell activeHref="/staff/finance/payments" title="Record payment">
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">Finance · Single invoice</div>
            <h1>Record payment received</h1>
            <p>
              Record only funds Finance has actually received. This immediately updates the
              invoice balance and issues a receipt.
            </p>
            <Link className="btn btn-outline-dark btn-sm" href="/staff/finance/payments">
              ← Back to payment list
            </Link>
          </div>
        </section>
        <section className="section">
          <div className="container" style={{ maxWidth: 520 }}>
            <div className="panel">
              <div className="eyebrow">{invoice.invoiceNo}</div>
              <h2 style={{ marginTop: 4 }}>{name}</h2>
              <p className="muted">Outstanding: {money(outstanding, invoice.currency)}</p>
              <form action={recordOfflinePayment} style={{ display: "grid", gap: 12, marginTop: 16 }}>
                <input type="hidden" name="invoiceId" value={invoice.id} />
                <label>
                  Amount received
                  <input
                    name="amount"
                    type="number"
                    min="0.01"
                    max={outstanding}
                    step="0.01"
                    defaultValue={outstanding}
                    required
                  />
                </label>
                <label>
                  Method
                  <select name="method" defaultValue="CASH" required>
                    <option value="CASH">Cash</option>
                    <option value="BANK_TRANSFER">Bank transfer</option>
                  </select>
                </label>
                <label>
                  Receipt / bank reference
                  <input name="reference" type="text" placeholder="Bank slip / receipt reference" />
                </label>
                <label>
                  Payment evidence
                  <input name="evidence" type="file" accept="image/*,.pdf" />
                </label>
                <button type="submit" className="btn btn-primary">
                  Record and issue receipt
                </button>
              </form>
            </div>
          </div>
        </section>
      </main>
    </StaffPageShell>
  );
}
