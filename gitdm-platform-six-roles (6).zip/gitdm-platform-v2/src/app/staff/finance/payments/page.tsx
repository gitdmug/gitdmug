import Link from "next/link";
import { GITDM } from "@/lib/branding";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { money, humanStatus } from "@/lib/status";

export const dynamic = "force-dynamic";
export const metadata = { title: `Finance Payments | ${GITDM.shortName}` };

/**
 * Congestion fix: list view only. Recording a payment opens a focused page
 * for that single invoice — no multi-form grid.
 */
export default async function FinancePaymentsPage() {
  const { db } = await requireOperationalStaffUser("finance.view");
  const [payments, invoices] = await Promise.all([
    db.payment.findMany({
      orderBy: { createdAt: "desc" },
      take: 250,
      include: { user: true, invoice: true, receipt: true },
    }),
    db.invoice.findMany({
      where: { status: { in: ["ISSUED", "PARTIALLY_PAID", "OVERDUE"] } },
      orderBy: { dueAt: "asc" },
      take: 200,
      include: { enrollment: { include: { user: true } } },
    }),
  ]);

  const outstanding = invoices.filter((i) => Number(i.amount) > Number(i.amountPaid));

  return (
    <StaffPageShell activeHref="/staff/finance/payments" title="Finance operations">
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">Finance · Payments</div>
            <h1>Payment control</h1>
            <p>Review provider transactions, verify manual records and trace receipts.</p>
          </div>
        </section>
        <section className="section">
          <div className="container">
            <div className="grid grid-3" style={{ marginBottom: 28 }}>
              <div className="panel">
                <div className="eyebrow">Pending</div>
                <h2>{payments.filter((p) => p.status === "PENDING").length}</h2>
              </div>
              <div className="panel">
                <div className="eyebrow">Completed</div>
                <h2>{payments.filter((p) => p.status === "COMPLETED").length}</h2>
              </div>
              <div className="panel">
                <div className="eyebrow">Completed value</div>
                <h2>
                  {money(
                    payments
                      .filter((p) => p.status === "COMPLETED")
                      .reduce((s, p) => s + Number(p.amount), 0),
                    "UGX"
                  )}
                </h2>
              </div>
            </div>

            <div className="panel" style={{ marginBottom: 28 }}>
              <div className="eyebrow">Cash and bank payments</div>
              <h2>Outstanding invoices</h2>
              <p>
                Select one invoice to open a focused recording page. This keeps the workspace
                uncluttered and records only funds Finance has actually received.
              </p>
              <div className="table-wrap" style={{ marginTop: 16 }}>
                <table className="data">
                  <thead>
                    <tr>
                      <th>Invoice</th>
                      <th>Learner</th>
                      <th>Outstanding</th>
                      <th>Status</th>
                      <th></th>
                    </tr>
                  </thead>
                  <tbody>
                    {outstanding.slice(0, 50).map((i) => {
                      const name =
                        [i.enrollment?.user?.firstName, i.enrollment?.user?.lastName]
                          .filter(Boolean)
                          .join(" ") ||
                        i.enrollment?.user?.email ||
                        "—";
                      const due = Number(i.amount) - Number(i.amountPaid);
                      return (
                        <tr key={i.id}>
                          <td>
                            <strong>{i.invoiceNo}</strong>
                          </td>
                          <td>{name}</td>
                          <td>{money(due, i.currency)}</td>
                          <td>{humanStatus(i.status)}</td>
                          <td>
                            <Link
                              className="btn btn-primary btn-sm"
                              href={`/staff/finance/payments/${i.id}`}
                            >
                              Record payment
                            </Link>
                          </td>
                        </tr>
                      );
                    })}
                    {!outstanding.length ? (
                      <tr>
                        <td colSpan={5} className="muted">
                          No outstanding invoices.
                        </td>
                      </tr>
                    ) : null}
                  </tbody>
                </table>
              </div>
            </div>

            <div className="panel">
              <div className="eyebrow">Recent payments</div>
              <h2>Transaction log</h2>
              <div className="table-wrap" style={{ marginTop: 12 }}>
                <table className="data">
                  <thead>
                    <tr>
                      <th>When</th>
                      <th>Amount</th>
                      <th>Method</th>
                      <th>Status</th>
                      <th>User</th>
                    </tr>
                  </thead>
                  <tbody>
                    {payments.slice(0, 40).map((p) => (
                      <tr key={p.id}>
                        <td>{new Date(p.createdAt).toLocaleString()}</td>
                        <td>{money(Number(p.amount), p.currency || "UGX")}</td>
                        <td>{p.providerMethod || p.provider || "—"}</td>
                        <td>{humanStatus(p.status)}</td>
                        <td>{p.user?.email || "—"}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          </div>
        </section>
      </main>
    </StaffPageShell>
  );
}
