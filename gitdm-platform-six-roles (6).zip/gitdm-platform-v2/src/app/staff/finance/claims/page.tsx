


import { GITDM } from "@/lib/branding";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { redirect } from "next/navigation";
import { submitClaim, departmentReviewClaim, financeUpdateClaim } from "@/app/control-centre/finance/claims/actions";
export const dynamic = "force-dynamic";
export const metadata = { title: `Expense Claims | ${GITDM.shortName}` };
export default async function ClaimsPage() {
  const { db, user, roleCodes } = await requireOperationalStaffUser();
  const isFinance = roleCodes.includes("FINANCE");
  const canSubmit = user.roles.some((r) => r.role.permissions.some((p) => p.permission.key === "finance.claims.submit"));
  const canReview = user.roles.some((r) => r.role.permissions.some((p) => p.permission.key === "finance.claims.review"));
  if (!isFinance && !canSubmit && !canReview) redirect("/control-centre?error=not-authorized");
  const assignments = await db.userDepartment.findMany({ where: { userId: user.id }, include: { department: true } });
  const isHeadIds = new Set(assignments.filter((a) => a.isHead).map((a) => a.departmentId));
  const where = isFinance ? {} : { OR: [{ requesterId: user.id }, { departmentId: { in: Array.from(isHeadIds) } }] };
  const claims = await db.staffExpenseClaim.findMany({ where, orderBy: { createdAt: "desc" }, take: 300, include: { requester: true, department: true } });
  return <StaffPageShell activeHref="/staff/finance/claims" title="Finance operations"><main><section className="page-hero"><div className="container"><div className="eyebrow">Finance · Claims</div><h1>{isFinance ? "Staff claims & expenditure" : "My expense claims"}</h1><p>{isFinance ? "Control departmental validation, Finance review, approval, payout and audit." : "Submit a claim and follow it through departmental validation, Finance review and disbursement."}</p></div></section><section className="section"><div className="container">
    {!isFinance ? <div className="card" style={{marginBottom:28}}><h2>Submit a claim</h2><form action={submitClaim} className="grid grid-2"><label>Department<select name="departmentId" required><option value="">Select assigned department</option>{assignments.map(a=><option key={a.departmentId} value={a.departmentId}>{a.department.name}</option>)}</select></label><label>Category<select name="category"><option>Travel</option><option>Research</option><option>Departmental supplies</option><option>Communication</option><option>Other</option></select></label><label>Amount<input name="amount" type="number" min="0.01" step="0.01" required/></label><label>Currency<select name="currency"><option>UGX</option><option>USD</option></select></label><label style={{gridColumn:"1/-1"}}>Business purpose & description<textarea name="description" required/></label><label style={{gridColumn:"1/-1"}}>Receipt evidence URLs<input name="receiptUrlsJson" placeholder="Optional secure document URLs, comma separated"/></label><button className="btn btn-primary">Submit for departmental review</button></form></div> : null}
    <div className="grid grid-3" style={{marginBottom:28}}><div className="panel"><div className="eyebrow">Visible claims</div><h2>{claims.length}</h2></div><div className="panel"><div className="eyebrow">Awaiting department</div><h2>{claims.filter(c=>c.status==="SUBMITTED").length}</h2></div><div className="panel"><div className="eyebrow">Awaiting Finance</div><h2>{claims.filter(c=>c.status==="FINANCE_REVIEW").length}</h2></div></div>
    <div className="stack">{claims.map(c=><article className="card" key={c.id}><div style={{display:"flex",justifyContent:"space-between",gap:12}}><div><span className="chip">{c.status}</span><h3>{c.category}</h3><p>{c.department.name} · {c.requester.firstName || c.requester.email} · {c.currency} {Number(c.amount).toLocaleString()}</p></div><strong>{c.createdAt.toLocaleDateString("en-UG")}</strong></div><p>{c.description}</p>{c.departmentNote?<p><strong>Department:</strong> {c.departmentNote}</p>:null}{c.financeNote?<p><strong>Finance:</strong> {c.financeNote}</p>:null}{c.paymentReference?<p><strong>Disbursement:</strong> {c.paymentReference}</p>:null}
      {isHeadIds.has(c.departmentId) && c.status === "SUBMITTED" ? <form action={departmentReviewClaim} className="actions"><input type="hidden" name="id" value={c.id}/><input name="note" placeholder="Department review note"/><button className="btn btn-primary btn-sm" name="decision" value="APPROVE">Forward to Finance</button><button className="btn btn-outline-dark btn-sm" name="decision" value="REJECT">Reject</button></form> : null}
      {isFinance && ["FINANCE_REVIEW","APPROVED"].includes(c.status) ? <form action={financeUpdateClaim} className="grid grid-2" style={{marginTop:16}}><input type="hidden" name="id" value={c.id}/><label>Finance note<input name="note"/></label><label>Payment reference<input name="paymentReference" placeholder="Required for disbursement"/></label><div className="actions"><button className="btn btn-primary btn-sm" name="status" value="APPROVED">Approve</button><button className="btn btn-outline-dark btn-sm" name="status" value="REJECTED">Reject</button><button className="btn btn-primary btn-sm" name="status" value="DISBURSED">Mark disbursed</button></div></form>:null}
    </article>)}</div>{claims.length===0?<div className="panel">No claims are currently visible in this workspace.</div>:null}
  </div></section></main></StaffPageShell>;
}
