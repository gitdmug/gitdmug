import { GITDM } from "@/lib/branding";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import Link from "next/link";

export const dynamic = "force-dynamic";
export const metadata = { title: `Academic workflow | ${GITDM.shortName}` };

/**
 * Department-centric academic operating floor.
 * Access is gated by operational staff capability; existing role records are left intact.
 * Flow: receive from admissions → orient → timetable → materials → classes → assess → exams → results → graduate/retake.
 */
export default async function AcademicWorkflowPage() {
  await requireOperationalStaffUser("academic.view");

  const steps = [
    {
      step: 1,
      title: "Receive handover from Admissions",
      desc: "Admitted students appear in the academic intake list after decision + fee clearance. Confirm programme, period and any special conditions.",
      href: "/staff/academic-director",
      action: "Open intake list",
    },
    {
      step: 2,
      title: "Orientation",
      desc: "Mark orientation complete on the student record. Student campus shows orientation status and next actions.",
      href: "/staff/registrar/students",
      action: "Student records",
    },
    {
      step: 3,
      title: "Set teaching calendar",
      desc: "Choose the course start date. The system uses the known teaching days (e.g. FX3M Mon/Wed 09:00–11:00 EAT; TA101 Tue/Thu/Fri) to generate the full class calendar, mid-course assessment window and exam date. Exam materials should be uploaded at least 14 days before the exam.",
      href: "/control-centre/timetable",
      action: "Timetable & generation",
    },
    {
      step: 4,
      title: "Publish live class links & materials",
      desc: "For each class event set delivery mode (online/hybrid/onsite), paste the Google Meet (or other) join URL, and upload learning resources (PDF, slides, notes). Students see the calendar and materials on campus.",
      href: "/staff/lecturer/classes",
      action: "Classes & links",
    },
    {
      step: 5,
      title: "Track attendance",
      desc: "Students join via the campus attendance controls. Optional Google Meet reconciliation is available when Workspace is configured. Attendance feeds progression and exam permit rules.",
      href: "/staff/lecturer/classes",
      action: "Attendance",
    },
    {
      step: 6,
      title: "Coursework & assessments",
      desc: "Create and publish assignments/quizzes against modules. Mark submissions. Results appear on the student assessments and results pages.",
      href: "/staff/lecturer/assessments",
      action: "Assessments",
    },
    {
      step: 7,
      title: "Examinations",
      desc: "Create the exam (objective / essay / mixed). Upload question paper and answer template at least 2 weeks before opensAt. Publish so students can sit within the timed window. One attempt, pass mark and results-release rules are enforced.",
      href: "/staff/exam-officer/exams",
      action: "Exam board",
    },
    {
      step: 8,
      title: "Results, retake / resit, graduation",
      desc: "Publish results. Failed or missed exams with valid reason move to retake/resit workflow. Successful completion feeds transcript and certificate readiness via Registrar.",
      href: "/staff/exam-officer/results",
      action: "Results",
    },
  ];

  return (
    <StaffPageShell activeHref="/staff/academic-director/workflow" title="Academic department workflow">
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">Academic Affairs · Department floor</div>
            <h1>End-to-end academic operating flow</h1>
            <p>
              One sequential path from admissions handover through teaching, assessment and completion.
              Department members share the same environment; existing role history is preserved for audit.
            </p>
          </div>
        </section>
        <section className="section">
          <div className="container">
            <div className="stack">
              {steps.map((s) => (
                <article key={s.step} className="card">
                  <div style={{ display: "flex", gap: 16, alignItems: "flex-start", flexWrap: "wrap" }}>
                    <div
                      style={{
                        width: 40,
                        height: 40,
                        borderRadius: "50%",
                        background: "var(--navy)",
                        color: "#fff",
                        display: "flex",
                        alignItems: "center",
                        justifyContent: "center",
                        fontWeight: 700,
                        flexShrink: 0,
                      }}
                    >
                      {s.step}
                    </div>
                    <div style={{ flex: 1, minWidth: 220 }}>
                      <h3 style={{ marginTop: 0 }}>{s.title}</h3>
                      <p className="muted">{s.desc}</p>
                      <Link className="btn btn-primary btn-sm" href={s.href}>
                        {s.action}
                      </Link>
                    </div>
                  </div>
                </article>
              ))}
            </div>
            <p className="muted" style={{ marginTop: 24 }}>
              Inter-department handoffs: Admissions decision + finance clearance unlock orientation; Academic
              publishes timetable and exams; Registrar owns transcripts and certificates; Student Success
              handles interventions; Technology supports Meet and platform operations.
            </p>
          </div>
        </section>
      </main>
    </StaffPageShell>
  );
}
