import Link from "next/link";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { requireOperationalStaffUser } from "@/lib/control-centre";

export const dynamic = "force-dynamic";

const rows = [
  ["Enrolment handoff", "Finance-cleared admitted students become academic enrolments and are assigned to the correct period/cohort.", "/staff/registrar/students"],
  ["Curriculum", "Programmes, courses and module sequences are approved before delivery.", "/control-centre/programmes"],
  ["Delivery", "Academic sets module dates and study patterns; lecturers prepare content for review.", "/staff/academic-director/delivery"],
  ["Timetable", "Academic schedules the official class. Lecturer adds the live link and teaches.", "/control-centre/timetable"],
  ["Assessment", "Coursework and quizzes measure learning during delivery; marks and feedback return to students.", "/staff/lecturer/assessments"],
  ["Examination", "Exam Office prepares and marks formal exams; Academic leadership approves publication.", "/staff/exam-officer/exams"],
  ["Results", "Provisional grades are synchronized, checked and published as final academic records.", "/staff/exam-officer/results"],
  ["Progression", "Registry and Academic review passed courses, repeats/resits and completion requirements.", "/staff/registrar/records"],
];

export default async function AcademicDirectorPage() {
  const { db } = await requireOperationalStaffUser("academic.view");
  const now = new Date();
  const [pending, classes, provisional, finals, exams, activeStudents] = await Promise.all([
    db.courseModule.count({ where: { approvalStatus: "PENDING_APPROVAL" } }),
    db.timetableEvent.count({ where: { startAt: { gte: now } } }),
    db.grade.count({ where: { status: "PROVISIONAL" } }),
    db.grade.count({ where: { status: "FINAL" } }),
    db.exam.count({ where: { status: { in: ["PENDING_APPROVAL", "PUBLISHED"] } } }),
    db.enrollment.count({ where: { status: { in: ["ACTIVE", "REPEATING"] } } }),
  ]);
  return <StaffPageShell activeHref="/staff/academic-director" title="Academic Director's Office" description="The quality and control point for curriculum, delivery, assessment, examinations, results and student progression.">
    <div className="grid grid-3">
      {[['Active learners',activeStudents,'Current academic enrolments'],['Delivery approvals',pending,'Modules awaiting review'],['Upcoming classes',classes,'Official timetable events'],['Exams',exams,'Pending approval or published'],['Provisional grades',provisional,'Awaiting final publication'],['Final results',finals,'Published academic records']].map(([t,v,d])=><div className="panel" key={String(t)}><div className="eyebrow">{t}</div><h2>{v}</h2><p>{d}</p></div>)}
    </div>
    <div className="card" style={{marginTop:28}}><div className="eyebrow">Academic operating floor</div><h2>One controlled student journey</h2><div className="table-wrap" style={{marginTop:18}}><table className="data"><thead><tr><th>Stage</th><th>How the department operates</th><th>Workspace</th></tr></thead><tbody>{rows.map(([t,d,h])=><tr key={t}><td><strong>{t}</strong></td><td>{d}</td><td><Link href={h} className="btn btn-outline-dark btn-sm">Open</Link></td></tr>)}</tbody></table></div></div>
    <div className="grid grid-3" style={{marginTop:28}}><Link href="/control-centre/academic" className="card" style={{textDecoration:"none"}}><h3>Academic operating floor</h3><p>See the complete institutional flow and department controls.</p></Link><Link href="/control-centre/timetable" className="card" style={{textDecoration:"none"}}><h3>Official timetable</h3><p>Only Academic Affairs schedules student-facing classes.</p></Link><Link href="/staff/exam-officer/results" className="card" style={{textDecoration:"none"}}><h3>Results publication</h3><p>Moderate and publish verified grades to the learner portal.</p></Link></div>
  </StaffPageShell>;
}
