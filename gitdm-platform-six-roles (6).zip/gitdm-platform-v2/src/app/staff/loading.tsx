export default function Loading() {
  return (
    <div className="staff-app" aria-busy="true" aria-label="Loading staff workspace">
      <div className="staff-shell">
        <aside className="staff-sidebar">
          <div className="staff-sidebar-head"><div className="staff-role-mark">G</div><div><strong>GITDM</strong><span>Staff workspace</span></div></div>
          <div className="loading-stack">{Array.from({ length: 9 }).map((_, i) => <div className="loading-bar" key={i} />)}</div>
        </aside>
        <main className="staff-main">
          <div className="loading-hero"><div className="loading-bar wide" /><div className="loading-bar medium" /></div>
          <section className="staff-metrics">{Array.from({ length: 4 }).map((_, i) => <div className="staff-metric loading-card" key={i} />)}</section>
          <section className="staff-work-grid">{Array.from({ length: 6 }).map((_, i) => <div className="staff-work-card loading-card" key={i} />)}</section>
        </main>
      </div>
    </div>
  );
}
