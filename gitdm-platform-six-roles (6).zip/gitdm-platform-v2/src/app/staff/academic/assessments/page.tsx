import Link from "next/link";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { requireOperationalStaffUser } from "@/lib/control-centre";

export const dynamic = "force-dynamic";

export default async function AcademicAssessmentsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; page?: string }>;
}) {
  const { db } = await requireOperationalStaffUser("assignments.manage");
  const sp = await searchParams;
  const q = (sp.q || "").trim();
  const page = Math.max(1, parseInt(sp.page || "1", 10) || 1);
  const pageSize = 20;

  const where = q ? { title: { contains: q, mode: "insensitive" as const } } : {};

  const [total, assignments] = await Promise.all([
    db.assignment.count({ where }),
    db.assignment.findMany({
      where,
      orderBy: { dueAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: { course: true, submissions: { select: { id: true, status: true } } },
    }),
  ]);
  const pages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <StaffPageShell
      activeHref="/staff/academic/assessments"
      title="Coursework & quizzes"
      description="Issue and mark programme assessments (approximately every third of the delivery). Formal examinations are set and published by Exam Office."
    >
      <div className="actions" style={{ marginBottom: 20 }}>
        <Link className="btn btn-primary btn-sm" href="/staff/lecturer/assessments">Set / manage assessments</Link>
        <form method="get" style={{ display: "inline-flex", gap: 8 }}>
          <input name="q" defaultValue={q} placeholder="Search title" />
          <button className="btn btn-outline-dark btn-sm" type="submit">Search</button>
        </form>
      </div>
      <div className="table-wrap">
        <table className="data">
          <thead>
            <tr><th>Title</th><th>Course</th><th>Status</th><th>Submissions</th><th></th></tr>
          </thead>
          <tbody>
            {assignments.map((a) => (
              <tr key={a.id}>
                <td><strong>{a.title}</strong></td>
                <td>{a.course?.code || "—"}</td>
                <td>{a.status}</td>
                <td>{a.submissions.length}</td>
                <td>
                  <Link className="btn btn-outline-dark btn-sm" href="/staff/lecturer/assessments">Mark / open</Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="actions" style={{ marginTop: 16 }}>
        {page > 1 ? <Link className="btn btn-outline-dark btn-sm" href={`/staff/academic/assessments?q=${encodeURIComponent(q)}&page=${page - 1}`}>Previous</Link> : null}
        <span className="muted">Page {page} of {pages} · {total} items</span>
        {page < pages ? <Link className="btn btn-outline-dark btn-sm" href={`/staff/academic/assessments?q=${encodeURIComponent(q)}&page=${page + 1}`}>Next</Link> : null}
      </div>
    </StaffPageShell>
  );
}
