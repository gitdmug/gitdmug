import Link from "next/link";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { requireOperationalStaffUser } from "@/lib/control-centre";

export const dynamic = "force-dynamic";

/**
 * Academic workspace — teaching, classes, coursework.
 * Formal exams belong to Exam Office. Permanent records belong to Registrar.
 */
export default async function AcademicDashboardPage() {
  const { db } = await requireOperationalStaffUser("academic.view");
  const now = new Date();
  const in24h = new Date(now.getTime() + 24 * 60 * 60 * 1000);

  const [activeStudents, upcomingClasses, next24h, openAssessments] = await Promise.all([
    db.enrollment.count({ where: { status: { in: ["ACTIVE", "REPEATING"] }, accessLevel: "FULL" } }),
    db.timetableEvent.count({ where: { startAt: { gte: now }, type: "CLASS" } }),
    db.timetableEvent.count({ where: { startAt: { gte: now, lte: in24h }, type: "CLASS" } }),
    db.assignment.count({ where: { status: "PUBLISHED" } }).catch(() => 0),
  ]);

  return (
    <StaffPageShell
      activeHref="/staff/academic"
      title="Academic"
      description="Teach, run classes, issue and mark coursework. Formal examinations are owned by Exam Office. Permanent records are owned by Registrar."
    >
      <div className="grid grid-4" style={{ marginBottom: 28 }}>
        <div className="panel"><div className="eyebrow">Active students (FULL access)</div><h2>{activeStudents}</h2></div>
        <div className="panel"><div className="eyebrow">Classes in next 24 hours</div><h2>{next24h}</h2></div>
        <div className="panel"><div className="eyebrow">Upcoming classes</div><h2>{upcomingClasses}</h2></div>
        <div className="panel"><div className="eyebrow">Open coursework</div><h2>{openAssessments}</h2></div>
      </div>

      <div className="grid grid-2">
        <article className="card">
          <h2>Classes</h2>
          <p>Only sessions within the next 24 hours appear for teaching. Add the join link and materials, take attendance.</p>
          <Link className="btn btn-primary btn-sm" href="/staff/academic/classes">Open classes</Link>
        </article>
        <article className="card">
          <h2>Courses & modules</h2>
          <p>Programme modules and delivery plans. Students track progress on My Programme.</p>
          <Link className="btn btn-outline-dark btn-sm" href="/staff/academic/courses">Open courses</Link>
        </article>
        <article className="card">
          <h2>Coursework & quizzes</h2>
          <p>Assessments at roughly every third of the programme. Set, publish, mark.</p>
          <Link className="btn btn-outline-dark btn-sm" href="/staff/academic/assessments">Open assessments</Link>
        </article>
        <article className="card">
          <h2>Timetable generation</h2>
          <p>Generate the full class calendar from programme duration, module days and public holidays. Lecturers only add the live link.</p>
          <Link className="btn btn-outline-dark btn-sm" href="/staff/academic/delivery">Generate timetable</Link>
        </article>
      </div>
    </StaffPageShell>
  );
}
