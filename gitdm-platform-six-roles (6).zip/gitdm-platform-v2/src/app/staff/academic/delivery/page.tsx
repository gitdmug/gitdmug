import Link from "next/link";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { generateAutomaticShortCourseTimetable } from "@/app/control-centre/timetable/actions";

export const dynamic = "force-dynamic";

export default async function AcademicDeliveryPage({
  searchParams,
}: {
  searchParams: Promise<{ ok?: string; created?: string; course?: string; error?: string }>;
}) {
  await requireOperationalStaffUser("academic.manage");
  const sp = await searchParams;

  return (
    <StaffPageShell
      activeHref="/staff/academic/delivery"
      title="Delivery & timetable generation"
      description="Choose the start date, teaching days pattern is fixed per course, and session time. The system builds every class, skips public holidays, and updates the student timetable. Lecturers edit the next class name and materials only when it enters the 24-hour window."
    >
      {sp.ok ? (
        <div className="panel" style={{ marginBottom: 20, borderColor: "var(--success, #16a34a)" }}>
          <strong>Timetable generated.</strong> {sp.created} class sessions created for {sp.course}.{" "}
          <Link href="/staff/academic/classes">View classes</Link>
          {" · "}
          <Link href="/campus/timetable">Student timetable view</Link>
        </div>
      ) : null}
      {sp.error ? (
        <div className="panel" style={{ marginBottom: 20, borderColor: "var(--danger, #dc2626)" }}>
          <strong>Could not generate:</strong> {sp.error.replace(/-/g, " ")}. Check course configuration and try again.
        </div>
      ) : null}

      <div className="card">
        <div className="eyebrow">Automatic generation</div>
        <h2>Create intake timetable</h2>
        <p>
          Select the active short course, the first teaching day, and morning or evening session.
          Classes are placed on the fixed teaching days for that course. Public holidays are skipped.
          The long Financial Markets pathway has no fixed timetable.
        </p>
        <div className="grid grid-3" style={{ marginTop: 16 }}>
          <div className="panel">
            <strong>Technical Analysis (TA101)</strong>
            <p>Tue, Thu, Fri · 1 month</p>
          </div>
          <div className="panel">
            <strong>Beginner Forex (FX3M)</strong>
            <p>Mon, Wed · 3 months</p>
          </div>
          <div className="panel">
            <strong>Financial Markets (long)</strong>
            <p>Self-paced · no auto timetable</p>
          </div>
        </div>
        <form
          action={generateAutomaticShortCourseTimetable}
          className="grid grid-3"
          style={{ marginTop: 18, alignItems: "end" }}
        >
          <label>
            Course
            <select name="courseCode" required>
              <option value="TA101">Certificate in Technical Analysis (TA101)</option>
              <option value="FX3M">Certificate in Beginner Forex Trading (FX3M)</option>
            </select>
          </label>
          <label>
            Start date
            <input name="startDate" type="date" required />
          </label>
          <label>
            Session
            <select name="session" defaultValue="MORNING">
              <option value="MORNING">Morning · 09:00–11:00</option>
              <option value="EVENING">Evening · 17:00–19:00</option>
            </select>
          </label>
          <div>
            <button className="btn btn-primary" type="submit">
              Generate timetable
            </button>
          </div>
        </form>
      </div>

      <div className="actions" style={{ marginTop: 24 }}>
        <Link className="btn btn-outline-dark btn-sm" href="/staff/academic/classes">
          Classes (24h window)
        </Link>
        <Link className="btn btn-outline-dark btn-sm" href="/control-centre/timetable">
          Full timetable oversight
        </Link>
        <Link className="btn btn-outline-dark btn-sm" href="/staff/academic">
          Academic dashboard
        </Link>
      </div>
    </StaffPageShell>
  );
}
