import Link from "next/link";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { requireOperationalStaffUser } from "@/lib/control-centre";

export const dynamic = "force-dynamic";

export default async function AcademicStudentsPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; page?: string }>;
}) {
  const { db } = await requireOperationalStaffUser("students.view");
  const sp = await searchParams;
  const q = (sp.q || "").trim();
  const page = Math.max(1, parseInt(sp.page || "1", 10) || 1);
  const pageSize = 25;

  const where: any = {
    status: { in: ["ACTIVE", "REPEATING"] },
    accessLevel: "FULL",
  };
  if (q) {
    where.user = {
      OR: [
        { email: { contains: q, mode: "insensitive" } },
        { firstName: { contains: q, mode: "insensitive" } },
        { lastName: { contains: q, mode: "insensitive" } },
      ],
    };
  }

  const [total, enrollments] = await Promise.all([
    db.enrollment.count({ where }),
    db.enrollment.findMany({
      where,
      orderBy: { createdAt: "desc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: { user: true, programme: true, period: true },
    }),
  ]);
  const pages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <StaffPageShell
      activeHref="/staff/academic/students"
      title="Active students"
      description="Students with FULL access (fee-cleared) who are in teaching. Search, then open the individual record."
    >
      <form method="get" className="actions" style={{ marginBottom: 20 }}>
        <input name="q" defaultValue={q} placeholder="Search name or email" style={{ minWidth: 240 }} />
        <button className="btn btn-outline-dark btn-sm" type="submit">Search</button>
      </form>

      <div className="table-wrap">
        <table className="data">
          <thead>
            <tr>
              <th>Student</th>
              <th>Programme</th>
              <th>Intake</th>
              <th>Status</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {enrollments.map((e) => (
              <tr key={e.id}>
                <td>
                  <strong>{[e.user.firstName, e.user.lastName].filter(Boolean).join(" ") || e.user.email}</strong>
                  <div className="tile-meta">{e.user.email}</div>
                </td>
                <td>{e.programme.shortName || e.programme.name}</td>
                <td>{e.period?.name || "—"}</td>
                <td>{e.status}</td>
                <td>
                  <Link className="btn btn-outline-dark btn-sm" href={`/staff/registrar/students/${e.userId}`}>
                    Open record
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="actions" style={{ marginTop: 16 }}>
        {page > 1 ? <Link className="btn btn-outline-dark btn-sm" href={`/staff/academic/students?q=${encodeURIComponent(q)}&page=${page - 1}`}>Previous</Link> : null}
        <span className="muted">Page {page} of {pages} · {total} students</span>
        {page < pages ? <Link className="btn btn-outline-dark btn-sm" href={`/staff/academic/students?q=${encodeURIComponent(q)}&page=${page + 1}`}>Next</Link> : null}
      </div>
    </StaffPageShell>
  );
}
