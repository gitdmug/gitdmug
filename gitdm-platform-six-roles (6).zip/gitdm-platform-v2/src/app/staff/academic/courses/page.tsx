import Link from "next/link";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { ACTIVE_COURSE_CODES } from "@/lib/current-catalogue";

export const dynamic = "force-dynamic";

export default async function AcademicCoursesPage({
  searchParams,
}: {
  searchParams: Promise<{ q?: string; page?: string }>;
}) {
  const { db } = await requireOperationalStaffUser("courses.view");
  const sp = await searchParams;
  const q = (sp.q || "").trim();
  const page = Math.max(1, parseInt(sp.page || "1", 10) || 1);
  const pageSize = 20;

  const where: any = {
    code: { in: [...ACTIVE_COURSE_CODES] },
    published: true,
  };
  if (q) {
    where.OR = [
      { code: { contains: q, mode: "insensitive" } },
      { title: { contains: q, mode: "insensitive" } },
    ];
  }

  const [total, courses] = await Promise.all([
    db.course.count({ where }),
    db.course.findMany({
      where,
      orderBy: { code: "asc" },
      skip: (page - 1) * pageSize,
      take: pageSize,
      include: { modules: { orderBy: { orderIndex: "asc" } } },
    }),
  ]);
  const pages = Math.max(1, Math.ceil(total / pageSize));

  return (
    <StaffPageShell
      activeHref="/staff/academic/courses"
      title="Courses & modules"
      description="Only the three public programmes are available for teaching. Modules here are the same ones students see on My Programme."
    >
      <form method="get" className="actions" style={{ marginBottom: 20 }}>
        <input name="q" defaultValue={q} placeholder="Search code or title" style={{ minWidth: 220 }} />
        <button className="btn btn-outline-dark btn-sm" type="submit">Search</button>
      </form>
      <div className="table-wrap sheet-table">
        <table className="data">
          <thead>
            <tr>
              <th>Code</th>
              <th>Title</th>
              <th>Modules</th>
              <th></th>
            </tr>
          </thead>
          <tbody>
            {courses.map((c) => (
              <tr key={c.id}>
                <td><strong>{c.code}</strong></td>
                <td>{c.title}</td>
                <td>{c.modules.length}</td>
                <td>
                  <Link className="btn btn-outline-dark btn-sm" href={`/control-centre/courses/${c.id}`}>
                    Open · edit modules & lessons
                  </Link>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <div className="actions" style={{ marginTop: 16 }}>
        {page > 1 ? (
          <Link className="btn btn-outline-dark btn-sm" href={`/staff/academic/courses?q=${encodeURIComponent(q)}&page=${page - 1}`}>
            Previous
          </Link>
        ) : null}
        <span className="muted">Page {page} of {pages} · {total} courses</span>
        {page < pages ? (
          <Link className="btn btn-outline-dark btn-sm" href={`/staff/academic/courses?q=${encodeURIComponent(q)}&page=${page + 1}`}>
            Next
          </Link>
        ) : null}
      </div>
    </StaffPageShell>
  );
}
