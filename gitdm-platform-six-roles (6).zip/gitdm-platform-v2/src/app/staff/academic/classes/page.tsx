import Link from "next/link";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { generateAutomaticShortCourseTimetable } from "@/app/control-centre/timetable/actions";

export const dynamic = "force-dynamic";

/**
 * Classes appear for teaching only within 24 hours of start time.
 * This keeps the page uncongested. Full calendar generation lives under Delivery.
 */
export default async function AcademicClassesPage() {
  const { db, user } = await requireOperationalStaffUser("academic.manage");
  const now = new Date();
  const in24h = new Date(now.getTime() + 24 * 60 * 60 * 1000);

  const events = await db.timetableEvent.findMany({
    where: { type: "CLASS" },
    orderBy: { startAt: "asc" },
    include: { course: true, period: true, lecturerUser: true },
    take: 200,
  });

  const actionable = events.filter(
    (e) => new Date(e.startAt) <= in24h && new Date(e.endAt) >= now
  );
  const upcoming = events.filter((e) => new Date(e.startAt) > in24h).slice(0, 15);
  const recentPast = events
    .filter((e) => new Date(e.endAt) < now)
    .slice(-8)
    .reverse();

  const isLeadership = user.roles.some((r) =>
    ["ACADEMIC", "ACADEMIC_DIRECTOR", "PRINCIPAL"].includes(r.role.code)
  );

  return (
    <StaffPageShell
      activeHref="/staff/academic/classes"
      title="Classes"
      description="Only sessions within the next 24 hours are open for teaching actions (join link, materials, attendance). Later sessions stay hidden until their window opens."
    >
      {isLeadership ? (
        <div className="card" style={{ marginBottom: 24 }}>
          <div className="eyebrow">Automatic timetable</div>
          <h2>Generate intake timetable</h2>
          <p>
            The system builds every class from programme duration, fixed teaching days and public
            holidays. Lecturers only add the live join link when the class becomes visible.
          </p>
          <form
            action={generateAutomaticShortCourseTimetable}
            className="grid grid-3"
            style={{ marginTop: 16, alignItems: "end" }}
          >
            <label>
              Course
              <select name="courseCode" required>
                <option value="TA101">Certificate in Technical Analysis (1 month)</option>
                <option value="FX3M">Certificate in Beginner Forex Trading (3 months)</option>
              </select>
            </label>
            <label>
              Start date
              <input name="startDate" type="date" required />
            </label>
            <label>
              Session
              <select name="session" defaultValue="MORNING">
                <option value="MORNING">Morning</option>
                <option value="EVENING">Evening</option>
              </select>
            </label>
            <div>
              <button className="btn btn-primary" type="submit">
                Generate timetable
              </button>
            </div>
          </form>
        </div>
      ) : null}

      <div className="grid grid-2" style={{ marginBottom: 28 }}>
        <div className="panel">
          <div className="eyebrow">Open now (next 24 hours)</div>
          <h2>{actionable.length}</h2>
        </div>
        <div className="panel">
          <div className="eyebrow">Later (hidden until window)</div>
          <h2>{upcoming.length}+</h2>
        </div>
      </div>

      <h2 style={{ marginBottom: 12 }}>Actionable sessions</h2>
      {actionable.length === 0 ? (
        <div className="panel">
          <p>No classes fall inside the next 24 hours. When a session approaches, it will appear here with upload and join-link controls.</p>
        </div>
      ) : (
        <div className="table-wrap">
          <table className="data">
            <thead>
              <tr>
                <th>When</th>
                <th>Course</th>
                <th>Title</th>
                <th>Join link</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {actionable.map((e) => (
                <tr key={e.id}>
                  <td>
                    {new Date(e.startAt).toLocaleString("en-UG", {
                      dateStyle: "medium",
                      timeStyle: "short",
                    })}
                  </td>
                  <td>{e.course?.code || "—"}</td>
                  <td>{e.title}</td>
                  <td>{e.googleMeetUrl || e.joinUrl ? "Connected" : "Missing"}</td>
                  <td>
                    <Link
                      className="btn btn-primary btn-sm"
                      href={`/staff/academic/classes/${e.id}`}
                    >
                      Open · link, materials, attendance
                    </Link>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {upcoming.length > 0 ? (
        <div style={{ marginTop: 36 }}>
          <h2 style={{ marginBottom: 12 }}>Coming later (preview only)</h2>
          <p className="muted">These stay closed until 24 hours before start. No materials or links yet.</p>
          <div className="table-wrap">
            <table className="data">
              <thead>
                <tr>
                  <th>When</th>
                  <th>Course</th>
                  <th>Title</th>
                </tr>
              </thead>
              <tbody>
                {upcoming.map((e) => (
                  <tr key={e.id}>
                    <td>
                      {new Date(e.startAt).toLocaleString("en-UG", {
                        dateStyle: "medium",
                        timeStyle: "short",
                      })}
                    </td>
                    <td>{e.course?.code || "—"}</td>
                    <td>{e.title}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : null}

      {recentPast.length > 0 ? (
        <div style={{ marginTop: 36 }}>
          <h2 style={{ marginBottom: 12 }}>Recently completed</h2>
          <div className="table-wrap">
            <table className="data">
              <thead>
                <tr>
                  <th>When</th>
                  <th>Course</th>
                  <th>Title</th>
                  <th></th>
                </tr>
              </thead>
              <tbody>
                {recentPast.map((e) => (
                  <tr key={e.id}>
                    <td>
                      {new Date(e.startAt).toLocaleString("en-UG", {
                        dateStyle: "medium",
                        timeStyle: "short",
                      })}
                    </td>
                    <td>{e.course?.code || "—"}</td>
                    <td>{e.title}</td>
                    <td>
                      <Link
                        className="btn btn-outline-dark btn-sm"
                        href={`/staff/academic/classes/${e.id}`}
                      >
                        View attendance
                      </Link>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      ) : null}
    </StaffPageShell>
  );
}
