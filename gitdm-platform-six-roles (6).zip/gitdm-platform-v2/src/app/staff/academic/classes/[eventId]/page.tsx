import Link from "next/link";
import { notFound } from "next/navigation";
import { GITDM } from "@/lib/branding";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { StaffPageShell } from "@/components/staff/StaffPageShell";
import {
  endOnlineClass,
  syncOnlineAttendance,
  updateClassSessionDetails,
  uploadClassMaterial,
} from "@/app/control-centre/courses/actions";

export const dynamic = "force-dynamic";
export const metadata = { title: `Class session | ${GITDM.shortName}` };

function parseNotes(raw: string | null | undefined) {
  if (!raw) return { materials: [] as { ref: string; name: string }[], materialsUrl: "", materialsNote: "" };
  try {
    const j = JSON.parse(raw);
    return {
      materials: Array.isArray(j.materials) ? j.materials : [],
      materialsUrl: j.materialsUrl || "",
      materialsNote: j.materialsNote || "",
    };
  } catch {
    return { materials: [], materialsUrl: "", materialsNote: raw };
  }
}

export default async function ClassSessionPage({
  params,
}: {
  params: Promise<{ eventId: string }>;
}) {
  const { eventId } = await params;
  const { db } = await requireOperationalStaffUser("attendance.manage");
  const event = await db.timetableEvent.findUnique({
    where: { id: eventId },
    include: {
      course: true,
      period: true,
      lecturerUser: true,
      attendance: { include: { user: true }, orderBy: { minutesAttended: "desc" } },
    },
  });
  if (!event) notFound();

  const meetUrl = event.googleMeetUrl || event.joinUrl || "";
  const meta = parseNotes(event.notes);
  const now = new Date();
  const in24h = new Date(now.getTime() + 24 * 60 * 60 * 1000);
  const actionable =
    new Date(event.startAt) <= in24h && new Date(event.endAt) >= new Date(now.getTime() - 2 * 60 * 60 * 1000);

  return (
    <StaffPageShell activeHref="/staff/academic/classes" title="Class session">
      <div className="container" style={{ maxWidth: 900, margin: "0 auto", padding: "24px 16px" }}>
        <div className="eyebrow">{event.course?.code || "Class"}</div>
        <h1 style={{ marginTop: 4 }}>{event.title}</h1>
        <p className="muted">
          {new Date(event.startAt).toLocaleString("en-UG", { dateStyle: "full", timeStyle: "short" })}
          {" – "}
          {new Date(event.endAt).toLocaleTimeString("en-UG", { hour: "2-digit", minute: "2-digit" })}
        </p>
        {!actionable ? (
          <div className="panel" style={{ marginTop: 16 }}>
            This class is outside the 24-hour teaching window. You can still view details; edit link and materials when it is within 24 hours of start.
          </div>
        ) : null}

        <div className="card" style={{ marginTop: 24 }}>
          <div className="eyebrow">Step 1 · Session details</div>
          <h2>Edit title, join link &amp; materials</h2>
          <form action={updateClassSessionDetails} className="stack" style={{ marginTop: 12 }}>
            <input type="hidden" name="eventId" value={event.id} />
            <label>
              Class title (shown to students)
              <input name="title" defaultValue={event.title} required />
            </label>
            <label>
              Join URL (Meet / Zoom / other)
              <input name="joinUrl" type="url" placeholder="https://meet.google.com/..." defaultValue={meetUrl} />
            </label>
            <label>
              Materials link (Drive, PDF URL, etc.)
              <input name="materialsUrl" type="url" placeholder="https://..." defaultValue={meta.materialsUrl} />
            </label>
            <label>
              Materials note
              <textarea name="materialsNote" rows={3} defaultValue={meta.materialsNote} placeholder="What students should prepare…" />
            </label>
            <button type="submit" className="btn btn-primary">
              Save session details
            </button>
          </form>
        </div>

        <div className="card" style={{ marginTop: 20 }}>
          <div className="eyebrow">Step 2 · Upload file</div>
          <h2>Class material from your device</h2>
          <p className="muted">PDF, slides, or document. One click upload (stored privately).</p>
          <form action={uploadClassMaterial} encType="multipart/form-data" className="actions" style={{ marginTop: 12 }}>
            <input type="hidden" name="eventId" value={event.id} />
            <input type="file" name="file" required accept=".pdf,.doc,.docx,.ppt,.pptx,.png,.jpg,.jpeg,.zip" />
            <button type="submit" className="btn btn-primary">
              Upload file
            </button>
          </form>
          {meta.materials.length ? (
            <ul style={{ marginTop: 16 }}>
              {meta.materials.map((m: { ref: string; name: string }, i: number) => (
                <li key={i}>{m.name || m.ref}</li>
              ))}
            </ul>
          ) : null}
        </div>

        <div className="card" style={{ marginTop: 20 }}>
          <div className="eyebrow">Step 3 · After class</div>
          <h2>Attendance</h2>
          <div className="actions" style={{ marginTop: 12 }}>
            <form action={syncOnlineAttendance}>
              <input type="hidden" name="eventId" value={event.id} />
              <button type="submit" className="btn btn-outline-dark">
                Sync Meet attendance
              </button>
            </form>
            <form action={endOnlineClass}>
              <input type="hidden" name="eventId" value={event.id} />
              <button type="submit" className="btn btn-outline-dark">
                Mark session ended
              </button>
            </form>
          </div>
          {event.attendance?.length ? (
            <div className="table-wrap sheet-table" style={{ marginTop: 16 }}>
              <table className="data">
                <thead>
                  <tr>
                    <th>Learner</th>
                    <th>Minutes</th>
                  </tr>
                </thead>
                <tbody>
                  {event.attendance.slice(0, 50).map((a) => (
                    <tr key={a.id}>
                      <td>
                        {[a.user?.firstName, a.user?.lastName].filter(Boolean).join(" ") || a.user?.email}
                      </td>
                      <td>{a.minutesAttended ?? "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          ) : (
            <p className="muted" style={{ marginTop: 12 }}>
              No attendance records yet.
            </p>
          )}
        </div>

        <div className="actions" style={{ marginTop: 24 }}>
          <Link className="btn btn-outline-dark btn-sm" href="/staff/academic/classes">
            ← All classes
          </Link>
        </div>
      </div>
    </StaffPageShell>
  );
}
