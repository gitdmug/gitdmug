import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { GITDM } from "@/lib/branding";
import { getDb } from "@/lib/db";
import { getAuthSession } from "@/lib/auth-session";
import { buyPublicProduct } from "./actions";
import { BookReadCounter } from "@/components/BookReadCounter";

export const dynamic = "force-dynamic";
export const metadata = { title: `GITDM Store | ${GITDM.shortName}` };

const productImages: Record<string,string> = {
  "GITDM Market Basics — Free Guide": "/media/gitdm-store-basics.jpg",
  "GITDM Financial Markets Handbook": "/media/gitdm-store-handbook-fm.jpg",
  "GITDM Trading & Derivatives Handbook": "/media/gitdm-store-handbook-td.jpg",
};

export default async function PublicStorePage(){
 const db=getDb();
 const session=await getAuthSession();
 const products=db?await db.storeProduct.findMany({where:{status:"ACTIVE",audience:"PUBLIC"},orderBy:{name:"asc"}}):[];
 return <><Header active="/store"/><main>
  <section className="page-hero"><div className="container"><div className="eyebrow">GITDM Store</div><h1>Learning materials for everyone.</h1><p>Purchase selected GITDM publications, guides and introductory materials. Student-only materials remain inside the secure campus store.</p></div></section>
  <section className="section"><div className="container"><div className="grid grid-3">
   {products.map(p=><article className="card visual-card" key={p.id}><img className="public-image card-image" src={productImages[p.name] || "/media/gitdm-store-fallback.jpg"} alt={`${p.name} thumbnail`} /><div className="card-body"><div className="eyebrow">{p.fulfillment.replaceAll("_"," ")}</div><h3>{p.name}</h3><p>{p.description||"GITDM learning material."}</p>{p.name.includes("Market Basics")?<p className="tile-meta"><BookReadCounter bookSlug="market-basics" trackOnMount={false}/></p>:p.name.includes("Financial Markets")?<p className="tile-meta"><BookReadCounter bookSlug="financial-markets-handbook" trackOnMount={false}/></p>:p.name.includes("Trading & Derivatives")?<p className="tile-meta"><BookReadCounter bookSlug="trading-derivatives-handbook" trackOnMount={false}/></p>:null}<strong>{p.currency} {Number(p.price).toLocaleString("en-UG")}</strong>{p.price.toString()==="0"?<p className="tile-meta">Free resource</p>:null}<div className="actions">{Number(p.price)===0?<Link href="/store/free-market-basics" className="btn btn-primary btn-sm">Read free book</Link>:session?.user?.sub?<form action={buyPublicProduct} className="form-grid"><input type="hidden" name="productId" value={p.id}/>{p.fulfillment==="BOTH"?<label className="tile-meta">Choose format<select name="fulfillmentMode" defaultValue="DIGITAL"><option value="DIGITAL">Digital book · read and download</option><option value="HARD_COPY">Printed copy</option></select></label>:<input type="hidden" name="fulfillmentMode" value={p.fulfillment}/>}<button className="btn btn-primary btn-sm">Buy</button></form>:<Link href={`/auth/login?returnTo=/store?product=${encodeURIComponent(p.id)}`} className="btn btn-primary btn-sm">Sign in to purchase</Link>}</div></div></article>)}
   {!products.length?<div className="panel"><h3>Public catalogue coming soon</h3><p>Public learning materials will appear here. Student-only materials are available after sign in.</p></div>:null}
  </div><div className="actions" style={{marginTop:32}}><Link href="/campus" className="btn btn-outline-dark">Student? Enter Campus</Link><Link href="/programmes" className="btn btn-outline-dark">Explore programmes</Link></div></div></section>
 </main><Footer/></>;
}
