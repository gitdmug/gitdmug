"use server";
import { redirect } from "next/navigation";
import { getAuthSession } from "@/lib/auth-session";
import { syncGITDMUser } from "@/lib/identity";
import { getDb } from "@/lib/db";
import { makeReference } from "@/lib/reference";
import { getPublicAppUrl, submitPesapalOrder } from "@/lib/pesapal";

export async function buyPublicProduct(fd:FormData){
 const productId=String(fd.get("productId")||"").trim();
 const session=await getAuthSession();
 if(!session?.user?.sub) redirect(`/auth/login?returnTo=/store?product=${encodeURIComponent(productId)}`);
 await syncGITDMUser(session);
 const db=getDb(); if(!db) redirect("/store?error=Database%20unavailable");
 const user=await db.user.findUnique({where:{authUserId:session.user.sub}});
 const product=await db.storeProduct.findFirst({where:{id:productId,status:"ACTIVE",audience:"PUBLIC"}});
 if(!user||!product) redirect("/store?error=This%20item%20is%20no%20longer%20available");
 const requestedMode=String(fd.get("fulfillmentMode")||"");
 const fulfillmentMode=product.fulfillment==="BOTH" ? (requestedMode==="HARD_COPY" ? "HARD_COPY" : "DIGITAL") : product.fulfillment;
 if(!["DIGITAL","HARD_COPY"].includes(fulfillmentMode)) redirect("/store?error=Choose%20a%20valid%20format");
 const email=user.email; const phone=user.phone||"";
 if(!phone) redirect("/campus/profile?error=Add%20your%20phone%20number%20before%20purchasing%20from%20the%20public%20store");
 const order=await db.storeOrder.create({data:{userId:user.id,orderNo:makeReference("PUB"),totalAmount:product.price,currency:product.currency,fulfillmentMode:fulfillmentMode as "DIGITAL"|"HARD_COPY",contactName:[user.firstName,user.lastName].filter(Boolean).join(" ")||email,contactEmail:email,contactPhone:phone,paymentStatus:"PENDING",items:{create:{productId:product.id,quantity:1,unitPrice:product.price,fulfillmentMode:fulfillmentMode as "DIGITAL"|"HARD_COPY"}}}});
 const merchantReference=`GITDM-PUBLIC-${order.orderNo}-${Date.now()}`.slice(0,50);
 const payment=await db.storePayment.create({data:{orderId:order.id,userId:user.id,provider:"PESAPAL",providerMerchantRef:merchantReference,amount:product.price,currency:product.currency,status:"PENDING"}});
 try{const appUrl=getPublicAppUrl();const response=await submitPesapalOrder({merchantReference,amount:Number(product.price),currency:product.currency,description:`GITDM public store ${product.name} (${fulfillmentMode})`,callbackUrl:`${appUrl}/api/payments/pesapal/callback`,cancellationUrl:`${appUrl}/api/payments/pesapal/cancel?merchantReference=${encodeURIComponent(merchantReference)}`,email,phone,firstName:user.firstName,lastName:user.lastName});if(!response.redirect_url||!response.order_tracking_id)throw new Error(response.message||"Pesapal did not return a checkout URL.");await db.storePayment.update({where:{id:payment.id},data:{providerRef:response.order_tracking_id,providerMerchantRef:response.merchant_reference||merchantReference,providerRedirectUrl:response.redirect_url,providerResponseJson:JSON.stringify(response)}});redirect(response.redirect_url);}catch(error){if(error&&typeof error==="object"&&"digest" in error)throw error;await db.storePayment.update({where:{id:payment.id},data:{status:"FAILED",providerStatus:error instanceof Error?error.message:"Payment start failed"}});await db.storeOrder.update({where:{id:order.id},data:{paymentStatus:"FAILED"}});redirect(`/store?error=${encodeURIComponent(error instanceof Error?error.message:"Payment could not be started")}`);}
}
