import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { GITDM } from "@/lib/branding";

export const metadata = {
  title: `Terms & Conditions | ${GITDM.shortName}`,
  description: "Terms for using the GITDM public website and digital learning services.",
};

export default function TermsPage() {
  return <><Header active="/terms" /><main>
    <section className="page-hero"><div className="container"><div className="eyebrow">Website policies</div><h1>Terms &amp; Conditions</h1><p>These terms explain the basic rules for using the GITDM website and digital learning services.</p></div></section>
    <section className="section"><div className="container"><div className="card stack">
      <p><strong>Effective date: 9 October 2026</strong></p>
      <h2>1. Using this website</h2><p>By accessing this website, you agree to use it lawfully and respectfully. Do not attempt to disrupt the website, gain unauthorised access, misuse accounts, upload harmful material or interfere with another person's use of the services.</p>
      <h2>2. Applications and student accounts</h2><p>Applicants must provide accurate and current information. Submitting an application does not by itself guarantee admission or enrolment. Access to student services may depend on admission decisions, identity and role verification, required payments and institutional processes. Keep your login credentials confidential and notify GITDM if you believe your account has been compromised.</p>
      <h2>3. Courses and learning materials</h2><p>Programme descriptions, timetables, modules, fees and delivery arrangements may be updated. The information communicated through official admissions and student channels will guide the applicable intake. Unless expressly permitted, website and course materials may not be copied, redistributed, sold or presented as your own work.</p>
      <h2>4. Educational and financial-risk notice</h2><p>GITDM provides education and general information, not personalised financial or investment advice. Trading involves risk and no profit or outcome is guaranteed. Please read the <a href="/disclaimer">Trading &amp; Education Disclaimer</a> before relying on trading-related content or following third-party links.</p>
      <h2>5. Third-party links and partners</h2><p>This website may link to external websites and services, including partner or referral links. Those services are operated independently and are subject to their own terms, privacy policies, fees and eligibility conditions. GITDM does not control or guarantee third-party content or services. Referral relationships, where present, do not remove trading risk.</p>
      <h2>6. Availability and accuracy</h2><p>We aim to keep the website accurate and available but do not guarantee uninterrupted access or that every item of information is complete, current or error-free. We may maintain, change or temporarily suspend website features for operational, security or academic reasons.</p>
      <h2>7. Privacy and personal information</h2><p>Personal information submitted through applications, contact forms or student services should be used for relevant institutional, admissions, academic, support and administrative purposes, subject to applicable law and any separate privacy notice provided by GITDM. Do not submit information that is not requested or necessary.</p>
      <h2>8. Changes and contact</h2><p>These terms may be updated as services and institutional requirements change. Continued use after an update means you accept the revised terms. For questions about these terms, contact <a href={`mailto:${GITDM.supportEmail}`}>{GITDM.supportEmail}</a>.</p>
    </div></div></section>
  </main><Footer /></>;
}
