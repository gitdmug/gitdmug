import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/access";
import { getDb } from "@/lib/db";
export async function POST(req: Request) {
  const user=await getCurrentUser(); const db=getDb(); if(!user||!db)return NextResponse.json({error:"Unauthorized"},{status:401});
  const {eventId}=await req.json(); const r=await db.classAttendanceRecord.findUnique({where:{userId_timetableEventId:{userId:user.id,timetableEventId:eventId}},include:{timetableEvent:true}});
  if(!r?.joinedAt||r.leftAt)return NextResponse.json({ok:true});
  const now=new Date(); const left=now>r.timetableEvent.endAt?r.timetableEvent.endAt:now; const mins=Math.max(0,Math.round((left.getTime()-r.joinedAt.getTime())/60000));
  await db.classAttendanceRecord.update({where:{id:r.id},data:{leftAt:left,lastSeenAt:now,minutesAttended:mins,status:mins>0?"PRESENT":"ABSENT"}});
  return NextResponse.json({ok:true,minutes:mins});
}
