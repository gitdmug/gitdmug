import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/access";
import { getDb } from "@/lib/db";
export async function POST(req: Request) {
  const user = await getCurrentUser(); const db = getDb(); if (!user || !db) return NextResponse.json({error:"Unauthorized"},{status:401});
  const { eventId } = await req.json();
  const event = await db.timetableEvent.findUnique({where:{id:eventId}}); if (!event?.courseId) return NextResponse.json({error:"Class not found"},{status:404});
  const enrollment = await db.enrollment.findFirst({where:{userId:user.id,status:{in:["ACTIVE","REPEATING"]},courses:{some:{courseId:event.courseId,status:{in:["ACTIVE","REPEATING"]}}}}});
  if (!enrollment) return NextResponse.json({error:"Not enrolled"},{status:403});
  const now=new Date(), openAt=new Date(event.startAt.getTime()-event.prepMinutes*60000);
  if(now<openAt||now>event.endAt) return NextResponse.json({error:"Class closed"},{status:400});
  const existing=await db.classAttendanceRecord.findUnique({where:{userId_timetableEventId:{userId:user.id,timetableEventId:event.id}}});
  if(existing?.joinedAt&&!existing.leftAt) return NextResponse.json({ok:true});
  if(existing?.leftAt) return NextResponse.json({error:"Attendance already closed"},{status:409});
  await db.classAttendanceRecord.create({data:{timetableEventId:event.id,userId:user.id,courseId:event.courseId,periodId:event.periodId??undefined,date:event.startAt,joinedAt:now,lastSeenAt:now,heartbeatCount:1,status:"PRESENT",source:"GITDM_BROWSER"}});
  return NextResponse.json({ok:true});
}
