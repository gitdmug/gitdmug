import { NextRequest, NextResponse } from "next/server";
import { generateWithCascade } from "@/lib/ai-providers";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

type ChatMessage = { role: "user" | "assistant"; content: string };

const requestBuckets = new Map<string, { count: number; resetAt: number }>();
function overRateLimit(key: string) {
  const now = Date.now();
  const bucket = requestBuckets.get(key);
  if (!bucket || bucket.resetAt <= now) {
    requestBuckets.set(key, { count: 1, resetAt: now + 60_000 });
    if (requestBuckets.size > 1500) {
      for (const [id, item] of requestBuckets) if (item.resetAt <= now) requestBuckets.delete(id);
    }
    return false;
  }
  bucket.count += 1;
  return bucket.count > 20;
}

const SYSTEM_PROMPT = `You are the public-facing GITDM (Global Institute of Trading and Derivatives Markets) website support assistant. Your main jobs are to answer general questions, explain how to navigate the site, help prospective learners understand published programme/admissions information, and guide visitors through the public store and free Market Basics guide.

Current site routes: Home /; programmes /programmes; admissions application /admissions/apply; public store /store; free online Market Basics book /store/free-market-basics; partners /partners; research /research; contact /contact; login /auth/login; student campus /campus.

Rules: Be warm, concise, practical, and beginner-friendly. Ask one clarifying question when necessary. When useful, name the exact page and explain the next step. Do not invent tuition, deadlines, entry requirements, payment status, credentials, accreditation, policies, or product availability. If the exact information is not present in the user's question or public-site context, say you cannot verify it and direct them to the relevant page or GITDM staff. Never claim to access accounts, submit applications, make purchases, issue refunds, or change records. Do not ask for passwords, full card details, OTPs, or private account credentials. Do not provide personalised financial, investment, or trading advice, predict market prices, or promise profits. Treat market education as educational only. For purchases, direct users to the store and explain that student-only resources require sign-in. The free Market Basics book is readable online at /store/free-market-basics. Do not make up links; only use the listed routes. Keep responses under 180 words unless the user asks for detail.`;

function localFallback(question: string, page: string) {
  const q = question.toLowerCase();
  if (/apply|admission|application|join|enrol|enroll/.test(q))
    return {
      answer:
        "To get started, open the Admissions application page and follow the application instructions shown there. For requirements or deadlines that are not clearly listed, confirm them with the GITDM admissions team before paying any fee.",
      links: [
        { label: "Start an application", href: "/admissions/apply" },
        { label: "Explore programmes", href: "/programmes" },
      ],
    };
  if (/free guide|market basics|book|guide|read/.test(q))
    return {
      answer:
        "You can read the free Market Basics book directly on the website. It introduces financial markets, instruments, price movements, analysis, risk, trading plans and learning discipline.",
      links: [
        { label: "Read the free book", href: "/store/free-market-basics" },
        { label: "Visit the store", href: "/store" },
      ],
    };
  if (/buy|purchase|store|pay|payment|product/.test(q))
    return {
      answer:
        "Open the public store to browse available learning materials. Free resources can be opened directly; purchasing paid items may require you to sign in. Check the product details and checkout instructions before proceeding.",
      links: [
        { label: "Open the store", href: "/store" },
        { label: "Sign in", href: "/auth/login" },
      ],
    };
  if (/course|programme|program|study|learn|training|class/.test(q))
    return {
      answer:
        "The Programmes page is the best place to review GITDM's published learning options and decide which path fits your current level. If you tell me your experience level and what you want to learn, I can help you navigate the information available on the site.",
      links: [
        { label: "Explore programmes", href: "/programmes" },
        { label: "Apply", href: "/admissions/apply" },
      ],
    };
  if (/contact|human|staff|person|support|help/.test(q))
    return {
      answer:
        "If you need a staff member to confirm a detail, use the Contact page. I can help explain the public website, but I cannot access private accounts or make changes to applications and payments.",
      links: [{ label: "Contact GITDM", href: "/contact" }],
    };
  if (/student|campus|login|sign in|portal|account/.test(q))
    return {
      answer:
        "For student resources, open the Campus area and sign in using the site's official login flow. Do not share your password or one-time codes in this chat. If you are new to GITDM, begin with the programme and admissions pages.",
      links: [
        { label: "Campus", href: "/campus" },
        { label: "Sign in", href: "/auth/login" },
        { label: "Admissions", href: "/admissions/apply" },
      ],
    };
  return {
    answer: `I can help you navigate GITDM, explore programmes, understand the application journey, and find resources in the store. You are currently viewing ${page || "the website"}. Tell me what you are trying to do, or choose one of the links below.`,
    links: [
      { label: "Programmes", href: "/programmes" },
      { label: "Admissions", href: "/admissions/apply" },
      { label: "Store", href: "/store" },
      { label: "Contact", href: "/contact" },
    ],
  };
}

export async function POST(request: NextRequest) {
  try {
    const ip = (request.headers.get("x-forwarded-for") || "unknown").split(",")[0].trim().slice(0, 80);
    if (overRateLimit(ip))
      return NextResponse.json(
        { error: "You have sent several messages in a short time. Please wait a minute and try again." },
        { status: 429 }
      );
    const body = await request.json();
    const messages = Array.isArray(body?.messages) ? (body.messages as ChatMessage[]) : [];
    const page = typeof body?.page === "string" ? body.page.slice(0, 160) : "/";
    const cleaned = messages
      .slice(-10)
      .filter((m) => (m?.role === "user" || m?.role === "assistant") && typeof m?.content === "string")
      .map((m) => ({ role: m.role, content: m.content.slice(0, 1200) }));
    const latest = [...cleaned].reverse().find((m) => m.role === "user");
    if (!latest?.content.trim()) return NextResponse.json({ error: "Please enter a question." }, { status: 400 });
    if (cleaned.length > 10)
      return NextResponse.json({ error: "Please shorten this conversation and try again." }, { status: 400 });

    const conversation = cleaned
      .map((m) => `${m.role === "user" ? "Visitor" : "Assistant"}: ${m.content}`)
      .join("\n");

    const ai = await generateWithCascade({
      system: `${SYSTEM_PROMPT}\nCurrent page path: ${page}`,
      user: conversation || latest.content,
      maxTokens: 450,
      temperature: 0.3,
    });

    if (!ai.text?.trim()) {
      return NextResponse.json({ ...localFallback(latest.content, page), mode: "guided-fallback" });
    }

    const answer = ai.text.trim();
    const links = [
      { label: "Programmes", href: "/programmes" },
      { label: "Admissions", href: "/admissions/apply" },
      { label: "Store", href: "/store" },
      { label: "Free Market Basics book", href: "/store/free-market-basics" },
      { label: "Contact", href: "/contact" },
    ].filter((link) => answer.toLowerCase().includes(link.label.toLowerCase().split(" ")[0]));

    return NextResponse.json({
      answer,
      links: links.slice(0, 3),
      mode: "ai",
      provider: ai.provider,
    });
  } catch (error) {
    console.error("GITDM assistant request failed", error instanceof Error ? error.message : "unknown error");
    return NextResponse.json(
      { error: "The assistant could not process that request. Please try again." },
      { status: 500 }
    );
  }
}
