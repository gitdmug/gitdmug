import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/access";
import { getDb } from "@/lib/db";
import { databaseFileResponse } from "@/lib/file-delivery";

export async function GET() {
  const user = await getCurrentUser();
  if (!user) return new NextResponse("Unauthorized", { status: 401 });
  const db = getDb();
  if (!db) return new NextResponse("Database unavailable", { status: 503 });
  const profile = await db.profile.findUnique({ where: { userId: user.id } });
  if (!profile?.avatarUrl) return NextResponse.json({ error: "No profile picture" }, { status: 404 });
  if (profile.avatarUrl.startsWith("neonfile:")) return (await databaseFileResponse(profile.avatarUrl, "inline"))!;
  return NextResponse.redirect(profile.avatarUrl);
}
