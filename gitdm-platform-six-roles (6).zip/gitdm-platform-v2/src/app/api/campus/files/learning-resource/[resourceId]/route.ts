import { NextResponse } from "next/server";
import { getAuthSession } from "@/lib/auth-session";
import { syncGITDMUser } from "@/lib/identity";
import { getDb } from "@/lib/db";
import { databaseFileResponse } from "@/lib/file-delivery";

export async function GET(request: Request, { params }: { params: Promise<{ resourceId: string }> }) {
  const session = await getAuthSession();
  if (!session?.user?.sub || !session.user.emailVerified) return new NextResponse("Unauthorized", { status: 401 });
  await syncGITDMUser(session);
  const db = getDb();
  if (!db) return new NextResponse("Database unavailable", { status: 503 });

  const user = await db.user.findUnique({
    where: { authUserId: session.user.sub },
    include: { roles: { include: { role: true } } },
  });
  if (!user) return new NextResponse("Unauthorized", { status: 401 });

  const { resourceId } = await params;
  const download = new URL(request.url).searchParams.get("download") === "1";
  const resource = await db.learningResource.findUnique({
    where: { id: resourceId },
    include: { lesson: { include: { module: { select: { courseId: true } } } } },
  });
  if (!resource) return new NextResponse("Not found", { status: 404 });

  const staff = user.roles.some((r) => !["STUDENT", "PARENT_GUARDIAN", "ALUMNI"].includes(r.role.code));
  let allowed = staff;
  if (!allowed) {
    const courseId = resource.lesson.module.courseId;
    const enrollment = await db.enrollment.findFirst({
      where: {
        userId: user.id,
        status: { in: ["ACTIVE", "REPEATING"] },
        courses: { some: { courseId, status: { in: ["ACTIVE", "REPEATING"] } } },
      },
      select: { id: true },
    });
    allowed = Boolean(enrollment);
  }
  if (!allowed) return new NextResponse("Forbidden", { status: 403 });

  if (resource.url.startsWith("neonfile:")) {
    return (await databaseFileResponse(resource.url, download ? "attachment" : "inline")) || new NextResponse("File unavailable", { status: 404 });
  }
  return NextResponse.redirect(resource.url);
}
