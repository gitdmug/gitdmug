import { NextResponse } from "next/server";
import { getAuthSession } from "@/lib/auth-session";
import { getDb } from "@/lib/db";
import { syncGITDMUser } from "@/lib/identity";
import { databaseFileResponse } from "@/lib/file-delivery";

export async function GET(_: Request, { params }: { params: Promise<{ fileId: string }> }) {
  const session = await getAuthSession();
  if (!session?.user?.sub) return new NextResponse("Unauthorized", { status: 401 });
  await syncGITDMUser(session);
  const db = getDb();
  if (!db) return new NextResponse("Database unavailable", { status: 503 });
  const user = await db.user.findUnique({ where: { authUserId: session.user.sub }, include: { roles: { include: { role: true } } } });
  if (!user) return new NextResponse("Unauthorized", { status: 401 });
  const { fileId } = await params;
  const file = await db.examSubmissionFile.findUnique({ where: { id: fileId }, include: { attempt: { select: { userId: true } } } });
  if (!file) return new NextResponse("Not found", { status: 404 });
  const staff = user.roles.some((r) => !["STUDENT", "PARENT_GUARDIAN", "ALUMNI"].includes(r.role.code));
  if (!staff && file.attempt.userId !== user.id) return new NextResponse("Forbidden", { status: 403 });
  if (file.url.startsWith("neonfile:")) return (await databaseFileResponse(file.url, "inline"))!;
  return NextResponse.redirect(new URL(file.url, "https://globalinstituteoftrading.com"));
}
