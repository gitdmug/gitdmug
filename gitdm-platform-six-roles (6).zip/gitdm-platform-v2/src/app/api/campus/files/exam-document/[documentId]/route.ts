import { NextResponse } from "next/server";
import { getAuthSession } from "@/lib/auth-session";
import { getDb } from "@/lib/db";
import { syncGITDMUser } from "@/lib/identity";
import { databaseFileResponse } from "@/lib/file-delivery";

export async function GET(_: Request, { params }: { params: Promise<{ documentId: string }> }) {
  const session = await getAuthSession();
  if (!session?.user?.sub) return new NextResponse("Unauthorized", { status: 401 });
  await syncGITDMUser(session);
  const db = getDb();
  if (!db) return new NextResponse("Database unavailable", { status: 503 });
  const user = await db.user.findUnique({ where: { authUserId: session.user.sub }, include: { roles: { include: { role: true } } } });
  if (!user) return new NextResponse("Unauthorized", { status: 401 });
  const { documentId } = await params;
  const doc = await db.examDocument.findUnique({ where: { id: documentId }, include: { exam: { select: { courseId: true } } } });
  if (!doc) return new NextResponse("Not found", { status: 404 });
  const isStaff = user.roles.some((r) => !["STUDENT", "PARENT_GUARDIAN", "ALUMNI"].includes(r.role.code));
  let allowed = isStaff;
  if (!allowed) {
    const enrollment = await db.enrollment.findFirst({ where: { userId: user.id, status: { in: ["ACTIVE", "REPEATING"] }, courses: { some: { courseId: doc.exam.courseId } } } });
    allowed = Boolean(enrollment);
  }
  if (!allowed) return new NextResponse("Forbidden", { status: 403 });
  if (doc.url.startsWith("neonfile:")) return (await databaseFileResponse(doc.url, "inline"))!;
  return NextResponse.redirect(new URL(doc.url, "https://globalinstituteoftrading.com"));
}
