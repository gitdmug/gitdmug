import { NextResponse } from "next/server";
import { getAuthSession } from "@/lib/auth-session";
import { getDb } from "@/lib/db";
import { syncGITDMUser } from "@/lib/identity";
import { databaseFileResponse } from "@/lib/file-delivery";

export async function GET(_: Request, { params }: { params: Promise<{ documentId: string }> }) {
  const session = await getAuthSession();
  if (!session?.user?.sub) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  await syncGITDMUser(session);
  const db = getDb();
  if (!db) return NextResponse.json({ error: "Database unavailable" }, { status: 503 });
  const user = await db.user.findUnique({
    where: { authUserId: session.user.sub },
    include: { roles: { include: { role: { include: { permissions: { include: { permission: true } } } } } } },
  });
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { documentId } = await params;
  const doc = await db.applicationDocument.findUnique({ where: { id: documentId } });
  if (!doc) return NextResponse.json({ error: "Not found" }, { status: 404 });

  // Keep the ownership lookup separate from the document query. This avoids
  // relying on a generated Prisma relation that may lag behind during a
  // rolling deployment and makes the authorization boundary explicit.
  const application = await db.application.findUnique({
    where: { id: doc.applicationId },
    select: { applicantId: true },
  });
  if (!application) return NextResponse.json({ error: "Application not found" }, { status: 404 });

  const allowed = user.roles.some((r) =>
    r.role.permissions.some((p) =>
      p.permission.key === "applications.view" ||
      p.permission.key === "applications.review" ||
      p.permission.key === "applications.manage",
    ),
  );
  if (!allowed && application.applicantId !== user.id) {
    return NextResponse.json({ error: "Forbidden" }, { status: 403 });
  }
  if (doc.fileUrl.startsWith("neonfile:")) return (await databaseFileResponse(doc.fileUrl, "inline"))!;
  return NextResponse.redirect(new URL(doc.fileUrl, "https://globalinstituteoftrading.com"));
}
