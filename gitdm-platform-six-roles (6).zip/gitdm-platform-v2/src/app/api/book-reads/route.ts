import { NextRequest, NextResponse } from "next/server";
import { getDb } from "@/lib/db";

export const dynamic = "force-dynamic";
const ALLOWED_BOOKS = new Set(["market-basics", "financial-markets-handbook", "trading-derivatives-handbook"]);

export async function GET(request: NextRequest) {
  const bookSlug = request.nextUrl.searchParams.get("bookSlug") || "";
  if (!ALLOWED_BOOKS.has(bookSlug)) return NextResponse.json({ error: "Unknown book." }, { status: 400 });
  const db = getDb();
  if (!db) return NextResponse.json({ count: 0, unavailable: true }, { headers: { "Cache-Control": "no-store" } });
  try {
    const count = await db.bookReadEvent.count({ where: { bookSlug } });
    return NextResponse.json({ count }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return NextResponse.json({ count: 0, unavailable: true }, { headers: { "Cache-Control": "no-store" } });
  }
}

export async function POST(request: NextRequest) {
  let body: { bookSlug?: unknown; visitorKey?: unknown };
  try { body = await request.json(); } catch { return NextResponse.json({ error: "Invalid request." }, { status: 400 }); }
  const bookSlug = typeof body.bookSlug === "string" ? body.bookSlug : "";
  const visitorKey = typeof body.visitorKey === "string" ? body.visitorKey : "";
  if (!ALLOWED_BOOKS.has(bookSlug) || visitorKey.length < 8 || visitorKey.length > 100 || !/^[a-zA-Z0-9-]+$/.test(visitorKey)) {
    return NextResponse.json({ error: "Invalid book reader details." }, { status: 400 });
  }
  const db = getDb();
  if (!db) return NextResponse.json({ count: 0, unavailable: true }, { headers: { "Cache-Control": "no-store" } });
  try {
    await db.bookReadEvent.upsert({
      where: { bookSlug_visitorKey: { bookSlug, visitorKey } },
      create: { bookSlug, visitorKey },
      update: {},
    });
    const count = await db.bookReadEvent.count({ where: { bookSlug } });
    return NextResponse.json({ count }, { headers: { "Cache-Control": "no-store" } });
  } catch {
    return NextResponse.json({ count: 0, unavailable: true }, { headers: { "Cache-Control": "no-store" } });
  }
}
