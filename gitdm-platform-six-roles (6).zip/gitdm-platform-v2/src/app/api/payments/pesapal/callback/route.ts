import { NextRequest, NextResponse } from "next/server";
import { getPublicAppUrl, settlePesapalPayment } from "@/lib/pesapal";
import { settleStorePesapalPayment } from "@/lib/store-payments";

export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  const trackingId = request.nextUrl.searchParams.get("OrderTrackingId")?.trim();
  const merchantReference =
    request.nextUrl.searchParams.get("OrderMerchantReference")?.trim();

  if (!trackingId) {
    return NextResponse.redirect(
      new URL("/campus/finance?payment=missing-reference", getPublicAppUrl()),
    );
  }

  try {
    const result = trackingId ? ((merchantReference?.startsWith("GITDM-STORE-") || merchantReference?.startsWith("GITDM-PUBLIC-")) ? await settleStorePesapalPayment(trackingId) : await settlePesapalPayment(trackingId)) : { status: "UNKNOWN" };
    const params = new URLSearchParams({
      payment: String(result.status || "PENDING").toLowerCase(),
    });
    if (merchantReference) params.set("reference", merchantReference);
    if ("paymentId" in result && result.paymentId) params.set("paymentId", result.paymentId);

    const destination = (merchantReference?.startsWith("GITDM-STORE-") || merchantReference?.startsWith("GITDM-PUBLIC-"))
      ? `/campus/store?payment=${params.get("payment") || "pending"}`
      : ("applicationId" in result && result.applicationId)
        ? `/admissions/apply/${result.applicationId}?payment=${params.get("payment") || "pending"}&reference=${encodeURIComponent(merchantReference || "")}`
        : `/campus/finance?${params.toString()}`;

    return NextResponse.redirect(new URL(destination, getPublicAppUrl()));
  } catch {
    return NextResponse.redirect(
      new URL("/campus/finance?payment=verification-error", getPublicAppUrl()),
    );
  }
}
