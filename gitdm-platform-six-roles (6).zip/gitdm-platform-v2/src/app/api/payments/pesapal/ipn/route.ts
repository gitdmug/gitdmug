import { NextRequest, NextResponse } from "next/server";
import { settlePesapalPayment } from "@/lib/pesapal";
import { settleStorePesapalPayment } from "@/lib/store-payments";

export const dynamic = "force-dynamic";

type Notification = {
  OrderNotificationType?: string;
  OrderTrackingId?: string;
  OrderMerchantReference?: string;
};

async function readNotification(request: NextRequest): Promise<Notification> {
  const query = request.nextUrl.searchParams;
  const notification: Notification = {
    OrderNotificationType:
      query.get("OrderNotificationType") ||
      query.get("pesapal_notification_type") ||
      undefined,
    OrderTrackingId:
      query.get("OrderTrackingId") ||
      query.get("pesapal_transaction_tracking_id") ||
      undefined,
    OrderMerchantReference:
      query.get("OrderMerchantReference") ||
      query.get("pesapal_merchant_reference") ||
      undefined,
  };

  if (request.method === "POST") {
    const contentType = request.headers.get("content-type") || "";
    try {
      if (contentType.includes("application/json")) {
        const body = (await request.json()) as Notification;
        Object.assign(notification, body);
      } else if (contentType.includes("application/x-www-form-urlencoded")) {
        const form = await request.formData();
        notification.OrderNotificationType =
          String(form.get("OrderNotificationType") || notification.OrderNotificationType || "");
        notification.OrderTrackingId =
          String(form.get("OrderTrackingId") || notification.OrderTrackingId || "");
        notification.OrderMerchantReference =
          String(form.get("OrderMerchantReference") || notification.OrderMerchantReference || "");
      }
    } catch {
      // Query parameters remain available if the body is empty/malformed.
    }
  }

  return notification;
}

async function handle(request: NextRequest) {
  const notification = await readNotification(request);
  const trackingId = notification.OrderTrackingId?.trim();

  if (!trackingId) {
    return NextResponse.json(
      {
        orderNotificationType: notification.OrderNotificationType || "IPNCHANGE",
        orderTrackingId: "",
        orderMerchantReference: notification.OrderMerchantReference || "",
        status: 200,
      },
      { status: 200 },
    );
  }

  try {
    const result = notification.OrderMerchantReference?.startsWith("GITDM-STORE-") ? await settleStorePesapalPayment(trackingId) : await settlePesapalPayment(trackingId);

    // Pesapal documents this JSON acknowledgement as the IPN response.
    // A 500 is only returned when our server could not process the event,
    // allowing Pesapal to retry it.
    return NextResponse.json(
      {
        orderNotificationType: notification.OrderNotificationType || "IPNCHANGE",
        orderTrackingId: trackingId,
        orderMerchantReference: notification.OrderMerchantReference || "",
        status: 200,
      },
      { status: 200 },
    );
  } catch {
    return NextResponse.json(
      {
        orderNotificationType: notification.OrderNotificationType || "IPNCHANGE",
        orderTrackingId: trackingId,
        orderMerchantReference: notification.OrderMerchantReference || "",
        status: 500,
      },
      { status: 500 },
    );
  }
}

export async function GET(request: NextRequest) {
  return handle(request);
}

export async function POST(request: NextRequest) {
  return handle(request);
}
