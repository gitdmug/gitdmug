import { NextResponse } from "next/server";
import { getDb } from "@/lib/db";

export const dynamic = "force-dynamic";

export async function GET(request: Request) {
  const db = getDb();
  const url = new URL(request.url);
  const merchantReference = url.searchParams.get("merchantReference")?.trim();
  if (db && merchantReference) {
    if (merchantReference.startsWith("GITDM-STORE-")) {
      const payment=await db.storePayment.findFirst({where:{provider:"PESAPAL",providerMerchantRef:merchantReference}});
      if(payment){await db.storePayment.update({where:{id:payment.id},data:{status:"CANCELLED",providerStatus:"ABANDONED"}});await db.storeOrder.update({where:{id:payment.orderId},data:{paymentStatus:"CANCELLED"}});}
      return NextResponse.redirect(new URL("/campus/store?payment=abandoned", request.url));
    }
    const payment = await db.payment.findFirst({ where: { provider: "PESAPAL", providerMerchantRef: merchantReference, status: "PENDING" }, include: { invoice: true } });
    if (payment) {
      await db.payment.update({ where: { id: payment.id }, data: { status: "CANCELLED", providerStatus: "ABANDONED", providerDescription: "ABANDONED: student left the Pesapal checkout before completion." } });
      if (payment.invoice.kind === "APPLICATION_FEE" && payment.invoice.applicationId) {
        return NextResponse.redirect(new URL(`/admissions/apply/${payment.invoice.applicationId}?payment=abandoned`, request.url));
      }
    }
  }
  return NextResponse.redirect(new URL("/campus/finance?payment=abandoned", request.url));
}
