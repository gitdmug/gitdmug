import { NextResponse } from "next/server";
import { getAuthSession } from "@/lib/auth-session";
import { syncGITDMUser } from "@/lib/identity";
import { getDb } from "@/lib/db";

export const runtime = "nodejs";

/** Department display name → single operational role code. */
const DEPARTMENT_ROLE: Record<string, string> = {
  Admissions: "ADMISSIONS",
  Finance: "FINANCE",
  "Academic Affairs": "ACADEMIC_DIRECTOR",
  "Examinations Office": "EXAM_OFFICER",
  Registry: "REGISTRAR",
  // legacy name aliases
  "Academic Affairs & Instruction": "ACADEMIC_DIRECTOR",
  "Student Success & Support": "REGISTRAR",
  "Operations & Business Administration": "FINANCE",
  "Technology & Infrastructure": "PRINCIPAL",
};

export async function POST(request: Request) {
  try {
    const session = await getAuthSession();
    if (!session?.user?.sub) {
      return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
    }
    await syncGITDMUser(session);
    const db = getDb();
    if (!db) return NextResponse.json({ error: "Database unavailable" }, { status: 503 });

    const actor = await db.user.findUnique({
      where: { authUserId: session.user.sub },
      include: { roles: { include: { role: true } } },
    });
    if (!actor) return NextResponse.json({ error: "User not found" }, { status: 401 });

    const actorRoles = actor.roles.map((r) => r.role.code);
    if (!actorRoles.includes("PRINCIPAL")) {
      return NextResponse.json({ error: "Only the Principal can assign departments" }, { status: 403 });
    }

    const body = await request.json();
    const userId = String(body.userId || "");
    const departmentId = String(body.departmentId || "");
    const action = body.action === "remove" ? "remove" : "assign";
    const isHead = Boolean(body.isHead);
    if (!userId || !departmentId) {
      return NextResponse.json({ error: "User and department are required" }, { status: 400 });
    }

    const [target, department] = await Promise.all([
      db.user.findUnique({ where: { id: userId } }),
      db.department.findUnique({ where: { id: departmentId } }),
    ]);
    if (!target) return NextResponse.json({ error: "Target user not found" }, { status: 404 });
    if (!department) return NextResponse.json({ error: "Department not found" }, { status: 404 });

    const targetIsPrincipal = await db.userRole.findFirst({
      where: { userId, role: { code: "PRINCIPAL" } },
    });
    if (targetIsPrincipal) {
      return NextResponse.json(
        { error: "The Principal cannot be assigned to a department." },
        { status: 409 }
      );
    }

    const roleCode = DEPARTMENT_ROLE[department.name];
    if (!roleCode || roleCode === "PRINCIPAL") {
      return NextResponse.json(
        {
          error: `Department "${department.name}" is not one of the six operational departments. Use Admissions, Finance, Academic Affairs, Examinations Office, or Registry.`,
        },
        { status: 400 }
      );
    }

    const operationalRole = await db.role.findUnique({ where: { code: roleCode as any } });
    if (!operationalRole) {
      return NextResponse.json(
        { error: `Role ${roleCode} is not configured. Run organisation sync.` },
        { status: 500 }
      );
    }

    // Ensure role is linked to this department and active
    await db.role.update({
      where: { id: operationalRole.id },
      data: { departmentId: department.id, isActive: true },
    });

    if (action === "assign") {
      await db.$transaction(async (tx) => {
        // One department at a time — remove other department memberships and non-principal staff roles
        await tx.userDepartment.deleteMany({ where: { userId } });
        await tx.userRole.deleteMany({
          where: {
            userId,
            role: {
              code: {
                notIn: ["PRINCIPAL", "STUDENT", "PARENT_GUARDIAN", "ALUMNI"],
              },
            },
          },
        });

        if (isHead) {
          await tx.userDepartment.updateMany({
            where: { departmentId, isHead: true },
            data: { isHead: false },
          });
        }

        await tx.userDepartment.create({
          data: { userId, departmentId, isHead },
        });

        await tx.userRole.create({
          data: {
            userId,
            roleId: operationalRole.id,
            assignedBy: actor.id,
          },
        });

        await tx.auditLog.create({
          data: {
            userId: actor.id,
            action: "DEPARTMENT_ASSIGN",
            entity: "UserDepartment",
            entityId: userId,
            metadataJson: JSON.stringify({
              departmentId,
              department: department.name,
              roleCode,
              isHead,
              targetEmail: target.email,
            }),
          },
        });
      });
    } else {
      await db.$transaction(async (tx) => {
        await tx.userDepartment.deleteMany({ where: { userId, departmentId } });
        await tx.userRole.deleteMany({
          where: { userId, roleId: operationalRole.id },
        });
        await tx.auditLog.create({
          data: {
            userId: actor.id,
            action: "DEPARTMENT_REMOVE",
            entity: "UserDepartment",
            entityId: userId,
            metadataJson: JSON.stringify({
              departmentId,
              department: department.name,
              targetEmail: target.email,
            }),
          },
        });
      });
    }

    return NextResponse.json({ ok: true, roleCode });
  } catch (error) {
    console.error("[departments API]", error);
    return NextResponse.json(
      { error: error instanceof Error ? error.message : "Server error" },
      { status: 500 }
    );
  }
}
