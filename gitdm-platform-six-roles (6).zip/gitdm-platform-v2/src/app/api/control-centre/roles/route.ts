import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/access";

export const runtime = "nodejs";

export async function POST() {
  const actor = await getCurrentUser();
  if (!actor) return NextResponse.json({ error: "Not authenticated" }, { status: 401 });
  const isPrincipal = actor.roles.some((item) => item.role.code === "PRINCIPAL");
  if (isPrincipal) return NextResponse.json({ error: "Individual role assignment is disabled. Assign the person to a department; shared departmental permissions are provisioned automatically, and each action is attributed to the signed-in staff member." }, { status: 403 });
  return NextResponse.json({ error: "Role assignment is disabled. Use department membership." }, { status: 403 });
}
