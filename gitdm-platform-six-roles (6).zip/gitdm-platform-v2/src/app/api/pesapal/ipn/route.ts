import { NextRequest } from "next/server";
import {
  GET as handlePesapalGet,
  POST as handlePesapalPost,
} from "@/app/api/payments/pesapal/ipn/route";

// Public Pesapal IPN endpoint used by the GITDM merchant configuration.
// Keep the canonical implementation under /api/payments/pesapal/ipn and
// expose this shorter URL as an alias.
export const dynamic = "force-dynamic";

export async function GET(request: NextRequest) {
  return handlePesapalGet(request);
}

export async function POST(request: NextRequest) {
  return handlePesapalPost(request);
}
