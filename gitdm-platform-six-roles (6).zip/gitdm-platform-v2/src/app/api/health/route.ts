import { NextResponse } from "next/server";

export const runtime = "nodejs";

const CORE_TABLES = [
  "User",
  "Role",
  "UserRole",
  "Programme",
  "AcademicPeriod",
  "Course",
  "CourseModule",
  "Lesson",
  "Enrollment",
  "Application",
  "Department",
  "UserDepartment",
  "StaffInvitation",
];

export async function GET() {
  const checks: Record<string, unknown> = {
    app: "ok",
    database: process.env.DATABASE_URL ? "not_checked" : "not_configured",
    auth: {
      neonAuthUrl: Boolean(process.env.NEON_AUTH_BASE_URL),
      cookieSecret: Boolean(process.env.NEON_AUTH_COOKIE_SECRET),
    },
    storage: {
      bucket: Boolean(process.env.NEON_STORAGE_BUCKET),
      endpoint: Boolean(process.env.AWS_ENDPOINT_URL_S3),
      accessKey: Boolean(process.env.AWS_ACCESS_KEY_ID),
      secretKey: Boolean(process.env.AWS_SECRET_ACCESS_KEY),
    },
  };

  if (process.env.DATABASE_URL) {
    try {
      const { getDb } = await import("@/lib/db");
      const db = getDb();
      if (!db) throw new Error("DATABASE_URL is unavailable at runtime.");

      await db.$queryRaw`SELECT 1`;
      const tableRows = await db.$queryRaw<Array<{ table_name: string }>>`
        SELECT table_name
        FROM information_schema.tables
        WHERE table_schema = 'public'
          AND table_name = ANY(${CORE_TABLES})
      `;
      const present = new Set(tableRows.map((row) => row.table_name));
      const missing = CORE_TABLES.filter((name) => !present.has(name));

      checks.database = "ok";
      checks.schema = {
        coreTables: missing.length ? "incomplete" : "ok",
        missingTables: missing,
      };
    } catch (error) {
      checks.database = "error";
      checks.databaseError = error instanceof Error ? error.message : String(error);
    }
  }

  const databaseHealthy = checks.database !== "error" && checks.database !== "not_configured";
  const authConfig = checks.auth as Record<string, boolean>;
  const authHealthy = authConfig.neonAuthUrl && authConfig.cookieSecret;

  const healthy = checks.app === "ok" && databaseHealthy && authHealthy;

  return NextResponse.json(
    {
      service: "GITDM Platform",
      version: "1.0.0",
      timestamp: new Date().toISOString(),
      checks,
    },
    { status: healthy ? 200 : 503 },
  );
}
