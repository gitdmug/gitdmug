import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/access";
import { getDb } from "@/lib/db";
import { generateWithCascade, keysPresentSummary } from "@/lib/ai-providers";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const cleanSymbol = (s: string) => s.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 24);

const safeJson = async (url: string) => {
  const r = await fetch(url, { cache: "no-store", signal: AbortSignal.timeout(9000) });
  if (!r.ok) throw new Error(`Feed returned ${r.status}`);
  return r.json();
};

function deriveLevels(last: number, buyPercent: number, timeframe?: string) {
  // Wider educational distances so outcomes cannot "win" instantly on noise
  const tf = String(timeframe || "").toLowerCase();
  let riskPct = 0.006; // day default ~0.6%
  if (/scalp|minute|m1|m5|m15/.test(tf)) riskPct = 0.0025;
  else if (/swing|days/.test(tf)) riskPct = 0.012;
  else if (/position|week/.test(tf)) riskPct = 0.025;
  const risk = Math.max(last * riskPct, last * 0.0003);
  const reward = risk * 1.8;
  if (buyPercent >= 55) {
    return { entry: last, stopLoss: +(last - risk).toFixed(6), takeProfit: +(last + reward).toFixed(6) };
  }
  if (buyPercent <= 45) {
    return { entry: last, stopLoss: +(last + risk).toFixed(6), takeProfit: +(last - reward).toFixed(6) };
  }
  return { entry: last, stopLoss: +(last - risk).toFixed(6), takeProfit: +(last + reward).toFixed(6) };
}

function normalizeTimeframe(raw: string) {
  const t = raw.toLowerCase().trim();
  if (/scalp/.test(t)) return "Scalping (minutes–hours)";
  if (/day|intraday/.test(t)) return "Day trading (hours–1 day)";
  if (/swing/.test(t)) return "Swing (days–weeks)";
  if (/position/.test(t)) return "Position (weeks–months)";
  if (t) return raw.slice(0, 80);
  return "Day trading (hours–1 day)";
}

export async function POST(req: Request) {
  try {
    const user = await getCurrentUser();
    if (!user) {
      return NextResponse.json(
        { error: "Create a free GITDM account or sign in to use AI instrument analysis." },
        { status: 401 }
      );
    }

    const fd = await req.formData();
    const symbolInput = String(fd.get("symbol") || "").trim().slice(0, 40);
    const symbol = cleanSymbol(symbolInput);
    const timeframeInput = String(fd.get("timeframe") || "day").trim();
    const requestedTimeframe = normalizeTimeframe(timeframeInput);
    if (!symbol) {
      return NextResponse.json(
        { error: "Enter a valid instrument symbol, for example EURUSD, XAUUSD or BTCUSD." },
        { status: 400 }
      );
    }

    const file = fd.get("chart");
    let imageBase64: { mime: string; data: string } | undefined;
    if (file instanceof File && file.size) {
      if (file.size > 5 * 1024 * 1024) {
        return NextResponse.json({ error: "Chart image must be 5 MB or smaller." }, { status: 413 });
      }
      if (!["image/png", "image/jpeg", "image/webp"].includes(file.type)) {
        return NextResponse.json({ error: "Upload a PNG, JPEG or WebP chart image." }, { status: 400 });
      }
      const b = Buffer.from(await file.arrayBuffer());
      imageBase64 = { mime: file.type, data: b.toString("base64") };
    }

    let marketContext =
      "Live quote context is unavailable; do not invent current prices or headlines.";
    let quoteValue: number | null = null;
    let newsHeadline = "";
    let newsSummary = "";
    let newsItems: { title: string; summary?: string }[] = [];

    try {
      const [qr, cr, nr] = await Promise.all([
        fetch(`https://biquote.io/api/${encodeURIComponent(symbol)}`, {
          cache: "no-store",
          signal: AbortSignal.timeout(6500),
        }),
        safeJson(`https://biquote.io/api/${encodeURIComponent(symbol)}/ohlc?interval=1h&limit=24`).catch(
          () => null
        ),
        safeJson(
          `https://biquote.io/api/news/market?symbol=${encodeURIComponent(symbol)}&language=en&maxResults=5`
        ).catch(() => null),
      ]);
      const q = qr.ok ? await qr.json() : null;
      const c = cr;
      const n = nr;
      const qv = q?.mid ?? q?.last ?? q?.lastPrice ?? q?.price ?? q?.close ?? q?.bid ?? q?.ask;
      if (qr.ok && q && typeof q === "object" && qv != null) {
        quoteValue = Number(qv);
        const bars = Array.isArray(c?.bars)
          ? c.bars.slice(0, 24).map((b: any) => ({
              t: b.openTime || b.time,
              o: b.open,
              h: b.high,
              l: b.low,
              c: b.close,
            }))
          : [];
        const headlines = Array.isArray(n)
          ? n
          : Array.isArray(n?.items)
            ? n.items
            : Array.isArray(n?.data)
              ? n.data
              : [];
        newsItems = headlines.slice(0, 5).map((h: any) => ({
          title: String(h.title || h.headline || "").slice(0, 200),
          summary: String(h.description || h.summary || "").slice(0, 300),
        }));
        if (newsItems[0]) {
          newsHeadline = newsItems[0].title;
          newsSummary = newsItems[0].summary || "";
        }
        marketContext = `Symbol ${symbol}. Quote mid/last ${qv}. Bid ${q.bid ?? "n/a"} Ask ${q.ask ?? "n/a"}. Timestamp ${q.timestamp || q.lastQuoteAt || "unknown"}. Recent hourly candles (up to 24): ${JSON.stringify(bars).slice(0, 1800)}. Recent headlines: ${JSON.stringify(newsItems).slice(0, 800)}.`;
      }
    } catch {
      // keep default
    }

    if (marketContext.includes("unavailable") && process.env.TWELVEDATA_API_KEY) {
      try {
        const fallbackKey = process.env.TWELVEDATA_API_KEY!;
        const [qr, tr] = await Promise.all([
          fetch(
            `https://api.twelvedata.com/quote?symbol=${encodeURIComponent(symbolInput)}&apikey=${encodeURIComponent(fallbackKey)}`,
            { cache: "no-store", signal: AbortSignal.timeout(9000) }
          ),
          fetch(
            `https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(symbolInput)}&interval=1h&outputsize=24&apikey=${encodeURIComponent(fallbackKey)}`,
            { cache: "no-store", signal: AbortSignal.timeout(9000) }
          ),
        ]);
        const q = qr.ok ? await qr.json() : null;
        const t = tr.ok ? await tr.json() : null;
        if (q?.close || q?.price) {
          quoteValue = Number(q.close || q.price);
          marketContext = `Symbol ${symbolInput}. Twelve Data quote close ${q.close || q.price}. Time series sample: ${JSON.stringify((t?.values || []).slice(0, 12)).slice(0, 1200)}.`;
        }
      } catch {
        // ignore
      }
    }

    const systemPrompt = `You are GITDM Market Research Assistant. Produce educational analysis only — never personalised investment advice or guaranteed forecasts.
Structure your reply as clear sections:
1) TECHNICAL VIEW — price structure, trend, momentum, key levels from the supplied candles/quote.
2) FUNDAMENTAL VIEW — macro, rates, commodities or corporate drivers relevant to the instrument; use supplied headlines when present.
3) SENTIMENTAL VIEW — market tone from headlines and recent price action (risk-on/off, positioning bias).
4) SCENARIO WEIGHTS — educational buy-side % and sell-side % that sum to 100, for the trader timeframe: ${requestedTimeframe}.
5) EDUCATIONAL LEVELS — suggested entry reference, stop-loss and take-profit distances framed as study levels only.
End with a short JSON block on its own line:
{"buyPercent":N,"sellPercent":N,"timeframe":"...","summary":"...","entry":N,"stopLoss":N,"takeProfit":N}
Be precise. Never fabricate current prices not present in the context.`;

    const userPrompt = `Instrument: ${symbolInput}\nTrader timeframe: ${requestedTimeframe}\n\nMarket context:\n${marketContext}\n\nProduce the full technical + fundamental + sentimental educational review for this timeframe.`;

    const ai = await generateWithCascade({
      system: systemPrompt,
      user: userPrompt,
      imageBase64,
      maxTokens: 2400,
      temperature: 0.2,
    });

    let analysis = ai.text || "";
    let provider = ai.provider;
    let providerError = ai.error || "";

    // Parse optional trailing JSON
    let parsed: any = null;
    if (analysis) {
      const jsonMatch = analysis.match(/\{[\s\S]*"buyPercent"[\s\S]*\}/);
      if (jsonMatch) {
        try {
          parsed = JSON.parse(jsonMatch[0]);
        } catch {
          // ignore
        }
      }
    }

    // Data-derived fallback so clients always get a complete result
    if (!analysis.trim()) {
      let candles: any[] = [];
      try {
        const raw = await safeJson(
          `https://biquote.io/api/${encodeURIComponent(symbol)}/ohlc?interval=1h&limit=48`
        );
        candles = Array.isArray(raw?.bars) ? raw.bars : Array.isArray(raw) ? raw : [];
      } catch {
        // ignore
      }
      const valid = candles
        .map((b: any) => ({
          open: Number(b.open),
          high: Number(b.high),
          low: Number(b.low),
          close: Number(b.close),
        }))
        .filter((b: any) => [b.open, b.high, b.low, b.close].every(Number.isFinite) && b.close > 0);

      if (valid.length >= 6) {
        const closes = valid.map((b: any) => b.close);
        const last = closes[closes.length - 1];
        const first = closes[0];
        const short = closes.slice(-6);
        const move = ((last - first) / first) * 100;
        const recentMove = ((short[short.length - 1] - short[0]) / short[0]) * 100;
        const trendScore = Math.max(-18, Math.min(18, move * 3 + recentMove * 2));
        const buy = Math.max(15, Math.min(85, Math.round(50 + trendScore)));
        const sell = 100 - buy;
        const bias =
          buy > 58 ? "Bullish scenario" : sell > 58 ? "Bearish scenario" : "Balanced scenario";
        const levels = deriveLevels(last, buy, requestedTimeframe);
        analysis = `DATA-DERIVED EDUCATIONAL REVIEW (AI providers unavailable)\n\nInstrument: ${symbolInput}\nCandles used: ${valid.length} hourly bars.\nNet move: ${move.toFixed(2)}%. Recent 6-bar move: ${recentMove.toFixed(2)}%.\n\nTECHNICAL VIEW\n- Structure inferred only from supplied closes and ranges.\n- Trend score (bounded heuristic): ${trendScore.toFixed(1)}.\n\nFUNDAMENTAL VIEW\n- No live fundamental feed in this fallback mode. Review official economic calendar and primary sources.\n\nSENTIMENTAL VIEW\n- Price action alone suggests ${bias.toLowerCase()}. Headlines were ${newsHeadline ? "partially available" : "not available"}.\n\nSCENARIO WEIGHTS (conditional, educational only)\n- Buy-side: ${buy}%\n- Sell-side: ${sell}%\n\nEDUCATIONAL LEVELS\n- Entry reference: ${levels.entry}\n- Stop-loss study level: ${levels.stopLoss}\n- Take-profit study level: ${levels.takeProfit}\n\nLIMITATIONS\n${providerError ? `AI providers: ${providerError}. ` : ""}Heuristic only — not a calibrated forecast.`;
        provider = "data-derived";
        const payload = {
          analysis,
          buyPercent: buy,
          sellPercent: sell,
          timeframe: requestedTimeframe,
          summary: `Data-derived scenario review for ${symbolInput}. Weights are heuristic from recent candles.`,
          bias,
          entryPrice: levels.entry,
          stopLoss: levels.stopLoss,
          takeProfit: levels.takeProfit,
          retrievedAt: new Date().toISOString(),
          mode: "data-derived",
          provider,
          reference: "MI-AI-001",
          keysDetected: keysPresentSummary(),
        };
        await persistRun(user.id, symbol, payload, quoteValue ?? levels.entry);
        return NextResponse.json(payload);
      }

      return NextResponse.json(
        {
          error: `Analysis is temporarily unavailable. ${providerError || "No provider keys returned content."} Reference: MI-AI-001`,
          code: "MI-AI-001",
          keysDetected: keysPresentSummary(),
        },
        { status: 502 }
      );
    }

    let buy = 50;
    let sell = 50;
    let timeframe = requestedTimeframe;
    let summary = `Educational scenario review for ${symbolInput}.`;
    let bias = "Balanced review";
    let entryPrice = quoteValue;
    let stopLoss: number | null = null;
    let takeProfit: number | null = null;

    if (parsed) {
      buy = Math.max(0, Math.min(100, Math.round(Number(parsed.buyPercent) || 50)));
      sell = 100 - buy;
      timeframe = String(parsed.timeframe || timeframe);
      summary = String(parsed.summary || summary);
      if (Number.isFinite(Number(parsed.entry))) entryPrice = Number(parsed.entry);
      if (Number.isFinite(Number(parsed.stopLoss))) stopLoss = Number(parsed.stopLoss);
      if (Number.isFinite(Number(parsed.takeProfit))) takeProfit = Number(parsed.takeProfit);
    } else {
      buy = /bearish/i.test(analysis) ? 35 : /bullish/i.test(analysis) ? 65 : 50;
      sell = 100 - buy;
    }
    bias = buy > sell ? "Bullish scenario" : sell > buy ? "Bearish scenario" : "Balanced scenario";

    if (entryPrice != null && (stopLoss == null || takeProfit == null)) {
      const levels = deriveLevels(entryPrice, buy, requestedTimeframe);
      stopLoss = stopLoss ?? levels.stopLoss;
      takeProfit = takeProfit ?? levels.takeProfit;
      entryPrice = entryPrice ?? levels.entry;
    }

    const result = {
      analysis,
      buyPercent: buy,
      sellPercent: sell,
      timeframe,
      summary,
      bias,
      entryPrice: entryPrice ?? null,
      stopLoss,
      takeProfit,
      retrievedAt: new Date().toISOString(),
      provider,
      keysDetected: keysPresentSummary(),
    };

    await persistRun(user.id, symbol, result, entryPrice ?? quoteValue);
    return NextResponse.json(result);
  } catch (e) {
    console.error("Market analysis request failed", e);
    return NextResponse.json(
      {
        error:
          "The analysis timed out or could not be processed. Please retry, or contact GITDM support if it continues.",
      },
      { status: 500 }
    );
  }
}

async function persistRun(
  userId: string,
  symbol: string,
  result: any,
  entryPrice?: number | null
) {
  try {
    const db = getDb();
    if (!db) return;
    const entry = entryPrice != null && Number.isFinite(Number(entryPrice)) ? Number(entryPrice) : null;
    const sl = result.stopLoss != null && Number.isFinite(Number(result.stopLoss)) ? Number(result.stopLoss) : null;
    const tp = result.takeProfit != null && Number.isFinite(Number(result.takeProfit)) ? Number(result.takeProfit) : null;
    await db.marketAnalysisRun.create({
      data: {
        userId,
        symbol,
        bias: result.bias || null,
        buyPercent: Number(result.buyPercent) || 50,
        sellPercent: Number(result.sellPercent) || 50,
        timeframe: result.timeframe || null,
        summary: result.summary || null,
        analysisText: typeof result.analysis === "string" ? result.analysis.slice(0, 12000) : null,
        provider: result.provider || null,
        outcome: "PENDING",
        outcomeNote: result.summary || null,
        entryPrice: entry,
        stopLoss: sl,
        takeProfit: tp,
      },
    });
  } catch (err) {
    console.error("persist MarketAnalysisRun failed", err);
  }
}
