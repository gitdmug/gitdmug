import { NextResponse } from "next/server";
import { getDb } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

/** Educational economic calendar. DB → Finnhub → Alpha Vantage → curated placeholders. */
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const days = Math.min(30, Math.max(1, Number(searchParams.get("days") || 14)));
  const from = new Date();
  const to = new Date(Date.now() + days * 24 * 60 * 60 * 1000);

  const db = getDb();
  let events: any[] = [];

  if (db) {
    try {
      events = await db.economicCalendarEvent.findMany({
        where: { scheduledAt: { gte: from, lte: to } },
        orderBy: { scheduledAt: "asc" },
        take: 80,
      });
    } catch {
      // table may not exist until first migrate
    }
  }

  // Finnhub
  if (process.env.FINNHUB_API_KEY && events.length < 5) {
    try {
      const fromStr = from.toISOString().slice(0, 10);
      const toStr = to.toISOString().slice(0, 10);
      const r = await fetch(
        `https://finnhub.io/api/v1/calendar/economic?from=${fromStr}&to=${toStr}&token=${encodeURIComponent(process.env.FINNHUB_API_KEY)}`,
        { cache: "no-store", signal: AbortSignal.timeout(10000) }
      );
      if (r.ok) {
        const j = await r.json();
        const rows = Array.isArray(j?.economicCalendar) ? j.economicCalendar : [];
        if (rows.length) {
          events = rows.slice(0, 60).map((x: any, i: number) => ({
            id: `fh-${i}-${x.event}`,
            title: x.event,
            country: x.country,
            currency: x.currency || null,
            impact: String(x.impact || "").toUpperCase() || null,
            scheduledAt: x.time
              ? new Date(x.time * (x.time < 1e12 ? 1000 : 1)).toISOString()
              : null,
            actual: x.actual != null ? String(x.actual) : null,
            forecast: x.estimate != null ? String(x.estimate) : null,
            previous: x.prev != null ? String(x.prev) : null,
            source: "finnhub",
          }));
        }
      }
    } catch (e) {
      console.error("Economic calendar Finnhub fetch failed", e);
    }
  }

  // Alpha Vantage economic indicators / earnings calendar style fallback
  if (process.env.ALPHA_VANTAGE_API_KEY && events.length < 5) {
    try {
      const key = process.env.ALPHA_VANTAGE_API_KEY;
      // Earnings calendar as a useful proxy when economic calendar is empty
      const r = await fetch(
        `https://www.alphavantage.co/query?function=EARNINGS_CALENDAR&horizon=3month&apikey=${encodeURIComponent(key)}`,
        { cache: "no-store", signal: AbortSignal.timeout(12000) }
      );
      if (r.ok) {
        const text = await r.text();
        const lines = text.trim().split("\n");
        if (lines.length > 1) {
          const headers = lines[0].split(",");
          const idx = {
            symbol: headers.indexOf("symbol"),
            name: headers.indexOf("name"),
            reportDate: headers.indexOf("reportDate"),
            fiscalDateEnding: headers.indexOf("fiscalDateEnding"),
            estimate: headers.indexOf("estimate"),
            currency: headers.indexOf("currency"),
          };
          const mapped = lines
            .slice(1, 40)
            .map((line, i) => {
              const cols = line.split(",");
              const reportDate = cols[idx.reportDate] || cols[idx.fiscalDateEnding];
              if (!reportDate) return null;
              const d = new Date(reportDate);
              if (Number.isNaN(d.getTime()) || d < from || d > to) return null;
              return {
                id: `av-${i}-${cols[idx.symbol]}`,
                title: `Earnings: ${cols[idx.name] || cols[idx.symbol]} (${cols[idx.symbol]})`,
                country: null,
                currency: cols[idx.currency] || "USD",
                impact: "MEDIUM",
                scheduledAt: d.toISOString(),
                actual: null,
                forecast: cols[idx.estimate] || null,
                previous: null,
                source: "alpha-vantage",
              };
            })
            .filter(Boolean);
          if (mapped.length) events = mapped as any[];
        }
      }
    } catch (e) {
      console.error("Economic calendar Alpha Vantage fetch failed", e);
    }
  }

  // Always merge curated major events so NFP, CPI, FOMC, etc. appear even when live feeds are thin
  {
    const base = Date.now();
    const day = 86400000;
    // Next approximate Friday 13:30 UTC for NFP-style scheduling (educational)
    const nextFriday = new Date(base);
    nextFriday.setUTCDate(nextFriday.getUTCDate() + ((5 - nextFriday.getUTCDay() + 7) % 7 || 7));
    nextFriday.setUTCHours(12, 30, 0, 0);
    const curated = [
      { id: "edu-nfp", title: "US Non-Farm Payrolls (NFP)", country: "US", currency: "USD", impact: "HIGH", scheduledAt: nextFriday.toISOString(), forecast: "—", previous: "—", source: "gitdm-curated" },
      { id: "edu-unemp", title: "US Unemployment Rate", country: "US", currency: "USD", impact: "HIGH", scheduledAt: nextFriday.toISOString(), forecast: "—", previous: "—", source: "gitdm-curated" },
      { id: "edu-cpi", title: "US CPI (Consumer Price Index)", country: "US", currency: "USD", impact: "HIGH", scheduledAt: new Date(base + 4 * day).toISOString(), forecast: "—", previous: "—", source: "gitdm-curated" },
      { id: "edu-fomc", title: "FOMC Interest Rate Decision", country: "US", currency: "USD", impact: "HIGH", scheduledAt: new Date(base + 10 * day).toISOString(), forecast: "—", previous: "—", source: "gitdm-curated" },
      { id: "edu-gdp", title: "US GDP (QoQ)", country: "US", currency: "USD", impact: "HIGH", scheduledAt: new Date(base + 12 * day).toISOString(), forecast: "—", previous: "—", source: "gitdm-curated" },
      { id: "edu-ecb", title: "ECB Interest Rate Decision", country: "EU", currency: "EUR", impact: "HIGH", scheduledAt: new Date(base + 6 * day).toISOString(), forecast: "—", previous: "—", source: "gitdm-curated" },
      { id: "edu-ukcpi", title: "UK CPI", country: "GB", currency: "GBP", impact: "HIGH", scheduledAt: new Date(base + 5 * day).toISOString(), forecast: "—", previous: "—", source: "gitdm-curated" },
      { id: "edu-boe", title: "Bank of England Rate Decision", country: "GB", currency: "GBP", impact: "HIGH", scheduledAt: new Date(base + 9 * day).toISOString(), forecast: "—", previous: "—", source: "gitdm-curated" },
      { id: "edu-boj", title: "Bank of Japan Policy Rate", country: "JP", currency: "JPY", impact: "HIGH", scheduledAt: new Date(base + 8 * day).toISOString(), forecast: "—", previous: "—", source: "gitdm-curated" },
      { id: "edu-retail", title: "US Retail Sales", country: "US", currency: "USD", impact: "MEDIUM", scheduledAt: new Date(base + 7 * day).toISOString(), forecast: "—", previous: "—", source: "gitdm-curated" },
      { id: "edu-pmi", title: "US ISM Manufacturing PMI", country: "US", currency: "USD", impact: "MEDIUM", scheduledAt: new Date(base + 3 * day).toISOString(), forecast: "—", previous: "—", source: "gitdm-curated" },
      { id: "edu-crude", title: "EIA Crude Oil Inventories", country: "US", currency: "USD", impact: "MEDIUM", scheduledAt: new Date(base + 2 * day).toISOString(), forecast: "—", previous: "—", source: "gitdm-curated" },
    ];
    const existingTitles = new Set(events.map((e: any) => String(e.title || "").toLowerCase()));
    for (const c of curated) {
      const key = c.title.toLowerCase().replace(/\s*\(.*?\)/g, "").trim();
      const already = [...existingTitles].some((t) => t.includes(key.split(" ")[0]) && t.includes(key.split(" ").slice(-1)[0]));
      if (!already) {
        events.push(c);
        existingTitles.add(c.title.toLowerCase());
      }
    }
    events.sort((a: any, b: any) => new Date(a.scheduledAt || 0).getTime() - new Date(b.scheduledAt || 0).getTime());
  }

  return NextResponse.json({
    from: from.toISOString(),
    to: to.toISOString(),
    events,
    sources: {
      finnhub: Boolean(process.env.FINNHUB_API_KEY),
      alphaVantage: Boolean(process.env.ALPHA_VANTAGE_API_KEY),
      curated: true,
    },
  });
}
