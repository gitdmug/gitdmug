import { NextResponse } from "next/server";
import { getCurrentUser } from "@/lib/access";
import { getDb } from "@/lib/db";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

async function livePrice(symbol: string): Promise<number | null> {
  try {
    const r = await fetch(`https://biquote.io/api/${encodeURIComponent(symbol)}`, {
      cache: "no-store",
      signal: AbortSignal.timeout(6000),
    });
    if (!r.ok) return null;
    const q = await r.json();
    const v = q?.mid ?? q?.last ?? q?.lastPrice ?? q?.price ?? q?.close;
    const n = Number(v);
    return Number.isFinite(n) ? n : null;
  } catch {
    return null;
  }
}

function minAgeMs(timeframe?: string | null): number {
  const t = String(timeframe || "").toLowerCase();
  if (/scalp|minute|m1|m5|m15/.test(t)) return 15 * 60 * 1000;
  if (/day|intraday|hours|h1|h4/.test(t)) return 2 * 60 * 60 * 1000;
  if (/swing|days/.test(t)) return 24 * 60 * 60 * 1000;
  if (/position|week/.test(t)) return 3 * 24 * 60 * 60 * 1000;
  return 60 * 60 * 1000;
}

async function autoResolvePending(db: NonNullable<ReturnType<typeof getDb>>, userId?: string) {
  try {
    const pending = await db.marketAnalysisRun.findMany({
      where: {
        outcome: "PENDING",
        ...(userId ? { userId } : {}),
        createdAt: { gte: new Date(Date.now() - 30 * 86400000) },
      },
      take: 40,
      orderBy: { createdAt: "asc" },
    });

    const now = Date.now();
    for (const run of pending) {
      const entry = run.entryPrice != null ? Number(run.entryPrice) : null;
      const sl = run.stopLoss != null ? Number(run.stopLoss) : null;
      const tp = run.takeProfit != null ? Number(run.takeProfit) : null;
      if (entry == null || sl == null || tp == null) continue;
      if (!Number.isFinite(entry) || !Number.isFinite(sl) || !Number.isFinite(tp)) continue;

      const age = now - new Date(run.createdAt).getTime();
      if (age < minAgeMs(run.timeframe)) continue;

      const price = await livePrice(run.symbol);
      if (price == null) continue;

      const span = Math.abs(tp - sl) || Math.abs(entry) * 0.001;
      const epsilon = Math.max(span * 0.02, Math.abs(entry) * 0.00005);
      if (Math.abs(price - entry) < epsilon) continue;

      const buyBias = (run.buyPercent ?? 50) >= 50;
      let outcome: "WIN" | "LOSS" | null = null;

      if (buyBias) {
        if (tp > entry && price >= tp) outcome = "WIN";
        else if (sl < entry && price <= sl) outcome = "LOSS";
        else if (tp < entry && price <= tp) outcome = "WIN";
        else if (sl > entry && price >= sl) outcome = "LOSS";
      } else {
        if (tp < entry && price <= tp) outcome = "WIN";
        else if (sl > entry && price >= sl) outcome = "LOSS";
        else if (tp > entry && price >= tp) outcome = "WIN";
        else if (sl < entry && price <= sl) outcome = "LOSS";
      }

      if (!outcome) continue;

      await db.marketAnalysisRun.update({
        where: { id: run.id },
        data: {
          outcome,
          outcomeAt: new Date(),
          resolvedAt: new Date(),
          outcomeNote: `Auto-resolved after ${Math.round(age / 60000)}m vs live ${price} (entry ${entry}, SL ${sl}, TP ${tp})`,
        },
      });
    }
  } catch (e) {
    console.error("autoResolvePending", e);
  }
}

export async function GET(req: Request) {
  const db = getDb();
  if (!db) {
    return NextResponse.json({ error: "Database unavailable" }, { status: 503 });
  }

  const { searchParams } = new URL(req.url);
  const period = (searchParams.get("period") || "month").toLowerCase();
  const limit = Math.min(500, Math.max(1, Number(searchParams.get("limit") || 50)));
  const symbolFilter = String(searchParams.get("symbol") || "")
    .toUpperCase()
    .replace(/[^A-Z0-9]/g, "");
  const days =
    period === "day"
      ? 1
      : period === "week"
        ? 7
        : period === "quarter"
          ? 90
          : period === "year"
            ? 365
            : period === "all"
              ? 3650
              : 30;
  const since = new Date(Date.now() - days * 24 * 60 * 60 * 1000);

  const user = await getCurrentUser();
  if (user) await autoResolvePending(db, user.id);

  const personalWhere: any = {
    createdAt: { gte: since },
    ...(user ? { userId: user.id } : { userId: "__none__" }),
    ...(symbolFilter ? { symbol: { contains: symbolFilter, mode: "insensitive" } } : {}),
  };

  const [publicAgg, personal, recent] = await Promise.all([
    db.marketAnalysisRun.groupBy({
      by: ["outcome"],
      where: { createdAt: { gte: since } },
      _count: { _all: true },
    }),
    user
      ? db.marketAnalysisRun.findMany({
          where: personalWhere,
          orderBy: { createdAt: "desc" },
          take: limit,
          select: {
            id: true,
            symbol: true,
            bias: true,
            buyPercent: true,
            sellPercent: true,
            timeframe: true,
            summary: true,
            provider: true,
            outcome: true,
            outcomeNote: true,
            retrievedAt: true,
            createdAt: true,
            entryPrice: true,
            stopLoss: true,
            takeProfit: true,
            resolvedAt: true,
          },
        })
      : Promise.resolve([]),
    db.marketAnalysisRun.findMany({
      where: { createdAt: { gte: since }, outcome: { in: ["WIN", "LOSS", "NEUTRAL"] } },
      orderBy: { createdAt: "desc" },
      take: 20,
      select: {
        symbol: true,
        bias: true,
        outcome: true,
        createdAt: true,
        provider: true,
      },
    }),
  ]);

  const counts: Record<string, number> = { PENDING: 0, WIN: 0, LOSS: 0, NEUTRAL: 0 };
  for (const row of publicAgg) {
    counts[row.outcome || "PENDING"] = row._count._all;
  }
  const resolved = counts.WIN + counts.LOSS + counts.NEUTRAL;
  const winRate = resolved > 0 ? Math.round((counts.WIN / resolved) * 1000) / 10 : null;

  return NextResponse.json({
    period,
    since: since.toISOString(),
    public: {
      totalRuns: Object.values(counts).reduce((a, b) => a + b, 0),
      pending: counts.PENDING,
      wins: counts.WIN,
      losses: counts.LOSS,
      neutral: counts.NEUTRAL,
      verifiedWinRatePercent: winRate,
    },
    personal,
    recent,
  });
}

export async function POST(req: Request) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Sign in required" }, { status: 401 });
  const db = getDb();
  if (!db) return NextResponse.json({ error: "Database unavailable" }, { status: 503 });

  const body = await req.json().catch(() => ({}));
  const id = String(body.id || "");
  const outcome = String(body.outcome || "").toUpperCase();
  if (!id || !["WIN", "LOSS", "NEUTRAL", "PENDING"].includes(outcome)) {
    return NextResponse.json({ error: "Invalid id or outcome" }, { status: 400 });
  }
  const run = await db.marketAnalysisRun.findFirst({ where: { id, userId: user.id } });
  if (!run) return NextResponse.json({ error: "Not found" }, { status: 404 });
  await db.marketAnalysisRun.update({
    where: { id },
    data: {
      outcome,
      outcomeAt: new Date(),
      outcomeNote: body.note ? String(body.note).slice(0, 400) : run.outcomeNote,
      ...(outcome !== "PENDING" ? { resolvedAt: new Date() } : { resolvedAt: null }),
    },
  });
  return NextResponse.json({ ok: true });
}
