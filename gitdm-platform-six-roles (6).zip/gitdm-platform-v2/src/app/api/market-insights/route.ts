import { NextResponse } from "next/server";
export const dynamic = "force-dynamic";
export const revalidate = 0;
type Row = Record<string, any>;
const TYPES: Record<string, string> = { forex: "Forex", crypto: "Crypto", commodities: "Commodity", stocks: "Stock", indices: "Index" };
const clean = (s: string) => s.toUpperCase().replace(/[^A-Z0-9]/g, "").slice(0, 24);
async function json(url: string, timeout = 9000): Promise<any> {
  const response = await fetch(url, { cache: "no-store", signal: AbortSignal.timeout(timeout), headers: { Accept: "application/json" } });
  if (!response.ok) throw new Error(`Market feed returned HTTP ${response.status}`);
  return response.json();
}
function rows(payload: any): Row[] {
  if (Array.isArray(payload)) return payload;
  for (const key of ["items", "symbols", "data", "results", "quotes", "bars", "values"]) if (Array.isArray(payload?.[key])) return payload[key];
  return [];
}
function quoteRow(q: Row, fallbackSymbol?: string, type?: string) {
  const symbol = q.symbol || q.name || fallbackSymbol;
  const price = q.mid ?? q.lastPrice ?? q.last ?? q.price ?? q.close ?? q.bid ?? q.ask;
  if (!symbol || price == null || !Number.isFinite(Number(price))) return null;
  const change = q.changePercent ?? q.dayDiffPercent ?? q.percent_change;
  return { symbol, description: q.description || q.name || symbol, price: Number(price), percent: change == null ? undefined : `${Number(change) >= 0 ? "+" : ""}${Number(change).toFixed(2)}%`, changePercent: change == null ? undefined : Number(change), type: q.type || type || "Instrument", bid: q.bid, ask: q.ask, timestamp: q.timestamp || q.lastQuoteAt };
}
async function biquoteQuote(symbol: string) { return json(`https://biquote.io/api/${encodeURIComponent(clean(symbol))}`, 7000); }
async function catalogue(type?: string, search?: string): Promise<Row[]> {
  const url = search
    ? `https://biquote.io/api/symbols/search?q=${encodeURIComponent(search)}&limit=50`
    : `https://biquote.io/api/symbols?${type ? `type=${encodeURIComponent(type)}&` : ""}quotedWithinDays=7&limit=200`;
  return rows(await json(url, 10000));
}
export async function GET(req: Request) {
  const { searchParams } = new URL(req.url);
  const symbolInput = searchParams.get("symbol");
  const search = (searchParams.get("search") || "").trim().slice(0, 80);
  const category = (searchParams.get("category") || "all").toLowerCase();
  if (search) {
    try {
      const matches = await catalogue(undefined, search);
      return NextResponse.json({ instruments: matches.map((x) => ({ symbol: x.symbol || x.name, description: x.description || x.name || x.symbol, type: x.type || x.assetClass, exchange: x.exchange, isActive: x.isActive })).filter((x) => x.symbol).slice(0, 50), updatedAt: new Date().toISOString() });
    } catch (error) {
      console.error("Instrument search failed [MI-DATA-002]", error instanceof Error ? error.message : "unknown");
      return NextResponse.json({ error: "Instrument search is temporarily unavailable. Please retry shortly. Reference: MI-DATA-002." }, { status: 502 });
    }
  }
  if (symbolInput) {
    const symbol = clean(symbolInput);
    if (!symbol) return NextResponse.json({ error: "Enter a valid instrument symbol." }, { status: 400 });
    try {
      const [tick, candleData] = await Promise.all([biquoteQuote(symbol), json(`https://biquote.io/api/${encodeURIComponent(symbol)}/ohlc?interval=1h&limit=100`, 10000).catch(() => null)]);
      const instrument = quoteRow(tick, symbol);
      if (!instrument) throw new Error("BiQuote returned no valid quote");
      return NextResponse.json({ instrument: { ...tick, ...instrument, symbol: tick.symbol || symbol }, candles: rows(candleData), updatedAt: new Date().toISOString(), notice: tick.marketState === "closed" || tick.stale ? "Market is closed or the quote is stale; this is the last known price, not a live tick." : undefined });
    } catch (error) {
      console.error("Instrument quote failed [MI-DATA-003]", symbol);
      const key = process.env.TWELVEDATA_API_KEY;
      if (key) {
        try {
          const [q, t] = await Promise.all([json(`https://api.twelvedata.com/quote?symbol=${encodeURIComponent(symbolInput)}&apikey=${encodeURIComponent(key)}`), json(`https://api.twelvedata.com/time_series?symbol=${encodeURIComponent(symbolInput)}&interval=1h&outputsize=100&apikey=${encodeURIComponent(key)}`).catch(() => null)]);
          if (q.status !== "error" && q.close != null) return NextResponse.json({ instrument: { symbol, description: q.name || symbol, mid: Number(q.close), last: Number(q.close), bid: null, ask: null, high: Number(q.high), low: Number(q.low), dayDiffPercent: Number(q.percent_change), marketState: q.is_market_open === false ? "closed" : "unknown", timestamp: q.datetime }, candles: rows(t).map((b) => ({ openTime: b.datetime, open: Number(b.open), high: Number(b.high), low: Number(b.low), close: Number(b.close) })), updatedAt: new Date().toISOString(), notice: "Backup market feed used; coverage and freshness may vary." });
        } catch (fallbackError) { console.error("Backup quote failed [MI-DATA-006]"); }
      }
      return NextResponse.json({ error: `No quote is available for ${symbolInput}. No recent quote is available for this instrument. Try another symbol or retry later. Reference: MI-DATA-003.` }, { status: 502 });
    }
  }

  const types = category === "all" ? Object.values(TYPES) : [TYPES[category] || "Forex"];
  let quotes: Row[] = [];
  let provider = "primary";
  let notice = "Market prices may be delayed; closed markets can show the last known quote.";
  // First use the provider's documented market movers endpoints.
  for (const type of types) {
    try {
      const [g, l] = await Promise.all([
        json(`https://biquote.io/api/market/gainers?type=${encodeURIComponent(type)}&limit=20&period=1D`),
        json(`https://biquote.io/api/market/losers?type=${encodeURIComponent(type)}&limit=20&period=1D`),
      ]);
      quotes.push(...[...rows(g), ...rows(l)].map((x) => quoteRow(x, undefined, type)).filter(Boolean) as Row[]);
    } catch (error) { console.error("Market movers unavailable [MI-DATA-004]", type); }
  }
  // If movers are empty or their payload shape changes, use the documented instrument catalogue and live tick endpoint.
  if (!quotes.length) {
    try {
      const symbols = (await Promise.all(types.map((type) => catalogue(type)))).flat();
      const unique = [...new Map(symbols.map((x) => [clean(String(x.symbol || x.name || "")), x])).values()].filter((x) => clean(String(x.symbol || x.name || ""))).slice(0, 35);
      const live = await Promise.all(unique.map(async (x) => {
        const symbol = String(x.symbol || x.name);
        try { return quoteRow(await biquoteQuote(symbol), symbol, x.type); } catch { return null; }
      }));
      quotes = live.filter(Boolean) as Row[];
      if (quotes.length) notice = "Live quotes retrieved. Movement rankings are limited to available quote fields.";
    } catch (error) { console.error("Instrument catalogue fallback failed [MI-DATA-005]"); }
  }
  if (!quotes.length && process.env.TWELVEDATA_API_KEY) {
    provider = "backup";
    notice = "Using the configured backup market feed. Instrument coverage and freshness may vary.";
    const symbols = (process.env.GITDM_WATCHLIST || "EUR/USD,GBP/USD,USD/JPY,XAU/USD,BTC/USD,ETH/USD,AAPL,SPX,USOIL").split(",").map((x) => x.trim()).filter(Boolean).slice(0, 20);
    quotes = (await Promise.all(symbols.map(async (symbol) => { try { const q = await json(`https://api.twelvedata.com/quote?symbol=${encodeURIComponent(symbol)}&apikey=${encodeURIComponent(process.env.TWELVEDATA_API_KEY!)}`); return q.status === "error" ? null : quoteRow({ ...q, symbol, mid: q.close, dayDiffPercent: q.percent_change }, symbol); } catch { return null; } }))).filter(Boolean) as Row[];
  }
  quotes = [...new Map(quotes.map((q) => [q.symbol, q])).values()].sort((a, b) => Math.abs(Number(b.changePercent) || 0) - Math.abs(Number(a.changePercent) || 0)).slice(0, 30);
  let news: Row[] = [];
  const newsTypeMap: Record<string, string> = { forex: "forex", crypto: "crypto", commodities: "commodity", stocks: "stock", indices: "index" };
  const newsCat = category !== "all" ? (newsTypeMap[category] || category) : "";
  try {
    const newsUrl = newsCat
      ? `https://biquote.io/api/news/market?language=en&type=${encodeURIComponent(newsCat)}&maxResults=30`
      : "https://biquote.io/api/news/market?language=en&country=US&maxResults=30";
    news = rows(await json(newsUrl)).map((x) => ({ headline: x.title || x.headline, source: x.publisher || x.source, datetime: x.publishedDate || x.datetime, url: x.url, summary: x.description })).filter((x) => x.headline);
  } catch (error) {
    console.error("Market headlines unavailable [MI-NEWS-001]");
    const key = process.env.FINNHUB_API_KEY;
    const fhCat = category === "crypto" ? "crypto" : category === "stocks" || category === "indices" ? "general" : "forex";
    if (key) try { news = rows(await json(`https://finnhub.io/api/v1/news?category=${fhCat}&token=${encodeURIComponent(key)}`)).slice(0, 30).map((x) => ({ headline: x.headline, source: x.source, datetime: x.datetime ? new Date(x.datetime * 1000).toISOString() : undefined, url: x.url, summary: x.summary })); } catch (e) { console.error("Backup headlines failed [MI-NEWS-002]"); }
  }
  // Client-side keyword soft-filter when still on a specific asset class
  if (category !== "all" && news.length) {
    const keywords: Record<string, RegExp> = {
      forex: /forex|fx|eur|usd|gbp|jpy|currency|central bank|ecb|fed|boj|interest rate/i,
      crypto: /crypto|bitcoin|btc|ethereum|eth|token|blockchain|defi/i,
      commodities: /gold|oil|silver|commodity|crude|xau|metal|wheat/i,
      stocks: /stock|equity|earnings|nasdaq|s&p|share|ipo/i,
      indices: /index|indices|dow|s&p|nasdaq|ftse|dax/i,
    };
    const re = keywords[category];
    if (re) {
      const filtered = news.filter((n) => re.test(`${n.headline || ""} ${n.summary || ""}`));
      if (filtered.length >= 3) news = filtered;
    }
  }
  return NextResponse.json({ quotes, news, updatedAt: new Date().toISOString(), notice: quotes.length ? notice : "No live quotes were returned. Please retry later. Reference: MI-DATA-001.", categories: Object.keys(TYPES) });
}
