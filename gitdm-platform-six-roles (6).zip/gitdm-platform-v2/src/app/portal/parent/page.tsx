import Link from "next/link";
import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/access";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";

export const dynamic = "force-dynamic";

export default async function ParentPortal() {
  const user = await getCurrentUser();
  if (!user) redirect("/auth/login");
  const allowed = user.roles.some((r) => r.role.code === "PARENT_GUARDIAN");
  if (!allowed) redirect("/campus");
  const name = [user.firstName, user.lastName].filter(Boolean).join(" ") || user.email;
  return (
    <>
      <Header workspace="staff" />
      <main>
        <section className="page-hero"><div className="container">
          <div className="eyebrow">GITDM Parent / Guardian Portal</div>
          <h1>Parent / Guardian Portal</h1>
          <p>Welcome, {name}. Monitor the academic and support information shared with you by GITDM.</p>
        </div></section>
        <section className="section"><div className="container">
          <div className="grid grid-2">
            <div className="card"><h2>Your account</h2><p>{user.email}</p><p>Role: PARENT / GUARDIAN</p></div>
            <div className="card"><h2>Services</h2><p>This role has its own landing area and does not use the student dashboard.</p><Link href="/auth/logout" className="btn btn-outline-dark">Sign out</Link></div>
          </div>
        </div></section>
      </main>
      <Footer />
    </>
  );
}
