import { getDb } from "@/lib/db";
import { GITDM } from "@/lib/branding";
export const dynamic="force-dynamic";
export const metadata={title:`Certificate Verification | ${GITDM.shortName}`};
export default async function VerifyCertificate({searchParams}:{searchParams:Promise<{number?:string}>}){
 const {number}=await searchParams; const db=getDb(); const certificate=number&&db?await db.certificate.findUnique({where:{number},include:{user:true,programme:true,verification:true}}):null;
 return <main style={{maxWidth:760,margin:"60px auto",padding:"0 20px"}}><div className="card"><div className="eyebrow">GITDM Registry</div><h1>Certificate verification</h1><p>Enter a certificate number to verify an official GITDM credential.</p><form><input name="number" defaultValue={number||""} placeholder="GITDM-CERT-2026-..." required/><button className="btn btn-primary" style={{marginTop:12}}>Verify</button></form>{number?<div className="panel" style={{marginTop:24}}>{certificate?.status==="ISSUED"?<><span className="badge">VERIFIED</span><h2>{certificate.programme.name}</h2><p>Certificate number: <strong>{certificate.number}</strong></p><p>Issued to: <strong>{[certificate.user.firstName,certificate.user.lastName].filter(Boolean).join(" ")||"GITDM student"}</strong></p><p>Issued: {certificate.issuedAt?.toLocaleDateString("en-UG")}</p></>:<><span className="badge warn">NOT VERIFIED</span><p>No active GITDM certificate was found for that number.</p></>}</div>:null}</div></main>
}
