"use client";

import { useEffect, useState } from "react";

type BeforeInstallPromptEvent = Event & {
  prompt: () => Promise<void>;
  userChoice: Promise<{ outcome: "accepted" | "dismissed" }>;
};

export function InstallAppClient() {
  const [deferred, setDeferred] = useState<BeforeInstallPromptEvent | null>(null);
  const [installed, setInstalled] = useState(false);
  const [message, setMessage] = useState<string | null>(null);

  useEffect(() => {
    const onBip = (e: Event) => {
      e.preventDefault();
      setDeferred(e as BeforeInstallPromptEvent);
    };
    const onInstalled = () => {
      setInstalled(true);
      setDeferred(null);
    };
    window.addEventListener("beforeinstallprompt", onBip);
    window.addEventListener("appinstalled", onInstalled);
    if (window.matchMedia("(display-mode: standalone)").matches) {
      setInstalled(true);
    }
    return () => {
      window.removeEventListener("beforeinstallprompt", onBip);
      window.removeEventListener("appinstalled", onInstalled);
    };
  }, []);

  async function install() {
    if (!deferred) {
      setMessage("Use your browser menu: Install app / Add to Home Screen.");
      return;
    }
    await deferred.prompt();
    const choice = await deferred.userChoice;
    if (choice.outcome === "accepted") {
      setInstalled(true);
      setMessage("App installed.");
    }
    setDeferred(null);
  }

  return (
    <div className="card">
      <div className="eyebrow">Download / Install app</div>
      <h2>{installed ? "App is installed" : "Install on this device"}</h2>
      <p>
        Get quick access to admissions, campus learning, classes and finance from your home screen.
      </p>
      {!installed ? (
        <button className="btn btn-primary" type="button" onClick={install}>
          Install app
        </button>
      ) : (
        <span className="badge success">Installed on this device</span>
      )}
      {message ? <p className="muted" style={{ marginTop: 12 }}>{message}</p> : null}
    </div>
  );
}
