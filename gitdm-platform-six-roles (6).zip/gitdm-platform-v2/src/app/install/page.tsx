import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { GITDM } from "@/lib/branding";
import { InstallAppClient } from "./InstallAppClient";

export const metadata = {
  title: `Install app | ${GITDM.shortName}`,
  description: "Install the GITDM campus app on your phone or desktop from Chrome.",
};

export default function InstallPage() {
  return (
    <>
      <Header />
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">Mobile & desktop</div>
            <h1>Install the GITDM app</h1>
            <p>
              Add Global Institute of Trading and Derivatives Markets to your home screen. Works from
              Chrome on Android and desktop, and from Safari on iPhone (Add to Home Screen).
            </p>
          </div>
        </section>
        <section className="section">
          <div className="container" style={{ maxWidth: 720 }}>
            <InstallAppClient />
            <div className="card" style={{ marginTop: 28 }}>
              <h2>Android (Chrome)</h2>
              <ol>
                <li>Open this site in Chrome.</li>
                <li>Tap the menu (⋮) → <strong>Install app</strong> or <strong>Add to Home screen</strong>.</li>
                <li>Or use the Install button above when Chrome offers it.</li>
              </ol>
              <h2 style={{ marginTop: 24 }}>iPhone (Safari)</h2>
              <ol>
                <li>Open this site in Safari.</li>
                <li>Tap the Share button.</li>
                <li>Choose <strong>Add to Home Screen</strong>.</li>
              </ol>
              <h2 style={{ marginTop: 24 }}>Desktop (Chrome / Edge)</h2>
              <ol>
                <li>Open the site in Chrome or Edge.</li>
                <li>Click the install icon in the address bar, or menu → Install GITDM.</li>
              </ol>
              <p className="muted" style={{ marginTop: 16 }}>
                This installs as a Progressive Web App (PWA). It opens full-screen like a native app
                and can receive notifications when you allow them.
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
