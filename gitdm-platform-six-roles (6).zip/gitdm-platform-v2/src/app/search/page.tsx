import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { GITDM } from "@/lib/branding";
import { ACTIVE_PROGRAMME_CODES, ACTIVE_COURSE_CODES } from "@/lib/current-catalogue";
import { getDb } from "@/lib/db";

export const dynamic = "force-dynamic";
export const metadata = { title: `Search | ${GITDM.shortName}` };

export default async function SearchPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q = "" } = await searchParams;
  const query = q.trim().slice(0, 100);
  const db = getDb();
  const results = db && query.length >= 2 ? await Promise.all([
    db.programme.findMany({ where: { status: "PUBLISHED", code: { in: [...ACTIVE_PROGRAMME_CODES] }, OR: [{ name: { contains: query, mode: "insensitive" } }, { shortName: { contains: query, mode: "insensitive" } }, { code: { contains: query, mode: "insensitive" } }] }, orderBy: { name: "asc" }, take: 20 }),
    db.course.findMany({ where: { code: { in: [...ACTIVE_COURSE_CODES] }, published: true, OR: [{ programme: { status: "PUBLISHED" } }, { facultyId: { not: null } }], AND: [{ OR: [{ title: { contains: query, mode: "insensitive" } }, { code: { contains: query, mode: "insensitive" } }, { description: { contains: query, mode: "insensitive" } }] }] }, include: { programme: true, facultyUnit: true }, orderBy: { title: "asc" }, take: 30 }),
  ] as const) : null;
  const programmes = results?.[0] ?? [];
  const courses = results?.[1] ?? [];
  return <><Header active="/programmes"/><main><section className="page-hero"><div className="container"><div className="eyebrow">Search GITDM</div><h1>Find programmes and courses</h1><form action="/search" method="get" className="actions" style={{marginTop:20,maxWidth:720}}><input name="q" defaultValue={query} placeholder="Search financial markets, trading, derivatives…" aria-label="Search query"/><button className="btn btn-primary" type="submit">Search</button></form><p>Search published programmes and courses by title, code or description.</p></div></section><section className="section"><div className="container"><div className="grid grid-2"><div><div className="eyebrow">Programmes</div><h2>Programme matches</h2>{!query ? <p>Enter at least two characters to search.</p> : programmes.length ? <div className="stack">{programmes.map((p) => <article className="card" key={p.id}><h3>{p.name}</h3><p>{p.description || "Explore this GITDM programme."}</p><div className="tile-meta">{p.code} · {p.durationMonths} months</div><Link className="btn btn-outline-dark btn-sm" href="/programmes">Explore programmes</Link></article>)}</div> : <p>No programme matches.</p>}</div><div><div className="eyebrow">Courses</div><h2>Course matches</h2>{!query ? <p>Course results will appear here.</p> : courses.length ? <div className="stack">{courses.map((c) => <article className="card" key={c.id}><h3>{c.title}</h3><p>{c.description || "Published course"}</p><div className="tile-meta">{c.code} · {c.facultyUnit?.name || c.programme?.name || "Faculty course"}</div><Link className="btn btn-outline-dark btn-sm" href="/programmes">Explore programme catalogue</Link></article>)}</div> : <p>No course matches.</p>}</div></div></div></section></main><Footer/></>;
}
