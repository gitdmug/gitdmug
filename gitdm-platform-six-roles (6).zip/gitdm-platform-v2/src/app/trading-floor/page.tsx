import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { TradingFloorBooking } from "@/components/TradingFloorBooking";
import { GITDM } from "@/lib/branding";
export const metadata={title:`Trading Floor | ${GITDM.shortName}`,description:"Book a weekly GITDM trading floor session."};
export default function TradingFloorPage(){return <><Header active="/trading-floor"/><main><section className="page-hero"><div className="container"><div className="eyebrow">GITDM Trading Floor</div><h1>A focused space for market practice.</h1><p>Reserve a seat for supervised learning, market observation and disciplined practice in our trading office.</p><div className="floor-facts"><span>Mon · Wed · Thu</span><span>1:00–5:00 pm</span><span>25 seats per session</span></div></div></section><section className="section"><div className="container"><TradingFloorBooking/></div></section></main><Footer/></>}
