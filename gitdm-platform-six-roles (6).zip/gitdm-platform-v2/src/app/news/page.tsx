import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import NewsHeadlines from "@/components/NewsHeadlines";
export const dynamic = "force-dynamic";
export default function NewsPage(){return <><Header active="/research"/><main><section className="page-hero"><div className="container"><div className="eyebrow">GITDM Market Intelligence</div><h1>Market news</h1><p>Headlines and context to help traders prepare for scheduled and developing events.</p></div></section><section className="section"><div className="container"><NewsHeadlines/></div></section></main><Footer/></>}
