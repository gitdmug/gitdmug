import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ControlNav } from "@/components/ControlNav";
import { GITDM } from "@/lib/branding";
import { requireStaffUser, getInstitutionSnapshot } from "@/lib/control-centre";

export const metadata = {
  title: `Control Centre | ${GITDM.shortName}`,
  description: "GITDM institutional Control Centre — Principal overview.",
};
export const dynamic = "force-dynamic";

/**
 * Principal-only home. Six operational departments only.
 * No role switcher, no obsolete department links.
 */
export default async function ControlCentrePage() {
  const { user, db } = await requireStaffUser("institution.view");
  const snap = await getInstitutionSnapshot(db);
  const displayName =
    [user.firstName, user.lastName].filter(Boolean).join(" ") || user.email;

  const departments = [
    {
      title: "Admissions",
      body: "Applications, interviews and decisions.",
      href: "/control-centre/admissions",
      metric: `${snap.totals.submittedApplications} in pipeline`,
    },
    {
      title: "Finance",
      body: "Payment verification and fee clearance.",
      href: "/control-centre/finance",
      metric: `${snap.totals.paidInvoices} paid / ${snap.totals.invoices} invoices`,
    },
    {
      title: "Academic",
      body: "Teaching, timetable, coursework.",
      href: "/control-centre/academic",
      metric: `${snap.totals.activeEnrollments} active students`,
    },
    {
      title: "Exam Office",
      body: "Formal exams and result publication.",
      href: "/control-centre/exams",
      metric: "Examinations",
    },
    {
      title: "Registrar",
      body: "Permanent records, transcripts, certificates.",
      href: "/staff/registrar/students",
      metric: `${snap.totals.users} people in system`,
    },
    {
      title: "People & departments",
      body: "Assign staff to one of the six departments.",
      href: "/control-centre/users",
      metric: "Staff assignment",
    },
  ];

  return (
    <>
      <Header workspace="staff" />
      <ControlNav active="/control-centre" />
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">Principal · Control Centre</div>
            <h1>Institution overview</h1>
            <p>
              Welcome, {displayName}. Oversight of the six operational departments. You do not process
              day-to-day work — each department owns its queue. Assign people under People &amp; departments.
            </p>
          </div>
        </section>
        <section className="section">
          <div className="container">
            <div className="grid grid-4" style={{ marginBottom: 28 }}>
              <div className="panel">
                <div className="eyebrow">Active students</div>
                <h2>{snap.totals.activeEnrollments}</h2>
              </div>
              <div className="panel">
                <div className="eyebrow">Limited access (fees)</div>
                <h2>{snap.totals.limitedAccess}</h2>
              </div>
              <div className="panel">
                <div className="eyebrow">Applications open</div>
                <h2>{snap.totals.submittedApplications}</h2>
              </div>
              <div className="panel">
                <div className="eyebrow">People</div>
                <h2>{snap.totals.users}</h2>
              </div>
            </div>

            <h2 style={{ marginBottom: 16 }}>Departments</h2>
            <div className="grid grid-2">
              {departments.map((d) => (
                <article className="card" key={d.href}>
                  <div className="eyebrow">{d.metric}</div>
                  <h2>{d.title}</h2>
                  <p>{d.body}</p>
                  <Link className="btn btn-primary btn-sm" href={d.href}>
                    Open
                  </Link>
                </article>
              ))}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
