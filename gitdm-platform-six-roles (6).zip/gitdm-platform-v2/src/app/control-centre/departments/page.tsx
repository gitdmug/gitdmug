import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ControlNav } from "@/components/ControlNav";
import { GITDM } from "@/lib/branding";
import { requireStaffUser } from "@/lib/control-centre";

export const metadata = { title: `Departments | Control Centre | ${GITDM.shortName}` };
export const dynamic = "force-dynamic";
const DEPARTMENT_ORDER = [
  ["Admissions & Enrollment", "Owns the complete applicant journey: enquiries, eligibility, applications, interviews, admission decisions, enrolment coordination, onboarding and handover to Finance.", ["ADMISSIONS"]],
  ["Academic Affairs & Instruction", "Owns academic leadership, curriculum, modules, teaching, assessments, examinations, quality, accessibility and learning resources.", ["PRINCIPAL","CURRICULUM_DEVELOPER","ONLINE_INSTRUCTOR","EXAM_OFFICER"]],
  ["Student Success & Support", "Owns advising, records, mentoring, retention, counselling, wellbeing, progression, student requests and graduation readiness.", ["ACADEMIC_ADVISOR_REGISTRAR","STUDENT_SUCCESS_COACH","SCHOOL_COUNSELOR"]],
  ["Technology & Infrastructure", "Owns infrastructure, cybersecurity, LMS operations, integrations, accounts, incidents and technical support.", ["CTO_IT_DIRECTOR","LMS_ADMINISTRATOR","HELPDESK_TECHNICIAN"]],
  ["Operations & Business Administration", "Owns institutional operations, compliance, finance, billing, payments, procurement coordination, reporting and audits.", ["OPERATIONS_COMPLIANCE_MANAGER","FINANCE"]],
] as const;
const roleLabels: Record<string,string> = {
  PRINCIPAL:"Director of Academics / Principal", ACADEMIC_DIRECTOR:"Academic Director", REGISTRAR:"Registrar", FACULTY:"Faculty", LECTURER:"Online Instructor / Lecturer", ADMISSIONS:"Admissions", FINANCE:"Finance", EXAM_OFFICER:"Exam Officer", STUDENT_AFFAIRS:"Student Affairs", LIBRARY:"Library", IT:"IT", MARKETING:"Marketing", PARTNER_SUPPORT:"Partner Support",
CURRICULUM_DEVELOPER:"Curriculum Developer / Instructional Designer", ONLINE_INSTRUCTOR:"Online Instructor (Teacher)", DIFFERENTIATED_LEARNING_COORDINATOR:"Special Education / Differentiated Learning Coordinator", STUDENT_SUCCESS_COACH:"Student Success Coach / Mentor", ACADEMIC_ADVISOR_REGISTRAR:"Academic Advisor & Registrar", SCHOOL_COUNSELOR:"School Counselor", CTO_IT_DIRECTOR:"CTO / IT Director", LMS_ADMINISTRATOR:"LMS Administrator", HELPDESK_TECHNICIAN:"Helpdesk Support Technician", OPERATIONS_COMPLIANCE_MANAGER:"Operations & Compliance Manager", BURSAR_BILLING_SPECIALIST:"Bursar / Billing Specialist"
};

export default async function DepartmentsPage() {
  const { db } = await requireStaffUser("users.view");
  const departments = await db.department.findMany({ orderBy: { name: "asc" }, include: { users: { include: { user: { select: { id: true, firstName: true, lastName: true, email: true, status: true } } } }, roles: { orderBy: { name: "asc" } } } });
  return <>
    <Header workspace="staff" /><ControlNav active="/control-centre/departments" />
    <main>
      <section className="page-hero"><div className="container"><div className="eyebrow">People &amp; Organisation</div><h1>Departments</h1><p>GITDM organisational units, department heads, and assigned staff.</p></div></section>
      <section className="section"><div className="container">
        <div className="actions" style={{ marginBottom: 24 }}><Link href="/control-centre/staff" className="btn btn-primary btn-sm">Staff register</Link><Link href="/control-centre/users" className="btn btn-outline-dark btn-sm">Users &amp; roles</Link></div>
        <div className="stack">
          {DEPARTMENT_ORDER.map(([name, description, roleCodes]) => {
            const department = departments.find((d) => d.name === name);
            const assigned = department?.users || [];
            const operational = assigned.filter((m) => m.user.status === "ACTIVE");
            return <div className="card" key={name}>
              <div className="eyebrow">Department {DEPARTMENT_ORDER.findIndex((d) => d[0] === name) + 1}</div>
              <h2>{name}</h2><p>{description}</p>
              <div className="grid grid-2" style={{ marginTop: 18 }}>
                <div><h3>Department access</h3><div className="stack">{roleCodes.map((code) => <div className="staff-notice" key={code}><strong>{roleLabels[code] || code}</strong><span className="muted">Shared department access</span></div>)}</div></div>
                <div><h3>Operational team</h3><p><strong>{operational.length}</strong> active member{operational.length === 1 ? "" : "s"} · target maximum 4</p>{operational.slice(0, 4).map((m) => <div key={m.user.id} className="staff-notice"><strong>{[m.user.firstName,m.user.lastName].filter(Boolean).join(" ") || m.user.email}</strong><span>{m.isHead ? "Department Head" : "Staff"}</span></div>)}{operational.length > 4 ? <p className="access-banner"><strong>Coverage review needed.</strong> This department currently has more than four active people; keep the first four as operational seats and move additional coverage through secondary-role assignments rather than creating more permanent seats.</p> : null}{assigned.filter((m) => m.user.status !== "ACTIVE").length ? <p className="muted">{assigned.filter((m) => m.user.status !== "ACTIVE").length} inactive/historical department record(s) retained for data continuity.</p> : null}</div>
              </div>
            </div>;
          })}
        </div>
        <div className="panel" style={{ marginTop: 24 }}><strong>Lean staffing rule:</strong> each department is designed for a maximum of 3–4 operational people. Responsibilities are consolidated into the positions above, so the institution does not need a separate person for every activity. Multiple people may be allocated to the same department. They use the same departmental actions; the signed-in account identifies who performed each action. Department allocation, not specialist sub-roles, determines who can work the queue.</div>
      </div></section>
    </main><Footer />
  </>;
}
