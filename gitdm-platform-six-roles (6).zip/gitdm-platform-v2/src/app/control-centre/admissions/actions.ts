"use server";

import { revalidatePath } from "next/cache";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { brandedEmail, sendEmail } from "@/lib/mail";
import { GITDM } from "@/lib/branding";
import { getPublicAppUrl } from "@/lib/pesapal";
import { notifyStudentChange } from "@/lib/student-email";

export async function decideApplication(formData: FormData) {
  const applicationId = String(formData.get("applicationId") || "");
  const decision = String(formData.get("decision") || "");
  const reason = String(formData.get("reason") || "").trim();
  if (!["ACCEPTED", "REJECTED", "CONDITIONAL"].includes(decision)) throw new Error("Invalid decision.");
  const { db, user } = await requireOperationalStaffUser("applications.decide");

  await db.$transaction(async (tx) => {
    const app = await tx.application.findUnique({
      where: { id: applicationId },
      include: {
        programme: { include: { periods: { where: { status: "OPEN" }, orderBy: { sequence: "asc" }, take: 1 }, rules: true } },
        feeInvoice: true,
        interviews: { orderBy: { scheduledAt: "desc" }, take: 1 },
      },
    });
    if (!app) throw new Error("Application not found.");
    if (["ACCEPTED", "WITHDRAWN"].includes(app.status)) throw new Error("This application is already closed.");

    const feePaid = Boolean(app.feeInvoice && Number(app.feeInvoice.amountPaid) >= Number(app.feeInvoice.amount) - 0.001 && app.feeInvoice.status === "PAID");
    if (app.programme.rules?.interviewByAdmissions) {
      const latestInterview = app.interviews[0];
      if (!latestInterview || latestInterview.status !== "COMPLETED") throw new Error("Complete the required admissions interview before recording the final decision.");
      if (latestInterview.outcome === "REJECT") throw new Error("The latest interview outcome is Reject. Record the rejection decision instead of continuing.");
    }
    const feeOverride = String(formData.get("feeOverride") || "").toLowerCase() === "true";
    if (!feePaid && !feeOverride) throw new Error("The UGX 10,000 application fee must be paid and receipted before Admissions can record a decision. Use the documented fee override only for an approved exception.");
    const next = decision === "REJECTED" ? "REJECTED" : "ACCEPTED";
    await tx.application.update({ where: { id: app.id }, data: { status: next, reviewedAt: new Date(), notes: reason || app.notes } });
    await tx.admissionDecision.create({ data: { applicationId: app.id, decidedById: user.id, decision: decision as "ACCEPTED" | "REJECTED" | "CONDITIONAL", reason: reason || null } });

    if (decision === "ACCEPTED" || decision === "CONDITIONAL") {
      const period = app.programme.periods[0] || null;
      let enrollment = await tx.enrollment.findFirst({ where: { userId: app.applicantId, programmeId: app.programmeId, periodId: period?.id || undefined }, orderBy: { createdAt: "desc" } });
      if (!enrollment) {
        enrollment = await tx.enrollment.create({ data: { userId: app.applicantId, programmeId: app.programmeId, periodId: period?.id || null, status: "ACTIVE", accessLevel: "LIMITED", admittedAt: new Date(), activatedAt: new Date() } });
        await tx.auditLog.create({ data: { userId: user.id, action: "ENROLLMENT_CREATED_FROM_ADMISSION", entity: "Enrollment", entityId: enrollment.id, metadataJson: JSON.stringify({ applicationId: app.id, programmeId: app.programmeId, periodId: period?.id || null }) } });
      } else {
        enrollment = await tx.enrollment.update({ where: { id: enrollment.id }, data: { status: "ACTIVE", accessLevel: "LIMITED", admittedAt: enrollment.admittedAt || new Date(), activatedAt: enrollment.activatedAt || new Date(), periodId: period?.id || enrollment.periodId } });
      }

      if (period) {
        const periodCourses = await tx.periodCourse.findMany({ where: { periodId: period.id }, select: { courseId: true } });
        const courseIds = periodCourses.length
          ? periodCourses.map((pc) => pc.courseId)
          : (await tx.course.findMany({ where: { programmeId: app.programmeId, published: true }, select: { id: true } })).map((course) => course.id);
        for (const courseId of courseIds) {
          await tx.courseEnrollment.upsert({
            where: { enrollmentId_courseId_attempt: { enrollmentId: enrollment.id, courseId, attempt: 1 } },
            update: { status: "ACTIVE" },
            create: { enrollmentId: enrollment.id, courseId, status: "ACTIVE", attempt: 1 },
          });
        }
        const invoiceNo = `GITDM-${new Date().getFullYear()}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`;
        const exists = await tx.invoice.findFirst({ where: { enrollmentId: enrollment.id, periodId: period.id, kind: "TUITION" } });
        if (!exists) {
          const invoice = await tx.invoice.create({ data: { enrollmentId: enrollment.id, periodId: period.id, invoiceNo, description: `${app.programme.name} — ${period.name}`, kind: "TUITION", amount: period.feeAmount, currency: period.currency, status: "ISSUED" } });
          await tx.auditLog.create({ data: { userId: user.id, action: "TUITION_INVOICE_CREATED_FROM_ADMISSION", entity: "Invoice", entityId: invoice.id, metadataJson: JSON.stringify({ applicationId: app.id, enrollmentId: enrollment.id, periodId: period.id, amount: Number(period.feeAmount) }) } });
        }
      }

      await tx.notification.create({ data: { userId: app.applicantId, type: "ADMISSIONS", title: decision === "CONDITIONAL" ? "Conditional admission recorded" : "Application accepted", body: `Your application for ${app.programme.name} has been ${decision === "CONDITIONAL" ? "accepted conditionally" : "accepted"}. Your student workspace is now available with limited access pending tuition clearance.${reason ? ` Admissions note: ${reason}` : ""}` } });
    } else {
      await tx.notification.create({ data: { userId: app.applicantId, type: "ADMISSIONS", title: "Application decision recorded", body: `Your application for ${app.programme.name} was not accepted. Review your application for the recorded reason and appeal option.${reason ? ` Admissions note: ${reason}` : ""}` } });
    }

    await tx.auditLog.create({ data: { userId: user.id, action: `APPLICATION_${decision}`, entity: "Application", entityId: app.id, metadataJson: JSON.stringify({ reason }) } });
  });

  
  // Notify applicant by email (soft-fail if mail not configured)
  try {
    const decided = await db.application.findUnique({
      where: { id: applicationId },
      include: { applicant: true, programme: true },
    });
    if (decided?.applicant?.email) {
      const accepted = decision === "ACCEPTED" || decision === "CONDITIONAL";
      const ref = applicationId.slice(-8).toUpperCase();
      const portal = `${getPublicAppUrl()}/admissions/apply/${applicationId}`;
      await sendEmail({
        to: decided.applicant.email,
        userId: decided.applicant.id,
        event: `APPLICATION_${decision}`,
        mailbox: "admissions",
        subject: accepted
          ? `Congratulations — admitted to ${decided.programme.name} | ${GITDM.shortName}`
          : `Application update — ${decided.programme.name} | ${GITDM.shortName}`,
        html: brandedEmail({
          title: accepted ? "You have been admitted" : "Application decision",
          bodyHtml: accepted
            ? `<p>Dear ${decided.legalName || decided.applicant.firstName || "Applicant"},</p>
               <p>Congratulations. Your application <strong>${ref}</strong> to <strong>${decided.programme.name}</strong> has been <strong>accepted</strong>${decision === "CONDITIONAL" ? " (conditional)" : ""}.</p>
               <p>${reason ? `<em>Note from Admissions:</em> ${reason}` : ""}</p>
               <p><strong>Next steps</strong></p>
               <ol style="padding-left:18px;line-height:1.6">
                 <li>Sign in to the Campus portal.</li>
                 <li>Complete any outstanding fee payment.</li>
                 <li>Once fees are verified you receive full learning access.</li>
               </ol>`
            : `<p>Dear ${decided.legalName || decided.applicant.firstName || "Applicant"},</p>
               <p>Thank you for applying to <strong>${decided.programme.name}</strong>.</p>
               <p>After careful review, application <strong>${ref}</strong> was <strong>not accepted</strong> at this time.</p>
               <p>${reason ? `<em>Note:</em> ${reason}` : ""}</p>
               <p>You may submit an appeal from your application page if you believe important information was missing or should be reconsidered.</p>`,
          ctaLabel: accepted ? "Open Campus / pay fees" : "View application / appeal",
          ctaHref: portal,
        }),
      });
    }
  } catch (err) {
    console.error("[GITDM admissions] decision email failed:", err);
  }


  revalidatePath("/control-centre/admissions");
  revalidatePath(`/control-centre/admissions/${applicationId}`);
  revalidatePath("/campus");
  revalidatePath("/campus/finance");
}

export async function reviewAppeal(formData: FormData) {
  const applicationId = String(formData.get("applicationId") || "");
  const decision = String(formData.get("decision") || "");
  const note = String(formData.get("note") || "").trim();
  if (!["ACCEPTED", "REJECTED"].includes(decision)) throw new Error("Invalid appeal decision.");
  const { db, user } = await requireOperationalStaffUser("applications.decide");
  await db.$transaction(async (tx) => {
    const app = await tx.application.findUnique({ where: { id: applicationId }, include: { programme: { include: { periods: { where: { status: "OPEN" }, orderBy: { sequence: "asc" }, take: 1 } } } } });
    if (!app || app.appealStatus !== "PENDING") throw new Error("No pending appeal was found.");
    if (decision === "ACCEPTED") {
      const period = app.programme.periods[0] || null;
      let enrollment = await tx.enrollment.findFirst({ where: { userId: app.applicantId, programmeId: app.programmeId, periodId: period?.id || undefined }, orderBy: { createdAt: "desc" } });
      if (!enrollment) enrollment = await tx.enrollment.create({ data: { userId: app.applicantId, programmeId: app.programmeId, periodId: period?.id || null, status: "ACTIVE", accessLevel: "LIMITED", admittedAt: new Date(), activatedAt: new Date() } });
      else enrollment = await tx.enrollment.update({ where: { id: enrollment.id }, data: { status: "ACTIVE", accessLevel: "LIMITED", admittedAt: enrollment.admittedAt || new Date(), activatedAt: enrollment.activatedAt || new Date(), periodId: period?.id || enrollment.periodId } });
      if (period) {
        const periodCourses = await tx.periodCourse.findMany({ where: { periodId: period.id }, select: { courseId: true } });
        const courseIds = periodCourses.length
          ? periodCourses.map((pc) => pc.courseId)
          : (await tx.course.findMany({ where: { programmeId: app.programmeId, published: true }, select: { id: true } })).map((course) => course.id);
        for (const courseId of courseIds) await tx.courseEnrollment.upsert({ where: { enrollmentId_courseId_attempt: { enrollmentId: enrollment.id, courseId, attempt: 1 } }, update: { status: "ACTIVE" }, create: { enrollmentId: enrollment.id, courseId, status: "ACTIVE", attempt: 1 } });
        const exists = await tx.invoice.findFirst({ where: { enrollmentId: enrollment.id, periodId: period.id, kind: "TUITION" } });
        if (!exists) await tx.invoice.create({ data: { enrollmentId: enrollment.id, periodId: period.id, invoiceNo: `GITDM-${new Date().getFullYear()}-${Math.random().toString(36).slice(2, 8).toUpperCase()}`, description: `${app.programme.name} — ${period.name}`, kind: "TUITION", amount: period.feeAmount, currency: period.currency, status: "ISSUED" } });
      }
      await tx.application.update({ where: { id: app.id }, data: { status: "ACCEPTED", appealStatus: "ACCEPTED", reviewedAt: new Date(), notes: note || app.notes } });
      await tx.admissionDecision.create({ data: { applicationId: app.id, decidedById: user.id, decision: "ACCEPTED", reason: note || "Appeal accepted." } });
      await tx.notification.create({ data: { userId: app.applicantId, type: "ADMISSIONS", title: "Appeal accepted", body: `Your admission appeal for ${app.programme.name} has been accepted. Your student onboarding is now active with limited access pending tuition clearance.` } });
    } else {
      await tx.application.update({ where: { id: app.id }, data: { appealStatus: "REJECTED", reviewedAt: new Date(), notes: note || app.notes } });
      await tx.notification.create({ data: { userId: app.applicantId, type: "ADMISSIONS", title: "Appeal decision recorded", body: `Your admission appeal for ${app.programme.name} was not accepted.${note ? ` Admissions note: ${note}` : ""}` } });
    }
    await tx.auditLog.create({ data: { userId: user.id, action: `APPLICATION_APPEAL_${decision}`, entity: "Application", entityId: app.id, metadataJson: JSON.stringify({ note }) } });
  });
  

  revalidatePath("/control-centre/admissions");
  revalidatePath(`/control-centre/admissions/${applicationId}`);
}

export async function updateApplicationStatus(formData: FormData) {
  const { db, user } = await requireOperationalStaffUser("applications.manage");
  const id = String(formData.get("applicationId") || "");
  const status = String(formData.get("status") || "");
  const note = String(formData.get("note") || "").trim();
  const allowed = ["UNDER_REVIEW", "INTERVIEW_REQUIRED", "ADDITIONAL_INFORMATION"];
  if (!allowed.includes(status)) throw new Error("Use the admissions decision workflow for accept/reject decisions.");
  const app = await db.application.findUnique({ where: { id } });
  if (!app) throw new Error("Application not found.");
  if (["ACCEPTED", "REJECTED", "WITHDRAWN"].includes(app.status)) throw new Error("This application is already closed.");
  await db.application.update({ where: { id }, data: { status: status as any, reviewedAt: new Date(), notes: note || app.notes } });
  await db.auditLog.create({ data: { userId: user.id, action: `APPLICATION_STATUS_${status}`, entity: "Application", entityId: id, metadataJson: JSON.stringify({ note }) } });
  await db.notification.create({ data: { userId: app.applicantId, type: "ADMISSIONS", title: "Application status updated", body: `Your GITDM application status is now ${status.replaceAll("_", " ")}.${note ? ` Note: ${note}` : ""}` } });
  const applicant = await db.user.findUnique({ where: { id: app.applicantId }, select: { id: true, email: true, firstName: true } });
  if (applicant?.email) await notifyStudentChange({ userId: app.applicantId, email: applicant.email, firstName: applicant.firstName, title: "Application status updated", body: `Your GITDM application status is now ${status.replaceAll("_", " ")}.${note ? ` Admissions note: ${note}` : ""}`, action: `APPLICATION_STATUS_${status}`, event: `APPLICATION_STATUS_${status}`, href: `/admissions/apply/${id}` });
  revalidatePath(`/control-centre/admissions/${id}`);
  

  revalidatePath("/control-centre/admissions");
}

export async function scheduleInterview(formData: FormData) {
  const { db, user } = await requireOperationalStaffUser("applications.manage");
  const id = String(formData.get("applicationId") || "");
  const scheduled = String(formData.get("scheduledAt") || "");
  const notes = String(formData.get("notes") || "").trim();
  const mode = String(formData.get("mode") || "PHYSICAL");
  const venue = String(formData.get("venue") || "").trim();
  const meetingUrl = String(formData.get("meetingUrl") || "").trim();
  if (!["PHYSICAL", "ONLINE"].includes(mode)) throw new Error("Choose a physical or online interview.");
  if (mode === "PHYSICAL" && !venue) throw new Error("Enter the physical interview venue.");
  if (mode === "ONLINE" && !meetingUrl) throw new Error("Enter the online meeting link.");
  if (!scheduled) throw new Error("Choose an interview date and time.");
  const date = new Date(scheduled);
  if (Number.isNaN(date.getTime())) throw new Error("Invalid interview date.");
  const app = await db.application.findUnique({ where: { id } });
  if (!app) throw new Error("Application not found.");
  if (app.status === "ACCEPTED") {
    const enrollment = await db.enrollment.findFirst({ where: { userId: app.applicantId, programmeId: app.programmeId, status: { in: ["ACTIVE", "REPEATING"] } }, orderBy: { createdAt: "desc" } });
    if (enrollment?.accessLevel === "FULL") throw new Error("Admissions is complete for this student. Interviews cannot be scheduled after admission and payment clearance.");
  }
  await db.interview.create({ data: { applicationId: id, interviewerId: user.id, status: "SCHEDULED", mode: mode as "PHYSICAL" | "ONLINE", scheduledAt: date, venue: mode === "PHYSICAL" ? venue : null, meetingUrl: mode === "ONLINE" ? meetingUrl : null, notes: notes || null } });
  await db.application.update({ where: { id }, data: { status: "INTERVIEW_REQUIRED", reviewedAt: new Date() } });
  await db.notification.create({ data: { userId: app.applicantId, type: "ADMISSIONS", title: "Admissions interview scheduled", body: `Your GITDM admissions interview is scheduled for ${date.toLocaleString("en-UG")}.` } });
  await db.auditLog.create({ data: { userId: user.id, action: "ADMISSIONS_INTERVIEW_SCHEDULED", entity: "Application", entityId: id, metadataJson: JSON.stringify({ scheduledAt: date.toISOString(), mode, venue: venue || null, meetingUrl: meetingUrl || null }) } });
  revalidatePath(`/control-centre/admissions/${id}`);
  

  revalidatePath("/control-centre/admissions");
}


export async function completeInterview(formData: FormData) {
  const { db, user } = await requireOperationalStaffUser("applications.manage");
  const applicationId = String(formData.get("applicationId") || "");
  const interviewId = String(formData.get("interviewId") || "");
  const outcome = String(formData.get("outcome") || "");
  const outcomeNote = String(formData.get("outcomeNote") || "").trim();
  if (!["CONTINUE", "REJECT"].includes(outcome)) throw new Error("Choose Continue or Reject.");
  if (outcomeNote.length < 5) throw new Error("Record a meaningful interview decision note.");
  const interview = await db.interview.findUnique({ where: { id: interviewId }, include: { application: true } });
  if (!interview || interview.applicationId !== applicationId) throw new Error("Interview record not found.");
  if (interview.status === "CANCELLED") throw new Error("Cancelled interviews cannot be completed.");
  await db.$transaction(async (tx) => {
    await tx.interview.update({ where: { id: interviewId }, data: { status: "COMPLETED", outcome: outcome as "CONTINUE" | "REJECT", outcomeNote, completedAt: new Date() } });
    await tx.application.update({ where: { id: applicationId }, data: { status: outcome === "REJECT" ? "REJECTED" : "UNDER_REVIEW", reviewedAt: new Date(), notes: outcomeNote } });
    if (outcome === "REJECT") {
      await tx.admissionDecision.create({ data: { applicationId, decidedById: user.id, decision: "REJECTED", reason: outcomeNote } });
    }
    await tx.notification.create({ data: { userId: interview.application.applicantId, type: "ADMISSIONS", title: outcome === "CONTINUE" ? "Interview completed" : "Application decision recorded", body: outcome === "CONTINUE" ? `Your admissions interview is complete and your application will continue to the next review stage.` : `Your application was not progressed after the admissions interview.${outcomeNote ? ` Admissions note: ${outcomeNote}` : ""}` } });
    await tx.auditLog.create({ data: { userId: user.id, action: `ADMISSIONS_INTERVIEW_${outcome}`, entity: "Interview", entityId: interviewId, metadataJson: JSON.stringify({ applicationId, outcome, outcomeNote }) } });
  });
  const applicant = await db.user.findUnique({ where: { id: interview.application.applicantId }, select: { id: true, email: true, firstName: true } });
  if (applicant?.email) {
    await notifyStudentChange({ userId: applicant.id, email: applicant.email, firstName: applicant.firstName, title: outcome === "CONTINUE" ? "Admissions interview completed" : "Admissions interview outcome", body: outcome === "CONTINUE" ? "Thank you for completing your admissions interview. Your application will continue through the remaining admissions review." : `Your application was not progressed after the admissions interview.${outcomeNote ? ` Note from Admissions: ${outcomeNote}` : ""}`, action: `ADMISSIONS_INTERVIEW_${outcome}`, event: `ADMISSIONS_INTERVIEW_${outcome}`, href: `/admissions/apply/${applicationId}` });
  }
  revalidatePath(`/staff/admissions/applications/${applicationId}`);
  revalidatePath("/staff/admissions/applications");
}

export async function sendAdmissionsMessage(formData: FormData) {
  const { db, user } = await requireOperationalStaffUser("applications.manage");
  const applicationId = String(formData.get("applicationId") || "");
  const subject = String(formData.get("subject") || "").trim();
  const body = String(formData.get("body") || "").trim();
  if (!subject || subject.length < 3) throw new Error("Enter a message subject.");
  if (!body || body.length < 10) throw new Error("Enter a meaningful message.");
  const app = await db.application.findUnique({ where: { id: applicationId }, include: { applicant: true, programme: true } });
  if (!app) throw new Error("Application not found.");
  const staff = await db.user.findUnique({ where: { id: user.id }, include: { departments: { include: { department: true } } } });
  const senderName = [staff?.firstName, staff?.lastName].filter(Boolean).join(" ") || staff?.email || "Admissions Team";
  const departmentName = staff?.departments.find((d) => /admission/i.test(d.department.name))?.department.name || "Admissions & Enrollment";
  const safe = (value: string) => value.replaceAll("&", "&amp;").replaceAll("<", "&lt;").replaceAll(">", "&gt;").replaceAll('"', "&quot;").replaceAll("'", "&#039;");
  const result = await sendEmail({
    to: app.applicant.email,
    userId: app.applicantId,
    event: "ADMISSIONS_STAFF_MESSAGE",
    mailbox: "admissions",
    subject: `${subject} | ${GITDM.shortName}`,
    html: brandedEmail({ title: safe(subject), bodyHtml: `<p>Dear ${safe(app.applicant.firstName || "Applicant")},</p><div style="white-space:pre-wrap;line-height:1.7">${safe(body)}</div><p style="margin-top:24px"><strong>${safe(senderName)}</strong><br/>${safe(departmentName)}<br/>${safe(GITDM.name)}</p>` }),
    text: `Dear ${app.applicant.firstName || "Applicant"},\n\n${body}\n\n${senderName}\n${departmentName}\n${GITDM.name}`,
  });
  await db.admissionsCommunication.create({ data: { applicationId, senderId: user.id, recipientId: app.applicantId, subject, body, senderName, departmentName, deliveryStatus: result.ok ? "SENT" : "FAILED" } });
  await db.notification.create({ data: { userId: app.applicantId, type: "ADMISSIONS", title: subject, body: body.slice(0, 500) } });
  await db.auditLog.create({ data: { userId: user.id, action: "ADMISSIONS_MESSAGE_SENT", entity: "Application", entityId: applicationId, metadataJson: JSON.stringify({ recipient: app.applicant.email, subject, deliveryStatus: result.ok ? "SENT" : "FAILED", senderName, departmentName }) } });
  revalidatePath(`/staff/admissions/applications/${applicationId}`);
  if (!result.ok) throw new Error(result.error || "The message could not be delivered. It was saved to the case as failed.");
}
