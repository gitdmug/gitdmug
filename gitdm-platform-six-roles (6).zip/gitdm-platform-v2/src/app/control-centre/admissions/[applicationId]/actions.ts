"use server";
import { revalidatePath } from "next/cache";
import { requireStaffUser } from "@/lib/control-centre";

export async function updateApplicationStatus(formData: FormData) {
  const { db, user } = await requireStaffUser("applications.manage");
  const id=String(formData.get("applicationId")||""); const status=String(formData.get("status")||""); const note=String(formData.get("note")||"").trim();
  const allowed=["UNDER_REVIEW","INTERVIEW_REQUIRED","ADDITIONAL_INFORMATION","REJECTED"];
  if(!allowed.includes(status)) throw new Error("Invalid application status.");
  const app=await db.application.findUnique({where:{id}}); if(!app) throw new Error("Application not found.");
  if(["ACCEPTED","REJECTED","WITHDRAWN"].includes(app.status)) throw new Error("This application is already closed.");
  await db.application.update({where:{id},data:{status:status as any,reviewedAt:new Date(),notes:note||app.notes}});
  await db.auditLog.create({data:{userId:user.id,action:`APPLICATION_STATUS_${status}`,entity:"Application",entityId:id,metadataJson:JSON.stringify({note})}});
  await db.notification.create({data:{userId:app.applicantId,type:"ADMISSIONS",title:"Application status updated",body:`Your GITDM application status is now ${status.replaceAll("_"," ")}.`}});
  revalidatePath(`/control-centre/admissions/${id}`); revalidatePath("/control-centre/admissions");
}

export async function scheduleInterview(formData: FormData) {
  const { db, user } = await requireStaffUser("applications.manage");
  const id=String(formData.get("applicationId")||""); const scheduled=String(formData.get("scheduledAt")||""); const notes=String(formData.get("notes")||"").trim();
  if(!scheduled) throw new Error("Choose an interview date and time."); const date=new Date(scheduled); if(Number.isNaN(date.getTime())) throw new Error("Invalid interview date.");
  const app=await db.application.findUnique({where:{id}}); if(!app) throw new Error("Application not found.");
  await db.interview.create({data:{applicationId:id,interviewerId:user.id,status:"SCHEDULED",scheduledAt:date,notes:notes||null}});
  await db.application.update({where:{id},data:{status:"INTERVIEW_REQUIRED",reviewedAt:new Date()}});
  await db.notification.create({data:{userId:app.applicantId,type:"ADMISSIONS",title:"Admissions interview scheduled",body:`Your GITDM admissions interview is scheduled for ${date.toLocaleString("en-UG")}.`}});
  await db.auditLog.create({data:{userId:user.id,action:"ADMISSIONS_INTERVIEW_SCHEDULED",entity:"Application",entityId:id,metadataJson:JSON.stringify({scheduledAt:date.toISOString()})}});
  revalidatePath(`/control-centre/admissions/${id}`); revalidatePath("/control-centre/admissions");
}
