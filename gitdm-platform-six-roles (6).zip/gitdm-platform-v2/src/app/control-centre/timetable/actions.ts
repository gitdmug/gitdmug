"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { generateShortCourseSessions } from "@/lib/timetable-generator";

export async function createTimetableEvent(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("academic.manage");
  const courseId = String(fd.get("courseId") || "") || undefined;
  const periodId = String(fd.get("periodId") || "") || undefined;
  const studentId = String(fd.get("studentId") || "") || undefined;
  const title = String(fd.get("title") || "").trim();
  const startAt = new Date(String(fd.get("startAt")));
  const endAt = new Date(String(fd.get("endAt")));
  if (!title || isNaN(startAt.getTime()) || isNaN(endAt.getTime()) || endAt <= startAt) {
    throw new Error("Title and valid start/end times are required.");
  }
  await db.timetableEvent.create({
    data: {
      courseId,
      periodId,
      studentId,
      title,
      type: String(fd.get("type") || "CLASS"),
      startAt,
      endAt,
      venue: String(fd.get("venue") || "") || undefined,
      lecturer: String(fd.get("lecturer") || "") || undefined,
      joinUrl: String(fd.get("joinUrl") || "") || undefined,
      notes: String(fd.get("notes") || "") || undefined,
    },
  });
  await db.auditLog.create({
    data: {
      userId: user.id,
      action: "TIMETABLE_EVENT_CREATED",
      entity: "TimetableEvent",
      metadataJson: JSON.stringify({ title }),
    },
  });
  revalidatePath("/control-centre/timetable");
  revalidatePath("/campus/timetable");
  revalidatePath("/staff/academic/classes");
}

/**
 * Generate class sessions from course pattern + start date + session.
 * Does not require pre-published lessons — uses module titles or Class N fallback.
 * Updates student + staff timetable views.
 */
export async function generateAutomaticShortCourseTimetable(fd: FormData) {
  const { db, user, roleCodes } = await requireOperationalStaffUser("academic.manage");
  const allowed = roleCodes.some((role) =>
    ["PRINCIPAL", "ACADEMIC_DIRECTOR", "REGISTRAR", "ACADEMIC"].includes(role)
  );
  if (!allowed) {
    redirect("/staff/academic/delivery?error=not-authorized");
  }

  const courseCode = String(fd.get("courseCode") || "") as "TA101" | "FX3M";
  const startRaw = String(fd.get("startDate") || "");
  const session = String(fd.get("session") || "MORNING") as "MORNING" | "EVENING";

  if (!["TA101", "FX3M"].includes(courseCode)) {
    redirect("/staff/academic/delivery?error=invalid-course");
  }
  if (!["MORNING", "EVENING"].includes(session)) {
    redirect("/staff/academic/delivery?error=invalid-session");
  }
  if (!/^\d{4}-\d{2}-\d{2}$/.test(startRaw)) {
    redirect("/staff/academic/delivery?error=invalid-date");
  }

  const startDate = new Date(`${startRaw}T00:00:00Z`);
  const programmeCode = courseCode === "TA101" ? "GITDM-TA1M" : "GITDM-FX3M";
  const programme = await db.programme.findUnique({
    where: { code: programmeCode },
    select: { id: true },
  });
  const course = await db.course.findUnique({
    where: { code: courseCode },
    select: { id: true, title: true },
  });
  if (!programme || !course) {
    redirect("/staff/academic/delivery?error=course-not-configured");
  }

  let period = await db.academicPeriod.findUnique({
    where: { programmeId_sequence: { programmeId: programme.id, sequence: 1 } },
    select: { id: true },
  });
  if (!period) {
    // Create period if missing so generation never hard-fails
    period = await db.academicPeriod.create({
      data: {
        programmeId: programme.id,
        sequence: 1,
        name: `${courseCode} intake`,
        status: "OPEN",
        startsAt: startDate,
        endsAt: new Date(startDate.getTime() + 120 * 86400000),
        feeAmount: 0,
        currency: "UGX",
      },
      select: { id: true },
    });
  }

  const holidayRows = await db.academicHoliday
    .findMany({
      where: {
        date: { gte: startDate, lte: new Date(startDate.getTime() + 370 * 86400000) },
        isObserved: true,
      },
      select: { date: true, name: true },
    })
    .catch(() => [] as { date: Date; name: string }[]);

  const generated = generateShortCourseSessions({
    courseCode,
    startDate,
    session,
    holidays: holidayRows,
  });

  const modules = await db.courseModule.findMany({
    where: { courseId: course.id },
    orderBy: { orderIndex: "asc" },
    include: {
      lessons: { orderBy: { orderIndex: "asc" }, select: { title: true, id: true } },
    },
  });

  const lessonSlots = modules.flatMap((module) =>
    module.lessons.map((lesson) => ({
      moduleId: module.id,
      title: lesson.title || module.title,
    }))
  );

  // Remove future untaught classes for this course+period so regeneration is clean
  await db.timetableEvent.deleteMany({
    where: {
      courseId: course.id,
      periodId: period.id,
      type: "CLASS",
      startAt: { gte: startDate },
    },
  });

  let created = 0;
  for (let i = 0; i < generated.events.length; i++) {
    const ev = generated.events[i];
    const slot = lessonSlots[i];
    const title =
      slot?.title ||
      (modules[i % Math.max(modules.length, 1)]?.title
        ? `${modules[i % modules.length].title} · Session ${i + 1}`
        : `${course.title} · Class ${i + 1}`);

    await db.timetableEvent.create({
      data: {
        courseId: course.id,
        periodId: period.id,
        moduleId: slot?.moduleId || modules[i % Math.max(modules.length, 1)]?.id || undefined,
        title,
        type: "CLASS",
        startAt: ev.startAt,
        endAt: ev.endAt,
        deliveryMode: "ONLINE",
        scheduledById: user.id,
      },
    });
    created++;
  }

  await db.auditLog.create({
    data: {
      userId: user.id,
      action: "TIMETABLE_AUTO_GENERATED",
      entity: "TimetableEvent",
      metadataJson: JSON.stringify({
        courseCode,
        session,
        startDate: startRaw,
        created,
      }),
    },
  });

  revalidatePath("/control-centre/timetable");
  revalidatePath("/campus/timetable");
  revalidatePath("/staff/academic/classes");
  revalidatePath("/staff/academic/delivery");
  revalidatePath("/campus/learning");
  redirect(`/staff/academic/delivery?ok=1&created=${created}&course=${courseCode}`);
}

export async function updateTimetableEvent(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("academic.manage");
  const id = String(fd.get("eventId") || "");
  if (!id) throw new Error("Missing event");
  const title = String(fd.get("title") || "").trim();
  const joinUrl = String(fd.get("joinUrl") || "").trim() || null;
  const notes = String(fd.get("notes") || "").trim() || null;
  await db.timetableEvent.update({
    where: { id },
    data: {
      ...(title ? { title } : {}),
      joinUrl,
      notes,
    },
  });
  await db.auditLog.create({
    data: {
      userId: user.id,
      action: "TIMETABLE_EVENT_UPDATED",
      entity: "TimetableEvent",
      entityId: id,
      metadataJson: JSON.stringify({ title, joinUrl }),
    },
  });
  revalidatePath("/staff/academic/classes");
  revalidatePath("/campus/timetable");
  revalidatePath("/campus/learning");
}
