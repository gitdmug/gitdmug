"use server";
import { revalidatePath } from "next/cache";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { uploadPrivateFile } from "@/lib/file-storage";
import { syncStudentCourseGrade } from "@/lib/grade-sync";
import { ACTIVE_COURSE_CODES } from "@/lib/current-catalogue";

export async function createExam(formData: FormData) {
  const { db, user } = await requireOperationalStaffUser("exams.manage");
  const courseId=String(formData.get("courseId")||""); const title=String(formData.get("title")||"").trim(); const periodId=String(formData.get("periodId")||"").trim()||undefined;
  const attemptsAllowed=Math.max(1,Number(formData.get("attemptsAllowed")||3)); const timeLimitMinutes=Number(formData.get("timeLimitMinutes")||0)||undefined;
  const opensAt=String(formData.get("opensAt")||"")?new Date(String(formData.get("opensAt"))):undefined; const closesAt=String(formData.get("closesAt")||"")?new Date(String(formData.get("closesAt"))):undefined;
  if(!courseId||!title)throw new Error("Course and examination title are required.");
  const course=await db.course.findFirst({where:{id:courseId,code:{in:[...ACTIVE_COURSE_CODES]}},select:{id:true}});
  if(!course)throw new Error("Only current intake courses can receive examinations.");
  const exam=await db.exam.create({data:{courseId,periodId,title,attemptsAllowed,timeLimitMinutes,opensAt,closesAt,deliveryMode:String(formData.get("deliveryMode")||"ONLINE") as any,submissionMode:String(formData.get("submissionMode")||"ONLINE_FORM") as any,venue:String(formData.get("venue")||"").trim()||undefined,room:String(formData.get("room")||"").trim()||undefined,formatDescription:String(formData.get("formatDescription")||"").trim()||undefined,permitRequired:formData.get("permitRequired")==="on",instructions:String(formData.get("instructions")||"").trim()||undefined,resultsReleaseAt:String(formData.get("resultsReleaseAt")||"")?new Date(String(formData.get("resultsReleaseAt"))):undefined,createdById:user.id}});
  await db.auditLog.create({data:{userId:user.id,action:"EXAM_CREATED",entity:"Exam",entityId:exam.id,metadataJson:JSON.stringify({courseId,title})}});revalidatePath("/control-centre/exams");
}
export async function addExamQuestion(formData: FormData) {const {db,user}=await requireOperationalStaffUser("exams.manage");const examId=String(formData.get("examId")||"");const type=String(formData.get("type")||"SINGLE_CHOICE") as any;const prompt=String(formData.get("prompt")||"").trim();const optionsRaw=String(formData.get("options")||"").trim();const correct=String(formData.get("correct")||"").trim();const marks=Number(formData.get("marks")||1);if(!examId||!prompt||!marks||marks<=0)throw new Error("Question text and positive marks are required.");const count=await db.examQuestion.count({where:{examId}});const options=optionsRaw?optionsRaw.split("\n").map(x=>x.trim()).filter(Boolean):[];const exam=await db.exam.findUnique({where:{id:examId},select:{status:true}});if(!exam||exam.status!=="DRAFT")throw new Error("Questions can only be changed while the examination is in draft.");await db.examQuestion.create({data:{examId,type,prompt,optionsJson:options.length?JSON.stringify(options):undefined,correctJson:correct?JSON.stringify(type==="MULTIPLE_CHOICE"?correct.split(",").map(x=>x.trim()):correct):undefined,marks,orderIndex:count}});await db.auditLog.create({data:{userId:user.id,action:"EXAM_QUESTION_ADDED",entity:"Exam",entityId:examId,metadataJson:JSON.stringify({orderIndex:count})}});revalidatePath(`/control-centre/exams/${examId}`)}
export async function uploadExamDocument(formData:FormData){const {db,user}=await requireOperationalStaffUser("exams.manage");const examId=String(formData.get("examId")||"");const type=String(formData.get("type")||"") as any;const title=String(formData.get("title")||"").trim();const file=formData.get("file");if(!examId||!title||!(file instanceof File)||!file.size)throw new Error("Exam, title and file are required.");if(!["QUESTION_PAPER","ANSWER_TEMPLATE","INSTRUCTIONS","REFERENCE"].includes(type))throw new Error("Invalid document type.");const url=await uploadPrivateFile(file,"gitdm/exams",`${examId}-${type}`);const doc=await db.examDocument.create({data:{examId,type,title,url,originalName:file.name}});await db.auditLog.create({data:{userId:user.id,action:"EXAM_DOCUMENT_UPLOADED",entity:"ExamDocument",entityId:doc.id,metadataJson:JSON.stringify({examId,type,name:file.name})}});revalidatePath(`/control-centre/exams/${examId}`)}
export async function submitExamForApproval(formData: FormData) {
 const { db, user } = await requireOperationalStaffUser("exams.manage");
 const examId = String(formData.get("examId") || "");
 const exam = await db.exam.findUnique({ where: { id: examId }, include: { course: true, questions: true } });
 if (!exam) throw new Error("Examination not found.");
 if (!exam.questions.length) throw new Error("Add at least one question before submitting the examination.");
 if (!["DRAFT", "REJECTED"].includes(exam.status)) throw new Error("Only draft or returned examinations can be submitted.");
 await db.exam.update({ where: { id: examId }, data: { status: "PENDING_APPROVAL", submittedById: user.id, submittedAt: new Date(), rejectionReason: null } });
 const directors = await db.user.findMany({ where: { status: "ACTIVE", roles: { some: { role: { code: { in: ["PRINCIPAL", "ACADEMIC_DIRECTOR"] } } } } }, select: { id: true } });
 if (directors.length) await db.notification.createMany({ data: directors.map((d) => ({ userId: d.id, type: "ACADEMIC" as const, title: "Examination awaiting approval", body: `${exam.course.code} — ${exam.title} has been prepared and submitted for Academic Director approval.` })) });
 await db.auditLog.create({ data: { userId: user.id, action: "EXAM_SUBMITTED_FOR_APPROVAL", entity: "Exam", entityId: examId } });
 revalidatePath(`/control-centre/exams/${examId}`); revalidatePath("/control-centre/exams");
}

export async function reviewExam(formData: FormData) {
 const { db, user } = await requireOperationalStaffUser("exams.manage");
 if (!user.roles.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR"].includes(r.role.code))) throw new Error("Only Academic leadership can approve examinations.");
 const examId = String(formData.get("examId") || ""); const decision = String(formData.get("decision") || ""); const reason = String(formData.get("reason") || "").trim();
 if (!['APPROVE','REJECT'].includes(decision)) throw new Error("Invalid examination review decision.");
 const exam = await db.exam.findUnique({ where: { id: examId }, include: { course: true, questions: true } });
 if (!exam || exam.status !== "PENDING_APPROVAL") throw new Error("This examination is not awaiting approval.");
 if (!exam.questions.length) throw new Error("An examination must contain at least one question.");
 if (decision === "REJECT") {
   await db.exam.update({ where: { id: examId }, data: { status: "REJECTED", rejectionReason: reason || "Please revise and resubmit.", approvedAt: null, approvedById: null } });
   if (exam.submittedById) await db.notification.create({ data: { userId: exam.submittedById, type: "ACADEMIC", title: "Examination returned for revision", body: `${exam.course.code} — ${exam.title} was returned by Academic leadership. ${reason || "Please review the examination and resubmit."}` } });
 } else {
   if (exam.opensAt && exam.closesAt && exam.closesAt <= exam.opensAt) throw new Error("Exam closing time must be after opening time.");
   await db.exam.update({ where: { id: examId }, data: { status: "PUBLISHED", publishedAt: new Date(), approvedAt: new Date(), approvedById: user.id, rejectionReason: null } });
   const enrolled = await db.courseEnrollment.findMany({ where: { courseId: exam.courseId, status: { in: ["ACTIVE", "REPEATING"] }, enrollment: { status: { in: ["ACTIVE", "REPEATING"] }, ...(exam.periodId ? { periodId: exam.periodId } : {}) } }, select: { enrollment: { select: { userId: true } } } });
   const ids = [...new Set(enrolled.map((e) => e.enrollment.userId))];
   if (ids.length) await db.notification.createMany({ data: ids.map((userId) => ({ userId, type: "ACADEMIC" as const, title: "Examination published", body: `${exam.course.code} — ${exam.title} is now published. Check the schedule and examination format in Exams & Assessments.` })) });
   if (exam.submittedById) await db.notification.create({ data: { userId: exam.submittedById, type: "ACADEMIC", title: "Examination approved", body: `${exam.course.code} — ${exam.title} has been approved and published by Academic leadership.` } });
 }
 await db.auditLog.create({ data: { userId: user.id, action: `EXAM_${decision === "APPROVE" ? "APPROVED" : "REJECTED"}`, entity: "Exam", entityId: examId, metadataJson: reason ? JSON.stringify({ reason }) : undefined } });
 revalidatePath(`/control-centre/exams/${examId}`); revalidatePath("/control-centre/exams"); revalidatePath("/campus/assessments");
}

export async function publishExam(formData: FormData){
 const {db,user}=await requireOperationalStaffUser("exams.manage"); const examId=String(formData.get("examId")||"");
 if(!user.roles.some((r)=>["PRINCIPAL","ACADEMIC_DIRECTOR"].includes(r.role.code))) throw new Error("Examinations are published by Academic leadership after review.");
 const exam=await db.exam.findUnique({where:{id:examId},include:{questions:true,course:true}});
 if(!exam||!exam.questions.length)throw new Error("An examination must contain at least one question before publishing.");
 if(exam.opensAt&&exam.closesAt&&exam.closesAt<=exam.opensAt)throw new Error("Exam closing time must be after opening time.");
 await db.exam.update({where:{id:examId},data:{status:"PUBLISHED",publishedAt:new Date()}});
 const enrollments=await db.courseEnrollment.findMany({where:{courseId:exam.courseId,status:{in:["ACTIVE","REPEATING"]},enrollment:{status:{in:["ACTIVE","REPEATING"]},...(exam.periodId?{periodId:exam.periodId}:{})}},select:{enrollment:{select:{userId:true}}}});
 const uniqueUsers=[...new Set(enrollments.map((x)=>x.enrollment.userId))];
 if(uniqueUsers.length){await db.notification.createMany({data:uniqueUsers.map((userId)=>({userId,type:"ACADEMIC",title:"Examination published",body:`${exam.course.code} — ${exam.title} is now available in Exams & Assessments. Check the schedule, format, venue and eligibility before the examination window opens.`}))});}
 await db.auditLog.create({data:{userId:user.id,action:"EXAM_PUBLISHED",entity:"Exam",entityId:examId,metadataJson:JSON.stringify({notifiedStudents:uniqueUsers.length})}});
 revalidatePath("/control-centre/exams"); revalidatePath(`/control-centre/exams/${examId}`); revalidatePath("/campus/assessments");
}
export async function closeExam(formData:FormData){const {db,user}=await requireOperationalStaffUser("exams.manage");const examId=String(formData.get("examId")||"");await db.exam.update({where:{id:examId},data:{status:"CLOSED"}});await db.auditLog.create({data:{userId:user.id,action:"EXAM_CLOSED",entity:"Exam",entityId:examId}});revalidatePath("/control-centre/exams");revalidatePath(`/control-centre/exams/${examId}`);revalidatePath("/campus/assessments")}
export async function finalizeExamAttempt(formData: FormData) {
  const { db, user } = await requireOperationalStaffUser("exams.mark");
  const attemptId = String(formData.get("attemptId") || "");
  const finalScore = Number(formData.get("finalScore"));
  if (!attemptId || Number.isNaN(finalScore) || finalScore < 0 || finalScore > 100) throw new Error("Final exam score must be between 0 and 100.");
  const attempt = await db.examAttempt.findUnique({ where: { id: attemptId }, include: { exam: { include: { course: true } } } });
  if (!attempt) throw new Error("Exam attempt not found.");
  const leadership = user.roles.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR"].includes(r.role.code));
  const status = leadership ? "FINALIZED" : "MARKED_PENDING_CONFIRMATION";
  await db.examAttempt.update({ where: { id: attemptId }, data: { manualScore: finalScore, finalScore, status } });
  if (leadership) {
    await syncStudentCourseGrade(db, attempt.userId, attempt.exam.courseId, attempt.exam.periodId);
  } else {
    const directors = await db.user.findMany({ where: { status: "ACTIVE", roles: { some: { role: { code: { in: ["PRINCIPAL", "ACADEMIC_DIRECTOR"] } } } } }, select: { id: true } });
    if (directors.length) await db.notification.createMany({ data: directors.map((d) => ({ userId: d.id, type: "ACADEMIC" as const, title: "Exam mark awaiting confirmation", body: `${attempt.exam.course.code} — ${attempt.exam.title} has been marked at ${finalScore.toFixed(1)}% and is awaiting Academic confirmation.` })) });
  }
  await db.notification.create({ data: { userId: attempt.userId, type: "ACADEMIC", title: leadership ? "Examination marked" : "Examination marked by lecturer", body: `${attempt.exam.course.code} — ${attempt.exam.title}: ${finalScore.toFixed(1)}%. ${leadership ? "The mark has been confirmed and synchronized into the course grade." : "The mark is awaiting Academic Director confirmation."}` } });
  await db.auditLog.create({ data: { userId: user.id, action: leadership ? "EXAM_ATTEMPT_CONFIRMED" : "EXAM_ATTEMPT_MARKED", entity: "ExamAttempt", entityId: attemptId, metadataJson: JSON.stringify({ examId: attempt.examId, finalScore, status }) } });
  revalidatePath(`/control-centre/exams/${attempt.examId}`); revalidatePath("/control-centre/results"); revalidatePath("/campus/assessments");
}

export async function confirmExamMark(formData: FormData) {
  const { db, user } = await requireOperationalStaffUser("results.moderate");
  if (!user.roles.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR"].includes(r.role.code))) throw new Error("Only Academic leadership can confirm lecturer examination marks.");
  const attemptId = String(formData.get("attemptId") || "");
  const attempt = await db.examAttempt.findUnique({ where: { id: attemptId }, include: { exam: { include: { course: true } } } });
  if (!attempt) throw new Error("Exam attempt not found.");
  if (attempt.status !== "MARKED_PENDING_CONFIRMATION") throw new Error("This examination mark is not awaiting confirmation.");
  await db.examAttempt.update({ where: { id: attemptId }, data: { status: "FINALIZED" } });
  await syncStudentCourseGrade(db, attempt.userId, attempt.exam.courseId, attempt.exam.periodId);
  await db.notification.create({ data: { userId: attempt.userId, type: "ACADEMIC", title: "Examination result confirmed", body: `${attempt.exam.course.code} — ${attempt.exam.title}: your examination mark has been confirmed by Academic leadership and synchronized into your course result.` } });
  await db.auditLog.create({ data: { userId: user.id, action: "EXAM_ATTEMPT_CONFIRMED", entity: "ExamAttempt", entityId: attemptId } });
  revalidatePath(`/control-centre/exams/${attempt.examId}`); revalidatePath("/control-centre/results"); revalidatePath("/campus/assessments");
}
