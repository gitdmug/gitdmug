import Link from "next/link";
import { notFound } from "next/navigation";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ControlNav } from "@/components/ControlNav";
import { GITDM } from "@/lib/branding";
import { requireStaffUser } from "@/lib/control-centre";
import { humanStatus } from "@/lib/status";
import { addExamQuestion, closeExam, finalizeExamAttempt, publishExam, uploadExamDocument, submitExamForApproval, reviewExam, confirmExamMark } from "../actions";

export const dynamic = "force-dynamic";
export const metadata = { title: `Examination | ${GITDM.shortName}` };

export default async function ExamDetailPage({ params }: { params: Promise<{ examId: string }> }) {
  const { examId } = await params;
  const { db } = await requireStaffUser("academic.view");
  const exam = await db.exam.findUnique({
    where: { id: examId },
    include: {
      course: true,
      period: true,
      documents: true,
      questions: { orderBy: { orderIndex: "asc" } },
      attempts: { orderBy: { submittedAt: "desc" }, include: { user: true, submissionFiles: true } },
    },
  });
  if (!exam) notFound();

  return (
    <>
      <Header workspace="staff" />
      <ControlNav active="/control-centre/exams" />
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">{exam.course.code} · Examination lifecycle</div>
            <h1>{exam.title}</h1>
            <p>{exam.period?.name || "No academic period"} · {exam.deliveryMode} · {exam.submissionMode.replaceAll("_", " ")}</p>
          </div>
        </section>
        <section className="section">
          <div className="container">
            <div className="actions" style={{ marginBottom: 24 }}>
              <span className="badge">{humanStatus(exam.status)}</span>{exam.status === "PUBLISHED" ? <span className="badge success">Visible to eligible enrolled students</span> : null}
              {exam.status === "DRAFT" || exam.status === "REJECTED" ? <form action={submitExamForApproval}><input type="hidden" name="examId" value={exam.id} /><button className="btn btn-primary btn-sm">Submit to Academic Director</button></form> : null}
              {exam.status === "PENDING_APPROVAL" ? <><form action={reviewExam}><input type="hidden" name="examId" value={exam.id} /><input type="hidden" name="decision" value="APPROVE"/><button className="btn btn-primary btn-sm">Approve &amp; publish</button></form><form action={reviewExam} className="actions"><input type="hidden" name="examId" value={exam.id}/><input type="hidden" name="decision" value="REJECT"/><input name="reason" placeholder="Revision feedback" required/><button className="btn btn-outline-dark btn-sm">Return for revision</button></form></> : null}
              {exam.status === "PUBLISHED" ? <form action={closeExam}><input type="hidden" name="examId" value={exam.id} /><button className="btn btn-outline-dark btn-sm">Close examination</button></form> : null}
              <Link href="/control-centre/exams" className="btn btn-outline-dark btn-sm">← Examination register</Link>
            </div>

            <div className="grid grid-3" style={{ marginBottom: 28 }}>
              <div className="panel"><div className="eyebrow">Schedule</div><h3>{exam.opensAt?.toLocaleString("en-UG") || "Not scheduled"}</h3><p>{exam.closesAt ? `Closes ${exam.closesAt.toLocaleString("en-UG")}` : "No closing time"}</p></div>
              <div className="panel"><div className="eyebrow">Format</div><h3>{exam.formatDescription || exam.submissionMode.replaceAll("_", " ")}</h3><p>{exam.timeLimitMinutes ? `${exam.timeLimitMinutes} minute limit` : "No time limit"}</p></div>
              <div className="panel"><div className="eyebrow">Venue / delivery</div><h3>{exam.deliveryMode}</h3><p>{exam.venue || "Online"}{exam.room ? ` · ${exam.room}` : ""}</p></div>
            </div>

            <div className="grid grid-2">
              <div>
                <div className="eyebrow">Question bank</div>
                <h2>{exam.questions.length} question(s)</h2>
                {exam.questions.map((q, i) => {
                  let options: string[] = [];
                  try { options = q.optionsJson ? JSON.parse(q.optionsJson) : []; } catch {}
                  return <div className="card" key={q.id} style={{ marginBottom: 12 }}>
                    <span className="chip">Q{i + 1} · {q.type} · {Number(q.marks)} mark(s)</span>
                    <h3>{q.prompt}</h3>
                    {options.length ? <ul>{options.map((o) => <li key={o}>{o}</li>)}</ul> : null}
                    <p style={{ margin: 0, fontSize: 13 }}>Auto-answer: {q.correctJson ? "Configured" : "Manual review"}</p>
                  </div>;
                })}
              </div>

              <div className="stack">
                {exam.status === "DRAFT" ? <div className="card">
                  <div className="eyebrow">Build paper</div><h2>Add question</h2>
                  <form action={addExamQuestion} className="stack">
                    <input type="hidden" name="examId" value={exam.id} />
                    <label>Question type<select name="type"><option value="SINGLE_CHOICE">Single choice</option><option value="MULTIPLE_CHOICE">Multiple choice</option><option value="TRUE_FALSE">True / False</option><option value="SHORT_ANSWER">Short answer</option><option value="NUMERICAL">Numerical</option><option value="ESSAY">Essay</option><option value="LINK_RESPONSE">Link / URL response</option></select></label>
                    <label>Question<textarea name="prompt" required /></label>
                    <label>Options<textarea name="options" placeholder="One option per line" /></label>
                    <label>Correct answer<input name="correct" placeholder="For multiple choice, comma-separate correct options" /></label>
                    <label>Marks<input name="marks" type="number" min="0.5" step="0.5" defaultValue="1" /></label>
                    <button className="btn btn-primary">Add question</button>
                  </form>
                </div> : <div className="card"><h2>Published paper locked</h2><p>Academic approval locks the question bank so student attempts cannot change underneath them.</p>{exam.rejectionReason ? <div className="access-banner"><strong>Revision feedback:</strong> {exam.rejectionReason}</div> : null}</div>}

                <div className="card">
                  <div className="eyebrow">Exam documents</div><h2>Upload controlled documents</h2>
                  <p>Question papers, instructions and answer templates are stored against this examination.</p>
                  <form action={uploadExamDocument} encType="multipart/form-data" className="stack">
                    <input type="hidden" name="examId" value={exam.id} />
                    <label>Document title<input name="title" required placeholder="Final Examination Instructions" /></label>
                    <label>Type<select name="type"><option value="QUESTION_PAPER">Question paper</option><option value="ANSWER_TEMPLATE">Answer template</option><option value="INSTRUCTIONS">Instructions</option><option value="REFERENCE">Reference</option></select></label>
                    <input type="file" name="file" accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.jpg,.jpeg,.png,.mp4,.mp3,.zip,.txt" required />
                    <button className="btn btn-outline-dark">Upload document</button>
                  </form>
                  {exam.documents.length ? <div className="stack" style={{ marginTop: 16 }}>{exam.documents.map((d) => <div className="staff-notice" key={d.id}><div><strong>{d.title}</strong><p>{d.originalName || d.type}</p></div><a className="btn btn-outline-dark btn-sm" href={d.url.startsWith("neonfile:") ? `/api/campus/files/exam-document/${d.id}` : d.url} target="_blank" rel="noreferrer">Open</a></div>)}</div> : null}
                </div>
              </div>
            </div>

            <div style={{ marginTop: 36 }}>
              <div className="eyebrow">Attempts & marking</div><h2>{exam.attempts.length} attempt(s)</h2>
              {exam.attempts.length ? <div className="table-wrap"><table className="data"><thead><tr><th>Student</th><th>Attempt</th><th>Submitted</th><th>Auto</th><th>Final</th><th>Status</th><th>Files</th><th>Action</th></tr></thead><tbody>
                {exam.attempts.map((a) => <tr key={a.id}>
                  <td>{[a.user.firstName, a.user.lastName].filter(Boolean).join(" ") || a.user.email}</td><td>{a.attemptNo}</td><td>{a.submittedAt ? a.submittedAt.toLocaleString("en-UG") : "—"}</td><td>{a.autoScore == null ? "—" : `${Number(a.autoScore).toFixed(1)}%`}</td><td>{a.finalScore == null ? "—" : `${Number(a.finalScore).toFixed(1)}%`}</td><td>{humanStatus(a.status)}</td>
                  <td>{a.submissionFiles.length ? a.submissionFiles.map((f) => <a key={f.id} href={`/api/campus/files/exam-submission/${f.id}`} target="_blank" rel="noreferrer">{f.originalName}</a>) : "—"}</td>
                  <td>{a.status === "MARKED_PENDING_CONFIRMATION" ? <form action={confirmExamMark}><input type="hidden" name="attemptId" value={a.id}/><button className="btn btn-primary btn-sm">Confirm mark</button></form> : a.status !== "FINALIZED" ? <form action={finalizeExamAttempt} className="actions"><input type="hidden" name="attemptId" value={a.id} /><input name="finalScore" type="number" min="0" max="100" step="0.1" defaultValue={a.finalScore != null ? Number(a.finalScore) : a.autoScore != null ? Number(a.autoScore) : ""} placeholder="%" style={{ maxWidth: 90 }} /><button className="btn btn-primary btn-sm">Record / mark</button></form> : <span className="badge">Confirmed</span>}</td>
                </tr>)}
              </tbody></table></div> : <div className="panel"><p>No student attempts have been submitted.</p></div>}
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
