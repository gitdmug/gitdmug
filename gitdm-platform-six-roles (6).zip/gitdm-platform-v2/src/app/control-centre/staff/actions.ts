"use server";
import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { requireStaffUser } from "@/lib/control-centre";

export async function inviteStaff(formData: FormData) {
  const { db, user, roleCodes } = await requireStaffUser();
  if (!roleCodes.includes("PRINCIPAL") && !(roleCodes as string[]).includes("IT")) throw new Error("Only authorised institutional access management can assign departments.");
  const email = String(formData.get("email") || "").trim().toLowerCase();
  const configuredPrincipalEmail = (process.env.PRINCIPAL_BOOTSTRAP_EMAIL || (process.env.PRINCIPAL_BOOTSTRAP_EMAILS || "").split(",")[0] || "").trim().replace(/^['"]|['"]$/g, "").toLowerCase();
  if (email && configuredPrincipalEmail && email === configuredPrincipalEmail) throw new Error("The configured Principal account cannot be assigned to a department.");
  const departmentId = String(formData.get("departmentId") || "");
  if (!email || !email.includes("@")) throw new Error("Enter a valid staff email.");
  if (!departmentId) throw new Error("Choose a department.");
  const department = await db.department.findUnique({ where: { id: departmentId } });
  if (!department) throw new Error("Department not found.");
  const roles = await db.role.findMany({ where: { departmentId, isActive: true, code: { notIn: ["PRINCIPAL", "STUDENT", "PARENT_GUARDIAN", "ALUMNI"] } }, orderBy: { code: "asc" } });
  if (!roles.length) throw new Error("This department has no active operational permissions configured yet.");
  const existing = await db.user.findFirst({ where: { email: { equals: email, mode: "insensitive" } } });
  if (existing) {
    const isPrincipal = await db.userRole.findFirst({ where: { userId: existing.id, role: { code: "PRINCIPAL" } }, select: { userId: true, roleId: true } });
    if (isPrincipal) throw new Error("The Principal cannot be assigned to a department or included in the staff register.");
    await db.$transaction(async (tx) => {
      // Department allocation is exclusive: move the staff member out of other
      // departments and remove only their other department access grants. Audit history is untouched.
      await tx.userDepartment.deleteMany({ where: { userId: existing.id, departmentId: { not: departmentId } } });
      await tx.userRole.deleteMany({ where: { userId: existing.id, role: { departmentId: { not: departmentId }, code: { notIn: ["PRINCIPAL", "STUDENT", "PARENT_GUARDIAN", "ALUMNI"] } } } });
      await tx.userDepartment.upsert({ where: { userId_departmentId: { userId: existing.id, departmentId } }, update: {}, create: { userId: existing.id, departmentId } });
      for (const role of roles) await tx.userRole.upsert({ where: { userId_roleId: { userId: existing.id, roleId: role.id } }, update: {}, create: { userId: existing.id, roleId: role.id, assignedBy: user.id } });
      await tx.auditLog.create({ data: { userId: user.id, action: "DEPARTMENT_MEMBER_ASSIGNED", entity: "UserDepartment", entityId: existing.id, metadataJson: JSON.stringify({ email, departmentId, department: department.name, provisionedDepartmentRoles: roles.map(r => r.code) }) } });
    });
  } else {
    const defaultRole = roles[0];
    const pending = await db.staffInvitation.findFirst({ where: { email, departmentId, status: "PENDING" } });
    if (!pending) await db.staffInvitation.create({ data: { email, roleCode: defaultRole.code, departmentId, invitedById: user.id } });
    await db.auditLog.create({ data: { userId: user.id, action: "DEPARTMENT_INVITATION_CREATED", entity: "StaffInvitation", metadataJson: JSON.stringify({ email, departmentId, department: department.name }) } });
  }
  revalidatePath("/control-centre/staff");
  revalidatePath("/control-centre/departments");
  revalidatePath("/control-centre/users");
  redirect("/control-centre/staff?department=assigned");
}
