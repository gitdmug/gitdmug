"use client";

export function StaffAllocationForm({ departments, action }: { departments: { id: string; name: string }[]; roles?: { code: string; name: string; departmentId: string | null }[]; action: (formData: FormData) => void | Promise<void> }) {
  return <form action={action} className="form-grid" style={{ marginTop: 18 }}>
    <div className="grid grid-2">
      <label>Staff email<input name="email" type="email" placeholder="staff@globalinstituteoftrading.com" required /></label>
      <label>Department<select name="departmentId" required defaultValue=""><option value="" disabled>Choose department…</option>{departments.map((d)=><option key={d.id} value={d.id}>{d.name}</option>)}</select></label>
    </div>
    <p className="muted" style={{ margin: 0 }}>Department membership grants access to the shared departmental workspace. Staff divide tasks among themselves; each action is recorded against the individual signed-in account.</p>
    <button className="btn btn-primary">Assign department</button>
  </form>;
}
