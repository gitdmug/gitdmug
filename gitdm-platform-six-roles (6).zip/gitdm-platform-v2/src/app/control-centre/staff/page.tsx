import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ControlNav } from "@/components/ControlNav";
import { inviteStaff } from "./actions"
import { GITDM } from "@/lib/branding";
import { requireStaffUser } from "@/lib/control-centre";
import { ensureInstitutionalRoles } from "@/lib/role-provisioning";
import { StaffAllocationForm } from "./StaffAllocationForm";

export const metadata = { title: `Staff | Control Centre | ${GITDM.shortName}` };
export const dynamic = "force-dynamic";

function label(value: string) {
  return value.replaceAll("_", " ").toLowerCase().replace(/(^|\s)\S/g, (c) => c.toUpperCase());
}

export default async function StaffRegisterPage() {
  const { db, roleCodes } = await requireStaffUser("users.view");
  await ensureInstitutionalRoles(db);
  const canAssign = roleCodes.includes("PRINCIPAL") || (roleCodes as string[]).includes("IT");
  const staffRoles = [
    "ADMISSIONS", "CURRICULUM_DEVELOPER", "ONLINE_INSTRUCTOR", "EXAM_OFFICER", "ACADEMIC_ADVISOR_REGISTRAR", "STUDENT_SUCCESS_COACH", "SCHOOL_COUNSELOR", "CTO_IT_DIRECTOR", "LMS_ADMINISTRATOR", "HELPDESK_TECHNICIAN", "OPERATIONS_COMPLIANCE_MANAGER", "FINANCE", "MARKETING",
  ];

  const users = await db.user.findMany({
    where: { roles: { some: { role: { code: { in: staffRoles as any } } } }, NOT: { roles: { some: { role: { code: "PRINCIPAL" } } } } },
    orderBy: [{ status: "asc" }, { createdAt: "desc" }],
    include: {
      roles: { include: { role: true } },
      departments: { include: { department: true } },
      _count: { select: { auditLogs: true, assignedTickets: true } },
    },
  });

  const operationalDepartmentNames = [
    "Admissions & Enrollment",
    "Academic Affairs & Instruction",
    "Student Success & Support",
    "Technology & Infrastructure",
    "Operations & Business Administration",
  ];
  const departments = await db.department.findMany({
    where: { name: { in: operationalDepartmentNames } },
    orderBy: { name: "asc" },
    include: { _count: { select: { users: true } } },
  });
  
  return (
    <>
      <Header workspace="staff" />
      <ControlNav active="/control-centre/staff" />
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">People &amp; Organisation</div>
            <h1>Staff register</h1>
            <p>Department staff, shared workspace membership, status, and individual operational activity. The Principal is institutional leadership and is not listed as staff.</p>
          </div>
        </section>
        <section className="section">
          <div className="container">
            <div className="actions" style={{ marginBottom: 24, flexWrap: "wrap" }}>
              <Link href="/control-centre/users" className="btn btn-outline-dark btn-sm">Users</Link>
              <Link href="/control-centre/departments" className="btn btn-primary btn-sm">Departments</Link>
              <Link href="/control-centre" className="btn btn-outline-dark btn-sm">Command Centre</Link>
            </div>

            
            {canAssign ? <div className="card" style={{ marginBottom: 28 }}>
              <div className="eyebrow">Principal staff allocation</div>
              <h2>Assign a staff member to a department</h2>
              <p>Choose only the department. All members share the department workspace and can divide the operational work among themselves. Individual actions remain attributed to the staff account that performed them.</p>
              <StaffAllocationForm action={inviteStaff} departments={departments.map((d)=>({id:d.id,name:d.name}))} />
            </div> : null}

            <div className="grid grid-3" style={{ marginBottom: 28 }}>
              <div className="panel"><div className="eyebrow">Staff</div><h2 style={{ margin: "8px 0 0", fontSize: "2rem" }}>{users.length}</h2><p style={{ margin: 0 }}>accounts with institutional staff roles</p></div>
              <div className="panel"><div className="eyebrow">Departments</div><h2 style={{ margin: "8px 0 0", fontSize: "2rem" }}>{departments.length}</h2><p style={{ margin: 0 }}>configured organisational units</p></div>
              <div className="panel"><div className="eyebrow">Active staff</div><h2 style={{ margin: "8px 0 0", fontSize: "2rem" }}>{users.filter((u) => u.status === "ACTIVE").length}</h2><p style={{ margin: 0 }}>accounts currently active</p></div>
            </div>

            {!canAssign ? <div className="panel" style={{ marginBottom: 24 }}><span className="badge warn">Read only</span><p style={{ margin: "10px 0 0" }}>Your role can review staff information. Access assignment remains restricted to the current authorised access-management roles.</p></div> : null}

            <div className="table-wrap">
              <table className="data">
                <thead><tr><th>Staff member</th><th>Department</th><th>Status</th><th>Activity</th><th>Profile</th></tr></thead>
                <tbody>
                  {users.map((u) => {
                    const name = [u.firstName, u.lastName].filter(Boolean).join(" ") || u.email;
                    const deps = u.departments.map((d) => `${d.department.name}${d.isHead ? " · Head" : ""}`);
                    return <tr key={u.id}>
                      <td><strong>{name}</strong><br /><span className="muted">{u.email}</span></td>
                      <td>{deps.length ? deps.join(", ") : "Unassigned"}</td>
                      <td><span className={`badge ${u.status === "ACTIVE" ? "ok" : "warn"}`}>{label(u.status)}</span></td>
                      <td>{u._count.assignedTickets} cases · {u._count.auditLogs} audit events</td>
                      <td><Link href={`/control-centre/staff/${u.id}`} className="btn btn-outline-dark btn-sm">Open</Link></td>
                    </tr>;
                  })}
                  {users.length === 0 ? <tr><td colSpan={5}>No staff accounts have been assigned to a department yet.</td></tr> : null}
                </tbody>
              </table>
            </div>

            <div className="panel" style={{ marginTop: 28 }}>
              <h3 style={{ marginTop: 0 }}>How staffing is organised</h3>
              <p style={{ marginBottom: 0 }}>Neon Auth establishes identity. The Principal assigns each staff member to one department. Department members share the department workspace and divide tasks internally; every action remains attributable to the individual account. The Principal remains outside departmental staffing and has exclusive institutional authority.</p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
