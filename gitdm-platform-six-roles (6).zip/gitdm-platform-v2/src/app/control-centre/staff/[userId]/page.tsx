import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ControlNav } from "@/components/ControlNav";
import { GITDM } from "@/lib/branding";
import { requireStaffUser } from "@/lib/control-centre";
import { StaffDepartmentForm } from "../../StaffDepartmentForm";

export const dynamic = "force-dynamic";
export const metadata = { title: `Staff profile | Control Centre | ${GITDM.shortName}` };

export default async function StaffProfilePage({ params }: { params: Promise<{ userId: string }> }) {
  const { user: actor, db, roleCodes } = await requireStaffUser("users.view");
  const { userId } = await params;
  const canAssignDepartment = roleCodes.includes("PRINCIPAL") || (roleCodes as string[]).includes("IT");
  const user = await db.user.findUnique({
    where: { id: userId },
    include: {
      profile: true,
      roles: { include: { role: true } },
      departments: { include: { department: true } },
      applications: { orderBy: { submittedAt: "desc" }, take: 5 },
      enrollments: { orderBy: { createdAt: "desc" }, take: 5, include: { programme: true } },
      assignedTickets: { orderBy: { createdAt: "desc" }, take: 5 },
      auditLogs: { orderBy: { createdAt: "desc" }, take: 8 },
    },
  });
  if (!user) return <><Header workspace="staff" /><ControlNav active="/control-centre/staff" /><main><section className="section"><div className="container"><h1>Staff member not found</h1><Link href="/control-centre/staff" className="btn btn-primary">Back to staff</Link></div></section></main><Footer /></>;
  const departments = await db.department.findMany({ orderBy: { name: "asc" } });
  const name = [user.firstName, user.lastName].filter(Boolean).join(" ") || user.email;

  return <>
    <Header workspace="staff" />
    <ControlNav active="/control-centre/staff" />
    <main>
      <section className="page-hero"><div className="container"><div className="eyebrow">Staff profile</div><h1>{name}</h1><p>{user.email} · {user.status}</p></div></section>
      <section className="section"><div className="container">
        <div className="actions" style={{ marginBottom: 24 }}><Link href="/control-centre/staff" className="btn btn-outline-dark btn-sm">← Staff register</Link></div>
        {user.roles.some((r) => r.role.code === "PRINCIPAL") ? <div className="panel" style={{ marginBottom: 24 }}><strong>Institutional Principal</strong><p style={{ marginBottom: 0 }}>This account sits above departmental staffing and cannot be assigned to a department or managed as a staff member.</p></div> : null}
        <div className="grid grid-3">
          <div className="panel"><div className="eyebrow">Identity</div><h3>{name}</h3><p>{user.email}</p><p>{user.phone || "No phone recorded"}</p><span className={`badge ${user.status === "ACTIVE" ? "ok" : "warn"}`}>{user.status}</span></div>
          <div className="panel"><div className="eyebrow">System-managed access</div><p style={{ marginTop: 12 }}>Access is provisioned from department membership. The Principal does not assign individual roles here.</p></div>
          <div className="panel"><div className="eyebrow">Departments</div><div style={{ marginTop: 12 }}>{user.departments.length ? user.departments.map((d) => <div key={d.departmentId}>{d.department.name}{d.isHead ? " · Head" : ""}</div>) : "Unassigned"}</div></div>
        </div>

        {canAssignDepartment && !user.roles.some((r) => r.role.code === "PRINCIPAL") ? <div className="grid grid-1" style={{ marginTop: 24 }}>
          <div className="panel"><h3 style={{ marginTop: 0 }}>Department assignment</h3><p>Assign this staff member to a department. The team divides operational responsibilities internally; each action remains attributed to the individual signed-in account.</p><StaffDepartmentForm userId={user.id} actorId={actor.id} departments={departments.map((d) => ({ id: d.id, name: d.name }))} current={user.departments.map((d) => ({ departmentId: d.departmentId, isHead: d.isHead }))} /></div>
        </div> : null}

        <div className="staff-section-head" style={{ marginTop: 40 }}><div><div className="eyebrow">Operational record</div><h2>Recent activity</h2></div></div>
        <div className="table-wrap"><table className="data"><thead><tr><th>Date</th><th>Action</th><th>Entity</th><th>Severity</th></tr></thead><tbody>{user.auditLogs.map((log) => <tr key={log.id}><td>{log.createdAt.toISOString().slice(0, 19).replace("T", " ")}</td><td>{log.action}</td><td>{log.entity}{log.entityId ? ` · ${log.entityId.slice(0, 10)}` : ""}</td><td>{log.severity}</td></tr>)}{user.auditLogs.length === 0 ? <tr><td colSpan={4}>No audit activity recorded for this account.</td></tr> : null}</tbody></table></div>
      </div></section>
    </main><Footer />
  </>;
}
