import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { GITDM } from "@/lib/branding";
import { requireStaffUser } from "@/lib/control-centre";
import { ControlNav } from "@/components/ControlNav";
import { isStaffRole } from "@/lib/role-provisioning";

export const metadata = {
  title: `Users | Control Centre | ${GITDM.shortName}`,
};

export const dynamic = "force-dynamic";

export default async function ControlCentreUsersPage() {
  const { db, roleCodes } = await requireStaffUser("users.view");
  // The Principal manages department membership only. Individual role assignment is intentionally not exposed here.
  const canAssign = roleCodes.includes("PRINCIPAL");
  // Show every institutional account; the Principal uses department allocation rather than individual role assignment.
  const users = await db.user.findMany({
    orderBy: { createdAt: "desc" },
    include: { roles: { include: { role: true } }, departments: { include: { department: true } }, enrollments: { select: { status: true, accessLevel: true } } },
  });

  const isPrincipal = (u: (typeof users)[number]) => u.roles.some((r) => r.role.code === "PRINCIPAL");
  const grouped = {
    leadership: users.filter(isPrincipal),
    members: users.filter((u) => !isPrincipal(u) && u.enrollments?.some((e) => ["ACTIVE", "REPEATING"].includes(e.status) && e.accessLevel === "FULL") && !u.roles.some((r) => isStaffRole(r.role.code as any)) && !u.roles.some((r) => ["PARENT_GUARDIAN", "ALUMNI"].includes(r.role.code))),
    limited: users.filter((u) => !isPrincipal(u) && !u.enrollments?.some((e) => ["ACTIVE", "REPEATING"].includes(e.status) && e.accessLevel === "FULL") && !u.roles.some((r) => isStaffRole(r.role.code as any)) && !u.roles.some((r) => ["PARENT_GUARDIAN", "ALUMNI"].includes(r.role.code))),
    staff: users.filter((u) => !isPrincipal(u) && u.roles.some((r) => isStaffRole(r.role.code as any))),
    other: users.filter((u) => !isPrincipal(u) && u.roles.some((r) => ["PARENT_GUARDIAN", "ALUMNI"].includes(r.role.code)) && !u.roles.some((r) => isStaffRole(r.role.code as any))),
  };


  return (
    <>
      <Header workspace="staff" />
      <ControlNav active="/control-centre/users" />
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">Control Centre</div>
            <h1>Users &amp; department membership</h1>
            <p>
              People who have signed in via Neon Auth. The Principal is a single, exclusive institutional authority outside departments and staff listings. Staff are assigned to one department; departmental access is shared and individual actions are logged to the account that performs them.
            </p>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className="actions" style={{ marginBottom: 24 }}>
              <Link href="/control-centre" className="btn btn-outline-dark btn-sm">
                ← Back to Control Centre
              </Link>
            </div>

            {!canAssign ? (
              <div className="panel" style={{ marginBottom: 24 }}>
                <span className="badge warn">Read only</span>
                <p style={{ marginTop: 12, marginBottom: 0 }}>
                  You can view users. Department assignment is available only to the Principal.
                </p>
              </div>
            ) : null}

            {([
              ["Institutional leadership (outside staff)", grouped.leadership],
              ["Full-access members", grouped.members],
              ["Limited-access users", grouped.limited],
              ["Staff & leadership", grouped.staff],
              ["Other member roles", grouped.other],
            ] as const).map(([title, group]) => (
              <section key={title} style={{ marginBottom: 30 }}>
                <div className="section-header compact"><div><div className="eyebrow">People</div><h2 style={{ margin: 0 }}>{title}</h2></div><span className="badge">{group.length}</span></div>
                <div className="table-wrap">
                  <table className="data">
                    <thead><tr><th>Email</th><th>Name</th><th>Status</th><th>Current department</th>{canAssign ? <th>Department management</th> : null}</tr></thead>
                    <tbody>
                      {group.map((u) => (
                        <tr key={u.id}>
                          <td>{u.email}</td><td>{[u.firstName, u.lastName].filter(Boolean).join(" ") || "—"}</td><td>{u.status}</td>
                          <td>{u.departments.map((d) => d.department.name).join(", ") || "Not assigned"}</td>
                          {canAssign ? <td>{isPrincipal(u) ? <span className="muted">Institutional authority · no department</span> : <Link className="btn btn-outline-dark btn-sm" href="/control-centre/staff">Assign department</Link>}</td> : null}
                        </tr>
                      ))}
                      {!group.length ? <tr><td colSpan={canAssign ? 5 : 4}>No users in this group.</td></tr> : null}
                    </tbody>
                  </table>
                </div>
              </section>
            ))}

            <div className="panel" style={{ marginTop: 28 }}>
              <h3 style={{ marginTop: 0 }}>How staffing works</h3>
              <ol style={{ marginBottom: 0, paddingLeft: 20 }}>
                <li>Any person signs up / logs in with Neon Auth.</li>
                <li>A normal account is simply a user; no STUDENT role is allocated.</li>
                <li>Principal assigns the department; department members share the operational workspace.</li>
                <li>On the next login, the role determines the landing workspace; staff never default to Student.</li>
              </ol>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
