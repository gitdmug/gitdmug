import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ControlNav } from "@/components/ControlNav";
import { GITDM } from "@/lib/branding";
import { requireStaffUser } from "@/lib/control-centre";

export const dynamic = "force-dynamic";
export const metadata = { title: `Trader insights | ${GITDM.shortName}` };

/**
 * Principal institutional view of all market analysis journals.
 */
export default async function PrincipalInsightsPage() {
  const { db } = await requireStaffUser("reports.view");

  const runs = await db.marketAnalysisRun.findMany({
    orderBy: { createdAt: "desc" },
    take: 500,
    include: { user: { select: { id: true, email: true, firstName: true, lastName: true } } },
  });

  const wins = runs.filter((r) => r.outcome === "WIN").length;
  const losses = runs.filter((r) => r.outcome === "LOSS").length;
  const pending = runs.filter((r) => r.outcome === "PENDING" || !r.outcome).length;
  const neutral = runs.filter((r) => r.outcome === "NEUTRAL").length;
  const decided = wins + losses;
  const winRate = decided ? Math.round((wins / decided) * 1000) / 10 : null;

  const bySymbol = new Map<string, { total: number; wins: number; losses: number }>();
  for (const r of runs) {
    const s = (r.symbol || "UNKNOWN").toUpperCase();
    const cur = bySymbol.get(s) || { total: 0, wins: 0, losses: 0 };
    cur.total++;
    if (r.outcome === "WIN") cur.wins++;
    if (r.outcome === "LOSS") cur.losses++;
    bySymbol.set(s, cur);
  }
  const pairStats = [...bySymbol.entries()]
    .map(([symbol, s]) => ({
      symbol,
      ...s,
      winRate: s.wins + s.losses ? Math.round((s.wins / (s.wins + s.losses)) * 1000) / 10 : null,
    }))
    .sort((a, b) => b.total - a.total);

  const mostTraded = pairStats[0];
  const mostWins = [...pairStats].sort((a, b) => b.wins - a.wins)[0];
  const mostLosses = [...pairStats].sort((a, b) => b.losses - a.losses)[0];

  const byUser = new Map<string, { name: string; email: string; total: number; wins: number; losses: number }>();
  for (const r of runs) {
    const id = r.userId || "anon";
    const name =
      [r.user?.firstName, r.user?.lastName].filter(Boolean).join(" ") || r.user?.email || "Unknown";
    const cur = byUser.get(id) || { name, email: r.user?.email || "", total: 0, wins: 0, losses: 0 };
    cur.total++;
    if (r.outcome === "WIN") cur.wins++;
    if (r.outcome === "LOSS") cur.losses++;
    byUser.set(id, cur);
  }
  const userStats = [...byUser.values()].sort((a, b) => b.total - a.total);

  const csvRows = [
    ["createdAt", "email", "name", "symbol", "bias", "outcome", "timeframe", "provider"].join(","),
    ...runs.map((r) =>
      [
        r.createdAt.toISOString(),
        r.user?.email || "",
        [r.user?.firstName, r.user?.lastName].filter(Boolean).join(" "),
        r.symbol,
        r.bias || "",
        r.outcome || "PENDING",
        r.timeframe || "",
        r.provider || "",
      ]
        .map((c) => `"${String(c).replace(/"/g, '""')}"`)
        .join(",")
    ),
  ].join("\n");

  return (
    <>
      <Header workspace="staff" />
      <ControlNav active="/control-centre/insights" />
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">Principal · Market behaviour</div>
            <h1>Institutional analysis journal</h1>
            <p>
              All signed-in market analysis runs across participants. Educational tracking only — not
              investment advice.
            </p>
          </div>
        </section>
        <section className="section">
          <div className="container">
            <div className="grid grid-4" style={{ marginBottom: 28 }}>
              <div className="panel">
                <div className="eyebrow">Total runs</div>
                <h2>{runs.length}</h2>
              </div>
              <div className="panel">
                <div className="eyebrow">Wins</div>
                <h2 style={{ color: "#16a34a" }}>{wins}</h2>
              </div>
              <div className="panel">
                <div className="eyebrow">Losses</div>
                <h2 style={{ color: "#dc2626" }}>{losses}</h2>
              </div>
              <div className="panel">
                <div className="eyebrow">Verified win rate</div>
                <h2>{winRate == null ? "—" : `${winRate}%`}</h2>
                <p className="muted">{pending} pending · {neutral} neutral</p>
              </div>
            </div>

            <div className="grid grid-3" style={{ marginBottom: 28 }}>
              <div className="panel">
                <div className="eyebrow">Most analysed pair</div>
                <h2>{mostTraded?.symbol || "—"}</h2>
                <p>{mostTraded ? `${mostTraded.total} runs` : ""}</p>
              </div>
              <div className="panel">
                <div className="eyebrow">Pair with most wins</div>
                <h2>{mostWins?.symbol || "—"}</h2>
                <p>{mostWins ? `${mostWins.wins} wins` : ""}</p>
              </div>
              <div className="panel">
                <div className="eyebrow">Pair with most losses</div>
                <h2>{mostLosses?.symbol || "—"}</h2>
                <p>{mostLosses ? `${mostLosses.losses} losses` : ""}</p>
              </div>
            </div>

            <div className="actions" style={{ marginBottom: 20 }}>
              <a
                className="btn btn-primary btn-sm"
                href={`data:text/csv;charset=utf-8,${encodeURIComponent(csvRows)}`}
                download={`gitdm-analysis-journal-${new Date().toISOString().slice(0, 10)}.csv`}
              >
                Export journal CSV
              </a>
              <Link className="btn btn-outline-dark btn-sm" href="/research/journal">
                Public journal view
              </Link>
            </div>

            <h2 style={{ marginBottom: 12 }}>By instrument</h2>
            <div className="table-wrap sheet-table">
              <table className="data">
                <thead>
                  <tr>
                    <th>Symbol</th>
                    <th>Runs</th>
                    <th>Wins</th>
                    <th>Losses</th>
                    <th>Win rate</th>
                  </tr>
                </thead>
                <tbody>
                  {pairStats.slice(0, 30).map((p) => (
                    <tr key={p.symbol}>
                      <td>
                        <strong>{p.symbol}</strong>
                      </td>
                      <td>{p.total}</td>
                      <td>{p.wins}</td>
                      <td>{p.losses}</td>
                      <td>{p.winRate == null ? "—" : `${p.winRate}%`}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <h2 style={{ margin: "28px 0 12px" }}>By participant</h2>
            <div className="table-wrap sheet-table">
              <table className="data">
                <thead>
                  <tr>
                    <th>Name</th>
                    <th>Email</th>
                    <th>Runs</th>
                    <th>Wins</th>
                    <th>Losses</th>
                  </tr>
                </thead>
                <tbody>
                  {userStats.slice(0, 50).map((u) => (
                    <tr key={u.email + u.name}>
                      <td>{u.name}</td>
                      <td>{u.email}</td>
                      <td>{u.total}</td>
                      <td>{u.wins}</td>
                      <td>{u.losses}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>

            <h2 style={{ margin: "28px 0 12px" }}>Recent runs</h2>
            <div className="table-wrap sheet-table">
              <table className="data">
                <thead>
                  <tr>
                    <th>When</th>
                    <th>Participant</th>
                    <th>Symbol</th>
                    <th>Outcome</th>
                    <th>Timeframe</th>
                  </tr>
                </thead>
                <tbody>
                  {runs.slice(0, 40).map((r) => (
                    <tr key={r.id}>
                      <td>{r.createdAt.toLocaleString("en-UG")}</td>
                      <td>
                        {[r.user?.firstName, r.user?.lastName].filter(Boolean).join(" ") ||
                          r.user?.email ||
                          "—"}
                      </td>
                      <td>{r.symbol}</td>
                      <td>{r.outcome || "PENDING"}</td>
                      <td>{r.timeframe || "—"}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
