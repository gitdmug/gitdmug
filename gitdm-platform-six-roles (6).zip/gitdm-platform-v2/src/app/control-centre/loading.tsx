export default function Loading() {
  return (
    <div className="control-centre-loading" aria-busy="true" aria-label="Loading control centre">
      <aside className="control-nav loading-control-nav"><div className="control-nav-brand"><div className="control-role-mark">G</div><div><strong>GITDM Control Centre</strong><span>Loading workspace…</span></div></div><div className="loading-stack">{Array.from({ length: 12 }).map((_, i) => <div className="loading-bar" key={i} />)}</div></aside>
      <main className="staff-main"><div className="loading-hero"><div className="loading-bar wide" /><div className="loading-bar medium" /></div><section className="staff-metrics">{Array.from({ length: 4 }).map((_, i) => <div className="staff-metric loading-card" key={i} />)}</section><section className="staff-work-grid">{Array.from({ length: 6 }).map((_, i) => <div className="staff-work-card loading-card" key={i} />)}</section></main>
    </div>
  );
}
