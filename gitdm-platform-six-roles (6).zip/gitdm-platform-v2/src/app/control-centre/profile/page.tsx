import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ControlNav } from "@/components/ControlNav";
import { GITDM } from "@/lib/branding";
import { requireStaffUser } from "@/lib/control-centre";
import { saveStaffProfile } from "./actions";

export const dynamic = "force-dynamic";
export const metadata = { title: `My Profile | Staff Workspace | ${GITDM.shortName}` };

export default async function StaffProfilePage({ searchParams }: { searchParams: Promise<{ saved?: string }> }) {
  const ctx = await requireStaffUser();
  const profile = await ctx.db.profile.findUnique({ where: { userId: ctx.user.id } });
  const params = await searchParams;
  const name = [ctx.user.firstName, ctx.user.lastName].filter(Boolean).join(" ") || "Your name is not set yet";
  const avatar = profile?.avatarUrl;
  const roleLabel = ctx.roleCodes.filter((r) => !["STUDENT", "PARENT_GUARDIAN", "ALUMNI"].includes(r)).map((r) => r.replaceAll("_", " ")).join(" · ");

  return (
    <>
      <Header workspace="staff" />
      <ControlNav active="/control-centre/profile" />
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">Staff workspace</div>
            <h1>My profile</h1>
            <p>Personalise your GITDM staff identity, contact details and profile picture. Your institutional roles remain controlled by authorised administrators.</p>
          </div>
        </section>
        <section className="section">
          <div className="container">
            {params.saved ? <div className="access-banner full" style={{ marginBottom: 20 }}><strong>Profile saved.</strong> Your staff profile has been updated.</div> : null}
            <div className="grid grid-2" style={{ alignItems: "start" }}>
              <div className="card">
                <div className="eyebrow">Your identity</div>
                <div style={{ display: "flex", gap: 18, alignItems: "center", marginBottom: 18 }}>
                  {avatar ? <img className="profile-avatar" src={avatar.startsWith("neonfile:") ? "/api/campus/files/profile" : avatar} alt="Profile" /> : <div className="profile-avatar profile-avatar-empty">{(ctx.user.firstName?.[0] || ctx.user.email[0]).toUpperCase()}</div>}
                  <div><h2 style={{ margin: 0 }}>{name}</h2><p style={{ margin: "6px 0 0" }}>{ctx.user.email}</p></div>
                </div>
                <p><strong>Institutional role:</strong> {roleLabel || "Staff"}</p>
                <p><strong>Status:</strong> {ctx.user.status}</p>
                <p style={{ marginBottom: 0 }}>Your profile picture is also used in the signed-in staff navigation so your workspace feels personal and recognisable.</p>
              </div>

              <div className="card">
                <div className="eyebrow">Personal details</div>
                <h2>Update your profile</h2>
                <form action={saveStaffProfile} encType="multipart/form-data" className="form-grid">
                  <div className="grid grid-2">
                    <label>First name<input name="firstName" defaultValue={ctx.user.firstName || ""} required /></label>
                    <label>Last name<input name="lastName" defaultValue={ctx.user.lastName || ""} /></label>
                    <label>Phone<input name="phone" defaultValue={ctx.user.phone || ""} /></label>
                    <label>Date of birth<input name="dateOfBirth" type="date" defaultValue={profile?.dateOfBirth ? profile.dateOfBirth.toISOString().slice(0, 10) : ""} /></label>
                    <label>Gender<input name="gender" defaultValue={profile?.gender || ""} /></label>
                    <label>Nationality<input name="nationality" defaultValue={profile?.nationality || ""} /></label>
                    <label>Address<input name="address" defaultValue={profile?.address || ""} /></label>
                    <label>City<input name="city" defaultValue={profile?.city || ""} /></label>
                    <label>Country<input name="country" defaultValue={profile?.country || "Uganda"} /></label>
                    <label>Emergency contact<input name="emergencyName" defaultValue={profile?.emergencyName || ""} /></label>
                    <label>Emergency phone<input name="emergencyPhone" defaultValue={profile?.emergencyPhone || ""} /></label>
                    <label>Profile picture<input name="avatar" type="file" accept="image/png,image/jpeg,image/webp" /></label>
                  </div>
                  <button className="btn btn-primary">Save profile</button>
                </form>
              </div>
            </div>
            <div className="actions" style={{ marginTop: 24 }}>
              <Link href="/control-centre" className="btn btn-outline-dark">← Command Centre</Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
