import { redirect } from "next/navigation";

/** Obsolete role-impersonation surface — Principal uses Control Centre overview. */
export default function AccessStaffRolesRedirect() {
  redirect("/control-centre");
}
