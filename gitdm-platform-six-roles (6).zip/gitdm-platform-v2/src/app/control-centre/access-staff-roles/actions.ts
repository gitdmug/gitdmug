"use server";
import { requireRole } from "@/lib/access";
export async function beginActing(_formData: FormData): Promise<never> {
  await requireRole("PRINCIPAL");
  throw new Error("Temporary role impersonation has been retired. Use department oversight instead.");
}
export async function exitActing(): Promise<never> {
  await requireRole("PRINCIPAL");
  throw new Error("Temporary role impersonation has been retired. Use department oversight instead.");
}
