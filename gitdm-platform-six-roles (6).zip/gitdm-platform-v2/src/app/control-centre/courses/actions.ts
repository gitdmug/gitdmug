"use server";

import { revalidatePath } from "next/cache";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { requireStudentSession } from "@/lib/student";
import { getDb } from "@/lib/db";
import { createMeetSpace, createCalendarClassEvent, updateCalendarClassEnd, endMeetConference, listConferenceRecordsBySpace, listConferenceParticipants, listParticipantSessions, getPersonEmail } from "@/lib/google-workspace";
import { uploadPrivateFile } from "@/lib/file-storage";
import { ACTIVE_COURSE_CODES, ACTIVE_FACULTY_CODES, ACTIVE_PROGRAMME_CODES } from "@/lib/current-catalogue";

function text(fd: FormData, key: string) { return String(fd.get(key) || "").trim(); }
function bool(fd: FormData, key: string) { return fd.get(key) === "on" || fd.get(key) === "true"; }

export async function createCourse(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("courses.manage");
  const facultyId = text(fd, "facultyId");
  const code = text(fd, "code").toUpperCase();
  const title = text(fd, "title");
  if (!facultyId || !code || !title) throw new Error("Faculty, course code and title are required.");
  const faculty = await db.faculty.findUnique({ where: { id: facultyId }, select: { code: true, name: true } });
  if (!faculty || !ACTIVE_FACULTY_CODES.includes(faculty.code as any)) throw new Error("Only the current active GITDM faculty may register courses in this intake.");
  const expectedPrefix = `${faculty.code}-`;
  if (!code.startsWith(expectedPrefix)) throw new Error(`Course code must start with ${expectedPrefix} for ${faculty.name}.`);
  if (!/^[A-Z]{3}-\d{3,4}$/.test(code)) throw new Error("Use the GITDM course-code format, for example FFM-103.");
  if (!ACTIVE_COURSE_CODES.includes(code as any)) throw new Error("This course code is not part of the current intake catalogue. Add it to the active catalogue when the institution is ready to launch it.");
  const programmeId = text(fd, "programmeId");
  if (programmeId) {
    const programme = await db.programme.findUnique({ where: { id: programmeId }, select: { code: true } });
    if (!programme || !ACTIVE_PROGRAMME_CODES.includes(programme.code as any)) throw new Error("Only the three current intake programmes may receive courses right now.");
  }
  const course = await db.course.create({ data: {
    facultyId, code, title,
    description: text(fd, "description") || null,
    programmeId: programmeId || null,
    published: bool(fd, "published"),
    studentSelectable: bool(fd, "studentSelectable"),
  }});
  await db.auditLog.create({ data: { userId: user.id, action: "COURSE_CATALOG_CREATED", entity: "Course", entityId: course.id, metadataJson: JSON.stringify({ code, facultyId }) } });
  revalidatePath("/control-centre/courses");
  revalidatePath("/campus/learning");
}

export async function assignLecturer(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("courses.manage");
  const courseId = text(fd, "courseId");
  const lecturerId = text(fd, "lecturerId");
  if (!courseId || !lecturerId) throw new Error("Course and lecturer are required.");
  const role = await db.userRole.findFirst({ where: { userId: lecturerId, role: { code: { in: ["LECTURER", "ONLINE_INSTRUCTOR"] } } } });
  if (!role) throw new Error("Selected user is not assigned the Online Instructor / Lecturer role.");
  await db.courseFaculty.upsert({ where: { courseId_userId: { courseId, userId: lecturerId } }, update: { isLead: true }, create: { courseId, userId: lecturerId, isLead: true } });
  await db.course.update({ where: { id: courseId }, data: { published: true, studentSelectable: true } });
  await db.auditLog.create({ data: { userId: user.id, action: "COURSE_LECTURER_ASSIGNED", entity: "CourseFaculty", entityId: `${courseId}:${lecturerId}` } });
  revalidatePath("/control-centre/courses");
  revalidatePath("/campus/learning");
}

export async function enrollInCourse(fd: FormData) {
  const ctx = await requireStudentSession("/campus/courses");
  const db = getDb();
  if (!db) throw new Error("Database is unavailable.");
  const courseId = text(fd, "courseId");
  const enrollment = await db.enrollment.findFirst({ where: { userId: ctx.user.id, status: { in: ["ACTIVE", "REPEATING"] } }, orderBy: { createdAt: "desc" } });
  if (!enrollment) throw new Error("You need an active enrolment before selecting a course.");
  const course = await db.course.findFirst({ where: { id: courseId, code: { in: [...ACTIVE_COURSE_CODES] } }, include: { facultyUnit: true, periodLinks: true } });
  const belongsToProgramme = course?.programmeId === enrollment.programmeId;
  const belongsToPeriod = !!enrollment.periodId && !!course?.periodLinks.some((p) => p.periodId === enrollment.periodId);
  if (!course || !course.published || !course.studentSelectable || !course.facultyId || (!belongsToProgramme && !belongsToPeriod)) throw new Error("This course is not part of your admitted programme or intake.");
  const already = await db.courseEnrollment.findFirst({ where: { enrollmentId: enrollment.id, courseId, status: { in: ["ACTIVE", "REPEATING"] } } });
  if (!already) await db.courseEnrollment.create({ data: { enrollmentId: enrollment.id, courseId, status: "ACTIVE" } });
  revalidatePath("/campus/learning");
  revalidatePath("/campus/courses");
}

export async function createOnlineClass(fd: FormData) {
  const { db, user, roleCodes } = await requireOperationalStaffUser("attendance.manage");
  const leadership = roleCodes.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR", "REGISTRAR"].includes(r));
  if (!leadership) throw new Error("Class scheduling is controlled by Academic Affairs. Lecturers may add the live-class link after a session is published.");
  const courseId = text(fd, "courseId"); const periodId = text(fd, "periodId") || null; const departmentId = text(fd, "departmentId") || null; const title = text(fd, "title");
  const startAt = new Date(text(fd, "startAt")); const endAt = new Date(text(fd, "endAt"));
  const prepMinutes = Math.max(0, Math.min(120, Number(text(fd, "prepMinutes") || 30)));
  if (!courseId || !title || isNaN(startAt.getTime()) || isNaN(endAt.getTime()) || endAt <= startAt) throw new Error("Course, title and valid start/end times are required.");
  if (startAt <= new Date()) throw new Error("Class start time must be in the future.");
  const course = await db.course.findFirst({ where: { id: courseId, code: { in: [...ACTIVE_COURSE_CODES] } } }); if (!course) throw new Error("Course not found or is not part of the current intake catalogue.");
  if (course.programmeId && !periodId) throw new Error("Select the cohort/intake for this programme course before scheduling the class.");
  if (periodId) {
    const period = await db.academicPeriod.findUnique({ where: { id: periodId }, select: { programmeId: true, name: true } });
    if (!period) throw new Error("Selected cohort/intake was not found.");
    if (course.programmeId && course.programmeId !== period.programmeId) throw new Error("The selected course does not belong to the selected programme/cohort. Choose a course from the same programme.");
  }
  const lecturerId = text(fd, "lecturerUserId") || null;
  if (lecturerId) { const r = await db.userRole.findFirst({where:{userId:lecturerId,role:{code:{in:["LECTURER","ONLINE_INSTRUCTOR"]}}}}); if(!r) throw new Error("Selected user is not an Online Instructor / Lecturer."); }

  const moduleId = text(fd, "moduleId") || null;
  if (moduleId) {
    const module = await db.courseModule.findUnique({ where: { id: moduleId }, select: { courseId: true } });
    if (!module || module.courseId !== courseId) throw new Error("Selected module does not belong to this course.");

  }
  const event = await db.timetableEvent.create({data:{courseId,periodId,moduleId,departmentId,title,startAt,endAt,prepMinutes,deliveryMode:"ONLINE",type:"CLASS",lecturerUserId:lecturerId,scheduledById:user.id,notes:text(fd,"notes")||null,joinUrl:null}});
  const enrolled = await db.courseEnrollment.findMany({
    where: { courseId, status: { in: ["ACTIVE", "REPEATING"] }, enrollment: { status: { in: ["ACTIVE", "REPEATING"] }, ...(periodId ? { periodId } : {}) } },
    select: { enrollment: { select: { userId: true } } },
  });
  const studentIds = [...new Set(enrolled.map((x) => x.enrollment.userId))];
  if (studentIds.length) await db.notification.createMany({ data: studentIds.map((userId) => ({ userId, type: "ACADEMIC" as const, title: "Class scheduled", body: `${course.code} — ${title} is scheduled for ${startAt.toLocaleString("en-UG")}. Check My Timetable for the class details and live link when published.` })) });
  await db.auditLog.create({data:{userId:user.id,action:"ONLINE_CLASS_SCHEDULED",entity:"TimetableEvent",entityId:event.id,metadataJson:JSON.stringify({courseId,periodId,lecturerId,notifiedStudents:studentIds.length})}});
  revalidatePath("/control-centre/timetable"); revalidatePath("/campus/timetable"); revalidatePath("/campus/lectures"); revalidatePath("/campus/academic");
}

export async function setClassLink(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("attendance.manage"); const id=text(fd,"eventId"); const joinUrl=text(fd,"joinUrl");
  if(!id||!/^https?:\/\//i.test(joinUrl)) throw new Error("Enter a valid class URL.");
  const event=await db.timetableEvent.findUnique({where:{id}}); if(!event) throw new Error("Class not found.");
  const leadership=user.roles.some((r)=>["PRINCIPAL","ACADEMIC_DIRECTOR","REGISTRAR"].includes(r.role.code));
  if(event.lecturerUserId!==user.id&&!leadership) throw new Error("Only the assigned Lecturer or academic leadership can add the class link.");
  await db.timetableEvent.update({where:{id},data:{joinUrl,googleMeetUrl:joinUrl}});
  if (event.courseId) {
    const enrolled = await db.courseEnrollment.findMany({ where: { courseId: event.courseId, status: { in: ["ACTIVE", "REPEATING"] }, enrollment: { status: { in: ["ACTIVE", "REPEATING"] }, ...(event.periodId ? { periodId: event.periodId } : {}) } }, select: { enrollment: { select: { userId: true } } } });
    const ids = [...new Set(enrolled.map((x) => x.enrollment.userId))];
    if (ids.length) await db.notification.createMany({ data: ids.map((userId) => ({ userId, type: "ACADEMIC" as const, title: "Live class link available", body: `${event.title} now has its live-class link. Open My Timetable to join at the scheduled time.` })) });
  }
  await db.auditLog.create({data:{userId:user.id,action:"CLASS_LINK_ADDED",entity:"TimetableEvent",entityId:id}});
  revalidatePath("/control-centre/timetable"); revalidatePath("/campus/timetable"); revalidatePath("/campus/academic");
}

export async function endOnlineClass(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("academic.manage");
  const id = text(fd, "eventId");
  const event = await db.timetableEvent.findUnique({ where: { id } });
  if (!event) throw new Error("Class not found.");
  if (event.lecturerUserId !== user.id && !user.roles.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR"].includes(r.role.code))) throw new Error("Only the lecturer or academic leadership can close this class.");
  const actualEnd = new Date();
  if (event.googleMeetSpaceName) {
    try { await endMeetConference(event.googleMeetSpaceName); } catch (error) { console.error("[GITDM] Meet end failed", error); }
  }
  if (event.googleCalendarEventId) {
    try { await updateCalendarClassEnd(event.googleCalendarEventId, actualEnd); } catch (error) { console.error("[GITDM] Calendar end update failed", error); }
  }
  await db.timetableEvent.update({ where: { id }, data: { endAt: actualEnd } });
  revalidatePath("/control-centre/timetable");
  revalidatePath("/campus/timetable");
}

export async function syncOnlineAttendance(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("attendance.manage");
  const id = text(fd, "eventId");
  const event = await db.timetableEvent.findUnique({ where: { id }, include: { course: true } });
  if (!event?.googleMeetSpaceName || !event.courseId) throw new Error("This class does not have a Google Meet space yet.");
  const records = await listConferenceRecordsBySpace(event.googleMeetSpaceName);
  const conferences = records?.conferenceRecords || [];
  const conference = conferences.sort((a: any, b: any) => String(b.startTime || "").localeCompare(String(a.startTime || "")))[0];
  if (!conference?.name) throw new Error("No completed Google Meet conference record is available yet.");
  const participants = await listConferenceParticipants(conference.name);
  let synced = 0;
  for (const participant of participants) {
    const start = participant.earliestStartTime ? new Date(participant.earliestStartTime) : null;
    const end = participant.latestEndTime ? new Date(participant.latestEndTime) : null;
    if (!start) continue;
    const sessions = participant.name ? await listParticipantSessions(participant.name) : [];
    const sessionMinutes = sessions.reduce((sum: number, session: any) => {
      if (!session.startTime) return sum;
      const s = new Date(session.startTime);
      const e = session.endTime ? new Date(session.endTime) : new Date();
      return sum + Math.max(0, Math.round((e.getTime() - s.getTime()) / 60000));
    }, 0);
    const personId = participant.signedinUser?.user as string | undefined;
    const email = personId ? await getPersonEmail(personId.replace(/^users\//, "")) : null;
    let localUser = email ? await db.user.findUnique({ where: { email }, select: { id: true } }) : null;
    if (!localUser && participant.signedinUser?.displayName) {
      const displayName = String(participant.signedinUser.displayName).trim();
      const parts = displayName.split(/\s+/).filter(Boolean);
      if (parts.length >= 2) {
        localUser = await db.user.findFirst({ where: { firstName: { equals: parts[0], mode: "insensitive" }, lastName: { equals: parts.slice(1).join(" "), mode: "insensitive" } }, select: { id: true } });
      }
    }
    if (!localUser) continue;
    await db.classAttendanceRecord.upsert({
      where: { userId_timetableEventId: { userId: localUser.id, timetableEventId: event.id } },
      update: { joinedAt: start, leftAt: end, minutesAttended: sessionMinutes, status: sessionMinutes > 0 ? "PRESENT" : "ABSENT", source: "GOOGLE_MEET", googleParticipantId: participant.name },
      create: { userId: localUser.id, courseId: event.courseId, periodId: event.periodId ?? undefined, timetableEventId: event.id, date: event.startAt, joinedAt: start, leftAt: end, minutesAttended: sessionMinutes, status: sessionMinutes > 0 ? "PRESENT" : "ABSENT", source: "GOOGLE_MEET", googleParticipantId: participant.name },
    });
    synced++;
  }
  await db.timetableEvent.update({ where: { id }, data: { conferenceRecordName: conference.name } });
  await db.auditLog.create({ data: { userId: user.id, action: "GOOGLE_MEET_ATTENDANCE_SYNCED", entity: "TimetableEvent", entityId: event.id, metadataJson: JSON.stringify({ synced }) } });
  revalidatePath("/control-centre/timetable");
  revalidatePath("/campus/timetable");
}

export async function addCourseModule(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("lessons.manage");
  const courseId = text(fd, "courseId");
  const title = text(fd, "title");
  if (!courseId || !title) throw new Error("Course and module title are required.");
  const assigned = await db.courseFaculty.findUnique({ where: { courseId_userId: { courseId, userId: user.id } } });
  const curriculumRole = user.roles.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR", "CURRICULUM_DEVELOPER", "REGISTRAR"].includes(r.role.code));
  if (!curriculumRole) throw new Error("Modules are created by Academic Affairs / Curriculum staff.");
  const max = await db.courseModule.findFirst({ where: { courseId }, orderBy: { orderIndex: "desc" }, select: { orderIndex: true } });
  await db.courseModule.create({ data: { courseId, title, description: text(fd, "description") || null, orderIndex: (max?.orderIndex ?? -1) + 1, published: false, approvalStatus: "DRAFT" } });
  revalidatePath(`/control-centre/courses/${courseId}`);
  revalidatePath("/campus/learning");
  revalidatePath(`/campus/learning/${courseId}`);
}

export async function addCourseLesson(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("lessons.manage");
  const courseId = text(fd, "courseId");
  const moduleId = text(fd, "moduleId");
  const title = text(fd, "title");
  const type = text(fd, "type");
  if (!courseId || !moduleId || !title || !["VIDEO","ARTICLE","DOCUMENT","LIVE_SESSION","EXTERNAL","RESOURCE"].includes(type)) throw new Error("Course, module, lesson title and type are required.");
  const assigned = await db.courseFaculty.findUnique({ where: { courseId_userId: { courseId, userId: user.id } } });
  if (!assigned && !user.roles.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR", "REGISTRAR"].includes(r.role.code))) throw new Error("You are not assigned to this course.");
  const max = await db.lesson.findFirst({ where: { moduleId }, orderBy: { orderIndex: "desc" }, select: { orderIndex: true } });
  await db.lesson.create({ data: { moduleId, title, type: type as any, content: text(fd, "content") || null, videoUrl: text(fd, "videoUrl") || null, durationMinutes: Number(text(fd, "durationMinutes") || 0) || null, orderIndex: (max?.orderIndex ?? -1) + 1, required: bool(fd, "required"), published: bool(fd, "published") } });
  revalidatePath(`/control-centre/courses/${courseId}`);
  revalidatePath("/campus/learning");
  revalidatePath(`/campus/learning/${courseId}`);
}

export async function addLessonResource(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("lessons.manage");
  const courseId = text(fd, "courseId");
  const lessonId = text(fd, "lessonId");
  const title = text(fd, "title");
  const url = text(fd, "url");
  if (!courseId || !lessonId || !title || !url) throw new Error("Lesson resource title and URL are required.");
  const assigned = await db.courseFaculty.findUnique({ where: { courseId_userId: { courseId, userId: user.id } } });
  if (!assigned && !user.roles.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR", "REGISTRAR"].includes(r.role.code))) throw new Error("You are not assigned to this course.");
  await db.learningResource.create({ data: { lessonId, title, url, fileType: text(fd, "fileType") || null } });
  revalidatePath(`/control-centre/courses/${courseId}`);
  revalidatePath("/campus/learning");
  revalidatePath(`/campus/learning/${courseId}`);
}

export async function uploadLessonResource(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("lessons.manage");
  const courseId = text(fd, "courseId");
  const lessonId = text(fd, "lessonId");
  const title = text(fd, "title");
  const file = fd.get("file");
  if (!courseId || !lessonId || !title || !(file instanceof File) || !file.size) {
    throw new Error("Course, lesson, material title and file are required.");
  }
  const assigned = await db.courseFaculty.findUnique({ where: { courseId_userId: { courseId, userId: user.id } } });
  if (!assigned && !user.roles.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR", "REGISTRAR"].includes(r.role.code))) throw new Error("You are not assigned to this course.");
  const extension = file.name.includes(".") ? file.name.split(".").pop()!.toLowerCase() : "";
  const allowed = new Set(["pdf","doc","docx","ppt","pptx","xls","xlsx","csv","zip","txt","md","jpg","jpeg","png","webp","mp4","mp3","m4a"]);
  if (!allowed.has(extension)) throw new Error("Unsupported learning material format. Use PDF, Word, PowerPoint, Excel/CSV, ZIP, text/Markdown, image, MP4 or MP3/M4A.");
  const token = await uploadPrivateFile(file, "gitdm/learning", `${courseId}-${lessonId}`);
  await db.learningResource.create({ data: { lessonId, title, url: token, fileType: file.type || file.name.split(".").pop()?.toUpperCase() || "FILE" } });
  await db.auditLog.create({ data: { userId: user.id, action: "LEARNING_RESOURCE_UPLOADED", entity: "LearningResource", metadataJson: JSON.stringify({ courseId, lessonId, title, name: file.name, size: file.size }) } });
  revalidatePath(`/control-centre/courses/${courseId}`);
  revalidatePath(`/campus/learning`);
}

export async function createAssignment(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("assignments.manage");
  const courseId = text(fd, "courseId");
  const title = text(fd, "title");
  const instructions = text(fd, "instructions");
  const maxMarks = Number(text(fd, "maxMarks") || 0);
  const dueRaw = text(fd, "dueAt");
  if (!courseId || !title || !instructions || !Number.isFinite(maxMarks) || maxMarks <= 0) throw new Error("Course, title, instructions and positive marks are required.");
  const assigned = await db.courseFaculty.findUnique({ where: { courseId_userId: { courseId, userId: user.id } } });
  const leadership = user.roles.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR"].includes(r.role.code));
  if (!assigned && !leadership) throw new Error("You are not assigned to this course.");
  const dueAt = dueRaw ? new Date(dueRaw) : null;
  if (dueAt && Number.isNaN(dueAt.getTime())) throw new Error("Invalid assignment deadline.");
  const assignment = await db.assignment.create({ data: { courseId, title, instructions, maxMarks, dueAt, createdById: user.id, status: "DRAFT" } });
  await db.auditLog.create({ data: { userId: user.id, action: "ASSIGNMENT_CREATED", entity: "Assignment", entityId: assignment.id } });
  revalidatePath(`/control-centre/courses/${courseId}`); revalidatePath("/campus/assessments");
}

export async function publishAssignment(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("assignments.manage");
  const assignmentId = text(fd, "assignmentId");
  const assignment = await db.assignment.findUnique({ where: { id: assignmentId }, include: { course: { include: { faculty: true } } } });
  if (!assignment) throw new Error("Assignment not found.");
  const assigned = assignment.course.faculty.some((f) => f.userId === user.id);
  const leadership = user.roles.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR"].includes(r.role.code));
  if (!assigned && !leadership) throw new Error("You are not assigned to this course.");
  await db.assignment.update({ where: { id: assignmentId }, data: { status: "PUBLISHED" } });
  const enrolled = await db.courseEnrollment.findMany({ where: { courseId: assignment.courseId, status: { in: ["ACTIVE", "REPEATING"] }, enrollment: { status: { in: ["ACTIVE", "REPEATING"] } } }, select: { enrollment: { select: { userId: true } } } });
  const ids = [...new Set(enrolled.map((x) => x.enrollment.userId))];
  if (ids.length) await db.notification.createMany({ data: ids.map((userId) => ({ userId, type: "ACADEMIC" as const, title: "New coursework available", body: `${assignment.course.code} — ${assignment.title} is now available in Exams & Assessments${assignment.dueAt ? `. Due ${assignment.dueAt.toLocaleString("en-UG")}.` : "."}` })) });
  await db.auditLog.create({ data: { userId: user.id, action: "ASSIGNMENT_PUBLISHED", entity: "Assignment", entityId: assignmentId, metadataJson: JSON.stringify({ notifiedStudents: ids.length }) } });
  revalidatePath(`/control-centre/courses/${assignment.courseId}`); revalidatePath("/campus/assessments"); revalidatePath("/campus/academic");
}

export async function gradeAssignmentSubmission(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("assignments.grade");
  const submissionId = text(fd, "submissionId");
  const score = Number(text(fd, "score"));
  const feedback = text(fd, "feedback");
  const submission = await db.assignmentSubmission.findUnique({ where: { id: submissionId }, include: { assignment: { include: { course: { include: { faculty: true } } } }, user: true } });
  if (!submission) throw new Error("Submission not found.");
  const assigned = submission.assignment.course.faculty.some((f) => f.userId === user.id);
  const leadership = user.roles.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR"].includes(r.role.code));
  if (!assigned && !leadership) throw new Error("You are not assigned to this course.");
  if (!Number.isFinite(score) || score < 0 || score > Number(submission.assignment.maxMarks)) throw new Error(`Score must be between 0 and ${Number(submission.assignment.maxMarks)}.`);
  await db.assignmentSubmission.update({ where: { id: submissionId }, data: { score, feedback: feedback || null, status: "GRADED", gradedAt: new Date(), gradedById: user.id } });
  await db.auditLog.create({ data: { userId: user.id, action: "ASSIGNMENT_GRADED", entity: "AssignmentSubmission", entityId: submissionId, metadataJson: JSON.stringify({ score, maxMarks: Number(submission.assignment.maxMarks) }) } });
  await db.notification.create({ data: { userId: submission.userId, type: "ACADEMIC", title: "Assignment graded", body: `${submission.assignment.course.code} — ${submission.assignment.title}: ${score}/${Number(submission.assignment.maxMarks)}.${feedback ? ` Feedback: ${feedback}` : ""}` } });
  revalidatePath(`/control-centre/courses/${submission.assignment.courseId}`); revalidatePath(`/campus/assessments/assignments/${submission.assignmentId}`); revalidatePath("/campus/assessments");
}

export async function updateModuleDeliveryPlan(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("lessons.manage");
  const courseId = text(fd, "courseId"); const moduleId = text(fd, "moduleId");
  const leadership = user.roles.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR", "REGISTRAR"].includes(r.role.code));
  if (!leadership) throw new Error("Module delivery dates and study patterns are controlled by Academic Affairs.");
  const startRaw = text(fd, "deliveryStartAt"); const endRaw = text(fd, "deliveryEndAt");
  const start = startRaw ? new Date(startRaw) : null; const end = endRaw ? new Date(endRaw) : null;
  if ((start && isNaN(start.getTime())) || (end && isNaN(end.getTime())) || (start && end && end < start)) throw new Error("Enter a valid delivery period.");
  const duration = Number(text(fd, "deliveryDurationMinutes") || 0);
  const days = text(fd, "studyDays").split(",").map(x => x.trim()).filter(Boolean);
  await db.courseModule.update({ where: { id: moduleId }, data: { deliveryStartAt: start, deliveryEndAt: end, deliveryDurationMinutes: duration > 0 ? duration : null, studyDaysJson: JSON.stringify(days), approvalStatus: "DRAFT", rejectionReason: null, submittedAt: null, submittedById: null, approvedAt: null, approvedById: null, published: false } });
  revalidatePath(`/control-centre/courses/${courseId}`); revalidatePath("/control-centre/academic/delivery");
}

export async function submitModuleForApproval(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("lessons.manage");
  const courseId = text(fd, "courseId"); const moduleId = text(fd, "moduleId");
  const assigned = await db.courseFaculty.findUnique({ where: { courseId_userId: { courseId, userId: user.id } } });
  if (!assigned && !user.roles.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR", "REGISTRAR"].includes(r.role.code))) throw new Error("You are not assigned to this course.");
  const module = await db.courseModule.findUnique({ where: { id: moduleId }, include: { lessons: { include: { resources: true } } } });
  if (!module || module.courseId !== courseId) throw new Error("Module not found.");
  if (!module.lessons.length) throw new Error("Add at least one lesson before submitting the module.");
  if (module.lessons.some(l => !l.title.trim())) throw new Error("Every lesson needs a title.");
  await db.courseModule.update({ where: { id: moduleId }, data: { approvalStatus: "PENDING_APPROVAL", submittedAt: new Date(), submittedById: user.id, rejectionReason: null, published: false } });
  await db.auditLog.create({ data: { userId: user.id, action: "COURSE_MODULE_SUBMITTED_FOR_APPROVAL", entity: "CourseModule", entityId: moduleId } });
  const academicDirectors = await db.user.findMany({ where: { roles: { some: { role: { code: "ACADEMIC_DIRECTOR" } } }, status: "ACTIVE" }, select: { id: true } });
  if (academicDirectors.length) await db.notification.createMany({ data: academicDirectors.map((d) => ({ userId: d.id, type: "ACADEMIC" as const, title: "Course delivery awaiting approval", body: `${module.title} for ${courseId} has been submitted by a lecturer and is ready for academic review.` })) });
  revalidatePath(`/control-centre/courses/${courseId}`); revalidatePath("/control-centre/academic/delivery");
}

export async function reviewModuleDelivery(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("academic.manage");
  if (!user.roles.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR"].includes(r.role.code))) throw new Error("Only the Principal or Academic Director can approve course delivery.");
  const moduleId = text(fd, "moduleId"); const decision = text(fd, "decision"); const reason = text(fd, "reason");
  if (!moduleId || !["APPROVE", "REJECT"].includes(decision)) throw new Error("A valid approval decision is required.");
  const module = await db.courseModule.findUnique({ where: { id: moduleId }, include: { course: { include: { faculty: { select: { userId: true } }, enrollments: { where: { status: { in: ["ACTIVE", "REPEATING"] } }, select: { enrollment: { select: { userId: true } } } } } } } });
  if (!module) throw new Error("Module not found.");
  await db.courseModule.update({ where: { id: moduleId }, data: decision === "APPROVE" ? { approvalStatus: "APPROVED", published: true, approvedAt: new Date(), approvedById: user.id, rejectionReason: null } : { approvalStatus: "REJECTED", published: false, approvedAt: null, approvedById: null, rejectionReason: reason || "Please revise the delivery plan and resubmit." } });
  if (decision === "APPROVE") await db.lesson.updateMany({ where: { moduleId }, data: { published: true } });
  await db.auditLog.create({ data: { userId: user.id, action: `COURSE_MODULE_${decision === "APPROVE" ? "APPROVED" : "REJECTED"}`, entity: "CourseModule", entityId: moduleId, metadataJson: reason ? JSON.stringify({ reason }) : undefined } });
  const studentIds = module.course.enrollments.map((e) => e.enrollment.userId);
  const lecturerIds = module.course.faculty.map((f) => f.userId);
  if (decision === "APPROVE" && studentIds.length) await db.notification.createMany({ data: studentIds.map((userId) => ({ userId, type: "ACADEMIC" as const, title: "New course module available", body: `${module.title} has been approved and published for your enrolled course.` })) });
  if (decision === "REJECT" && lecturerIds.length) await db.notification.createMany({ data: lecturerIds.map((userId) => ({ userId, type: "ACADEMIC" as const, title: "Course module returned for revision", body: `${module.title} needs revision before it can be published. ${reason || "Please review the Academic Director feedback."}` })) });
  revalidatePath(`/control-centre/courses/${module.courseId}`); revalidatePath("/control-centre/academic/delivery"); revalidatePath("/campus/learning"); revalidatePath("/campus/timetable");
}

export async function publishCourseModule(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("lessons.manage");
  const courseId = text(fd, "courseId");
  const moduleId = text(fd, "moduleId");
  if (!user.roles.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR", "REGISTRAR"].includes(r.role.code))) throw new Error("Modules are published through Academic Director approval.");
  await db.courseModule.update({ where: { id: moduleId }, data: { published: bool(fd, "published"), approvalStatus: bool(fd, "published") ? "APPROVED" : "DRAFT" } });
  revalidatePath(`/control-centre/courses/${courseId}`);
  revalidatePath("/campus/learning");
  revalidatePath(`/campus/learning/${courseId}`);
}

export async function createQuiz(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("quizzes.manage");
  const courseId = text(fd, "courseId");
  const title = text(fd, "title");
  const instructions = text(fd, "instructions");
  const passMarkPercent = Number(text(fd, "passMarkPercent") || 50);
  const attemptsAllowed = Number(text(fd, "attemptsAllowed") || 1);
  const timeLimitMinutes = Number(text(fd, "timeLimitMinutes") || 0) || null;
  if (!courseId || !title) throw new Error("Course and quiz title are required.");
  const assigned = await db.courseFaculty.findUnique({ where: { courseId_userId: { courseId, userId: user.id } } });
  const leadership = user.roles.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR", "CURRICULUM_DEVELOPER"].includes(r.role.code));
  if (!assigned && !leadership) throw new Error("You are not assigned to this course.");
  const quiz = await db.quiz.create({ data: { courseId, title, instructions: instructions || null, passMarkPercent, attemptsAllowed: Math.max(1, attemptsAllowed), timeLimitMinutes, status: "DRAFT" } });
  await db.auditLog.create({ data: { userId: user.id, action: "QUIZ_CREATED", entity: "Quiz", entityId: quiz.id, metadataJson: JSON.stringify({ courseId }) } });
  revalidatePath("/staff/lecturer/assessments");
  revalidatePath(`/staff/lecturer/courses/${courseId}`);
}

export async function addQuizQuestion(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("quizzes.manage");
  const quizId = text(fd, "quizId");
  const prompt = text(fd, "prompt");
  const optionsRaw = text(fd, "options");
  const correct = text(fd, "correct");
  const marks = Number(text(fd, "marks") || 1);
  if (!quizId || !prompt || !marks || marks <= 0) throw new Error("Quiz, question and positive marks are required.");
  const quiz = await db.quiz.findUnique({ where: { id: quizId }, include: { course: { include: { faculty: true } } } });
  if (!quiz || quiz.status !== "DRAFT") throw new Error("Questions can only be changed while the quiz is a draft.");
  const assigned = quiz.course.faculty.some((f) => f.userId === user.id);
  const leadership = user.roles.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR", "CURRICULUM_DEVELOPER"].includes(r.role.code));
  if (!assigned && !leadership) throw new Error("You are not assigned to this course.");
  const count = await db.quizQuestion.count({ where: { quizId } });
  const options = optionsRaw ? optionsRaw.split("\n").map((x) => x.trim()).filter(Boolean) : [];
  await db.quizQuestion.create({ data: { quizId, prompt, optionsJson: options.length ? JSON.stringify(options) : null, correctJson: correct ? JSON.stringify(correct) : null, marks, orderIndex: count } });
  revalidatePath("/staff/lecturer/assessments");
}

export async function publishQuiz(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("quizzes.manage");
  const quizId = text(fd, "quizId");
  const quiz = await db.quiz.findUnique({ where: { id: quizId }, include: { course: { include: { faculty: true } }, questions: true } });
  if (!quiz) throw new Error("Quiz not found.");
  if (!quiz.questions.length) throw new Error("Add at least one question before publishing the quiz.");
  const assigned = quiz.course.faculty.some((f) => f.userId === user.id);
  const leadership = user.roles.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR", "CURRICULUM_DEVELOPER"].includes(r.role.code));
  if (!assigned && !leadership) throw new Error("You are not assigned to this course.");
  await db.quiz.update({ where: { id: quizId }, data: { status: "PUBLISHED" } });
  await db.auditLog.create({ data: { userId: user.id, action: "QUIZ_PUBLISHED", entity: "Quiz", entityId: quizId } });
  revalidatePath("/staff/lecturer/assessments");
  revalidatePath("/campus/assessments");
}


export async function updateClassSessionDetails(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("academic.manage");
  const id = text(fd, "eventId");
  const title = text(fd, "title");
  const joinUrl = text(fd, "joinUrl") || undefined;
  const materialsUrl = text(fd, "materialsUrl") || undefined;
  const materialsNote = text(fd, "materialsNote") || undefined;
  const event = await db.timetableEvent.findUnique({ where: { id } });
  if (!event) throw new Error("Class not found.");
  const notesPayload = {
    materialsUrl: materialsUrl || undefined,
    materialsNote: materialsNote || undefined,
    updatedBy: user.id,
    updatedAt: new Date().toISOString(),
  };
  // Merge with existing notes if JSON
  let notes = JSON.stringify(notesPayload);
  try {
    const prev = event.notes ? JSON.parse(event.notes) : {};
    if (prev && typeof prev === "object") notes = JSON.stringify({ ...prev, ...notesPayload });
  } catch { /* plain text notes replaced */ }

  await db.timetableEvent.update({
    where: { id },
    data: {
      ...(title ? { title } : {}),
      ...(joinUrl ? { joinUrl, googleMeetUrl: joinUrl } : {}),
      notes,
    },
  });
  await db.auditLog.create({
    data: { userId: user.id, action: "CLASS_SESSION_UPDATED", entity: "TimetableEvent", entityId: id },
  });
  revalidatePath("/staff/academic/classes");
  revalidatePath(`/staff/academic/classes/${id}`);
  revalidatePath("/campus/timetable");
  revalidatePath("/campus/learning");
}

export async function uploadClassMaterial(fd: FormData) {
  const { db, user } = await requireOperationalStaffUser("academic.manage");
  const id = text(fd, "eventId");
  const file = fd.get("file");
  const event = await db.timetableEvent.findUnique({ where: { id } });
  if (!event) throw new Error("Class not found.");
  if (!(file instanceof File) || file.size === 0) throw new Error("Choose a file to upload.");
  const { uploadPrivateFile } = await import("@/lib/file-storage");
  const ref = await uploadPrivateFile(file, "class-materials", user.id);
  let prev: Record<string, unknown> = {};
  try { prev = event.notes ? JSON.parse(event.notes) : {}; } catch { prev = { legacyNotes: event.notes }; }
  const materials = Array.isArray(prev.materials) ? prev.materials : [];
  materials.push({ ref, name: file.name, uploadedAt: new Date().toISOString(), by: user.id });
  await db.timetableEvent.update({
    where: { id },
    data: { notes: JSON.stringify({ ...prev, materials }) },
  });
  await db.auditLog.create({
    data: { userId: user.id, action: "CLASS_MATERIAL_UPLOADED", entity: "TimetableEvent", entityId: id, metadataJson: JSON.stringify({ name: file.name }) },
  });
  revalidatePath(`/staff/academic/classes/${id}`);
  revalidatePath("/campus/learning");
}
