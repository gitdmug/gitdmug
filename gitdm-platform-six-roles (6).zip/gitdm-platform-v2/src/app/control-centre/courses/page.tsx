import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ControlNav } from "@/components/ControlNav";
import { GITDM } from "@/lib/branding";
import { requireStaffUser } from "@/lib/control-centre";
import { createCourse, assignLecturer } from "./actions";
import { ACTIVE_COURSE_CODES, ACTIVE_FACULTY_CODES, ACTIVE_PROGRAMME_CODES } from "@/lib/current-catalogue";
import { courseDisplayTitle } from "@/lib/course-display";

export const dynamic = "force-dynamic";
export const metadata = { title: `Course Catalogue | ${GITDM.shortName}` };

export default async function CoursesAdmin() {
  const { db, roleCodes } = await requireStaffUser("courses.view");
  const canManage = roleCodes.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR", "REGISTRAR"].includes(r));
  const [faculties, courses, lecturers, programmes] = await Promise.all([
    db.faculty.findMany({ where: { code: { in: [...ACTIVE_FACULTY_CODES] } }, orderBy: { name: "asc" } }),
    db.course.findMany({ where: { code: { in: [...ACTIVE_COURSE_CODES] } }, orderBy: [{ facultyUnit: { name: "asc" } }, { orderIndex: "asc" }, { title: "asc" }], include: { facultyUnit: true, faculty: { include: { user: true } }, programme: true, _count: { select: { modules: true, enrollments: true } } } }),
    db.user.findMany({ where: { roles: { some: { role: { code: { in: ["LECTURER", "ONLINE_INSTRUCTOR"] } } } } }, orderBy: [{ firstName: "asc" }, { lastName: "asc" }, { email: "asc" }] }),
    db.programme.findMany({ where: { code: { in: [...ACTIVE_PROGRAMME_CODES] } }, orderBy: { name: "asc" } }),
  ]);
  return <>
    <Header workspace="staff" /><ControlNav active="/control-centre/courses" />
    <main>
      <section className="page-hero"><div className="container"><div className="eyebrow">Academic catalogue</div><h1>Faculties &amp; courses</h1><p>GITDM is currently operating one active financial-markets faculty and three intake programmes. A course is registered once, receives its permanent code, and becomes student-selectable after it is published and a lecturer is allocated.</p></div></section>
      <section className="section"><div className="container">
        <div className="grid grid-2" style={{alignItems:"start"}}>
          <div className="card"><div className="eyebrow">Current intake catalogue</div><h2>Three active courses</h2><p>The current intake is intentionally limited to TA101, FX3M, and the 12-month Certificate in Financial Markets, Trading and Derivatives. Legacy course records remain stored for historical continuity but are hidden from the active course workflow. New offerings should be activated deliberately by updating the current catalogue first.</p><div className="meta"><span className="chip">TA101</span><span className="chip">FX3M</span><span className="chip">FFM-101 · Flagship certificate</span></div></div>
          <div className="card"><div className="eyebrow">Faculty model</div><h2>Current faculty and catalogue</h2>{faculties.map(f=><div key={f.id} className="staff-notice" style={{marginTop:12}}><div><strong>{f.code} · {f.name}</strong><p>{f.description}</p><span className="chip">{courses.filter(c=>c.facultyUnit?.id===f.id).length} courses</span></div></div>)}</div>
        </div>

        <div style={{marginTop:36}}><div className="eyebrow">Course register</div><h2>Published and developing courses</h2><div className="stack" style={{marginTop:18}}>
          {courses.map(c=><article className="card" key={c.id}>
            <div style={{display:"flex",justifyContent:"space-between",gap:16,alignItems:"flex-start",flexWrap:"wrap"}}><div><span className="chip chip-accent">{c.code}</span><span className="chip" style={{marginLeft:8}}>{c.facultyUnit?.code || "Unassigned faculty"}</span><h3 style={{marginTop:10}}>{courseDisplayTitle(c.code, c.title)}</h3><p>{c.description || "No description yet."}</p></div><div className="meta"><span className="chip">{c.published ? "Published" : "Draft"}</span><span className="chip">{c.studentSelectable ? "Student selectable" : "Staff only"}</span></div></div>
            <p><strong>Lecturer:</strong> {c.faculty.length ? c.faculty.map(f=>[f.user.firstName,f.user.lastName].filter(Boolean).join(" ")||f.user.email).join(", ") : "Not allocated"} · <strong>Modules:</strong> {c._count.modules} · <strong>Students:</strong> {c._count.enrollments}</p><div className="meta"><span className="chip">{c.durationMonths} month{c.durationMonths === 1 ? "" : "s"}</span><span className="chip">{c.durationMonths === 12 ? "Study at your convenience" : `${c.sessionsPerWeek} sessions/week`}</span><span className="chip">{c.catalogueVisible ? "Public catalogue" : "Hidden from catalogue"}</span></div>
            <div className="actions" style={{flexWrap:"wrap"}}><Link href={`/control-centre/courses/${c.id}`} className="btn btn-primary btn-sm">Open course workspace</Link>{canManage ? <form action={assignLecturer} className="actions" style={{flexWrap:"wrap"}}><input type="hidden" name="courseId" value={c.id}/><select name="lecturerId" required><option value="">Allocate lecturer…</option>{lecturers.map(l=><option key={l.id} value={l.id}>{[l.firstName,l.lastName].filter(Boolean).join(" ")||l.email}</option>)}</select><button className="btn btn-outline-dark btn-sm">Allocate lecturer</button></form> : null}</div>
          </article>)}
          {!courses.length ? <div className="panel">No courses yet. Register the first course above.</div> : null}
        </div></div>
        <div className="actions" style={{marginTop:28}}><Link href="/control-centre/programmes" className="btn btn-outline-dark btn-sm">Programme builder</Link><Link href="/control-centre/timetable" className="btn btn-primary btn-sm">Schedule classes</Link></div>
      </div></section>
    </main><Footer />
  </>;
}
