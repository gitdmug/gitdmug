"use server";
import { notifyStudentChange } from "@/lib/student-email";
import { revalidatePath } from "next/cache";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { syncStudentCourseGrade } from "@/lib/grade-sync";

export async function syncProvisionalGrades() {
  const { db, user } = await requireOperationalStaffUser("results.moderate");
  const enrollments = await db.enrollment.findMany({ where: { status: { in: ["ACTIVE", "REPEATING"] } }, include: { courses: true } });
  let count=0; for(const enrollment of enrollments){for(const ce of enrollment.courses.filter((x:any)=>x.status==="ACTIVE"||x.status==="REPEATING")){await syncStudentCourseGrade(db,enrollment.userId,ce.courseId,enrollment.periodId);count++;}}
  await db.auditLog.create({data:{userId:user.id,action:"PROVISIONAL_GRADES_SYNCHRONIZED",entity:"Grade",metadataJson:JSON.stringify({count})}});
  revalidatePath("/control-centre/results");revalidatePath("/campus/assessments");revalidatePath("/campus/academic");
}

export async function publishGrade(formData: FormData) {
  const { db, user } = await requireOperationalStaffUser("results.publish");
  const gradeId = String(formData.get("gradeId") || "");
  const grade = await db.grade.findUnique({ where: { id: gradeId }, include: { user: true, course: { include: { programme: { include: { rules: true } } } } } });
  if (!grade) throw new Error("Grade not found.");
  const attendance = await db.attendanceRecord.findMany({ where: { userId: grade.userId, courseId: grade.courseId, periodId: grade.periodId || undefined } });
  const classAttendance = await db.classAttendanceRecord.findMany({ where: { userId: grade.userId, courseId: grade.courseId, periodId: grade.periodId || undefined }, include: { timetableEvent: { select: { startAt: true, endAt: true } } } });
  const attendancePct = classAttendance.length ? (() => { const scheduled = classAttendance.reduce((sum, a) => sum + Math.max(1, Math.round((new Date((a as any).timetableEvent?.endAt || a.date).getTime() - new Date((a as any).timetableEvent?.startAt || a.date).getTime()) / 60000)), 0); return scheduled ? Math.min(100, classAttendance.reduce((sum,a)=>sum+Math.max(0,a.minutesAttended),0) / scheduled * 100) : 0; })() : (attendance.length ? attendance.filter(a => a.status !== "ABSENT").length / attendance.length * 100 : 0);
  const attendanceMinimum = Number(grade.course.programme?.rules?.attendanceMinimumPercent ?? 70);
  if (attendancePct < attendanceMinimum) throw new Error(`Grade cannot be published because attendance is below the ${attendanceMinimum}% requirement.`);
  if (Number(grade.examPercent) <= 0 && Number(grade.totalPercent) > 0) throw new Error("A finalized examination result is required before publishing this grade.");
  const examRelease = await db.exam.findFirst({where:{courseId:grade.courseId,periodId:grade.periodId||undefined},orderBy:{resultsReleaseAt:"desc"},select:{resultsReleaseAt:true}});
  if (examRelease?.resultsReleaseAt && examRelease.resultsReleaseAt > new Date()) throw new Error(`Result publication is scheduled for ${examRelease.resultsReleaseAt.toLocaleString("en-UG")}.`);
  await db.grade.update({ where: { id: gradeId }, data: { status: "FINAL", finalizedAt: new Date() } });
  await db.auditLog.create({ data: { userId: user.id, action: "GRADE_PUBLISHED", entity: "Grade", entityId: gradeId, metadataJson: JSON.stringify({ studentId: grade.userId, courseId: grade.courseId, total: Number(grade.totalPercent) }) } });
  await db.notification.create({ data: { userId: grade.userId, type: "ACADEMIC", title: "Result published", body: `${grade.course.code} — ${grade.course.title}: ${Number(grade.totalPercent).toFixed(1)}%` } });
  const resultUser = await db.user.findUnique({where:{id:grade.userId},select:{email:true,firstName:true}});
  if(resultUser?.email) await notifyStudentChange({userId:grade.userId,email:resultUser.email,firstName:resultUser.firstName,title:"Result published",body:`${grade.course.code} — ${grade.course.title}: ${Number(grade.totalPercent).toFixed(1)}%`,action:"RESULT_PUBLISHED",event:"RESULT_PUBLISHED",href:"/campus/results"});
  revalidatePath("/control-centre/results"); revalidatePath("/campus/assessments"); revalidatePath("/campus/academic");
}
