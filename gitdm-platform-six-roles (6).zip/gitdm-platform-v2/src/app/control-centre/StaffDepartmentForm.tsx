"use client";
import { useRouter } from "next/navigation";
import { useState } from "react";

type Department = { id: string; name: string };
type Current = { departmentId: string; isHead: boolean };

export function StaffDepartmentForm({ userId, departments, current }: { userId: string; actorId: string; departments: Department[]; current: Current[] }) {
  const router = useRouter();
  const [departmentId, setDepartmentId] = useState("");
  const [isHead, setIsHead] = useState(false);
  const [busy, setBusy] = useState(false);
  const [message, setMessage] = useState<string | null>(null);
  async function save(action: "assign" | "remove", id: string, head = false) {
    setBusy(true); setMessage(null);
    try {
      const res = await fetch("/api/control-centre/departments", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ userId, departmentId: id, isHead: head, action }) });
      const data = await res.json();
      if (!res.ok) setMessage(data.error || "Failed"); else { setMessage(action === "assign" ? "Department assigned" : "Department removed"); router.refresh(); }
    } catch { setMessage("Network error"); } finally { setBusy(false); }
  }
  const available = departments.filter((d) => !current.some((c) => c.departmentId === d.id));
  return <div style={{ display: "grid", gap: 10 }}>
    <div style={{ display: "flex", gap: 8 }}><select value={departmentId} onChange={(e) => setDepartmentId(e.target.value)} disabled={busy} style={{ flex: 1 }}><option value="">Select department…</option>{available.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select><label style={{ display: "flex", alignItems: "center", gap: 5, fontSize: 13 }}><input type="checkbox" checked={isHead} onChange={(e) => setIsHead(e.target.checked)} /> Head</label><button className="btn btn-primary btn-sm" disabled={!departmentId || busy} onClick={() => save("assign", departmentId, isHead)}>Assign</button></div>
    <div style={{ display: "grid", gap: 6 }}>{current.map((c) => { const d = departments.find((x) => x.id === c.departmentId); return <div key={c.departmentId} style={{ display: "flex", justifyContent: "space-between", gap: 8, alignItems: "center", padding: "8px 10px", border: "1px solid var(--border, #ddd)", borderRadius: 6 }}><span>{d?.name || c.departmentId}{c.isHead ? " · Head" : ""}</span><button className="btn btn-outline-dark btn-sm" disabled={busy} onClick={() => save("remove", c.departmentId)}>Remove</button></div>; })}</div>
    {message ? <span style={{ fontSize: 12, color: "var(--muted)" }}>{message}</span> : null}
  </div>;
}
