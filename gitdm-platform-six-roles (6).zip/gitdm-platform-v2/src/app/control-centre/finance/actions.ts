"use server";
import { randomUUID } from "node:crypto";
import { revalidatePath } from "next/cache";
import { requireOperationalStaffUser } from "@/lib/control-centre";
import { settlePesapalPayment } from "@/lib/pesapal";

export async function verifyPayment(formData: FormData) {
  const paymentId = String(formData.get("paymentId") || "");
  const { db, user } = await requireOperationalStaffUser("payments.verify");

  const payment = await db.payment.findUnique({
    where: { id: paymentId },
    select: { id: true, provider: true, providerRef: true },
  });

  if (!payment) throw new Error("Payment not found.");

  // Staff verification must never manually override a Pesapal transaction.
  // It re-queries Pesapal instead, using the same authoritative settlement path
  // as the customer callback and IPN.
  if (payment.provider === "PESAPAL") {
    if (!payment.providerRef) throw new Error("Pesapal tracking reference is missing.");
    await settlePesapalPayment(payment.providerRef);
  } else {
    await db.$transaction(async (tx) => {
      const current = await tx.payment.findUnique({
        where: { id: paymentId },
        include: {
          invoice: {
            include: {
              enrollment: {
                include: { programme: { include: { rules: true } } },
              },
            },
          },
        },
      });
      if (!current || current.status !== "PENDING") {
        throw new Error("Payment is not pending.");
      }

      await tx.payment.update({
        where: { id: current.id },
        data: { status: "COMPLETED", verifiedAt: new Date() },
      });

      const newPaid = Number(current.invoice.amountPaid) + Number(current.amount);
      const status =
        newPaid >= Number(current.invoice.amount) ? "PAID" : "PARTIALLY_PAID";

      const invoiceUpdate = await tx.invoice.updateMany({
        where: { id: current.invoiceId, amountPaid: current.invoice.amountPaid, status: current.invoice.status },
        data: { amountPaid: newPaid, status },
      });
      if (invoiceUpdate.count !== 1) throw new Error("Invoice balance changed during verification. Refresh and retry.");

      const enrollment = current.invoice.enrollment;
      const totalInvoices = await tx.invoice.aggregate({
        where: {
          enrollmentId: enrollment.id,
          ...(current.invoice.periodId
            ? { periodId: current.invoice.periodId }
            : { periodId: null }),
          status: { notIn: ["DRAFT", "VOID"] },
        },
        _sum: { amount: true, amountPaid: true },
      });
      const pct =
        Number(totalInvoices._sum.amount || 0) > 0
          ? (Number(totalInvoices._sum.amountPaid || 0) /
              Number(totalInvoices._sum.amount || 0)) *
            100
          : 0;
      const threshold = Number(
        enrollment.programme.rules?.activationPaymentPercent || 60,
      );
      const access = pct >= threshold ? "FULL" : "LIMITED";

      await tx.enrollment.update({
        where: { id: enrollment.id },
        data: {
          accessLevel: access,
          activatedAt:
            access === "FULL"
              ? enrollment.activatedAt || new Date()
              : enrollment.activatedAt,
        },
      });

      const existingReceipt = await tx.receipt.findUnique({
        where: { paymentId: current.id },
      });
      if (!existingReceipt) {
        await tx.receipt.create({
          data: {
            paymentId: current.id,
            invoiceId: current.invoiceId,
            userId: current.userId,
            receiptNo: `RCT-${new Date().getFullYear()}-${randomUUID().replaceAll("-", "").slice(0, 12).toUpperCase()}`,
          },
        });
      }

      await tx.notification.create({
        data: {
          userId: current.userId,
          type: "FINANCE",
          title: "Payment verified",
          body: `A payment of ${current.currency} ${Number(current.amount).toLocaleString()} has been verified. Your learning access is now ${access === "FULL" ? "open" : "limited"} based on current clearance.`,
        },
      });

      await tx.auditLog.create({
        data: {
          userId: user.id,
          action: "PAYMENT_VERIFIED",
          entity: "Payment",
          entityId: current.id,
          metadataJson: JSON.stringify({
            amount: Number(current.amount),
            provider: current.provider,
            providerRef: current.providerRef,
          }),
        },
      });
    });
  }

  revalidatePath("/control-centre/finance");
  revalidatePath("/staff/admissions/applications");
  revalidatePath("/staff/admissions");
  revalidatePath("/control-centre/finance/payments");
  revalidatePath("/campus");
  revalidatePath("/campus/finance");
  revalidatePath("/campus/learning");
}

export async function recordOfflinePayment(formData: FormData) {
  const invoiceId = String(formData.get("invoiceId") || "").trim();
  const method = String(formData.get("method") || "").toUpperCase();
  const reference = String(formData.get("reference") || "").trim();
  const evidence = formData.get("evidence");
  const amount = Number(formData.get("amount"));
  if (!["CASH", "BANK_TRANSFER"].includes(method)) throw new Error("Choose cash or bank transfer.");
  if (!Number.isFinite(amount) || amount <= 0) throw new Error("Enter a valid payment amount.");
  const { db, user } = await requireOperationalStaffUser("finance.manage");
  let evidenceUrl: string | null = null;
  if (evidence instanceof File && evidence.size > 0) {
    const { uploadPrivateFile } = await import("@/lib/file-storage");
    evidenceUrl = await uploadPrivateFile(evidence, "gitdm/finance/payment-evidence", user.id);
  }
  await db.$transaction(async (tx) => {
    const invoice = await tx.invoice.findUnique({
      where: { id: invoiceId },
      include: { enrollment: { include: { programme: { include: { rules: true } } } } },
    });
    if (!invoice || invoice.status === "VOID" || invoice.status === "DRAFT") throw new Error("This invoice is not available for payment recording.");
    const balance = Number(invoice.amount) - Number(invoice.amountPaid);
    if (amount > balance + 0.001) throw new Error("Payment exceeds the outstanding invoice balance.");
    if (reference) {
      const duplicate = await tx.payment.findFirst({ where: { provider: method, providerMerchantRef: reference } });
      if (duplicate) throw new Error("That cash/bank reference has already been recorded.");
    }
    const newPaid = Number(invoice.amountPaid) + amount;
    const nextStatus = newPaid >= Number(invoice.amount) - 0.001 ? "PAID" : "PARTIALLY_PAID";
    const invoiceUpdate = await tx.invoice.updateMany({
      where: { id: invoice.id, amountPaid: invoice.amountPaid, status: invoice.status },
      data: { amountPaid: newPaid, status: nextStatus },
    });
    if (invoiceUpdate.count !== 1) throw new Error("Invoice balance changed. Refresh before recording this payment.");
    const payment = await tx.payment.create({
      data: {
        invoiceId: invoice.id,
        userId: invoice.enrollment.userId,
        provider: method,
        providerMethod: method === "CASH" ? "Cash" : "Bank transfer",
        providerMerchantRef: reference || null,
        providerConfirmationCode: reference || null,
        amount,
        currency: invoice.currency,
        status: "COMPLETED",
        evidenceUrl,
        verifiedAt: new Date(),
      },
    });

    const enrollment = invoice.enrollment;
    const currentPeriodInvoices = await tx.invoice.aggregate({
      where: { enrollmentId: enrollment.id, periodId: enrollment.periodId, status: { notIn: ["DRAFT", "VOID"] } },
      _sum: { amount: true, amountPaid: true },
    });
    const total = Number(currentPeriodInvoices._sum.amount || 0);
    const paid = Number(currentPeriodInvoices._sum.amountPaid || 0);
    const percent = total > 0 ? (paid / total) * 100 : 0;
    const threshold = Number(enrollment.programme.rules?.activationPaymentPercent || 60);
    const accessLevel = percent >= threshold ? "FULL" : "LIMITED";
    await tx.enrollment.update({
      where: { id: enrollment.id },
      data: { accessLevel, activatedAt: accessLevel === "FULL" ? enrollment.activatedAt || new Date() : enrollment.activatedAt },
    });
    const receiptNo = `RCT-${new Date().getFullYear()}-${randomUUID().replaceAll("-", "").slice(0, 12).toUpperCase()}`;
    await tx.receipt.create({ data: { paymentId: payment.id, invoiceId: invoice.id, userId: invoice.enrollment.userId, receiptNo } });
    await tx.notification.create({
      data: { userId: invoice.enrollment.userId, type: "FINANCE", title: "Payment received", body: `Finance recorded ${invoice.currency} ${amount.toLocaleString()} by ${method === "CASH" ? "cash" : "bank transfer"}. Receipt ${receiptNo} is available in your Finance page.` },
    });
    await tx.auditLog.create({
      data: { userId: user.id, action: "OFFLINE_PAYMENT_RECORDED", entity: "Payment", entityId: payment.id, metadataJson: JSON.stringify({ invoiceId, amount, currency: invoice.currency, method, reference, receiptNo }) },
    });
  });
  revalidatePath("/control-centre/finance");
  revalidatePath("/control-centre/finance/payments");
  revalidatePath("/control-centre/finance/invoices");
  revalidatePath("/campus/finance");
  revalidatePath("/campus");
  revalidatePath("/campus/learning");
}

export async function overrideExamClearance(formData: FormData) {
  const { db, user } = await requireOperationalStaffUser("finance.manage");
  const enrollmentId = String(formData.get("enrollmentId") || "");
  const reason = String(formData.get("reason") || "").trim();
  if (!enrollmentId || reason.length < 8) throw new Error("A documented clearance reason is required.");
  const enrollment = await db.enrollment.findUnique({ where: { id: enrollmentId }, include: { user: true } });
  if (!enrollment) throw new Error("Enrollment not found.");
  await db.enrollment.update({ where: { id: enrollmentId }, data: { financialClearanceOverride: true, financialOverrideReason: reason, financialOverrideById: user.id, financialOverrideAt: new Date() } });
  await db.notification.create({ data: { userId: enrollment.userId, type: "FINANCE", title: "Financial examination clearance granted", body: "Finance has recorded an approved examination-clearance override on your enrolment." } });
  await db.auditLog.create({ data: { userId: user.id, action: "FINANCIAL_EXAM_CLEARANCE_OVERRIDE", entity: "Enrollment", entityId: enrollmentId, metadataJson: JSON.stringify({ reason, studentId: enrollment.userId }) } });
  revalidatePath("/control-centre/finance");
  revalidatePath("/campus");
  revalidatePath("/campus/assessments");
}
