"use server";
import { revalidatePath } from "next/cache";
import { requireOperationalStaffUser } from "@/lib/control-centre";

function csvRows(text:string){
  const lines=text.replace(/\r/g,"").split("\n").map(x=>x.trim()).filter(Boolean); if(!lines.length) return [];
  const parse=(line:string)=>line.split(/,(?=(?:[^\"]*\"[^\"]*\")*[^\"]*$)/).map(x=>x.replace(/^\"|\"$/g,"").trim());
  const headers=parse(lines[0]).map(x=>x.toLowerCase());
  return lines.slice(1).map(line=>{const cells=parse(line);const row:Record<string,string>={};headers.forEach((h,i)=>row[h]=cells[i]||"");return row;});
}
export async function importBankStatement(formData:FormData){
  const {db,user}=await requireOperationalStaffUser("finance.reconcile"); const file=formData.get("file"); if(!(file instanceof File)||!file.size) throw new Error("Upload a CSV bank statement.");
  const rows=csvRows(await file.text()); if(!rows.length) throw new Error("The CSV has no transaction rows.");
  let imported=0,matched=0,exceptions=0;
  for(const row of rows){const externalRef=row.externalref||row.reference||row.transactionid||row.id;const amount=Number((row.amount||row.credit||"").replace(/,/g,""));const description=row.description||row.narration||"Bank transaction";const date=new Date(row.transactiondate||row.date||row.valuedate);if(!externalRef||!Number.isFinite(amount)||amount<=0||Number.isNaN(date.getTime())){exceptions++;continue;}
    const existing=await db.bankTransaction.findUnique({where:{externalRef}}); if(existing) continue;
    const refCandidates=[externalRef,description].filter(Boolean);
    const payment=await db.payment.findFirst({where:{status:"COMPLETED",OR:refCandidates.flatMap(ref=>[{providerRef:ref},{providerMerchantRef:ref},{providerConfirmationCode:ref}]),amount:{equals:amount}}});
    await db.bankTransaction.create({data:{externalRef,transactionDate:date,description,amount,currency:row.currency||"UGX",status:payment?"MATCHED":"UNMATCHED",matchedPaymentId:payment?.id,importedById:user.id}}); imported++; if(payment) matched++;
  }
  await db.auditLog.create({data:{userId:user.id,action:"BANK_STATEMENT_IMPORTED",entity:"BankTransaction",metadataJson:JSON.stringify({imported,matched,exceptions,file:file.name})}});
  revalidatePath("/control-centre/finance/reconciliation");
}
export async function resolveBankTransaction(formData:FormData){const{db,user}=await requireOperationalStaffUser("finance.reconcile");const id=String(formData.get("id")||""),paymentId=String(formData.get("paymentId")||""),note=String(formData.get("note")||"").trim();const tx=await db.bankTransaction.findUnique({where:{id}});if(!tx)throw new Error("Bank transaction not found.");if(paymentId){const payment=await db.payment.findUnique({where:{id:paymentId}});if(!payment)throw new Error("Payment not found.");await db.bankTransaction.update({where:{id},data:{matchedPaymentId:payment.id,status:"MATCHED",resolutionNote:note||"Manually matched by Finance"}});}else await db.bankTransaction.update({where:{id},data:{status:"RESOLVED",resolutionNote:note||"Resolved by Finance"}});await db.auditLog.create({data:{userId:user.id,action:"BANK_TRANSACTION_RESOLVED",entity:"BankTransaction",entityId:id,metadataJson:JSON.stringify({paymentId,note})}});revalidatePath("/control-centre/finance/reconciliation");}
