import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ControlNav } from "@/components/ControlNav";
import { GITDM } from "@/lib/branding";
import { requireStaffUser } from "@/lib/control-centre";
import { money } from "@/lib/status";

export const dynamic = "force-dynamic";
export const metadata = { title: `Finance Reports | ${GITDM.shortName}` };

export default async function FinanceReportsPage() {
  const { db } = await requireStaffUser("reports.view");
  const sixMonthsAgo = new Date();
  sixMonthsAgo.setDate(1);
  sixMonthsAgo.setMonth(sixMonthsAgo.getMonth() - 5);
  const [invoices, payments, active, examBlocked] = await Promise.all([
    db.invoice.findMany({ where: { status: { notIn: ["DRAFT", "VOID"] } }, select: { amount: true, amountPaid: true, currency: true, status: true } }),
    db.payment.findMany({ where: { status: "COMPLETED", createdAt: { gte: sixMonthsAgo } }, select: { amount: true, currency: true, createdAt: true } }),
    db.enrollment.count({ where: { status: "ACTIVE", accessLevel: "FULL" } }),
    db.enrollment.count({ where: { status: "ACTIVE", accessLevel: "LIMITED" } }),
  ]);
  const currencies = [...new Set([...invoices.map((i) => i.currency), ...payments.map((p) => p.currency)])];
  const monthStarts = Array.from({ length: 6 }, (_, index) => {
    const date = new Date(sixMonthsAgo);
    date.setMonth(date.getMonth() + index);
    return date;
  });
  const monthLabel = (date: Date) => date.toLocaleDateString("en-UG", { month: "short", year: "2-digit" });
  const monthlyByCurrency = currencies.map((currency) => {
    const values = monthStarts.map((month) => ({
      label: monthLabel(month),
      amount: payments.filter((p) => p.currency === currency && p.createdAt.getFullYear() === month.getFullYear() && p.createdAt.getMonth() === month.getMonth()).reduce((sum, p) => sum + Number(p.amount), 0),
    }));
    return { currency, values, max: Math.max(1, ...values.map((v) => v.amount)) };
  });
  const month = new Date();
  month.setDate(1);
  const monthPaid = payments.filter((p) => p.createdAt >= month).reduce((sum, p) => sum + Number(p.amount), 0);
  return <><Header workspace="staff"/><ControlNav active="/control-centre/finance"/><main><section className="page-hero"><div className="container"><div className="eyebrow">Finance · Reports</div><h1>Financial position</h1><p>Institution-level billing, collections and access-clearance indicators. Draft invoice requests are excluded from billed totals.</p></div></section><section className="section"><div className="container">
    <div className="grid grid-3">{currencies.map((currency) => { const rows = invoices.filter((i) => i.currency === currency); const billed = rows.reduce((sum, i) => sum + Number(i.amount), 0); const paid = rows.reduce((sum, i) => sum + Number(i.amountPaid), 0); return <div className="panel" key={currency}><div className="eyebrow">Billed · {currency}</div><h2>{money(billed,currency)}</h2><p>Collected against invoices: {money(paid,currency)}</p><p style={{marginBottom:0}}>Outstanding: {money(Math.max(0,billed-paid),currency)}</p></div>; })}
      <div className="panel"><div className="eyebrow">Collected this month</div><h2>{money(monthPaid, currencies.length === 1 ? currencies[0] : "Mixed")}</h2><p>Completed transactions only</p></div><div className="panel"><div className="eyebrow">Fully activated students</div><h2>{active}</h2></div><div className="panel"><div className="eyebrow">Limited access / financial clearance pending</div><h2>{examBlocked}</h2></div>
    </div>
    <div className="panel" style={{marginTop:28}}><div className="eyebrow">Collections trend</div><h2>Monthly payments received · last six months</h2>{monthlyByCurrency.map((series) => <div key={series.currency} style={{marginTop:24}}><h3>{series.currency}</h3><div style={{display:"grid",gap:12}}>{series.values.map((v) => <div key={v.label} style={{display:"grid",gridTemplateColumns:"72px minmax(0,1fr) 150px",gap:12,alignItems:"center"}}><span>{v.label}</span><div style={{height:14,background:"var(--surface-muted, #edf0f5)",borderRadius:999,overflow:"hidden"}}><div style={{height:"100%",width:`${Math.max(0,(v.amount/series.max)*100)}%`,background:"var(--accent, #c99a2e)",borderRadius:999}}/></div><strong style={{textAlign:"right"}}>{money(v.amount,series.currency)}</strong></div>)}</div></div>)}{currencies.length===0?<p>No invoice or payment data is available yet.</p>:null}</div>
    <div className="panel" style={{marginTop:28}}><h3 style={{marginTop:0}}>Control rule</h3><p style={{marginBottom:0}}>Financial status is derived from invoice and payment records. Staff should never grant learning or examination access by changing a client-side flag.</p></div>
  </div></section></main><Footer/></>;
}
