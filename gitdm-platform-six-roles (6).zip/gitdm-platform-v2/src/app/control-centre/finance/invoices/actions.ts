"use server";
import { notifyStudentChange } from "@/lib/student-email";

import { revalidatePath } from "next/cache";
import { requireOperationalStaffUser } from "@/lib/control-centre";

export async function createPeriodInvoice(formData: FormData) {
  const enrollmentId = String(formData.get("enrollmentId") || "");
  const { db, user } = await requireOperationalStaffUser("finance.manage");
  const enrollment = await db.enrollment.findUnique({ where: { id: enrollmentId }, include: { user: true, programme: true, period: true } });
  if (!enrollment || !enrollment.period) throw new Error("An active academic period is required before issuing a period invoice.");
  const existing = await db.invoice.findFirst({ where: { enrollmentId, periodId: enrollment.period.id, status: { not: "VOID" } } });
  if (existing) throw new Error("An invoice already exists for this enrolment and academic period.");
  const count = await db.invoice.count();
  const invoiceNo = `GITDM-INV-${new Date().getFullYear()}-${String(count + 1).padStart(5, "0")}`;
  const dueAt = new Date(); dueAt.setDate(dueAt.getDate() + 14);
  const invoice = await db.invoice.create({ data: { enrollmentId, periodId: enrollment.period.id, invoiceNo, description: `${enrollment.programme.name} — ${enrollment.period.name}`, amount: enrollment.period.feeAmount, currency: enrollment.period.currency, dueAt } });
  await db.auditLog.create({ data: { userId: user.id, action: "INVOICE_ISSUED", entity: "Invoice", entityId: invoice.id, metadataJson: JSON.stringify({ invoiceNo, enrollmentId, amount: Number(enrollment.period.feeAmount), currency: enrollment.period.currency }) } });
  await db.notification.create({ data: { userId: enrollment.userId, type: "FINANCE", title: "Invoice issued", body: `Invoice ${invoiceNo} for ${enrollment.period.currency} ${Number(enrollment.period.feeAmount).toLocaleString()} is now available.` } });
  const invoiceUser = await db.user.findUnique({where:{id:enrollment.userId},select:{email:true,firstName:true}});
  if(invoiceUser?.email) await notifyStudentChange({userId:enrollment.userId,email:invoiceUser.email,firstName:invoiceUser.firstName,title:"Invoice issued",body:`Invoice ${invoiceNo} for ${enrollment.period.currency} ${Number(enrollment.period.feeAmount).toLocaleString()} is now available.`,action:"INVOICE_ISSUED",event:"INVOICE_ISSUED",href:"/campus/finance"});
  revalidatePath("/control-centre/finance"); revalidatePath("/control-centre/finance/invoices"); revalidatePath("/campus/finance");
}

export async function markOverdueInvoices() {
  const { db, user } = await requireOperationalStaffUser("finance.manage");
  const result = await db.invoice.updateMany({ where: { dueAt: { lt: new Date() }, status: { in: ["ISSUED", "PARTIALLY_PAID"] } }, data: { status: "OVERDUE" } });
  await db.auditLog.create({ data: { userId: user.id, action: "INVOICES_MARKED_OVERDUE", entity: "Invoice", metadataJson: JSON.stringify({ count: result.count }) } });
  revalidatePath("/control-centre/finance"); revalidatePath("/control-centre/finance/invoices");
}

export async function issueRequestedInvoice(formData: FormData) {
  const invoiceId = String(formData.get("invoiceId") || "").trim();
  const { db, user } = await requireOperationalStaffUser("finance.manage");
  const invoice = await db.invoice.findUnique({ where: { id: invoiceId }, include: { enrollment: { include: { user: true } } } });
  if (!invoice) throw new Error("Invoice request not found.");
  if (invoice.status !== "DRAFT") throw new Error("Only draft invoice requests can be issued.");
  const dueAt = new Date();
  dueAt.setDate(dueAt.getDate() + 14);
  await db.$transaction([
    db.invoice.update({ where: { id: invoice.id }, data: { status: "ISSUED", dueAt } }),
    db.notification.create({ data: { userId: invoice.enrollment.userId, type: "FINANCE", title: "Invoice issued", body: `Finance has issued invoice ${invoice.invoiceNo}. You may now print it and clear it by ${dueAt.toLocaleDateString("en-UG")}.` } }),
    db.auditLog.create({ data: { userId: user.id, action: "OFFLINE_INVOICE_ISSUED", entity: "Invoice", entityId: invoice.id, metadataJson: JSON.stringify({ invoiceNo: invoice.invoiceNo, paymentPreference: invoice.paymentPreference, dueAt }) } }),
  ]);
  revalidatePath("/control-centre/finance");
  revalidatePath("/control-centre/finance/invoices");
  revalidatePath("/campus/finance");
}
