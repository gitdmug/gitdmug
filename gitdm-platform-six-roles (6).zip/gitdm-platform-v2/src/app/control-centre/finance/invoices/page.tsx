import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ControlNav } from "@/components/ControlNav";
import { GITDM } from "@/lib/branding";
import { requireStaffUser } from "@/lib/control-centre";
import { money, humanStatus } from "@/lib/status";
import { createPeriodInvoice, issueRequestedInvoice, markOverdueInvoices } from "./actions";

export const dynamic = "force-dynamic";
export const metadata = { title: `Finance Invoices | ${GITDM.shortName}` };

export default async function FinanceInvoicesPage() {
  const { db } = await requireStaffUser("finance.view");
  const [invoices, enrollments] = await Promise.all([
    db.invoice.findMany({ orderBy: { dueAt: "desc" }, take: 200, include: { enrollment: { include: { user: true, programme: true } } } }),
    db.enrollment.findMany({ where: { status: { in: ["ACTIVE", "REPEATING"] } }, orderBy: { createdAt: "desc" }, take: 100, include: { user: true, programme: true, period: true, invoices: { where: { status: { not: "VOID" } } } } }),
  ]);
  const invoicePeriods = await db.academicPeriod.findMany({ where: { id: { in: invoices.map(i => i.periodId).filter((id): id is string => Boolean(id)) } } });
  const periodById = new Map<string, { name: string }>(invoicePeriods.map(p => [p.id, { name: p.name }]));
  const candidates = enrollments.filter(e => e.period && !e.invoices.some(i => i.periodId === e.periodId));
  return <><Header workspace="staff"/><ControlNav active="/control-centre/finance"/><main><section className="page-hero"><div className="container"><div className="eyebrow">Finance · Invoices</div><h1>Institutional billing</h1><p>Issue period invoices, monitor balances and keep financial records tied to enrolments.</p></div></section><section className="section"><div className="container">
    <div className="actions" style={{marginBottom:24}}><form action={markOverdueInvoices}><button className="btn btn-outline-dark btn-sm">Refresh overdue status</button></form></div>
    <div className="grid grid-2" style={{marginBottom:32}}><div className="panel"><div className="eyebrow">Ready to invoice</div><h2>{candidates.length}</h2><p>Active enrolments without a current-period invoice.</p>{candidates.slice(0,10).map(e=><form key={e.id} action={createPeriodInvoice} className="panel" style={{marginTop:10,padding:14}}><input type="hidden" name="enrollmentId" value={e.id}/><strong>{[e.user.firstName,e.user.lastName].filter(Boolean).join(" ") || e.user.email}</strong><div style={{fontSize:13,margin:"4px 0 10px"}}>{e.programme.shortName || e.programme.name} · {e.period?.name} · {money(e.period?.feeAmount || 0,e.period?.currency || "UGX")}</div><button className="btn btn-primary btn-sm">Issue invoice</button></form>)}</div><div className="panel"><div className="eyebrow">Finance rule</div><h3>Clearance lifecycle</h3><p style={{marginBottom:8}}>60% of the current fee activates full learning access. 100% is required before the final examination.</p><p style={{margin:0}}>Every provider payment must be confirmed server-side before balances and access are changed.</p></div></div>
    <div className="eyebrow">Invoice register</div><h2>All invoices</h2><div className="table-wrap"><table className="data"><thead><tr><th>Invoice</th><th>Student</th><th>Period</th><th>Amount</th><th>Paid</th><th>Balance</th><th>Due</th><th>Method / action</th></tr></thead><tbody>{invoices.map(i=>{const balance=Math.max(0,Number(i.amount)-Number(i.amountPaid));return <tr key={i.id}><td>{i.invoiceNo}</td><td>{[i.enrollment.user.firstName,i.enrollment.user.lastName].filter(Boolean).join(" ")||i.enrollment.user.email}</td><td>{(i.periodId ? periodById.get(i.periodId)?.name : null)||"—"}</td><td>{money(i.amount,i.currency)}</td><td>{money(i.amountPaid,i.currency)}</td><td>{money(balance,i.currency)}</td><td>{i.dueAt?new Date(i.dueAt).toLocaleDateString():"—"}</td><td>{i.status === "DRAFT" ? <><div>{humanStatus(i.status)} · {i.paymentPreference === "BANK_TRANSFER" ? "Bank transfer" : "Cash"} request</div><form action={issueRequestedInvoice} style={{marginTop:8}}><input type="hidden" name="invoiceId" value={i.id}/><button className="btn btn-primary btn-sm" type="submit">Issue invoice</button></form></> : <>{humanStatus(i.status)}{i.paymentPreference ? <div className="tile-meta">Requested: {i.paymentPreference === "BANK_TRANSFER" ? "Bank transfer" : "Cash"}</div> : null}</>}</td></tr>})}</tbody></table></div>
  </div></section></main><Footer/></>;
}
