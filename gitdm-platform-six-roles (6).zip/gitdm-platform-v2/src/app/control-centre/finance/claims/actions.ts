"use server";
import { revalidatePath } from "next/cache";
import { requireOperationalStaffUser } from "@/lib/control-centre";

async function notifyDepartmentHeads(db: any, departmentId: string, title: string, body: string) {
  const heads = await db.userDepartment.findMany({ where: { departmentId, isHead: true }, select: { userId: true } });
  if (heads.length) await db.notification.createMany({ data: heads.map((h: any) => ({ userId: h.userId, type: "FINANCE", title, body })) });
}

export async function submitClaim(formData: FormData) {
  const { db, user } = await requireOperationalStaffUser("finance.claims.submit");
  const departmentId = String(formData.get("departmentId") || "");
  const category = String(formData.get("category") || "").trim();
  const description = String(formData.get("description") || "").trim();
  const amount = Number(formData.get("amount"));
  if (!departmentId || !category || !description || !Number.isFinite(amount) || amount <= 0) throw new Error("Department, category, description and a positive amount are required.");
  const assignment = await db.userDepartment.findUnique({ where: { userId_departmentId: { userId: user.id, departmentId } }, include: { department: true } });
  if (!assignment) throw new Error("You may only submit a claim against a department to which you are assigned.");
  const claim = await db.staffExpenseClaim.create({ data: { requesterId: user.id, departmentId, category, description, amount, currency: String(formData.get("currency") || "UGX"), receiptUrlsJson: String(formData.get("receiptUrlsJson") || "") || undefined } });
  await notifyDepartmentHeads(db, departmentId, "Expense claim awaiting departmental review", `${assignment.department.name}: ${category} claim for ${claim.currency} ${amount.toLocaleString()} was submitted by ${user.firstName || user.email}.`);
  await db.auditLog.create({ data: { userId: user.id, action: "EXPENSE_CLAIM_SUBMITTED", entity: "StaffExpenseClaim", entityId: claim.id, metadataJson: JSON.stringify({ departmentId, amount, category }) } });
  revalidatePath("/control-centre/finance/claims");
}

export async function departmentReviewClaim(formData: FormData) {
  const { db, user } = await requireOperationalStaffUser("finance.claims.submit");
  const id = String(formData.get("id") || "");
  const decision = String(formData.get("decision") || "");
  const note = String(formData.get("note") || "").trim();
  if (!["APPROVE", "REJECT"].includes(decision)) throw new Error("Invalid departmental decision.");
  const claim = await db.staffExpenseClaim.findUnique({ where: { id }, include: { department: true } });
  if (!claim) throw new Error("Claim not found.");
  const head = await db.userDepartment.findUnique({ where: { userId_departmentId: { userId: user.id, departmentId: claim.departmentId } } });
  if (!head?.isHead && !user.roles.some((r: any) => r.role.code === "FINANCE")) throw new Error("Only the department head or Finance can review this claim.");
  const next = decision === "APPROVE" ? "FINANCE_REVIEW" : "REJECTED";
  await db.staffExpenseClaim.update({ where: { id }, data: { status: next, departmentNote: note || undefined, departmentReviewerId: user.id, departmentReviewedAt: new Date() } });
  await db.notification.create({ data: { userId: claim.requesterId, type: "FINANCE", title: next === "FINANCE_REVIEW" ? "Expense claim passed departmental review" : "Expense claim rejected", body: note || (next === "FINANCE_REVIEW" ? "Your claim has been forwarded to Finance." : "Your expense claim was not approved by the department.") } });
  await db.auditLog.create({ data: { userId: user.id, action: `EXPENSE_CLAIM_DEPARTMENT_${decision}`, entity: "StaffExpenseClaim", entityId: id, metadataJson: JSON.stringify({ note }) } });
  revalidatePath("/control-centre/finance/claims");
}

export async function financeUpdateClaim(formData: FormData) {
  const { db, user } = await requireOperationalStaffUser("finance.manage");
  const id = String(formData.get("id") || "");
  const status = String(formData.get("status") || "");
  const note = String(formData.get("note") || "").trim();
  const paymentReference = String(formData.get("paymentReference") || "").trim();
  if (!["APPROVED", "REJECTED", "DISBURSED"].includes(status)) throw new Error("Invalid Finance decision.");
  const claim = await db.staffExpenseClaim.findUnique({ where: { id } });
  if (!claim) throw new Error("Claim not found.");
  if (status === "APPROVED" && claim.status !== "FINANCE_REVIEW") throw new Error("Only claims that passed departmental review can be approved by Finance.");
  if (status === "REJECTED" && !["FINANCE_REVIEW", "APPROVED"].includes(claim.status)) throw new Error("This claim is not currently in a Finance decision state.");
  if (status === "DISBURSED" && claim.status !== "APPROVED") throw new Error("A claim must be approved before it can be disbursed.");
  if (status === "DISBURSED" && !paymentReference) throw new Error("A payout reference is required before marking a claim disbursed.");
  if (status === "DISBURSED") {
    await db.$transaction(async (tx: any) => {
      const budget = await tx.financeBudget.findFirst({ where: { departmentId: claim.departmentId, fiscalYear: new Date().getFullYear(), status: "APPROVED" } });
      if (!budget) throw new Error("No approved departmental budget exists for the current fiscal year.");
      const available = Number(budget.amount) - Number(budget.spent);
      if (available + 0.001 < Number(claim.amount)) throw new Error("The approved departmental budget does not have enough unspent balance for this claim.");
      await tx.financeBudget.update({ where: { id: budget.id }, data: { spent: { increment: claim.amount } } });
      await tx.staffExpenseClaim.update({ where: { id }, data: { status: "DISBURSED", financeNote: note || undefined, financeReviewerId: user.id, financeReviewedAt: new Date(), paymentReference, disbursedAt: new Date() } });
      await tx.auditLog.create({ data: { userId: user.id, action: "BUDGET_SPEND_POSTED", entity: "FinanceBudget", entityId: budget.id, metadataJson: JSON.stringify({ claimId: id, amount: Number(claim.amount), paymentReference }) } });
    });
  } else {
    await db.staffExpenseClaim.update({ where: { id }, data: { status: status as any, financeNote: note || undefined, financeReviewerId: user.id, financeReviewedAt: new Date(), paymentReference: paymentReference || undefined } });
  }
  await db.notification.create({ data: { userId: claim.requesterId, type: "FINANCE", title: `Expense claim ${status.toLowerCase()}`, body: status === "DISBURSED" ? `Your claim has been disbursed. Reference: ${paymentReference}.` : note || `Finance changed your claim status to ${status.toLowerCase()}.` } });
  await db.auditLog.create({ data: { userId: user.id, action: `EXPENSE_CLAIM_${status}`, entity: "StaffExpenseClaim", entityId: id, metadataJson: JSON.stringify({ note, paymentReference }) } });
  revalidatePath("/control-centre/finance/claims");
}
