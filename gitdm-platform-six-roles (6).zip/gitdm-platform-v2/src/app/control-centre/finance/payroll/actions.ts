"use server";
import { revalidatePath } from "next/cache";
import { requireOperationalStaffUser } from "@/lib/control-centre";
export async function createPayroll(formData:FormData){const{db,user}=await requireOperationalStaffUser("finance.payroll.manage");const userId=String(formData.get("userId")||""),periodLabel=String(formData.get("periodLabel")||"").trim(),gross=Number(formData.get("gross")),deductions=Number(formData.get("deductions")||0),payslipUrl=String(formData.get("payslipUrl")||"").trim();if(!userId||!periodLabel||!Number.isFinite(gross)||gross<0||!Number.isFinite(deductions)||deductions<0||deductions>gross)throw new Error("Valid staff member, period, gross pay and deductions are required.");const net=gross-deductions;const row=await db.payrollRecord.create({data:{userId,periodLabel,gross,deductions,net,currency:String(formData.get("currency")||"UGX"),payslipUrl:payslipUrl||undefined,status:"ISSUED"}});await db.notification.create({data:{userId,title:"Payslip issued",type:"FINANCE",body:`Your ${periodLabel} payslip is now available. Net pay: UGX ${net.toLocaleString()}.`}});await db.auditLog.create({data:{userId:user.id,action:"PAYROLL_ISSUED",entity:"PayrollRecord",entityId:row.id,metadataJson:JSON.stringify({staffUserId:userId,periodLabel,net})}});revalidatePath("/control-centre/finance/payroll");}

export async function markPayrollPaid(formData: FormData) {
  const { db, user } = await requireOperationalStaffUser("finance.payroll.manage");
  const id = String(formData.get("id") || "");
  const reference = String(formData.get("paymentReference") || "").trim();
  if (!id || !reference) throw new Error("A payroll payout reference is required.");
  const row = await db.payrollRecord.findUnique({ where: { id } });
  if (!row) throw new Error("Payroll record not found.");
  await db.payrollRecord.update({ where: { id }, data: { status: "PAID", paymentReference: reference, paidAt: new Date() } });
  await db.notification.create({ data: { userId: row.userId, type: "FINANCE", title: "Payroll payment recorded", body: `Your ${row.periodLabel} payroll has been marked paid. Reference: ${reference}.` } });
  await db.auditLog.create({ data: { userId: user.id, action: "PAYROLL_PAID", entity: "PayrollRecord", entityId: id, metadataJson: JSON.stringify({ reference }) } });
  revalidatePath("/control-centre/finance/payroll");
}
