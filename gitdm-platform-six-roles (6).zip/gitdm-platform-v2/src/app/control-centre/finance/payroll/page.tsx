import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ControlNav } from "@/components/ControlNav";
import { GITDM } from "@/lib/branding";
import { requireStaffUser } from "@/lib/control-centre";
import { createPayroll, markPayrollPaid } from "./actions";

export const dynamic = "force-dynamic";
export const metadata = { title: `Payroll | ${GITDM.shortName}` };

export default async function PayrollPage() {
  const { db, roleCodes, user } = await requireStaffUser("finance.payroll.view");
  const isFinance = roleCodes.includes("FINANCE");
  const staff = isFinance
    ? await db.user.findMany({
        where: {
          roles: { some: { role: { code: { notIn: ["STUDENT", "PARENT_GUARDIAN", "ALUMNI"] } } } },
          status: "ACTIVE",
        },
        orderBy: { email: "asc" },
        take: 500,
      })
    : [];
  const rows = await db.payrollRecord.findMany({
    where: isFinance ? {} : { userId: user.id },
    orderBy: { createdAt: "desc" },
    take: 300,
    include: { user: true },
  });

  return (
    <>
      <Header workspace="staff" />
      <ControlNav active="/control-centre/finance/payroll" />
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">Finance · Payroll</div>
            <h1>{isFinance ? "Payroll control" : "My payroll"}</h1>
            <p>
              {isFinance
                ? "Issue staff payroll records and retain the payslip reference in the institutional finance trail."
                : "View your issued payroll history and follow each payslip to its payment status."}
            </p>
          </div>
        </section>
        <section className="section">
          <div className="container">
            {isFinance ? (
              <div className="card" style={{ marginBottom: 28 }}>
                <h2>Issue payslip record</h2>
                <form action={createPayroll} className="grid grid-2">
                  <label>
                    Staff member
                    <select name="userId" required>
                      <option value="">Select staff</option>
                      {staff.map((s) => (
                        <option key={s.id} value={s.id}>
                          {[s.firstName, s.lastName].filter(Boolean).join(" ") || s.email}
                        </option>
                      ))}
                    </select>
                  </label>
                  <label>Period<input name="periodLabel" placeholder="September 2026" required /></label>
                  <label>Gross pay<input name="gross" type="number" min="0" step="0.01" required /></label>
                  <label>Deductions<input name="deductions" type="number" min="0" step="0.01" defaultValue="0" required /></label>
                  <label>Currency<select name="currency"><option>UGX</option><option>USD</option></select></label>
                  <label>Payslip URL<input name="payslipUrl" placeholder="Optional secure payslip document" /></label>
                  <button className="btn btn-primary">Issue payslip</button>
                </form>
              </div>
            ) : null}
            <div className="table-wrap">
              <table className="data">
                <thead><tr><th>Period</th><th>{isFinance ? "Staff" : "Record"}</th><th>Gross</th><th>Deductions</th><th>Net</th><th>Status</th><th>Payslip</th></tr></thead>
                <tbody>
                  {rows.map((r) => (
                    <tr key={r.id}>
                      <td>{r.periodLabel}</td>
                      <td>{isFinance ? ([r.user.firstName, r.user.lastName].filter(Boolean).join(" ") || r.user.email) : "Personal payroll"}</td>
                      <td>{r.currency} {Number(r.gross).toLocaleString()}</td>
                      <td>{r.currency} {Number(r.deductions).toLocaleString()}</td>
                      <td><strong>{r.currency} {Number(r.net).toLocaleString()}</strong></td>
                      <td>{r.status}</td>
                      <td>{r.payslipUrl ? <a href={r.payslipUrl} target="_blank" rel="noreferrer">Open</a> : "—"}{isFinance && r.status === "ISSUED" ? <form action={markPayrollPaid} className="actions" style={{marginTop:6}}><input type="hidden" name="id" value={r.id}/><input name="paymentReference" placeholder="Payout ref" required/><button className="btn btn-primary btn-sm">Mark paid</button></form> : null}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
