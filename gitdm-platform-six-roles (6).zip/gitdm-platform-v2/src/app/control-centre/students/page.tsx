import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ControlNav } from "@/components/ControlNav";
import { GITDM } from "@/lib/branding";
import { requireStaffUser } from "@/lib/control-centre";

export const dynamic = "force-dynamic";
export const metadata = { title: `Student Register | ${GITDM.shortName}` };

export default async function StudentsPage() {
  const { db } = await requireStaffUser("students.view");
  const students = await db.user.findMany({
    where: { enrollments: { some: {} } },
    orderBy: { createdAt: "desc" },
    take: 300,
    include: {
      enrollments: {
        include: { programme: true, period: true },
        orderBy: { createdAt: "desc" },
        take: 1,
      },
    },
  });

  return (
    <>
      <Header workspace="staff" />
      <ControlNav active="/control-centre/students" />
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">Registry · Student services</div>
            <h1>Student register</h1>
            <p>
              Staff see the institutional student register here — not the student dashboard.
              Open an individual record to review that learner's academic, admissions and finance state.
            </p>
          </div>
        </section>
        <section className="section">
          <div className="container">
            <div className="table-wrap">
              <table className="data">
                <thead>
                  <tr><th>Student</th><th>Status</th><th>Programme</th><th>Period</th><th>Enrolment</th><th>Portal</th></tr>
                </thead>
                <tbody>
                  {students.map((s) => {
                    const e = s.enrollments[0];
                    return (
                      <tr key={s.id}>
                        <td><strong>{[s.firstName, s.lastName].filter(Boolean).join(" ") || s.email}</strong><br/><span className="muted">{s.email}</span></td>
                        <td>{s.status}</td>
                        <td>{e?.programme.name || "Not enrolled"}</td>
                        <td>{e?.period?.name || "—"}</td>
                        <td>{e?.status || "Pending"}</td>
                        <td><Link className="btn btn-outline-dark btn-sm" href={`/control-centre/students/${s.id}`}>Open record</Link></td>
                      </tr>
                    );
                  })}
                  {students.length === 0 ? <tr><td colSpan={6}>No student accounts have been provisioned yet.</td></tr> : null}
                </tbody>
              </table>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
