import Link from "next/link";
import { notFound } from "next/navigation";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ControlNav } from "@/components/ControlNav";
import { GITDM } from "@/lib/branding";
import { requireStaffUser } from "@/lib/control-centre";

export const dynamic = "force-dynamic";

export default async function StudentRecordPage({ params }: { params: Promise<{ userId: string }> }) {
  const { db } = await requireStaffUser("students.view");
  const { userId } = await params;
  // Keep the base User query independent from optional relations. This is
  // intentionally more resilient to Prisma Client/schema drift during staged
  // deployments: each institutional relation is loaded from its own model,
  // so one stale generated relation cannot collapse the entire staff record.
  const student = await db.user.findFirst({
    where: { id: userId, enrollments: { some: {} } },
  });
  if (!student) notFound();

  const [profile, applications, enrollments] = await Promise.all([
    db.profile.findUnique({ where: { userId: student.id } }),
    db.application.findMany({
      where: { applicantId: student.id },
      include: { programme: true },
      orderBy: { submittedAt: "desc" },
    }),
    db.enrollment.findMany({
      where: { userId: student.id },
      include: { programme: true, period: true, invoices: { orderBy: { dueAt: "asc" } } },
      orderBy: { createdAt: "desc" },
    }),
  ]);

  const name = [student.firstName, student.lastName].filter(Boolean).join(" ") || student.email;
  const latest = enrollments[0];
  const invoices = enrollments.flatMap((e) => e.invoices);
  const paid = invoices.reduce((sum, i) => sum + Number(i.amountPaid), 0);
  const billed = invoices.reduce((sum, i) => sum + Number(i.amount), 0);
  const paidPercent = billed > 0 ? Math.min(100, Math.round((paid / billed) * 1000) / 10) : 0;

  return (
    <>
      <Header workspace="staff" />
      <ControlNav active="/control-centre/students" />
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="actions" style={{ marginBottom: 16 }}>
              <Link href="/control-centre/students" className="btn btn-outline-dark btn-sm">← Student register</Link>
            </div>
            <div className="eyebrow">Student institutional record</div>
            <h1>{name}</h1>
            <p>{student.email} · {student.status} · Read-only staff view</p>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className="grid grid-3" style={{ marginBottom: 28 }}>
              <div className="panel"><div className="eyebrow">Programme</div><h3>{latest?.programme.name || "Not enrolled"}</h3><p>{latest?.period?.name || "No active period"}</p></div>
              <div className="panel"><div className="eyebrow">Campus access</div><h3>{latest?.accessLevel || "NONE"}</h3><p>{latest?.status || "No enrolment"}</p></div>
              <div className="panel"><div className="eyebrow">Fee progress</div><h3>{paidPercent}%</h3><p>Based on recorded invoices for this learner.</p></div>
            </div>

            <div className="grid grid-2">
              <div className="panel">
                <div className="eyebrow">Identity</div>
                <h2>{name}</h2>
                <p><strong>Email:</strong> {student.email}</p>
                <p><strong>Phone:</strong> {student.phone || "—"}</p>
                <p><strong>Country:</strong> {profile?.country || "—"}</p>
                <p><strong>Created:</strong> {student.createdAt.toISOString().slice(0, 10)}</p>
              </div>
              <div className="panel">
                <div className="eyebrow">Admissions</div>
                {applications.length ? applications.map((a) => (
                  <div key={a.id} className="staff-notice" style={{ marginTop: 10 }}>
                    <strong>{a.programme.name}</strong><p>{a.status.replaceAll("_", " ")}{a.submittedAt ? ` · ${a.submittedAt.toISOString().slice(0, 10)}` : ""}</p>
                  </div>
                )) : <p>No applications on record.</p>}
              </div>
            </div>

            <div className="panel" style={{ marginTop: 28 }}>
              <div className="eyebrow">Enrolments & finance</div>
              <div className="table-wrap" style={{ marginTop: 16 }}>
                <table className="data">
                  <thead><tr><th>Programme</th><th>Period</th><th>Status</th><th>Access</th><th>Billed</th><th>Paid</th></tr></thead>
                  <tbody>{enrollments.map((e) => {
                    const eBilled = e.invoices.reduce((sum, i) => sum + Number(i.amount), 0);
                    const ePaid = e.invoices.reduce((sum, i) => sum + Number(i.amountPaid), 0);
                    return <tr key={e.id}><td>{e.programme.name}</td><td>{e.period?.name || "—"}</td><td>{e.status}</td><td>{e.accessLevel}</td><td>{e.period?.currency || e.invoices[0]?.currency || "UGX"} {eBilled.toLocaleString()}</td><td>{e.period?.currency || e.invoices[0]?.currency || "UGX"} {ePaid.toLocaleString()}</td></tr>;
                  })}</tbody>
                </table>
              </div>
            </div>

            <div className="panel" style={{ marginTop: 28 }}>
              <div className="eyebrow">Staff boundary</div>
              <h3>Institutional view, not student impersonation</h3>
              <p>
                This page deliberately keeps staff in the Control Centre. Staff and directors do not inherit the
                student's navigation, dashboard or private action controls. When a future support workflow needs a
                true student-session preview, it can be added as a separately audited read-only mode.
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
