import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { GITDM } from "@/lib/branding";
import { requireStaffUser } from "@/lib/control-centre";
import { CreateProgrammeForm } from "./CreateProgrammeForm";
import { ACTIVE_PROGRAMME_CODES } from "@/lib/current-catalogue";

export const metadata = {
  title: `Programmes | Control Centre | ${GITDM.shortName}`,
};

export const dynamic = "force-dynamic";

export default async function ControlCentreProgrammesPage() {
  const { db, roleCodes } = await requireStaffUser("programmes.view");
  const canManage = roleCodes.includes("ACADEMIC_DIRECTOR");

  const programmes = await db.programme.findMany({
    where: { code: { in: [...ACTIVE_PROGRAMME_CODES] } },
    orderBy: { createdAt: "desc" },
    include: {
      periods: { orderBy: { sequence: "asc" } },
      rules: true,
      _count: { select: { applications: true, enrollments: true, courses: true } },
    },
  });

  return (
    <>
      <Header workspace="staff" />
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">Control Centre</div>
            <h1>Programmes</h1>
            <p>
              Academic programmes configured in the system. The flagship certificate and
              period fees come from the foundation seed; the no-code builder lets authorised academic staff configure the programme, rules, periods, courses, faculty, modules and lessons without editing code.
            </p>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <CreateProgrammeForm canManage={canManage} />
            <div className="actions" style={{ marginBottom: 24 }}>
              <Link href="/control-centre" className="btn btn-outline-dark btn-sm">
                ← Back to Control Centre
              </Link>
            </div>

            {programmes.length === 0 ? (
              <div className="panel">
                <span className="badge warn">No programmes</span>
                <p style={{ marginTop: 12 }}>
                  The database has no programmes yet. Run the seed on Vercel (or{" "}
                  <code>npm run db:seed</code> with <code>DATABASE_URL</code>) to create the
                  Certificate in Financial Markets, Trading and Derivatives and three
                  trimesters at UGX 600,000.
                </p>
              </div>
            ) : (
              <div style={{ display: "grid", gap: 24 }}>
                {programmes.map((p) => (
                  <article key={p.id} className="card" style={{ padding: 28 }}>
                    <div className="meta" style={{ marginBottom: 12 }}>
                      <span className="chip chip-accent">{p.status}</span>
                      <span className="chip">{p.code}</span>
                      <span className="chip">{p.durationMonths} months</span>
                    </div>
                    <h2 style={{ marginTop: 0 }}>{p.name}</h2>
                    <div className="actions" style={{ marginBottom: 12 }}><Link href={`/control-centre/programmes/${p.id}`} className="btn btn-primary btn-sm">Open programme builder</Link></div>
                    {p.description ? <p>{p.description}</p> : null}
                    <p>
                      Application fee:{" "}
                      <strong>
                        {p.currency} {Number(p.applicationFee).toLocaleString()}
                      </strong>
                      {" · "}
                      {p._count.courses} courses · {p._count.enrollments} enrolments ·{" "}
                      {p._count.applications} applications
                    </p>

                    {p.periods.length > 0 ? (
                      <div className="table-wrap" style={{ marginTop: 16 }}>
                        <table className="data">
                          <thead>
                            <tr>
                              <th>Period</th>
                              <th>Fee</th>
                              <th>Status</th>
                            </tr>
                          </thead>
                          <tbody>
                            {p.periods.map((period) => (
                              <tr key={period.id}>
                                <td>
                                  {period.name} (#{period.sequence})
                                </td>
                                <td>
                                  {period.currency}{" "}
                                  {Number(period.feeAmount).toLocaleString()}
                                </td>
                                <td>{period.status}</td>
                              </tr>
                            ))}
                          </tbody>
                        </table>
                      </div>
                    ) : null}

                    {p.rules ? (
                      <div className="table-wrap" style={{ marginTop: 16 }}>
                        <table className="data">
                          <thead>
                            <tr>
                              <th>Academic rule</th>
                              <th>Value</th>
                            </tr>
                          </thead>
                          <tbody>
                            <tr>
                              <td>Pass mark</td>
                              <td>{Number(p.rules.passMarkPercent)}%</td>
                            </tr>
                            <tr>
                              <td>Attendance minimum</td>
                              <td>{Number(p.rules.attendanceMinimumPercent)}%</td>
                            </tr>
                            <tr>
                              <td>Assignment / Quiz / Exam weights</td>
                              <td>
                                {Number(p.rules.assignmentWeightPercent)}% /{" "}
                                {Number(p.rules.quizWeightPercent)}% /{" "}
                                {Number(p.rules.examWeightPercent)}%
                              </td>
                            </tr>
                            <tr>
                              <td>Exam attempts</td>
                              <td>{p.rules.examAttemptsAllowed}</td>
                            </tr>
                            <tr>
                              <td>Campus unlock (fee %)</td>
                              <td>{Number(p.rules.activationPaymentPercent)}%</td>
                            </tr>
                            <tr>
                              <td>Exam eligibility (fee %)</td>
                              <td>{Number(p.rules.examPaymentClearancePercent)}%</td>
                            </tr>
                          </tbody>
                        </table>
                      </div>
                    ) : null}
                  </article>
                ))}
              </div>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
