"use client";
import { createProgramme } from "./actions";

export function CreateProgrammeForm({ canManage }: { canManage: boolean }) {
  if (!canManage) return null;
  return <details className="panel" style={{ marginBottom: 24 }}>
    <summary style={{ cursor: "pointer", fontWeight: 700 }}>+ Create a new programme</summary>
    <form action={createProgramme} style={{ display: "grid", gap: 14, marginTop: 18 }}>
      <div className="grid grid-3">
        <label>Programme code<input name="code" placeholder="GITDM-CFMTD" required /></label>
        <label>Programme name<input name="name" placeholder="Certificate in Financial Markets..." required /></label>
        <label>Short name<input name="shortName" placeholder="CFMTD" /></label>
        <label>Duration (months)<input name="durationMonths" type="number" min="1" defaultValue="12" /></label>
        <label>Application fee<input name="applicationFee" type="number" min="0" defaultValue="10000" /></label>
        <label>Currency<input name="currency" defaultValue="UGX" /></label>
      </div>
      <label>Description<textarea name="description" rows={3} placeholder="Programme purpose and scope" /></label>
      <div style={{ display: "flex", gap: 18, flexWrap: "wrap" }}>
        <label><input name="requiresApplication" type="checkbox" defaultChecked /> Requires application</label>
        <label><input name="requiresAdmission" type="checkbox" defaultChecked /> Requires admission</label>
      </div>
      <button className="btn btn-primary" type="submit">Create programme</button>
    </form>
  </details>;
}
