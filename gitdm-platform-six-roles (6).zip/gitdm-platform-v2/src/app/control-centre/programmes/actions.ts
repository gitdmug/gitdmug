"use server";

import { revalidatePath } from "next/cache";
import { requireStaffUser } from "@/lib/control-centre";
import { ACTIVE_PROGRAMME_CODES } from "@/lib/current-catalogue";

function text(formData: FormData, key: string, fallback = "") {
  return String(formData.get(key) ?? fallback).trim();
}

function number(formData: FormData, key: string, fallback = 0) {
  const value = Number(formData.get(key));
  return Number.isFinite(value) ? value : fallback;
}

function bool(formData: FormData, key: string) {
  return formData.get(key) === "on" || formData.get(key) === "true";
}

function programmePath(id: string) {
  return `/control-centre/programmes/${id}`;
}

export async function createProgramme(formData: FormData) {
  const { db, user } = await requireStaffUser("programmes.manage");
  const code = text(formData, "code").toUpperCase();
  const name = text(formData, "name");
  if (!code || !name) throw new Error("Programme code and name are required.");

  const programme = await db.programme.create({
    data: {
      code,
      name,
      shortName: text(formData, "shortName") || null,
      description: text(formData, "description") || null,
      durationMonths: number(formData, "durationMonths", 12),
      applicationFee: number(formData, "applicationFee", 0),
      currency: text(formData, "currency", "UGX").toUpperCase(),
      status: "DRAFT",
      requiresApplication: bool(formData, "requiresApplication"),
      requiresAdmission: bool(formData, "requiresAdmission"),
      rules: { create: {} },
    },
  });

  await db.auditLog.create({
    data: {
      userId: user.id,
      action: "PROGRAMME_CREATED",
      entity: "Programme",
      entityId: programme.id,
      metadataJson: JSON.stringify({ code, name }),
    },
  });

  revalidatePath("/control-centre/programmes");
}

export async function updateProgramme(formData: FormData) {
  const { db, user } = await requireStaffUser("programmes.manage");
  const id = text(formData, "programmeId");
  if (!id) throw new Error("Programme ID is required.");

  const status = text(formData, "status");
  if (!['DRAFT', 'PUBLISHED', 'ARCHIVED'].includes(status)) throw new Error("Invalid programme status.");

  await db.programme.update({
    where: { id },
    data: {
      code: text(formData, "code").toUpperCase(),
      name: text(formData, "name"),
      shortName: text(formData, "shortName") || null,
      description: text(formData, "description") || null,
      durationMonths: number(formData, "durationMonths", 12),
      applicationFee: number(formData, "applicationFee", 0),
      currency: text(formData, "currency", "UGX").toUpperCase(),
      status: status as "DRAFT" | "PUBLISHED" | "ARCHIVED",
      requiresApplication: bool(formData, "requiresApplication"),
      requiresAdmission: bool(formData, "requiresAdmission"),
    },
  });

  await db.auditLog.create({
    data: { userId: user.id, action: "PROGRAMME_UPDATED", entity: "Programme", entityId: id },
  });
  revalidatePath("/control-centre/programmes");
  revalidatePath(programmePath(id));
}

export async function saveRules(formData: FormData) {
  const { db, user } = await requireStaffUser("programmes.manage");
  const programmeId = text(formData, "programmeId");
  if (!programmeId) throw new Error("Programme ID is required.");

  const values = {
    minimumEducation: text(formData, "minimumEducation", "Secondary education / Uganda S4 equivalent"),
    passMarkPercent: number(formData, "passMarkPercent", 50),
    attendanceMinimumPercent: number(formData, "attendanceMinimumPercent", 70),
    assignmentWeightPercent: number(formData, "assignmentWeightPercent", 30),
    quizWeightPercent: number(formData, "quizWeightPercent", 20),
    examWeightPercent: number(formData, "examWeightPercent", 50),
    examAttemptsAllowed: number(formData, "examAttemptsAllowed", 3),
    activationPaymentPercent: number(formData, "activationPaymentPercent", 60),
    examPaymentClearancePercent: number(formData, "examPaymentClearancePercent", 100),
    allowsCourseRepeat: bool(formData, "allowsCourseRepeat"),
    academicTeamDecidesResit: bool(formData, "academicTeamDecidesResit"),
    certificateMaxMonths: number(formData, "certificateMaxMonths", 2),
    requiresIdentityDocument: bool(formData, "requiresIdentityDocument"),
    requiresEducationDocument: bool(formData, "requiresEducationDocument"),
    interviewByAdmissions: bool(formData, "interviewByAdmissions"),
  };

  const weightTotal = values.assignmentWeightPercent + values.quizWeightPercent + values.examWeightPercent;
  if (weightTotal !== 100) throw new Error("Assignment, quiz and exam weights must total exactly 100%.");

  await db.programmeRule.upsert({ where: { programmeId }, update: values, create: { programmeId, ...values } });
  await db.auditLog.create({ data: { userId: user.id, action: "PROGRAMME_RULES_UPDATED", entity: "ProgrammeRule", entityId: programmeId } });
  revalidatePath(programmePath(programmeId));
}

export async function addPeriod(formData: FormData) {
  const { db, user } = await requireStaffUser("programmes.manage");
  const programmeId = text(formData, "programmeId");
  const name = text(formData, "name");
  if (!programmeId || !name) throw new Error("Programme and period name are required.");
  const existing = await db.academicPeriod.findFirst({ where: { programmeId }, orderBy: { sequence: "desc" }, select: { sequence: true } });
  const sequence = existing ? existing.sequence + 1 : 1;
  const period = await db.academicPeriod.create({
    data: { programmeId, name, sequence, feeAmount: number(formData, "feeAmount", 0), currency: text(formData, "currency", "UGX").toUpperCase(), status: "PLANNED" },
  });
  await db.auditLog.create({ data: { userId: user.id, action: "ACADEMIC_PERIOD_CREATED", entity: "AcademicPeriod", entityId: period.id, metadataJson: JSON.stringify({ programmeId, sequence }) } });
  revalidatePath(programmePath(programmeId));
}

export async function updatePeriod(formData: FormData) {
  const { db, user } = await requireStaffUser("programmes.manage");
  const id = text(formData, "periodId");
  const programmeId = text(formData, "programmeId");
  const status = text(formData, "status");
  if (!['PLANNED', 'OPEN', 'CLOSED'].includes(status)) throw new Error("Invalid period status.");
  await db.academicPeriod.update({ where: { id }, data: { name: text(formData, "name"), feeAmount: number(formData, "feeAmount", 0), currency: text(formData, "currency", "UGX").toUpperCase(), status: status as "PLANNED" | "OPEN" | "CLOSED" } });
  await db.auditLog.create({ data: { userId: user.id, action: "ACADEMIC_PERIOD_UPDATED", entity: "AcademicPeriod", entityId: id } });
  revalidatePath(programmePath(programmeId));
}

export async function addCourse(formData: FormData) {
  const { db, user } = await requireStaffUser("courses.manage");
  const programmeId = text(formData, "programmeId");
  const code = text(formData, "code").toUpperCase();
  const title = text(formData, "title");
  if (!programmeId || !code || !title) throw new Error("Programme, course code and title are required.");
  const programme = await db.programme.findUnique({ where: { id: programmeId }, select: { code: true } });
  if (!programme || !ACTIVE_PROGRAMME_CODES.includes(programme.code as any)) throw new Error("Only the three current intake programmes may receive courses right now.");
  const max = await db.course.findFirst({ where: { programmeId }, orderBy: { orderIndex: "desc" }, select: { orderIndex: true } });
  const durationMonths = number(formData, "durationMonths", 1);
  const sessionsPerWeek = number(formData, "sessionsPerWeek", durationMonths === 12 ? 0 : durationMonths === 1 ? 3 : 2);
  if (![1, 3, 12].includes(durationMonths)) throw new Error("Course duration must be 1, 3 or 12 months.");
  const course = await db.course.create({ data: { programmeId, code, title, description: text(formData, "description") || null, orderIndex: (max?.orderIndex ?? -1) + 1, durationMonths, sessionsPerWeek, catalogueVisible: true } });
  await db.auditLog.create({ data: { userId: user.id, action: "COURSE_CREATED", entity: "Course", entityId: course.id, metadataJson: JSON.stringify({ programmeId, code }) } });
  revalidatePath(programmePath(programmeId));
}

export async function updateCourse(formData: FormData) {
  const { db, user } = await requireStaffUser("courses.manage");
  const id = text(formData, "courseId");
  const programmeId = text(formData, "programmeId");
  const durationMonths = number(formData, "durationMonths", 1);
  const sessionsPerWeek = number(formData, "sessionsPerWeek", durationMonths === 12 ? 0 : durationMonths === 1 ? 3 : 2);
  if (![1, 3, 12].includes(durationMonths)) throw new Error("Course duration must be 1, 3 or 12 months.");
  if (sessionsPerWeek < 0 || sessionsPerWeek > 7) throw new Error("Sessions per week must be between 1 and 7.");
  await db.course.update({ where: { id }, data: { code: text(formData, "code").toUpperCase(), title: text(formData, "title"), description: text(formData, "description") || null, orderIndex: number(formData, "orderIndex", 0), durationMonths, sessionsPerWeek, catalogueVisible: bool(formData, "catalogueVisible"), published: bool(formData, "published") } });
  await db.auditLog.create({ data: { userId: user.id, action: "COURSE_UPDATED", entity: "Course", entityId: id } });
  revalidatePath(programmePath(programmeId));
}

export async function linkCoursePeriod(formData: FormData) {
  const { db, user } = await requireStaffUser("courses.manage");
  const programmeId = text(formData, "programmeId");
  const courseId = text(formData, "courseId");
  const periodId = text(formData, "periodId");
  const action = text(formData, "action");
  if (action === "remove") await db.periodCourse.delete({ where: { periodId_courseId: { periodId, courseId } } });
  else await db.periodCourse.upsert({ where: { periodId_courseId: { periodId, courseId } }, update: { required: bool(formData, "required") }, create: { periodId, courseId, required: bool(formData, "required") } });
  await db.auditLog.create({ data: { userId: user.id, action: `COURSE_PERIOD_${action.toUpperCase()}`, entity: "PeriodCourse", entityId: `${periodId}:${courseId}` } });
  revalidatePath(programmePath(programmeId));
}

export async function addModule(formData: FormData) {
  const { db, user } = await requireStaffUser("courses.manage");
  const courseId = text(formData, "courseId");
  const programmeId = text(formData, "programmeId");
  const title = text(formData, "title");
  const max = await db.courseModule.findFirst({ where: { courseId }, orderBy: { orderIndex: "desc" }, select: { orderIndex: true } });
  const module = await db.courseModule.create({ data: { courseId, title, description: text(formData, "description") || null, orderIndex: (max?.orderIndex ?? -1) + 1 } });
  await db.auditLog.create({ data: { userId: user.id, action: "COURSE_MODULE_CREATED", entity: "CourseModule", entityId: module.id } });
  revalidatePath(programmePath(programmeId));
}

export async function updateModule(formData: FormData) {
  const { db, user } = await requireStaffUser("courses.manage");
  const id = text(formData, "moduleId");
  const programmeId = text(formData, "programmeId");
  await db.courseModule.update({ where: { id }, data: { title: text(formData, "title"), description: text(formData, "description") || null, orderIndex: number(formData, "orderIndex", 0), published: bool(formData, "published") } });
  await db.auditLog.create({ data: { userId: user.id, action: "COURSE_MODULE_UPDATED", entity: "CourseModule", entityId: id } });
  revalidatePath(programmePath(programmeId));
}

export async function addLesson(formData: FormData) {
  const { db, user } = await requireStaffUser("lessons.manage");
  const moduleId = text(formData, "moduleId");
  const programmeId = text(formData, "programmeId");
  const title = text(formData, "title");
  const type = text(formData, "type");
  if (!['VIDEO', 'ARTICLE', 'DOCUMENT', 'LIVE_SESSION', 'EXTERNAL', 'RESOURCE'].includes(type)) throw new Error("Invalid lesson type.");
  const max = await db.lesson.findFirst({ where: { moduleId }, orderBy: { orderIndex: "desc" }, select: { orderIndex: true } });
  const lesson = await db.lesson.create({ data: { moduleId, title, type: type as "VIDEO" | "ARTICLE" | "DOCUMENT" | "LIVE_SESSION" | "EXTERNAL" | "RESOURCE", content: text(formData, "content") || null, videoUrl: text(formData, "videoUrl") || null, durationMinutes: number(formData, "durationMinutes", 0) || null, orderIndex: (max?.orderIndex ?? -1) + 1, required: bool(formData, "required") } });
  await db.auditLog.create({ data: { userId: user.id, action: "LESSON_CREATED", entity: "Lesson", entityId: lesson.id } });
  revalidatePath(programmePath(programmeId));
}

export async function updateLesson(formData: FormData) {
  const { db, user } = await requireStaffUser("lessons.manage");
  const id = text(formData, "lessonId");
  const programmeId = text(formData, "programmeId");
  const type = text(formData, "type");
  if (!['VIDEO', 'ARTICLE', 'DOCUMENT', 'LIVE_SESSION', 'EXTERNAL', 'RESOURCE'].includes(type)) throw new Error("Invalid lesson type.");
  await db.lesson.update({ where: { id }, data: { title: text(formData, "title"), type: type as "VIDEO" | "ARTICLE" | "DOCUMENT" | "LIVE_SESSION" | "EXTERNAL" | "RESOURCE", content: text(formData, "content") || null, videoUrl: text(formData, "videoUrl") || null, durationMinutes: number(formData, "durationMinutes", 0) || null, orderIndex: number(formData, "orderIndex", 0), required: bool(formData, "required"), published: bool(formData, "published") } });
  await db.auditLog.create({ data: { userId: user.id, action: "LESSON_UPDATED", entity: "Lesson", entityId: id } });
  revalidatePath(programmePath(programmeId));
}

export async function assignFaculty(formData: FormData) {
  const { db, user } = await requireStaffUser("courses.manage");
  const courseId = text(formData, "courseId");
  const programmeId = text(formData, "programmeId");
  const facultyId = text(formData, "facultyId");
  const action = text(formData, "action");
  if (action === "remove") await db.courseFaculty.delete({ where: { courseId_userId: { courseId, userId: facultyId } } });
  else await db.courseFaculty.upsert({ where: { courseId_userId: { courseId, userId: facultyId } }, update: { isLead: bool(formData, "isLead") }, create: { courseId, userId: facultyId, isLead: bool(formData, "isLead") } });
  await db.auditLog.create({ data: { userId: user.id, action: `COURSE_FACULTY_${action.toUpperCase()}`, entity: "CourseFaculty", entityId: `${courseId}:${facultyId}` } });
  revalidatePath(programmePath(programmeId));
}
