import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ControlNav } from "@/components/ControlNav";
import { GITDM } from "@/lib/branding";
import { ACTIVE_PROGRAMME_CODES, ACTIVE_COURSE_CODES } from "@/lib/current-catalogue";
import { requireStaffUser } from "@/lib/control-centre";
import { ProgrammeBuilderForms } from "./ProgrammeBuilderForms";

export const dynamic = "force-dynamic";
export const metadata = { title: `Programme Builder | ${GITDM.shortName}` };

export default async function ProgrammeBuilderPage({ params }: { params: Promise<{ programmeId: string }> }) {
  const { programmeId } = await params;
  const { db, roleCodes } = await requireStaffUser("programmes.view");
  const canManage = roleCodes.includes("ACADEMIC_DIRECTOR");
  const programme = await db.programme.findFirst({
    where: { id: programmeId, code: { in: [...ACTIVE_PROGRAMME_CODES] } },
    include: {
      rules: true,
      periods: { orderBy: { sequence: "asc" }, include: { courseLinks: { where: { course: { code: { in: [...ACTIVE_COURSE_CODES] } } }, include: { course: true } } } },
      courses: { where: { code: { in: [...ACTIVE_COURSE_CODES] } }, orderBy: { orderIndex: "asc" }, include: { modules: { orderBy: { orderIndex: "asc" }, include: { lessons: { orderBy: { orderIndex: "asc" } } } }, faculty: { include: { user: { select: { id: true, firstName: true, lastName: true, email: true } } } }, periodLinks: true } },
    },
  });
  if (!programme) return <><Header workspace="staff" /><ControlNav active="/control-centre/programmes" /><main><section className="section"><div className="container"><div className="panel">Programme not found.</div></div></section></main><Footer /></>;
  const faculty = await db.user.findMany({ where: { roles: { some: { role: { code: { in: ["LECTURER", "ONLINE_INSTRUCTOR"] } } } }, status: "ACTIVE" }, orderBy: [{ lastName: "asc" }, { firstName: "asc" }], select: { id: true, firstName: true, lastName: true, email: true } });
  const rules = programme.rules ?? { minimumEducation: "Secondary education / Uganda S4 equivalent", passMarkPercent: 50, attendanceMinimumPercent: 70, assignmentWeightPercent: 30, quizWeightPercent: 20, examWeightPercent: 50, examAttemptsAllowed: 3, activationPaymentPercent: 60, examPaymentClearancePercent: 100, allowsCourseRepeat: true, academicTeamDecidesResit: true, certificateMaxMonths: 2, requiresIdentityDocument: true, requiresEducationDocument: true, interviewByAdmissions: true };
  return <>
    <Header workspace="staff" /><ControlNav active="/control-centre/programmes" />
    <main>
      <section className="page-hero"><div className="container"><div className="eyebrow">Academic Directorate · No-code builder</div><h1>{programme.name}</h1><p>{programme.code} · {programme.durationMonths} months · {programme.status}</p></div></section>
      <section className="section"><div className="container">
        <div className="actions" style={{ marginBottom: 24 }}><Link href="/control-centre/programmes" className="btn btn-outline-dark btn-sm">← All programmes</Link></div>
        {!canManage ? <div className="panel" style={{ marginBottom: 24 }}><strong>Read-only view.</strong> Your role can inspect programme configuration, but only authorised academic management roles can change it.</div> : null}
        <ProgrammeBuilderForms programme={programme} rules={rules} periods={programme.periods} courses={programme.courses} faculty={faculty} canManage={canManage} />
      </div></section>
    </main><Footer />
  </>;
}
