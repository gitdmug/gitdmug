import { updateProgramme, saveRules, addPeriod, updatePeriod, addCourse, updateCourse, linkCoursePeriod, addModule, updateModule, addLesson, updateLesson, assignFaculty } from "../actions";

type AnyProgramme = any;
const money = (n: unknown) => Number(n ?? 0).toLocaleString();

export function ProgrammeBuilderForms({ programme, rules, periods, courses, faculty, canManage }: { programme: AnyProgramme; rules: AnyProgramme; periods: AnyProgramme[]; courses: AnyProgramme[]; faculty: AnyProgramme[]; canManage: boolean }) {
  return <div style={{ display: "grid", gap: 28 }}>
    <section className="panel">
      <div className="eyebrow">01 · Programme identity</div><h2>Programme settings</h2>
      <form action={updateProgramme} style={{ display: "grid", gap: 14 }}>
        <input type="hidden" name="programmeId" value={programme.id} />
        <div className="grid grid-3">
          <label>Code<input name="code" defaultValue={programme.code} disabled={!canManage} required /></label>
          <label>Name<input name="name" defaultValue={programme.name} disabled={!canManage} required /></label>
          <label>Short name<input name="shortName" defaultValue={programme.shortName ?? ""} disabled={!canManage} /></label>
          <label>Duration<input name="durationMonths" type="number" min="1" defaultValue={programme.durationMonths} disabled={!canManage} /></label>
          <label>Application fee<input name="applicationFee" type="number" min="0" defaultValue={Number(programme.applicationFee)} disabled={!canManage} /></label>
          <label>Currency<input name="currency" defaultValue={programme.currency} disabled={!canManage} /></label>
          <label>Status<select name="status" defaultValue={programme.status} disabled={!canManage}><option value="DRAFT">Draft</option><option value="PUBLISHED">Published</option><option value="ARCHIVED">Archived</option></select></label>
        </div>
        <label>Description<textarea name="description" rows={3} defaultValue={programme.description ?? ""} disabled={!canManage} /></label>
        <div style={{ display: "flex", gap: 18, flexWrap: "wrap" }}><label><input name="requiresApplication" type="checkbox" defaultChecked={programme.requiresApplication} disabled={!canManage} /> Requires application</label><label><input name="requiresAdmission" type="checkbox" defaultChecked={programme.requiresAdmission} disabled={!canManage} /> Requires admission</label></div>
        {canManage ? <button className="btn btn-primary" type="submit">Save programme</button> : null}
      </form>
    </section>

    <section className="panel">
      <div className="eyebrow">02 · Academic rules</div><h2>Rules that govern this programme</h2>
      <form action={saveRules} style={{ display: "grid", gap: 14 }}>
        <input type="hidden" name="programmeId" value={programme.id} />
        <div className="grid grid-3">
          <label>Minimum education<input name="minimumEducation" defaultValue={rules.minimumEducation} disabled={!canManage} /></label>
          <label>Pass mark %<input name="passMarkPercent" type="number" min="0" max="100" defaultValue={Number(rules.passMarkPercent)} disabled={!canManage} /></label>
          <label>Attendance minimum %<input name="attendanceMinimumPercent" type="number" min="0" max="100" defaultValue={Number(rules.attendanceMinimumPercent)} disabled={!canManage} /></label>
          <label>Assignment weight %<input name="assignmentWeightPercent" type="number" min="0" max="100" defaultValue={Number(rules.assignmentWeightPercent)} disabled={!canManage} /></label>
          <label>Quiz weight %<input name="quizWeightPercent" type="number" min="0" max="100" defaultValue={Number(rules.quizWeightPercent)} disabled={!canManage} /></label>
          <label>Exam weight %<input name="examWeightPercent" type="number" min="0" max="100" defaultValue={Number(rules.examWeightPercent)} disabled={!canManage} /></label>
          <label>Exam attempts<input name="examAttemptsAllowed" type="number" min="1" defaultValue={rules.examAttemptsAllowed} disabled={!canManage} /></label>
          <label>Campus unlock fee %<input name="activationPaymentPercent" type="number" min="0" max="100" defaultValue={Number(rules.activationPaymentPercent)} disabled={!canManage} /></label>
          <label>Exam clearance fee %<input name="examPaymentClearancePercent" type="number" min="0" max="100" defaultValue={Number(rules.examPaymentClearancePercent)} disabled={!canManage} /></label>
          <label>Certificate max months<input name="certificateMaxMonths" type="number" min="0" defaultValue={rules.certificateMaxMonths} disabled={!canManage} /></label>
        </div>
        <div style={{ display: "flex", gap: 18, flexWrap: "wrap" }}>
          {[["allowsCourseRepeat","Allow course repeat",rules.allowsCourseRepeat],["academicTeamDecidesResit","Academic team decides resit",rules.academicTeamDecidesResit],["requiresIdentityDocument","Require identity document",rules.requiresIdentityDocument],["requiresEducationDocument","Require education document",rules.requiresEducationDocument],["interviewByAdmissions","Admissions interview required",rules.interviewByAdmissions]].map(([name,label,checked])=><label key={String(name)}><input name={String(name)} type="checkbox" defaultChecked={Boolean(checked)} disabled={!canManage} /> {String(label)}</label>)}
        </div>
        {canManage ? <button className="btn btn-primary" type="submit">Save academic rules</button> : null}
      </form>
    </section>

    <section className="panel">
      <div className="eyebrow">03 · Academic periods</div><h2>Periods / trimesters</h2>
      {canManage ? <form action={addPeriod} className="grid grid-3" style={{ marginBottom: 20 }}><input type="hidden" name="programmeId" value={programme.id} /><label>Period name<input name="name" placeholder="Trimester 1" required /></label><label>Fee<input name="feeAmount" type="number" min="0" defaultValue="600000" /></label><label>Currency<input name="currency" defaultValue="UGX" /></label><button className="btn btn-primary" type="submit">Add period</button></form> : null}
      <div style={{ display: "grid", gap: 12 }}>{periods.map((period) => <form action={updatePeriod} key={period.id} className="card" style={{ padding: 18 }}><input type="hidden" name="periodId" value={period.id} /><input type="hidden" name="programmeId" value={programme.id} /><div className="grid grid-3"><label>#{period.sequence}<input name="name" defaultValue={period.name} disabled={!canManage} /></label><label>Fee<input name="feeAmount" type="number" defaultValue={Number(period.feeAmount)} disabled={!canManage} /></label><label>Status<select name="status" defaultValue={period.status} disabled={!canManage}><option value="PLANNED">Planned</option><option value="OPEN">Open</option><option value="CLOSED">Closed</option></select></label></div>{canManage ? <button className="btn btn-outline-dark btn-sm" type="submit">Save period</button> : null}</form>)}</div>
    </section>

    <section className="panel">
      <div className="eyebrow">04 · Courses</div><h2>Course catalogue</h2>
      {canManage ? <form action={addCourse} style={{ display: "grid", gap: 12, marginBottom: 22 }}><input type="hidden" name="programmeId" value={programme.id} /><div className="grid grid-3"><label>Course code<input name="code" placeholder="FM101" required /></label><label>Title<input name="title" placeholder="Introduction to Financial Markets" required /></label><label>Description<input name="description" /></label></div><button className="btn btn-primary" type="submit">Add course</button></form> : null}
      <div style={{ display: "grid", gap: 24 }}>{courses.map((course) => <CourseEditor key={course.id} programme={programme} course={course} periods={periods} faculty={faculty} canManage={canManage} />)}</div>
      {courses.length === 0 ? <div className="muted">No courses yet. Create the first course above.</div> : null}
    </section>
  </div>;
}

function CourseEditor({ programme, course, periods, faculty, canManage }: AnyProgramme) {
  const linked = new Set(course.periodLinks.map((x: AnyProgramme) => x.periodId));
  return <article className="card" style={{ padding: 24 }}>
    <form action={updateCourse} style={{ display: "grid", gap: 12 }}><input type="hidden" name="courseId" value={course.id} /><input type="hidden" name="programmeId" value={programme.id} /><div className="grid grid-3"><label>Code<input name="code" defaultValue={course.code} disabled={!canManage} /></label><label>Title<input name="title" defaultValue={course.title} disabled={!canManage} /></label><label>Order<input name="orderIndex" type="number" defaultValue={course.orderIndex} disabled={!canManage} /></label><label>Delivery duration<select name="durationMonths" defaultValue={String(course.durationMonths ?? 1)} disabled={!canManage}><option value="1">1 month</option><option value="3">3 months</option><option value="12">12 months</option></select></label><label>Sessions per week<input name="sessionsPerWeek" type="number" min="0" max="7" defaultValue={course.sessionsPerWeek ?? (course.durationMonths === 12 ? 0 : course.durationMonths === 1 ? 3 : 2)} disabled={!canManage} /></label></div><label>Description<textarea name="description" rows={2} defaultValue={course.description ?? ""} disabled={!canManage} /></label><div style={{display:"flex",gap:18,flexWrap:"wrap"}}><label><input name="published" type="checkbox" defaultChecked={course.published} disabled={!canManage} /> Published</label><label><input name="catalogueVisible" type="checkbox" defaultChecked={course.catalogueVisible !== false} disabled={!canManage} /> Public catalogue</label></div>{canManage ? <button className="btn btn-outline-dark btn-sm" type="submit">Save course</button> : null}</form>
    <div style={{ marginTop: 22, paddingTop: 18, borderTop: "1px solid var(--border, #ddd)" }}><strong>Periods</strong><div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 10 }}>{periods.map((period: AnyProgramme) => <form action={linkCoursePeriod} key={period.id}><input type="hidden" name="programmeId" value={programme.id} /><input type="hidden" name="courseId" value={course.id} /><input type="hidden" name="periodId" value={period.id} />{linked.has(period.id) ? <><input type="hidden" name="action" value="remove" /><button className="chip chip-accent" type="submit" disabled={!canManage}>{period.name} · linked</button></> : <><input type="hidden" name="action" value="add" /><input type="hidden" name="required" value="true" /><button className="chip" type="submit" disabled={!canManage}>+ {period.name}</button></>}</form>)}</div></div>
    <div style={{ marginTop: 22, paddingTop: 18, borderTop: "1px solid var(--border, #ddd)" }}><strong>Faculty</strong>{canManage ? <form action={assignFaculty} style={{ display: "flex", gap: 8, marginTop: 10, flexWrap: "wrap" }}><input type="hidden" name="programmeId" value={programme.id} /><input type="hidden" name="courseId" value={course.id} /><input type="hidden" name="action" value="assign" /><select name="facultyId"><option value="">Select faculty…</option>{faculty.map((f: AnyProgramme)=><option key={f.id} value={f.id}>{[f.firstName,f.lastName].filter(Boolean).join(" ") || f.email}</option>)}</select><label><input type="checkbox" name="isLead" /> Lead</label><button className="btn btn-outline-dark btn-sm">Assign</button></form> : null}<div style={{ display: "grid", gap: 6, marginTop: 10 }}>{course.faculty.map((f: AnyProgramme)=><div key={f.user.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 8 }}><span>{[f.user.firstName,f.user.lastName].filter(Boolean).join(" ") || f.user.email}{f.isLead ? " · Lead" : ""}</span>{canManage?<form action={assignFaculty}><input type="hidden" name="programmeId" value={programme.id}/><input type="hidden" name="courseId" value={course.id}/><input type="hidden" name="facultyId" value={f.user.id}/><input type="hidden" name="action" value="remove"/><button className="btn btn-outline-dark btn-sm">Remove</button></form>:null}</div>)}</div></div>
    <div style={{ marginTop: 22, paddingTop: 18, borderTop: "1px solid var(--border, #ddd)" }}><strong>Modules & lessons</strong>{canManage?<form action={addModule} style={{ display: "flex", gap: 8, marginTop: 10 }}><input type="hidden" name="programmeId" value={programme.id}/><input type="hidden" name="courseId" value={course.id}/><input name="title" placeholder="Module title" required/><input name="description" placeholder="Description"/><button className="btn btn-outline-dark btn-sm">Add module</button></form>:null}<div style={{ display: "grid", gap: 16, marginTop: 14 }}>{course.modules.map((module: AnyProgramme)=><ModuleEditor key={module.id} programmeId={programme.id} module={module} canManage={canManage}/>)}</div>{course.modules.length===0?<div className="muted" style={{marginTop:10}}>No modules yet.</div>:null}</div>
  </article>;
}

function ModuleEditor({ programmeId, module, canManage }: AnyProgramme) {
  return <div style={{ border: "1px solid var(--border, #ddd)", borderRadius: 8, padding: 16 }}>
    <form action={updateModule} style={{ display: "grid", gap: 8 }}><input type="hidden" name="moduleId" value={module.id}/><input type="hidden" name="programmeId" value={programmeId}/><div className="grid grid-3"><label>Module<input name="title" defaultValue={module.title} disabled={!canManage}/></label><label>Order<input name="orderIndex" type="number" defaultValue={module.orderIndex} disabled={!canManage}/></label><label><input name="published" type="checkbox" defaultChecked={module.published} disabled={!canManage}/> Published</label></div><input name="description" defaultValue={module.description ?? ""} placeholder="Module description" disabled={!canManage}/>{canManage?<button className="btn btn-outline-dark btn-sm" type="submit">Save module</button>:null}</form>
    {canManage?<form action={addLesson} style={{ display:"grid", gap:8, marginTop:14 }}><input type="hidden" name="programmeId" value={programmeId}/><input type="hidden" name="moduleId" value={module.id}/><div className="grid grid-3"><input name="title" placeholder="Lesson title" required/><select name="type" defaultValue="ARTICLE"><option>VIDEO</option><option>ARTICLE</option><option>DOCUMENT</option><option>LIVE_SESSION</option><option>EXTERNAL</option><option>RESOURCE</option></select><input name="durationMinutes" type="number" min="0" placeholder="Minutes"/></div><input name="videoUrl" placeholder="Video / external URL (optional)"/><textarea name="content" rows={2} placeholder="Lesson content / instructions"/><label><input name="required" type="checkbox" defaultChecked/> Required lesson</label><button className="btn btn-outline-dark btn-sm">Add lesson</button></form>:null}
    <div style={{ display:"grid", gap:10, marginTop:14 }}>{module.lessons.map((lesson: AnyProgramme)=><form action={updateLesson} key={lesson.id} className="card" style={{padding:12}}><input type="hidden" name="lessonId" value={lesson.id}/><input type="hidden" name="programmeId" value={programmeId}/><div className="grid grid-3"><input name="title" defaultValue={lesson.title} disabled={!canManage}/><select name="type" defaultValue={lesson.type} disabled={!canManage}><option>VIDEO</option><option>ARTICLE</option><option>DOCUMENT</option><option>LIVE_SESSION</option><option>EXTERNAL</option><option>RESOURCE</option></select><input name="orderIndex" type="number" defaultValue={lesson.orderIndex} disabled={!canManage}/></div><input name="videoUrl" defaultValue={lesson.videoUrl ?? ""} placeholder="Video / URL" disabled={!canManage}/><textarea name="content" rows={2} defaultValue={lesson.content ?? ""} placeholder="Content" disabled={!canManage}/><div style={{display:"flex",gap:14,flexWrap:"wrap"}}><label><input name="required" type="checkbox" defaultChecked={lesson.required} disabled={!canManage}/> Required</label><label><input name="published" type="checkbox" defaultChecked={lesson.published} disabled={!canManage}/> Published</label></div>{canManage?<button className="btn btn-outline-dark btn-sm">Save lesson</button>:null}</form>)}</div>
  </div>;
}
