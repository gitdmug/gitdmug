import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ControlNav } from "@/components/ControlNav";
import { GITDM } from "@/lib/branding";
import { requireStaffUser } from "@/lib/control-centre";
import { reviewModuleDelivery } from "@/app/control-centre/courses/actions";

export const dynamic = "force-dynamic";
export const metadata = { title: `Course Delivery Approval | ${GITDM.shortName}` };

export default async function DeliveryApprovalPage() {
  const { db, user } = await requireStaffUser("academic.view");
  const leadership = user.roles.some((r) => ["PRINCIPAL", "ACADEMIC_DIRECTOR"].includes(r.role.code));
  const modules = await db.courseModule.findMany({
    where: { approvalStatus: "PENDING_APPROVAL" },
    orderBy: { submittedAt: "asc" },
    include: { course: { include: { programme: true, facultyUnit: true, faculty: { include: { user: true } } } }, lessons: { include: { resources: true }, orderBy: { orderIndex: "asc" } }, timetableEvents: { orderBy: { startAt: "asc" }, include: { lecturerUser: true } } },
  });
  return <><Header workspace="staff"/><ControlNav active="/control-centre/academic"/><main><section className="page-hero"><div className="container"><div className="eyebrow">Academic Directorate · Delivery approval</div><h1>Approve course delivery</h1><p>Lecturers prepare the module plan, study calendar, classes and materials here. Students see the module only after academic approval.</p></div></section><section className="section"><div className="container">
    {!modules.length ? <div className="panel"><h2>No delivery plans awaiting approval</h2><p>When a lecturer submits a complete module, it will appear here for academic review.</p></div> : <div className="stack">{modules.map((m:any) => <article className="card" key={m.id}>
      <div style={{display:"flex",justifyContent:"space-between",gap:16,flexWrap:"wrap"}}><div><span className="chip chip-accent">{m.course.code}</span><h2 style={{marginTop:10}}>{m.title}</h2><p>{m.course.programme?.name || "Programme not specified"} · {m.course.facultyUnit?.name || "Faculty"}</p><p>Submitted {m.submittedAt ? new Date(m.submittedAt).toLocaleString("en-UG") : "—"}</p></div><span className="badge warn">Pending approval</span></div>
      <div className="grid grid-3" style={{marginTop:18}}><div className="staff-notice"><strong>Delivery period</strong><p>{m.deliveryStartAt ? new Date(m.deliveryStartAt).toLocaleDateString("en-UG") : "Not set"} → {m.deliveryEndAt ? new Date(m.deliveryEndAt).toLocaleDateString("en-UG") : "Not set"}</p></div><div className="staff-notice"><strong>Study pattern</strong><p>{m.studyDaysJson ? JSON.parse(m.studyDaysJson).join(", ") || "Not set" : "Not set"}</p></div><div className="staff-notice"><strong>Materials</strong><p>{m.lessons.length} lesson(s) · {m.lessons.reduce((n:number,l:any)=>n+l.resources.length,0)} resource(s) · {m.timetableEvents.length} class(es)</p></div></div>
      <div className="stack" style={{marginTop:18}}>{m.lessons.map((l:any)=><div className="staff-notice" key={l.id}><div><strong>{l.title}</strong><p>{l.type} · {l.durationMinutes || "—"} min · {l.resources.length} material(s)</p>{l.content ? <p>{l.content}</p> : null}</div></div>)}</div>
      <div className="actions" style={{marginTop:18}}><Link href={`/control-centre/courses/${m.courseId}`} className="btn btn-outline-dark btn-sm">Open course workspace</Link>{leadership ? <><form action={reviewModuleDelivery}><input type="hidden" name="moduleId" value={m.id}/><input type="hidden" name="decision" value="APPROVE"/><button className="btn btn-primary btn-sm">Approve &amp; publish to students</button></form><form action={reviewModuleDelivery} className="actions"><input type="hidden" name="moduleId" value={m.id}/><input type="hidden" name="decision" value="REJECT"/><input name="reason" placeholder="Revision feedback" required/><button className="btn btn-outline-dark btn-sm">Return for revision</button></form></> : <span className="badge">View only</span>}</div>
    </article>)}</div>}
    <div className="actions" style={{marginTop:28}}><Link href="/control-centre/academic" className="btn btn-outline-dark btn-sm">← Academic dashboard</Link><Link href="/control-centre/courses" className="btn btn-primary btn-sm">Course catalogue</Link></div>
  </div></section></main><Footer/></>;
}
