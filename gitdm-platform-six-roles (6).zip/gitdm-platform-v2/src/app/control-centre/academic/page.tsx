import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { ControlNav } from "@/components/ControlNav";
import { GITDM } from "@/lib/branding";
import { requireStaffUser } from "@/lib/control-centre";
import { ACTIVE_COURSE_CODES } from "@/lib/current-catalogue";

export const dynamic = "force-dynamic";
export const metadata = { title: `Academic Operating Floor | ${GITDM.shortName}` };

const stages = [
  ["1", "Admissions → Academic", "Finance confirms the admitted student's required payment. Registry/Academic receives an active enrolment and assigns the programme period/cohort.", "Registrar / Academic", "Enrolled student record", "/control-centre/students"],
  ["2", "Programme & curriculum", "Academic Affairs maintains programmes, periods, courses, module sequence, learning outcomes and the delivery calendar before teaching begins.", "Academic Director", "Approved curriculum", "/control-centre/programmes"],
  ["3", "Course delivery plan", "For each module, Academic sets the delivery window, study pattern and cohort timetable. Lecturers do not create student-facing classes.", "Academic Affairs", "Published timetable", "/control-centre/academic/delivery"],
  ["4", "Teaching & learning", "Lecturers prepare lessons, notes, videos, readings and links. Academic approval controls publication; students see only approved content for their enrolment.", "Lecturer → Academic", "Visible learning module", "/control-centre/courses"],
  ["5", "Live classes & attendance", "Academic publishes the class. Lecturer adds the live link and teaches. GITDM records attendance and exposes the same class, link and attendance status to the student.", "Academic → Lecturer", "Student calendar + attendance", "/control-centre/timetable"],
  ["6", "Formative assessment", "Assignments and quizzes are published against the course, students submit online/file evidence, lecturers mark and return feedback. Every submission remains auditable.", "Lecturer / Faculty", "Marked coursework", "/staff/lecturer/assessments"],
  ["7", "Formal examination", "Examination Office prepares the exam, controlled documents/question bank and schedule, then Academic leadership approves publication. Students receive the approved exam window and format.", "Exam Officer → Academic", "Exam attempt", "/staff/exam-officer/exams"],
  ["8", "Marking & moderation", "Objective items may be auto-marked; written work is manually marked. Marks move through confirmation/moderation before becoming part of the provisional course grade.", "Exam Officer / Academic", "Provisional grade", "/staff/exam-officer/results"],
  ["9", "Result publication", "The system checks the programme grading rules and attendance requirement. Approved final grades are published to the student's Academic Record and transcript pathway.", "Academic / Registry", "Final course result", "/staff/exam-officer/results"],
  ["10", "Progression & completion", "Academic/Registry review passed courses, repeats/resits, outstanding requirements and programme completion before transcript/certificate issuance.", "Registry + Academic", "Progression / credential", "/staff/registrar/records"],
];

export default async function AcademicPage() {
  const { db } = await requireStaffUser("academic.view");
  const now = new Date();
  const [programmes, activeEnrollments, courses, modules, pendingModules, lessons, upcomingClasses, assignments, upcomingExams, provisionalGrades, finalGrades, attendance] = await Promise.all([
    db.programme.count(),
    db.enrollment.count({ where: { status: { in: ["ACTIVE", "REPEATING"] } } }),
    db.course.count({ where: { code: { in: [...ACTIVE_COURSE_CODES] } } }),
    db.courseModule.count({ where: { course: { code: { in: [...ACTIVE_COURSE_CODES] } } } }),
    db.courseModule.count({ where: { approvalStatus: "PENDING_APPROVAL" } }),
    db.lesson.count({ where: { published: true, module: { course: { code: { in: [...ACTIVE_COURSE_CODES] } } } } }),
    db.timetableEvent.count({ where: { startAt: { gte: now }, course: { code: { in: [...ACTIVE_COURSE_CODES] } } } }),
    db.assignment.count({ where: { status: "PUBLISHED", course: { code: { in: [...ACTIVE_COURSE_CODES] } } } }),
    db.exam.count({ where: { course: { code: { in: [...ACTIVE_COURSE_CODES] } }, status: "PUBLISHED", OR: [{ closesAt: null }, { closesAt: { gte: now } }] } }),
    db.grade.count({ where: { status: "PROVISIONAL", course: { code: { in: [...ACTIVE_COURSE_CODES] } } } }),
    db.grade.count({ where: { status: "FINAL", course: { code: { in: [...ACTIVE_COURSE_CODES] } } } }),
    db.classAttendanceRecord.count(),
  ]);
  return <><Header workspace="staff" /><ControlNav active="/control-centre/academic" /><main>
    <section className="page-hero"><div className="container"><div className="eyebrow">Academic operating floor</div><h1>One learner, one controlled academic route</h1><p>Academic Affairs owns the learning journey from enrolment handoff through teaching, assessment, examination, results and progression. Each approved action is reflected in the student's portal.</p></div></section>
    <section className="section"><div className="container">
      <div className="grid grid-4" style={{marginBottom:28}}>
        {[["Enrolled students", activeEnrollments, "Active / repeating learners"],["Courses", courses, "Course records"],["Modules", modules, `${pendingModules} awaiting approval`],["Upcoming classes", upcomingClasses, "Published timetable events"],["Published lessons", lessons, "Student-visible learning content"],["Coursework", assignments, "Published assignments"],["Examinations", upcomingExams, "Published exam windows"],["Results", finalGrades, `${provisionalGrades} provisional · ${attendance} attendance records`]].map(([label,value,sub])=><div className="panel" key={String(label)}><div className="eyebrow">{label}</div><h2>{value}</h2><p>{sub}</p></div>)}
      </div>
      <div className="card" style={{marginBottom:28}}><div className="eyebrow">Department operating floor</div><h2>One case, one controlled route</h2><p>Nothing becomes student-facing merely because a staff member created it. Academic publication gates are deliberate: curriculum → delivery plan → timetable → learning content → assessment → examination → moderation → final result.</p><div className="table-wrap" style={{marginTop:18}}><table className="data"><thead><tr><th>Stage</th><th>Owner</th><th>Action</th><th>Student outcome</th></tr></thead><tbody>{stages.map(([n,title,desc,owner,outcome])=><tr key={n}><td><strong>{n}</strong> · {title}</td><td>{owner}</td><td>{desc}</td><td>{outcome}</td></tr>)}</tbody></table></div></div>
      <div className="grid grid-3">
        <Link className="card" href="/control-centre/programmes" style={{textDecoration:"none"}}><h3>Programme & curriculum</h3><p>Maintain programme rules, periods, courses and curriculum structure.</p><span className="btn btn-outline-dark btn-sm">Open curriculum</span></Link>
        <Link className="card" href="/control-centre/academic/delivery" style={{textDecoration:"none"}}><h3>Delivery approvals</h3><p>Approve lecturer-prepared modules before they become visible to students.</p><span className="btn btn-outline-dark btn-sm">Review delivery</span></Link>
        <Link className="card" href="/control-centre/timetable" style={{textDecoration:"none"}}><h3>Academic timetable</h3><p>Own cohort classes, live-session dates, venues, links and attendance windows.</p><span className="btn btn-primary btn-sm">Manage timetable</span></Link>
        <Link className="card" href="/control-centre/exams" style={{textDecoration:"none"}}><h3>Examination office</h3><p>Control exam preparation, documents, question banks, attempts and release.</p><span className="btn btn-outline-dark btn-sm">Manage exams</span></Link>
        <Link className="card" href="/control-centre/results" style={{textDecoration:"none"}}><h3>Results & moderation</h3><p>Synchronize provisional grades, enforce attendance rules and publish final results.</p><span className="btn btn-outline-dark btn-sm">Open results</span></Link>
        <Link className="card" href="/control-centre/students" style={{textDecoration:"none"}}><h3>Student academic record</h3><p>Investigate enrolment, course allocation, attendance, assessments and progression.</p><span className="btn btn-outline-dark btn-sm">Open student register</span></Link>
      </div>
      <div className="panel" style={{marginTop:28}}><strong>Governance rule:</strong> lecturers can create and mark learning activities for their assigned courses, but they cannot create, move or silently publish student-facing timetable events. Academic Affairs owns the official calendar.</div>
    </div></section></main><Footer /></>;
}
