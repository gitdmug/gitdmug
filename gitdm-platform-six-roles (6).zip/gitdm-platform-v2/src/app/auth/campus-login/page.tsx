import { redirect } from "next/navigation";

export default function CampusLoginPage() {
  redirect("/auth/login?returnTo=/campus");
}
