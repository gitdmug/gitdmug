"use server";

import { redirect } from "next/navigation";
import { getCurrentUser } from "@/lib/access";
import { getDb } from "@/lib/db";
import { notifyStudentChange } from "@/lib/student-email";
import { ACTIVE_PROGRAMME_CODES } from "@/lib/current-catalogue";


async function assertProgrammeApplicationAllowed(db: any, userId: string, programmeId: string, programmeDurationMonths: number) {
  const running = await db.enrollment.findMany({
    where: { userId, status: { in: ["ACTIVE", "REPEATING"] } },
    include: { programme: { select: { id: true, name: true, durationMonths: true } } },
    orderBy: { createdAt: "desc" },
  });

  if (!running.length) return;

  // Normal rule: one running programme at a time. The only exception is a
  // learner on the 12-month programme who may take one 1-month short
  // course alongside it. A second short course is never allowed concurrently.
  const longRunning = running.some((e: { programme: { durationMonths: number } }) => e.programme.durationMonths >= 12);
  const shortRunning = running.some((e: { programme: { durationMonths: number } }) => e.programme.durationMonths < 12);
  const shortTarget = programmeDurationMonths === 1;
  const longTarget = programmeDurationMonths >= 12;

  if (longRunning && shortTarget && !shortRunning) {
    const existingShortApplication = await db.application.findFirst({
      where: {
        applicantId: userId,
        programme: { durationMonths: 1 },
        status: { in: ["DRAFT", "SUBMITTED", "UNDER_REVIEW", "INTERVIEW_REQUIRED", "ADDITIONAL_INFORMATION", "ACCEPTED"] },
      },
      select: { id: true, programme: { select: { name: true } } },
      orderBy: { submittedAt: "desc" },
    });
    if (existingShortApplication) {
      throw new Error(`You already have a short-course application (${existingShortApplication.programme.name}) while your 12-month programme is running.`);
    }
    return;
  }

  const current = running[0].programme.name;
  if (longTarget || !shortTarget || shortRunning) {
    throw new Error(`You already have a current programme running: ${current}. You cannot apply for another programme until it is completed. The only exception is one 1-month short course alongside a 12-month programme.`);
  }
}

export async function startApplication(formData: FormData) {
  const user = await getCurrentUser();
  const db = getDb();
  if (!user || !db) redirect("/auth/login?returnTo=/admissions/apply");

  const programmeId = String(formData.get("programmeId") || "").trim();
  const programme = await db.programme.findFirst({
    where: { id: programmeId, code: { in: [...ACTIVE_PROGRAMME_CODES] }, status: "PUBLISHED", requiresApplication: true, applicationsOpen: true },
    include: { rules: true, periods: { where: { status: "OPEN" }, orderBy: { sequence: "asc" }, take: 1 } },
  });
  if (!programme) throw new Error("This programme is not currently open for the October intake.");

  await assertProgrammeApplicationAllowed(db, user.id, programmeId, programme.durationMonths);

  const existing = await db.application.findFirst({
    where: {
      applicantId: user.id,
      programmeId,
      status: { in: ["DRAFT", "SUBMITTED", "UNDER_REVIEW", "INTERVIEW_REQUIRED", "ADDITIONAL_INFORMATION", "ACCEPTED"] },
    },
    orderBy: { submittedAt: "desc" },
  });
  if (existing) redirect(`/admissions/apply/${existing.id}`);

  const app = await db.$transaction(async (tx) => {
    const created = await tx.application.create({
      data: { applicantId: user.id, programmeId, status: "DRAFT" },
    });

    const period = programme.periods[0] || null;
    const enrollment = await tx.enrollment.create({
      data: {
        userId: user.id,
        programmeId,
        periodId: period?.id || null,
        status: "PENDING",
        accessLevel: "LIMITED",
      },
    });

    if (Number(programme.applicationFee) > 0) {
      const invoiceNo = `GITDM-APP-${new Date().getFullYear()}-${created.id.slice(-8).toUpperCase()}`;
      await tx.invoice.create({
        data: {
          enrollmentId: enrollment.id,
          periodId: null,
          applicationId: created.id,
          invoiceNo,
          description: `GITDM application fee — ${programme.name}`,
          kind: "APPLICATION_FEE",
          amount: Number(programme.applicationFee),
          currency: programme.currency,
          status: "ISSUED",
        },
      });
    }

    await tx.auditLog.create({
      data: {
        userId: user.id,
        action: "APPLICATION_STARTED",
        entity: "Application",
        entityId: created.id,
        metadataJson: JSON.stringify({ programmeId, programmeCode: programme.code }),
      },
    });

    return created;
  });

  redirect(`/admissions/apply/${app.id}`);
}

export async function submitApplication(formData: FormData) {
  const user = await getCurrentUser();
  const db = getDb();
  if (!user || !db) redirect("/auth/login");

  const id = String(formData.get("applicationId") || "");
  const app = await db.application.findFirst({
    where: { id, applicantId: user.id, status: "DRAFT" },
    include: { documents: true, programme: { include: { rules: true } }, feeInvoice: true },
  });
  if (!app) throw new Error("Application not found.");

  const needsId = app.programme.rules?.requiresIdentityDocument ?? true;
  const needsEducation = app.programme.rules?.requiresEducationDocument ?? true;
  const hasId = app.documents.some((d) => d.type === "IDENTITY");
  const hasEducation = app.documents.some((d) => d.type === "EDUCATION");
  if (needsId && !hasId) throw new Error("Upload your identity document before submitting.");
  if (needsEducation && !hasEducation) throw new Error("Upload your education document before submitting.");
  await db.application.update({ where: { id }, data: { status: "SUBMITTED", submittedAt: new Date() } });
  const submissionBody = `Your ${app.programme.name} application has been submitted. Admissions will review your documents and contact you if an interview or additional information is required.`;
  await db.notification.create({
    data: { userId: user.id, type: "ADMISSIONS", title: "Application submitted", body: submissionBody },
  });
  await notifyStudentChange({ userId: user.id, email: user.email, firstName: user.firstName, title: "Application submitted", body: submissionBody, action: "APPLICATION_SUBMITTED", event: "APPLICATION_SUBMITTED", href: `/admissions/apply/${id}` });
  await db.auditLog.create({ data: { userId: user.id, action: "APPLICATION_SUBMITTED", entity: "Application", entityId: id } });
  redirect(`/admissions/apply/${id}?submitted=1`);
}
