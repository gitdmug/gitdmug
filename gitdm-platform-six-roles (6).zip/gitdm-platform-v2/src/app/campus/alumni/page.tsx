import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { StudentNav } from "@/components/StudentNav";
import { GITDM } from "@/lib/branding";
import { requireStudentSession } from "@/lib/student";
import { getDb } from "@/lib/db";

export const dynamic="force-dynamic";
export const metadata={title:`Alumni | ${GITDM.shortName}`};

export default async function AlumniPage(){
 const ctx=await requireStudentSession("/campus/alumni"); const db=getDb();
 const certificates=db?await db.certificate.findMany({where:{userId:ctx.user.id},include:{programme:true},orderBy:{issuedAt:"desc"}}):[];
 return <><Header workspace="student"/><StudentNav active="/campus/alumni"/><main><section className="page-hero"><div className="container"><div className="eyebrow">Alumni Network</div><h1>Your GITDM relationship continues after graduation.</h1><p>Keep your academic identity, certificates and connection to the institute in one place.</p></div></section><section className="section"><div className="container"><div className="grid grid-3"><div className="panel"><div className="eyebrow">Status</div><h2>{certificates.length?"Alumni ready":"Member journey"}</h2><p>Your account remains the gateway to lifelong GITDM services.</p></div><div className="panel"><div className="eyebrow">Credentials</div><h2>{certificates.length}</h2><p>Certificates linked to your account.</p></div><div className="panel"><div className="eyebrow">Benefits</div><h2>Lifetime</h2><p>Stay connected to learning, events, resources and institutional updates.</p></div></div><div className="grid grid-2" style={{marginTop:28}}><div className="card"><h3>What alumni can use</h3><ul className="feature-list"><li>Verified academic history and certificate trail</li><li>Access to selected alumni learning materials and events</li><li>Institutional announcements and community opportunities</li><li>Future professional-development and partner opportunities</li></ul></div><div className="card"><h3>Your credentials</h3>{certificates.length?certificates.map(c=><div key={c.id} className="panel" style={{marginBottom:12}}><strong>{c.programme.name}</strong><p>Certificate {c.number}</p></div>):<p>Your alumni credentials will appear here once your programme is completed and your certificate is issued.</p>}<div className="actions"><Link href="/campus/profile" className="btn btn-outline-dark">Keep profile updated</Link><Link href="/store" className="btn btn-outline-dark">Public store</Link></div></div></div></div></section></main><Footer/></>;
}
