import Link from "next/link";
import { redirect } from "next/navigation";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { StudentNav } from "@/components/StudentNav";
import { GITDM } from "@/lib/branding";
import { requireStudentSession } from "@/lib/student";
import { getDb } from "@/lib/db";
import { humanStatus } from "@/lib/status";
import { LocalGreeting } from "@/components/LocalGreeting";

export const metadata = {
  title: `Campus | ${GITDM.shortName}`,
  description: "GITDM digital campus dashboard.",
};

export const dynamic = "force-dynamic";

export default async function CampusDashboardPage({
  searchParams,
}: {
  searchParams: Promise<{ error?: string }>;
}) {
  const params = await searchParams;

  // Resolve the institutional account once. This loader has a defensive
  // fallback for partially migrated production schemas and also identifies
  // staff before the student workspace is rendered.
  const ctx = await requireStudentSession("/campus");
  if (ctx.isStaff) {
    redirect("/staff");
  }
  const { primaryEnrollment: enr, accessLevel, feePercentPaid, activationThreshold } =
    ctx;

  const db = getDb();
  // Optional dashboard widgets — never let a missing table/relation take down /campus
  let notifications: any[] = [];
  let pendingAssignments = 0;
  if (db) {
    try {
      notifications = await db.notification.findMany({
        where: { userId: ctx.user.id },
        orderBy: { createdAt: "desc" },
        take: 5,
      });
    } catch (err) {
      console.error("[GITDM campus] notifications query skipped:", err);
    }
    if (enr) {
      try {
        pendingAssignments = await db.assignment.count({
          where: {
            course: {
              enrollments: {
                some: {
                  enrollmentId: enr.id,
                  status: { in: ["ACTIVE", "REPEATING"] },
                },
              },
            },
            status: "PUBLISHED",
            submissions: {
              none: {
                userId: ctx.user.id,
                status: { in: ["SUBMITTED", "GRADED", "RETURNED"] },
              },
            },
          },
        });
      } catch (err) {
        console.error("[GITDM campus] pending assignments query skipped:", err);
      }
    }
  }
  const greetingName = ctx.user.firstName?.trim() || ctx.user.lastName?.trim() || "there";

  return (
    <>
      <Header active="/campus" workspace="student" />
      <StudentNav active="/campus" fullAccess={accessLevel === "FULL"} />
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">Campus dashboard</div>
            <h1><LocalGreeting name={greetingName} /></h1>
            <p>
              {enr
                ? `${enr.programme.name}${enr.period ? ` · ${enr.period.name}` : ""}`
                : "Your admissions, learning and finance workspace."}
            </p>
          </div>
        </section>

        <section className="section">
          <div className="container">
            {params.error ? (
              <div className="panel" style={{ marginBottom: 20, borderColor: "var(--accent)" }}>
                <span className="badge warn">Notice</span>
                <p style={{ marginTop: 12, marginBottom: 0 }}>{params.error}</p>
              </div>
            ) : null}

            {accessLevel === "NONE" ? (
              <div className="access-banner">
                <strong>Limited campus access.</strong>{" "}
                {ctx.applications.length > 0 ? (
                  <>
                    You have {ctx.applications.length} application(s). Track status under
                    Profile, or{" "}
                    <Link href="/admissions">continue admissions</Link>.
                  </>
                ) : (
                  <>
                    Start by{" "}
                    <Link href="/admissions">applying for admission</Link>. After
                    acceptance and fee clearance, full campus access unlocks.
                  </>
                )}
              </div>
            ) : accessLevel === "LIMITED" || accessLevel === "RESTRICTED" ? (
              <div className="access-banner">
                <strong>
                  Limited campus — complete {activationThreshold}% of your current period
                  fee to unlock full learning access.
                </strong>
                <div className="progress-bar">
                  <span style={{ width: `${Math.min(100, feePercentPaid)}%` }} />
                </div>
                <p style={{ margin: "10px 0 0", fontSize: 14 }}>
                  Paid progress: <strong>{feePercentPaid}%</strong> of period fees.{" "}
                  <Link href="/campus/finance">Go to Finance</Link> to pay.
                </p>
              </div>
            ) : (
              <div className="access-banner full">
                <strong>Full campus access is active</strong> for your current enrolment.
                Final exams still require 100% clearance of the period fee.
              </div>
            )}

            <div className="grid grid-3" style={{ marginBottom: 28 }}>
              <div className="panel">
                <div className="eyebrow">Programme</div>
                <h3 style={{ margin: "8px 0 4px" }}>
                  {enr?.programme.shortName || enr?.programme.name || "Not enrolled"}
                </h3>
                <p style={{ margin: 0, fontSize: 14 }}>
                  {enr
                    ? `${enr.status.replaceAll("_", " ")} · ${enr.accessLevel} access`
                    : "Apply to join a programme"}
                </p>
              </div>
              <div className="panel">
                <div className="eyebrow">Fees</div>
                <h3 style={{ margin: "8px 0 4px" }}>{feePercentPaid}% cleared</h3>
                <p style={{ margin: 0, fontSize: 14 }}>
                  Unlock at {activationThreshold}% · Exam at 100%
                </p>
              </div>
              <div className="panel">
                <div className="eyebrow">Applications</div>
                <h3 style={{ margin: "8px 0 4px" }}>{ctx.applications.length}</h3>
                <p style={{ margin: 0, fontSize: 14 }}>
                  {ctx.applications[0]
                    ? `Latest: ${ctx.applications[0].status.replaceAll("_", " ")}`
                    : "No applications yet"}
                </p>
              </div>
            </div>

            <div className="grid grid-2" style={{ marginBottom: 28 }}>
              <div className="panel">
                <div className="eyebrow">Next actions</div>
                <h2 style={{marginTop:8}}>Your checklist</h2>
                <ul className="feature-list">
                  {!enr ? <li><Link href="/admissions">Complete or track your application</Link></li> : null}
                  {enr && feePercentPaid < activationThreshold ? <li><Link href="/campus/finance">Clear your period fee to unlock learning</Link></li> : null}
                  {enr && feePercentPaid >= activationThreshold && pendingAssignments > 0 ? <li><Link href="/campus/assessments">{pendingAssignments} assignment(s) need attention</Link></li> : null}
                  {enr && feePercentPaid >= 100 ? <li><Link href="/campus/assessments">Check exam eligibility and schedule</Link></li> : null}
                  {enr && feePercentPaid >= activationThreshold ? <li><Link href="/campus/learning">Continue your learning</Link></li> : null}
                </ul>
              </div>
              <div className="panel">
                <div className="eyebrow">Notifications</div><h2 style={{marginTop:8}}>Latest updates</h2>
                {notifications.length ? <div className="stack">{notifications.map(n=><div key={n.id}><strong>{n.title}</strong><p>{n.body}</p><div className="tile-meta">{humanStatus(n.type)} · {n.createdAt.toLocaleDateString("en-UG")}</div></div>)}</div> : <p>No new notifications.</p>}
              </div>
            </div>

            <div className="eyebrow">Quick access</div>
            <h2>Campus areas</h2>
            <div className="campus-grid" style={{ marginTop: 16 }}>
              <Link href="/campus/learning" className="campus-tile">
                <h3>My learning</h3>
                <p>Programme, courses, modules and lessons for your active period.</p>
                <div className="tile-meta">
                  {ctx.canAccessLearning ? "Open" : "Unlocks at 60% fees"}
                </div>
              </Link>
              <Link href="/campus/assessments" className="campus-tile">
                <h3>Assessments</h3>
                <p>Assignments, quizzes, examinations and results.</p>
                <div className="tile-meta">
                  {ctx.canAccessExams ? "Exam eligible path" : "Fee & attendance gates apply"}
                </div>
              </Link>
              <Link href="/campus/academic" className="campus-tile">
                <h3>Academic record</h3>
                <p>Attendance, grades, transcript and certificate eligibility.</p>
                <div className="tile-meta">Records</div>
              </Link>
              <Link href="/campus/timetable" className="campus-tile"><h3>My timetable</h3><p>Classes, tutorials and scheduled academic activities.</p><div className="tile-meta">Schedule</div></Link>
              <Link href="/campus/requests" className="campus-tile"><h3>Requests</h3><p>Submit and track cases through Student Services.</p><div className="tile-meta">Case tracking</div></Link>
              <Link href="/campus/notifications" className="campus-tile"><h3>Notifications</h3><p>Academic, finance, support and community updates.</p><div className="tile-meta">Action centre</div></Link>
              <Link href="/campus/store" className="campus-tile"><h3>GITDM Store</h3><p>Order student materials and track collection.</p><div className="tile-meta">Orders</div></Link>
              <Link href="/campus/finance" className="campus-tile">
                <h3>Finance</h3>
                <p>Invoices, payments, receipts and access-gate status.</p>
                <div className="tile-meta">{feePercentPaid}% paid</div>
              </Link>
              <Link href="/campus/support" className="campus-tile">
                <h3>Support</h3>
                <p>Raise tickets with Student Affairs, IT or Partner Support.</p>
                <div className="tile-meta">Help desk</div>
              </Link>
              {!enr ? <Link href="/campus/apply" className="campus-tile campus-tile-accent">
                <h3>Apply to GITDM</h3>
                <p>Browse published programmes, compare requirements and continue an application.</p>
                <div className="tile-meta">Admissions workspace</div>
              </Link> : null}
              <Link href="/campus/profile" className="campus-tile">
                <h3>Profile</h3>
                <p>Identity, contacts, applications and linked guardians.</p>
                <div className="tile-meta">{ctx.user.email}</div>
              </Link>
              {ctx.isStaff ? (
                <Link href="/control-centre" className="campus-tile">
                  <h3>Control Centre</h3>
                  <p>Staff institutional workspace (Principal and departments).</p>
                  <div className="tile-meta">Staff only</div>
                </Link>
              ) : null}
            </div>

            {ctx.applications.length > 0 ? (
              <div style={{ marginTop: 36 }}>
                <div className="eyebrow">Admissions</div>
                <h2>Your applications</h2>
                <div className="table-wrap" style={{ marginTop: 16 }}>
                  <table className="data">
                    <thead>
                      <tr>
                        <th>Programme</th>
                        <th>Status</th>
                        <th>Submitted</th>
                      </tr>
                    </thead>
                    <tbody>
                      {ctx.applications.map((a) => (
                        <tr key={a.id}>
                          <td>{a.programme.name}</td>
                          <td>{a.status.replaceAll("_", " ")}</td>
                          <td>
                            {a.submittedAt
                              ? a.submittedAt.toISOString().slice(0, 10)
                              : "—"}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            ) : null}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
