import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { GITDM } from "@/lib/branding";
import { getAuthSession } from "@/lib/auth-session";

export const dynamic = "force-dynamic";
export const metadata = {
  title: `Explore the Campus | ${GITDM.shortName}`,
  description: "Preview the GITDM digital campus before joining a programme.",
};

const areas = [
  ["My Programme", "See how programmes, periods and academic milestones are organised."],
  ["My Courses", "A connected learning space for course materials, lessons and resources."],
  ["Exams & Assessments", "Understand how assessed work, examinations and academic progress are brought together."],
  ["Academic Record", "Results, attendance and completion records stay connected to your student identity."],
  ["Finance", "View invoices, payments, receipts and clearance from one student workspace."],
  ["Documents, Messages & Support", "Keep institutional documents, requests and support conversations in one place."],
  ["Student Store", "Access student-only learning materials and resources alongside your academic workspace."],
  ["Alumni", "Stay connected to GITDM after completion and continue benefiting from the network."],
];

export default async function CampusPreviewPage() {
  let signedIn = false;
  let name = "";
  try {
    const session = await getAuthSession();
    signedIn = Boolean(session?.user?.sub);
    name = session?.user?.name || session?.user?.given_name || "";
  } catch {
    // Public preview remains available even when authentication is unavailable.
  }

  return (
    <>
      <Header active="/campus" />
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">Digital Campus · Preview</div>
            <h1>See how the GITDM student journey is organised.</h1>
            <p>
              This is the public, limited-access view of the campus. Explore the structure
              and understand what is available to students before you join a programme.
            </p>
            <div className="actions">
              {signedIn ? (
                <Link href="/campus" className="btn btn-primary">Open my campus</Link>
              ) : (
                <>
                  <a href="/auth/signup" className="btn btn-primary">Create your GITDM account</a>
                  <a href="/auth/campus-login" className="btn btn-outline-dark">Campus login</a>
                </>
              )}
              <Link href="/admissions" className="btn btn-outline-dark">View admissions</Link>
              <Link href="/campus/catalog" className="btn btn-outline-dark">Browse free course previews</Link>
            </div>
            {signedIn ? (
              <div className="access-banner full" style={{ marginTop: 22 }}>
                <strong>{name ? `Welcome, ${name}.` : "Welcome to GITDM."}</strong> Your account is active.
                Open your campus to continue.
              </div>
            ) : null}
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className="section-header">
              <div>
                <div className="eyebrow">Limited public access</div>
                <h2>A preview, not the private student record.</h2>
                <p className="section-intro">
                  Visitors can understand the campus layout without seeing private student
                  information, grades, payments or institutional records. Those areas open
                  only inside the authenticated student workspace.
                </p>
              </div>
            </div>

            <div className="grid grid-2">
              {areas.map(([title, description]) => (
                <article className="card" key={title}>
                  <div className="eyebrow">Campus area</div>
                  <h3>{title}</h3>
                  <p>{description}</p>
                  <span className="chip">Preview only</span>
                </article>
              ))}
            </div>
          </div>
        </section>

        <section className="section alt">
          <div className="container grid grid-2" style={{ alignItems: "center", gap: 42 }}>
            <div>
              <div className="eyebrow">Why create an account?</div>
              <h2>One identity follows you through the GITDM journey.</h2>
              <p className="section-intro">
                Your account is the starting point for applications, admissions updates,
                learning access, academic records, finance, support and your long-term alumni
                connection. Creating an account does not mean you are automatically admitted.
              </p>
              <div className="actions">
                <a href="/auth/signup" className="btn btn-primary">Create account</a>
                <Link href="/programmes" className="btn btn-outline-dark">Explore programmes</Link>
              </div>
            </div>
            <div className="panel">
              <div className="eyebrow">Access model</div>
              <div className="stack" style={{ marginTop: 14 }}>
                <div className="staff-notice"><strong>Visitor</strong><p>Public pages and limited campus preview.</p></div>
                <div className="staff-notice"><strong>Registered applicant</strong><p>Account, application journey and admissions communication.</p></div>
                <div className="staff-notice"><strong>Student</strong><p>Full student campus according to enrolment and access rules.</p></div>
                <div className="staff-notice"><strong>Alumnus</strong><p>Alumni network and continuing institutional connection after completion.</p></div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
