"use client";

import { useEffect, useRef, useState } from "react";

export function LiveClassAttendanceButton({ eventId, joinUrl }: { eventId: string; joinUrl?: string | null }) {
  const [state, setState] = useState<"idle"|"joining"|"active">("idle");
  const timer = useRef<ReturnType<typeof setInterval> | null>(null);

  useEffect(() => {
    const onHide = () => { if (state === "active") { navigator.sendBeacon("/api/attendance/leave", new Blob([JSON.stringify({ eventId })], { type: "application/json" })); } };
    window.addEventListener("pagehide", onHide);
    return () => { window.removeEventListener("pagehide", onHide); if (timer.current) clearInterval(timer.current); };
  }, [state, eventId]);

  async function pulse() {
    try { await fetch("/api/attendance/pulse", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ eventId }), keepalive: true }); } catch {}
  }

  async function join() {
    setState("joining");
    const response = await fetch("/api/attendance/join", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ eventId }) });
    if (!response.ok) { setState("idle"); return; }
    setState("active");
    if (joinUrl) window.open(joinUrl, "_blank", "noopener,noreferrer");
    await pulse();
    if (!timer.current) timer.current = setInterval(pulse, 60_000);
  }

  async function leave() {
    if (timer.current) clearInterval(timer.current);
    timer.current = null;
    await fetch("/api/attendance/leave", { method: "POST", headers: { "content-type": "application/json" }, body: JSON.stringify({ eventId }), keepalive: true }).catch(() => {});
    setState("idle");
    window.location.reload();
  }

  return state === "active"
    ? <button className="btn btn-outline-dark btn-sm" type="button" onClick={leave}>End my attendance</button>
    : <button className="btn btn-primary btn-sm" type="button" disabled={state === "joining"} onClick={join}>{state === "joining" ? "Opening class…" : "Join & record attendance"}</button>;
}
