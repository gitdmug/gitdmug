"use server";

import { revalidatePath } from "next/cache";
import { getCurrentUser } from "@/lib/access";
import { getDb } from "@/lib/db";

async function resolveEventAccess(eventId: string) {
  const user = await getCurrentUser();
  const db = getDb();
  if (!user || !db) throw new Error("Unauthorized");
  const event = await db.timetableEvent.findUnique({ where: { id: eventId }, include: { course: true } });
  if (!event) throw new Error("Class not found.");
  const courseId = event.courseId;
  if (!courseId) throw new Error("This timetable item is not linked to a course and cannot record course attendance.");
  const staff = user.roles.some((r) => !["STUDENT", "PARENT_GUARDIAN", "ALUMNI"].includes(r.role.code));
  let allowed = staff && event.lecturerUserId === user.id;
  if (!allowed && event.courseId) {
    const enrollment = await db.enrollment.findFirst({
      where: { userId: user.id, status: { in: ["ACTIVE", "REPEATING"] }, courses: { some: { courseId, status: { in: ["ACTIVE", "REPEATING"] } } } },
      select: { id: true },
    });
    allowed = Boolean(enrollment);
  }
  if (!allowed) throw new Error("You are not a participant in this class.");
  return { db, user, event, courseId };
}

export async function joinClass(formData: FormData) {
  const eventId = String(formData.get("eventId") || "");
  const { db, user, event, courseId } = await resolveEventAccess(eventId);
  const now = new Date();
  const openAt = new Date(event.startAt.getTime() - event.prepMinutes * 60_000);
  if (now < openAt || now > event.endAt) throw new Error("This class is not currently open for attendance.");
  const existing = await db.classAttendanceRecord.findUnique({ where: { userId_timetableEventId: { userId: user.id, timetableEventId: event.id } } });
  if (existing?.joinedAt && !existing.leftAt) {
    revalidatePath("/campus/timetable");
    revalidatePath("/control-centre/timetable");
    return;
  }
  if (existing?.leftAt) throw new Error("Attendance for this class has already been checked out.");
  await db.classAttendanceRecord.create({
    data: { timetableEventId: event.id, userId: user.id, courseId, periodId: event.periodId ?? undefined, date: event.startAt, joinedAt: now, status: "PRESENT", source: "GITDM_CHECK_IN" },
  });
  revalidatePath("/campus/timetable");
  revalidatePath("/control-centre/timetable");
}

export async function leaveClass(formData: FormData) {
  const eventId = String(formData.get("eventId") || "");
  const { db, user, event, courseId } = await resolveEventAccess(eventId);
  const record = await db.classAttendanceRecord.findUnique({ where: { userId_timetableEventId: { userId: user.id, timetableEventId: event.id } } });
  if (!record?.joinedAt) throw new Error("Check in to the class before checking out.");
  const now = new Date();
  const leftAt = now > event.endAt ? event.endAt : now;
  const minutes = Math.max(0, Math.round((leftAt.getTime() - record.joinedAt.getTime()) / 60000));
  await db.classAttendanceRecord.update({ where: { id: record.id }, data: { leftAt, minutesAttended: minutes, status: minutes > 0 ? "PRESENT" : "ABSENT", source: record.source || "GITDM_CHECK_IN" } });
  revalidatePath("/campus/timetable");
  revalidatePath("/control-centre/timetable");
}
