import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { StudentNav } from "@/components/StudentNav";
import { GITDM } from "@/lib/branding";
import { getAuthoritativeEnrollmentCourseIds, requireStudentSession } from "@/lib/student";
import { getDb } from "@/lib/db";
import { humanStatus } from "@/lib/status";

export const dynamic = "force-dynamic";
export const metadata = { title: `Course Work | Exams & Assessments | ${GITDM.shortName}` };

export default async function CourseWorkPage() {
 const ctx=await requireStudentSession("/campus/assessments/course-work"); const enr=ctx.primaryEnrollment; const db=getDb(); let assignments:any[]=[], quizzes:any[]=[];
 if(enr&&db&&ctx.canAccessLearning){ const courseIds=await getAuthoritativeEnrollmentCourseIds(db,enr); [assignments,quizzes]=await Promise.all([
   db.assignment.findMany({where:{courseId:{in:courseIds},status:"PUBLISHED"},orderBy:{dueAt:"asc"},include:{course:true,submissions:{where:{userId:ctx.user.id}}}}),
   db.quiz.findMany({where:{courseId:{in:courseIds},status:"PUBLISHED"},include:{course:true,attempts:{where:{userId:ctx.user.id},orderBy:{attemptNo:"desc"}}}}),
 ]); }
 return <><Header active="/campus" workspace="student"/><StudentNav active="/campus/assessments"/><main>
  <section className="page-hero"><div className="container"><div className="eyebrow">Exams & Assessments · Course Work</div><h1>Course Work</h1><p>View and submit your course work assignments and knowledge checks for your enrolled modules.</p></div></section>
  <section className="section"><div className="container">{!enr?<div className="panel"><h2>Enrollment required</h2><p>Course work becomes available after enrolment.</p></div>:!ctx.canAccessLearning?<div className="access-banner"><strong>Course work is locked.</strong> Clear the required period fee to unlock learning access. <Link href="/campus/finance">View finance</Link>.</div>:<div className="grid grid-2">
   <div><div className="eyebrow">Assignments</div><h2>Assignments</h2>{assignments.length?<div className="stack">{assignments.map(a=><div className="card" key={a.id}><span className="chip">{a.course.code}</span><h3>{a.title}</h3><p>{a.dueAt?`Due ${a.dueAt.toLocaleString("en-UG")}`:"No deadline set"}</p><div className="tile-meta">{a.submissions[0]?.status?humanStatus(a.submissions[0].status):"Not submitted"}</div><div className="actions"><Link href={`/campus/assessments/assignments/${a.id}`} className="btn btn-primary btn-sm">{a.submissions[0]?.status?"Open submission":"Start assignment"}</Link></div></div>)}</div>:<div className="panel"><p>No published assignments.</p></div>}</div>
   <div><div className="eyebrow">Knowledge checks</div><h2>Quizzes</h2>{quizzes.length?<div className="stack">{quizzes.map(q=><div className="card" key={q.id}><span className="chip">{q.course.code}</span><h3>{q.title}</h3><p>{q.timeLimitMinutes?`${q.timeLimitMinutes} minutes · `:""}{q.attemptsAllowed} attempt(s)</p><div className="tile-meta">{q.attempts[0]?.status?humanStatus(q.attempts[0].status):"Not started"}</div><div className="actions"><Link href={`/campus/assessments/quizzes/${q.id}`} className="btn btn-outline-dark btn-sm">Open quiz</Link></div></div>)}</div>:<div className="panel"><p>No published quizzes.</p></div>}</div>
  </div>}<div className="actions" style={{marginTop:28}}><Link href="/campus/assessments" className="btn btn-outline-dark btn-sm">← Exams & Assessments</Link></div></div></section>
 </main><Footer/></>;
}
