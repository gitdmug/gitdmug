import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { StudentNav } from "@/components/StudentNav";
import { GITDM } from "@/lib/branding";
import { getAuthoritativeEnrollmentCourseIds, requireStudentSession } from "@/lib/student";
import { getDb } from "@/lib/db";

export const dynamic = "force-dynamic";
export const metadata = { title: `Examinations | Exams & Assessments | ${GITDM.shortName}` };

export default async function ExaminationsPage(){
 const ctx=await requireStudentSession("/campus/assessments/exams"); const enr=ctx.primaryEnrollment; const db=getDb(); let exams:any[]=[];
 if(enr&&db){ const courseIds=await getAuthoritativeEnrollmentCourseIds(db,enr); exams=await db.exam.findMany({where:{courseId:{in:courseIds},status:"PUBLISHED",OR:[{periodId:null},{periodId:enr.period?.id||""}]},orderBy:{opensAt:"asc"},include:{course:true,period:true,attempts:{where:{userId:ctx.user.id},orderBy:{attemptNo:"desc"}}}}); }
 return <><Header active="/campus" workspace="student"/><StudentNav active="/campus/assessments"/><main>
  <section className="page-hero"><div className="container"><div className="eyebrow">Exams & Assessments · Examinations</div><h1>Examinations</h1><p>Access your scheduled examinations, check eligibility and submit your answers online.</p></div></section>
  <section className="section"><div className="container">{!enr?<div className="panel"><h2>Enrollment required</h2><p>Examinations become available after enrolment.</p></div>:!exams.length?<div className="panel"><h2>No published examinations</h2><p>Your Examination Office has not published an examination for your current enrolment period yet.</p></div>:<div className="stack">{exams.map(e=>{const latest=e.attempts[0]; return <div className="card" key={e.id}><div style={{display:"flex",justifyContent:"space-between",gap:16,alignItems:"flex-start"}}><div><span className="chip chip-accent">{e.course.code}</span><h2 style={{marginTop:10}}>{e.title}</h2></div><span className={ctx.canAccessExams?"badge":"badge locked"}>{ctx.canAccessExams?"Eligible by fee":"Fee gate closed"}</span></div><p>{e.opensAt?`Opens ${e.opensAt.toLocaleString("en-UG")}`:"Schedule pending"}{e.closesAt?` · Closes ${e.closesAt.toLocaleString("en-UG")}`:""}</p><div className="tile-meta">{e.attemptsAllowed} attempt(s) · {e.timeLimitMinutes||"No"} minute limit · {e.deliveryMode}</div>{latest?.status&&latest.status!=="NOT_STARTED"?<div className="tile-meta">Latest attempt: {latest.status.replaceAll("_"," ")}</div>:null}<div className="actions">{ctx.canAccessExams?<Link href={`/campus/assessments/exams/${e.id}`} className="btn btn-primary btn-sm">Open examination</Link>:<Link href="/campus/finance" className="btn btn-outline-dark btn-sm">View finance</Link>}</div></div>})}</div>}<div className="actions" style={{marginTop:28}}><Link href="/campus/assessments" className="btn btn-outline-dark btn-sm">← Exams & Assessments</Link></div></div></section>
 </main><Footer/></>;
}
