import { redirect, notFound } from "next/navigation";
import Link from "next/link";
import { Header } from "@/components/Header";
import { ExamTimer } from "@/components/ExamTimer";
import { Footer } from "@/components/Footer";
import { StudentNav } from "@/components/StudentNav";
import { requireStudentSession } from "@/lib/student";
import { getDb } from "@/lib/db";
import { startOrSubmitExam } from "./actions";

export const dynamic = "force-dynamic";

export default async function ExamPage({ params, searchParams }: { params: Promise<{ examId: string }>; searchParams: Promise<{ submitted?: string }> }) {
  const { examId } = await params;
  const qs = await searchParams;
  const ctx = await requireStudentSession(`/campus/assessments/exams/${examId}`);
  if (!ctx.canAccessExams && !ctx.isStaff) redirect("/campus/assessments");
  const db = getDb();
  if (!db) redirect("/campus");
  const exam = await db.exam.findFirst({
    where: { id: examId, status: "PUBLISHED" },
    include: {
      course: true,
      period: true,
      questions: { orderBy: { orderIndex: "asc" } },
      documents: true,
      attempts: { where: { userId: ctx.user.id }, orderBy: { attemptNo: "desc" }, include: { submissionFiles: true } },
    },
  });
  if (!exam) notFound();

  const active = exam.attempts.find((a) => a.status === "IN_PROGRESS");
  const latest = exam.attempts.find((a) => a.status !== "IN_PROGRESS");
  const used = exam.attempts.filter((a) => a.status !== "ABANDONED").length;
  const now = new Date();
  const windowOpen = (!exam.opensAt || now >= exam.opensAt) && (!exam.closesAt || now <= exam.closesAt);
  let attendance = 100;
  if (!ctx.isStaff) {
    const rec = await db.attendanceRecord.findMany({ where: { userId: ctx.user.id, courseId: exam.courseId, periodId: exam.periodId || undefined } });
    attendance = rec.length ? rec.filter((r) => r.status !== "ABSENT").length / rec.length * 100 : 100;
  }
  const eligible = ctx.isStaff || (ctx.canAccessExams && attendance >= 70);
  const resultVisible = latest?.finalScore != null && (!exam.resultsReleaseAt || now >= exam.resultsReleaseAt);

  return (
    <>
      <Header active="/campus" workspace="student" />
      <StudentNav active="/campus/assessments" />
      <main>
        <section className="page-hero"><div className="container"><div className="eyebrow">{exam.course.code} · Formal Examination</div><h1>{exam.title}</h1><p>{exam.deliveryMode} · {exam.submissionMode.replaceAll("_", " ")} · {exam.timeLimitMinutes ? `${exam.timeLimitMinutes} minutes · ` : ""}{exam.attemptsAllowed} attempt(s)</p></div></section>
        <section className="section"><div className="container">
          {qs.submitted ? <div className="access-banner"><strong>Submission received.</strong> Your attempt is now with the Examination Office for marking. Keep this page and your notification as your submission record.</div> : null}

          <div className="grid grid-3" style={{ marginBottom: 28 }}>
            <div className="panel"><div className="eyebrow">Schedule</div><h3>{exam.opensAt ? exam.opensAt.toLocaleString("en-UG") : "Open on publication"}</h3><p>{exam.closesAt ? `Closes ${exam.closesAt.toLocaleString("en-UG")}` : "No closing time published"}</p></div>
            <div className="panel"><div className="eyebrow">Eligibility</div><h3>{eligible ? "Eligible" : "Not eligible"}</h3><p>Fees: {ctx.canAccessExams ? "cleared" : "not cleared"} · Attendance: {attendance.toFixed(1)}%</p></div>
            <div className="panel"><div className="eyebrow">Submission</div><h3>{exam.submissionMode.replaceAll("_", " ")}</h3><p>{exam.venue || "Online examination room"}{exam.room ? ` · ${exam.room}` : ""}</p></div>
          </div>

          <div className="grid grid-2" style={{ alignItems: "start" }}>
            <div className="card">
              <div className="eyebrow">Exam brief</div><h2>How this examination works</h2>
              <p>{exam.instructions || "Read every question, answer all required items, save your work, then submit once you are satisfied. After submission the attempt is locked for marking."}</p>
              <p><strong>Format:</strong> {exam.formatDescription || "Structured online questions."}</p>
              {exam.permitRequired ? <p><Link href={`/campus/assessments/exams/${exam.id}/permit`} className="btn btn-outline-dark btn-sm">View / print exam permit</Link></p> : null}
              <p><strong>Submission destination:</strong> GITDM Examination System. Your answers and any uploaded files are stored against this attempt.</p>
              {exam.documents.length ? <div className="stack">{exam.documents.map((d) => <div className="staff-notice" key={d.id}><div><strong>{d.title}</strong><p>{d.type.replaceAll("_", " ")}</p></div><a className="btn btn-outline-dark btn-sm" href={d.url.startsWith("neonfile:") ? `/api/campus/files/exam-document/${d.id}` : d.url} target="_blank" rel="noreferrer">Open</a></div>)}</div> : null}
            </div>
            <div className="card">
              <div className="eyebrow">Outcome</div><h2>What happens after submission</h2>
              <ol><li>Submission is time-stamped and locked.</li><li>Objective questions are auto-marked; written/file responses go to manual review.</li><li>The Examination Office finalizes the attempt.</li><li>Academic results are synchronized into your course grade.</li><li>After publication, the result appears in Results & Transcript.</li></ol>
              {latest?.status && latest.status !== "IN_PROGRESS" ? <div className="access-banner"><strong>Latest attempt:</strong> {latest.status.replaceAll("_", " ")} {latest.submittedAt ? `· ${latest.submittedAt.toLocaleString("en-UG")}` : ""}</div> : null}
              {resultVisible ? <div className="panel" style={{ marginTop: 12 }}><strong>Exam result: {Number(latest!.finalScore).toFixed(1)}%</strong><p>Published result availability is now open for this examination attempt.</p></div> : latest?.finalScore != null ? <div className="panel" style={{ marginTop: 12 }}>A score exists, but the published release time has not been reached.</div> : null}
            </div>
          </div>

          {!active && used >= exam.attemptsAllowed ? (
            <div className="panel" style={{ marginTop: 28 }}><h2>No attempts remaining</h2><p>Contact the Examination Office through Requests & Applications if you believe your attempt entitlement is incorrect.</p></div>
          ) : !active ? (
            <form action={startOrSubmitExam} className="panel" style={{ marginTop: 28 }}>
              <input type="hidden" name="examId" value={exam.id} /><input type="hidden" name="action" value="start" />
              <h2>Enter examination room</h2><p>{windowOpen ? "Starting creates your official server-side attempt. Do not start until you are ready to sit the examination." : "The published examination window is currently closed."}</p>
              <button className="btn btn-primary" disabled={!eligible || !windowOpen}>Start examination</button>
            </form>
          ) : (
            <form action={startOrSubmitExam} className="stack" style={{ marginTop: 28 }} encType="multipart/form-data">
              <input type="hidden" name="examId" value={exam.id} /><input type="hidden" name="attemptId" value={active.id} />
              {exam.timeLimitMinutes ? <ExamTimer startedAt={active.startedAt!.toISOString()} timeLimit={exam.timeLimitMinutes} /> : null}
              <div className="access-banner"><strong>Attempt {active.attemptNo} in progress.</strong> Save your answers before final submission. Final submission locks the attempt.</div>
              {exam.questions.map((q, i) => {
                let options: string[] = [];
                try { options = q.optionsJson ? JSON.parse(q.optionsJson) : []; } catch {}
                return <div className="card" key={q.id}>
                  <span className="eyebrow">Question {i + 1} · {Number(q.marks)} mark(s) · {q.type.replaceAll("_", " ")}</span><h3 style={{ marginTop: 8 }}>{q.prompt}</h3>
                  {options.length ? q.type === "MULTIPLE_CHOICE" ? options.map((o) => <label key={o} style={{ display: "block", padding: "8px 0" }}><input type="checkbox" name={`q_${q.id}`} value={o} /> {o}</label>) : options.map((o) => <label key={o} style={{ display: "block", padding: "8px 0" }}><input type="radio" name={`q_${q.id}`} value={o} /> {o}</label>) : q.type === "LINK_RESPONSE" ? <input name={`q_${q.id}`} type="url" placeholder="Paste your TradingView / research / supporting link" required /> : <textarea name={`q_${q.id}`} rows={6} placeholder="Type your answer here" />}
                </div>;
              })}
              {["FILE_UPLOAD", "ONLINE_AND_FILE"].includes(exam.submissionMode) ? <div className="card"><h3>Attach completed answer file</h3><p>Upload the completed answer script in the format specified by the Examination Office. The file becomes part of this attempt record.</p><input type="file" name="submissionFile" accept=".pdf,.doc,.docx,.ppt,.pptx,.xls,.xlsx,.jpg,.jpeg,.png,.mp4,.mp3,.zip,.txt" multiple /></div> : null}
              <div className="actions"><button className="btn btn-outline-dark" name="action" value="save">Save draft answers</button><button className="btn btn-primary" name="action" value="submit">Submit final exam</button></div>
            </form>
          )}

          <div className="actions"><Link href="/campus/assessments" className="btn btn-outline-dark btn-sm">← Exams & Assessments</Link><Link href="/campus/requests" className="btn btn-outline-dark btn-sm">Contact Examination Office</Link></div>
        </div></section>
      </main>
      <Footer />
    </>
  );
}
