"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { requireStudentSession } from "@/lib/student";
import { getDb } from "@/lib/db"; import { notifyStudentChange } from "@/lib/student-email";
import { uploadPrivateFile } from "@/lib/file-storage";

function parseAnswer(question: any, formData: FormData) {
  const key = `q_${question.id}`;
  const values = formData.getAll(key).map(String).filter(Boolean);
  return question.type === "MULTIPLE_CHOICE" ? values : (values[0] || "");
}
function isCorrect(question:any, answer:any){
  try { const correct=JSON.parse(question.correctJson||"null"); if(Array.isArray(correct)){const a=Array.isArray(answer)?answer:[answer];return JSON.stringify([...a].sort())===JSON.stringify([...correct].map(String).sort());} return String(correct)===String(answer); } catch { return false; }
}
async function eligibility(db:any, ctx:any, exam:any){
 if(ctx.isStaff) return;
 if(!ctx.canAccessExams) throw new Error("Your exam fee-clearance requirement has not been met.");
 // Use ClassAttendanceRecord (browser join/pulse + Google Meet sync) so recorded class presence qualifies students for exams.
 const records=await db.classAttendanceRecord.findMany({where:{userId:ctx.user.id,courseId:exam.courseId,periodId:exam.periodId||undefined}});
 const attendance=records.length?records.filter((r:any)=>r.status!=="ABSENT").length/records.length*100:100;
 if(attendance<70) throw new Error(`Exam access is blocked because attendance is ${attendance.toFixed(1)}%; the minimum is 70%.`);
}
export async function startOrSubmitExam(formData:FormData){
 const ctx=await requireStudentSession("/campus/assessments"); const db=getDb(); if(!db)redirect("/campus");
 const examId=String(formData.get("examId")||""); const action=String(formData.get("action")||"");
 const exam=await db.exam.findUnique({where:{id:examId},include:{course:true,questions:{orderBy:{orderIndex:"asc"}},attempts:{where:{userId:ctx.user.id},orderBy:{attemptNo:"desc"}}}}); if(!exam)throw new Error("Exam unavailable.");
 await eligibility(db,ctx,exam);
 const now=new Date();
 if(action==="start"){
   if(exam.status!=="PUBLISHED")throw new Error("Exam is not currently published.");
   if(exam.opensAt&&now<exam.opensAt)throw new Error("Exam has not opened yet.");
   if(exam.closesAt&&now>exam.closesAt)throw new Error("The exam window has closed.");
   const active=exam.attempts.find(a=>a.status==="IN_PROGRESS"); if(active)redirect(`/campus/assessments/exams/${exam.id}`);
   const used=exam.attempts.filter(a=>a.status!=="ABANDONED").length; if(used>=exam.attemptsAllowed)throw new Error("No attempts remaining.");
   const attempt=await db.examAttempt.create({data:{examId,userId:ctx.user.id,attemptNo:used+1,status:"IN_PROGRESS",startedAt:now}});
   await db.auditLog.create({data:{userId:ctx.user.id,action:"EXAM_STARTED",entity:"ExamAttempt",entityId:attempt.id,metadataJson:JSON.stringify({examId,attemptNo:used+1})}});
   revalidatePath(`/campus/assessments/exams/${examId}`); redirect(`/campus/assessments/exams/${examId}`);
 }
 const attemptId=String(formData.get("attemptId")||""); const attempt=await db.examAttempt.findFirst({where:{id:attemptId,examId,userId:ctx.user.id,status:"IN_PROGRESS"}}); if(!attempt)throw new Error("Active exam attempt not found.");
 if(exam.opensAt&&now<exam.opensAt)throw new Error("Exam has not opened.");
 if(exam.closesAt&&now>exam.closesAt&&!exam.lateSubmissionAllowed)throw new Error("The exam window has closed and late submission is not allowed.");
 if(exam.timeLimitMinutes&&attempt.startedAt&&now.getTime()-attempt.startedAt.getTime()>exam.timeLimitMinutes*60000+30000)throw new Error("The examination time has expired.");
 const saveOnly=action==="save";
 let auto=0; let autoPossible=true;
 for(const question of exam.questions){
   const answer=parseAnswer(question,formData); const objective=["SINGLE_CHOICE","MULTIPLE_CHOICE","TRUE_FALSE","NUMERICAL"].includes(question.type); if(!objective)autoPossible=false; const marks=objective&&question.correctJson&&answer!==""&&(!Array.isArray(answer)||answer.length)?(isCorrect(question,answer)?Number(question.marks):0):null; if(marks!==null)auto+=marks;
   await db.examAnswer.upsert({where:{attemptId_questionId:{attemptId,questionId:question.id}},update:{answerJson:JSON.stringify(answer),autoMarks:marks},create:{attemptId,questionId:question.id,answerJson:JSON.stringify(answer),autoMarks:marks}});
 }
 if(saveOnly){await db.auditLog.create({data:{userId:ctx.user.id,action:"EXAM_DRAFT_SAVED",entity:"ExamAttempt",entityId:attempt.id}});revalidatePath(`/campus/assessments/exams/${examId}`);return;}
 const files=formData.getAll("submissionFile"); for(const file of files){ if(file instanceof File&&file.size>0){const url=await uploadPrivateFile(file,"gitdm/exam-submissions",`${ctx.user.id}-${attempt.id}`);await db.examSubmissionFile.create({data:{attemptId:attempt.id,originalName:file.name,url}}); } }
 const max=exam.questions.reduce((s,q)=>s+Number(q.marks),0);const pct=autoPossible&&max?auto/max*100:null;
 const status=pct===null?"MANUAL_REVIEW":"AUTO_MARKED";
 await db.examAttempt.update({where:{id:attempt.id},data:{status,submittedAt:now,autoScore:pct,finalScore:pct}});
 await db.auditLog.create({data:{userId:ctx.user.id,action:"EXAM_SUBMITTED",entity:"ExamAttempt",entityId:attempt.id,metadataJson:JSON.stringify({examId,autoScore:pct,submissionMode:exam.submissionMode})}});
 await db.notification.create({data:{userId:ctx.user.id,type:"ACADEMIC",title:"Examination submitted",body:`${exam.course.code} — ${exam.title}: your attempt has been received by the GITDM examination system and is now in ${status.replaceAll("_"," ")} status.`}});
 await notifyStudentChange({userId:ctx.user.id,email:ctx.user.email,firstName:ctx.user.firstName,title:"Examination submitted",body:`${exam.course.code} — ${exam.title}: your attempt has been received and is now in ${status.replaceAll("_"," ")} status.`,action:"EXAM_SUBMITTED",event:"EXAM_SUBMITTED",href:"/campus/assessments"});
 revalidatePath(`/campus/assessments/exams/${examId}`);revalidatePath("/campus/assessments");redirect(`/campus/assessments/exams/${examId}?submitted=1`);
}
