import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { StudentNav } from "@/components/StudentNav";
import { GITDM } from "@/lib/branding";
import { requireStudentSession } from "@/lib/student";
import { getDb } from "@/lib/db";

export const dynamic = "force-dynamic";
export const metadata = { title: `Examination Results | Exams & Assessments | ${GITDM.shortName}` };

export default async function ExaminationResultsPage(){
 const ctx=await requireStudentSession("/campus/assessments/results"); const db=getDb(); let exams:any[]=[];
 if(db){ exams=await db.exam.findMany({where:{status:"PUBLISHED",attempts:{some:{userId:ctx.user.id,finalScore:{not:null}}}},orderBy:{opensAt:"desc"},include:{course:true,attempts:{where:{userId:ctx.user.id,finalScore:{not:null}},orderBy:{attemptNo:"desc"}}}}); }
 return <><Header active="/campus" workspace="student"/><StudentNav active="/campus/assessments"/><main>
  <section className="page-hero"><div className="container"><div className="eyebrow">Exams & Assessments · Examination Results</div><h1>Examination Results</h1><p>View your published examination results and examination record.</p></div></section>
  <section className="section"><div className="container">{!exams.length?<div className="panel"><h2>No published examination results</h2><p>When the Examination Office releases a result for one of your examination attempts, it will appear here.</p></div>:<div className="stack">{exams.map(e=>{const attempt=e.attempts[0]; return <div className="card" key={e.id}><span className="chip chip-accent">{e.course.code}</span><h2 style={{marginTop:10}}>{e.title}</h2><div className="grid grid-3" style={{marginTop:18}}><div className="panel"><div className="eyebrow">Result</div><h2>{Number(attempt.finalScore).toFixed(1)}%</h2><p>Published examination score</p></div><div className="panel"><div className="eyebrow">Attempt</div><h3>#{attempt.attemptNo}</h3><p>{attempt.submittedAt?`Submitted ${attempt.submittedAt.toLocaleDateString("en-UG")}`:"Submission date unavailable"}</p></div><div className="panel"><div className="eyebrow">Status</div><h3>{attempt.status.replaceAll("_"," ")}</h3><p>Official examination attempt</p></div></div></div>})}</div>}<div className="actions" style={{marginTop:28}}><Link href="/campus/assessments" className="btn btn-outline-dark btn-sm">← Exams & Assessments</Link><Link href="/campus/academic/transcript" className="btn btn-outline-dark btn-sm">Academic Transcript</Link></div></div></section>
 </main><Footer/></>;
}
