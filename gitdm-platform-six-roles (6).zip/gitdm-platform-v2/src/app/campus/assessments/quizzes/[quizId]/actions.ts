"use server";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { getCurrentUser } from "@/lib/access";
import { getDb } from "@/lib/db"; import { notifyStudentChange } from "@/lib/student-email";

export async function startQuiz(formData: FormData) {
  const user = await getCurrentUser();
  const db = getDb();
  if (!user || !db) throw new Error("Unauthorized");
  const quizId = String(formData.get("quizId") || "");
  const q = await db.quiz.findFirst({ where: { id: quizId, status: "PUBLISHED" }, include: { attempts: { where: { userId: user.id }, orderBy: { attemptNo: "desc" } } } });
  if (!q) throw new Error("Quiz unavailable.");

  const active = q.attempts.find((attempt) => attempt.status === "IN_PROGRESS");
  if (active) {
    if (q.timeLimitMinutes && active.startedAt && Date.now() - active.startedAt.getTime() > q.timeLimitMinutes * 60_000) {
      await db.quizAttempt.update({ where: { id: active.id }, data: { status: "ABANDONED" } });
    } else {
      redirect(`/campus/assessments/quizzes/${quizId}`);
    }
  }

  const attemptNo = (q.attempts[0]?.attemptNo || 0) + 1;
  if (attemptNo > q.attemptsAllowed) throw new Error("No attempts remaining.");
  await db.quizAttempt.create({ data: { quizId, userId: user.id, attemptNo, status: "IN_PROGRESS", startedAt: new Date() } });
  revalidatePath(`/campus/assessments/quizzes/${quizId}`);
  redirect(`/campus/assessments/quizzes/${quizId}`);
}

export async function submitQuiz(formData: FormData) {
  const user = await getCurrentUser();
  const db = getDb();
  if (!user || !db) throw new Error("Unauthorized");
  const quizId = String(formData.get("quizId") || "");
  const q = await db.quiz.findFirst({
    where: { id: quizId, status: "PUBLISHED" },
    include: { questions: true, attempts: { where: { userId: user.id }, orderBy: { attemptNo: "desc" } } },
  });
  if (!q) throw new Error("Quiz unavailable.");

  const attempt = q.attempts.find((item) => item.status === "IN_PROGRESS");
  if (!attempt || !attempt.startedAt) throw new Error("Start the quiz before submitting it.");
  const expired = Boolean(q.timeLimitMinutes && Date.now() - attempt.startedAt.getTime() > q.timeLimitMinutes * 60_000 + 30_000);
  if (expired) {
    await db.quizAttempt.update({ where: { id: attempt.id }, data: { status: "ABANDONED", submittedAt: new Date() } });
    await db.auditLog.create({ data: { userId: user.id, action: "QUIZ_TIMED_OUT", entity: "QuizAttempt", entityId: attempt.id, metadataJson: JSON.stringify({ quizId }) } });
    throw new Error("The quiz time limit has expired. Your attempt was closed.");
  }

  let score = 0;
  for (const question of q.questions) {
    const answer = String(formData.get(`q_${question.id}`) || "");
    let correct = false;
    try {
      const parsed = JSON.parse(question.correctJson || "null");
      correct = Array.isArray(parsed) ? parsed.includes(answer) : parsed === answer;
    } catch {}
    const marks = correct ? Number(question.marks) : 0;
    score += marks;
    await db.quizAnswer.upsert({
      where: { attemptId_questionId: { attemptId: attempt.id, questionId: question.id } },
      update: { answerJson: JSON.stringify(answer), isCorrect: correct, marks },
      create: { attemptId: attempt.id, questionId: question.id, answerJson: JSON.stringify(answer), isCorrect: correct, marks },
    });
  }
  const max = q.questions.reduce((sum, x) => sum + Number(x.marks), 0);
  const pct = max ? score / max * 100 : 0;
  await db.quizAttempt.update({ where: { id: attempt.id }, data: { status: "AUTO_MARKED", submittedAt: new Date(), score: pct } });
  await db.auditLog.create({ data: { userId: user.id, action: "QUIZ_SUBMITTED", entity: "QuizAttempt", entityId: attempt.id, metadataJson: JSON.stringify({ quizId, score: pct }) } });
  await db.notification.create({data:{userId:user.id,type:"ACADEMIC",title:"Quiz marked",body:`${q.title}: you scored ${pct.toFixed(1)}%. This result is included in the course assessment record.`}});
 await notifyStudentChange({userId:user.id,email:user.email,firstName:user.firstName,title:"Quiz marked",body:`${q.title}: you scored ${pct.toFixed(1)}%. This result is included in the course assessment record.`,action:"QUIZ_MARKED",event:"QUIZ_MARKED",href:"/campus/assessments"});
  revalidatePath(`/campus/assessments/quizzes/${quizId}`);
  revalidatePath("/campus/assessments");
}
