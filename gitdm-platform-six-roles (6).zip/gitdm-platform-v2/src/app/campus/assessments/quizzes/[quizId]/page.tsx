import Link from "next/link";
import { redirect, notFound } from "next/navigation";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { StudentNav } from "@/components/StudentNav";
import { GITDM } from "@/lib/branding";
import { requireStudentSession } from "@/lib/student";
import { getDb } from "@/lib/db";
import { ExamTimer } from "@/components/ExamTimer";
import { startQuiz, submitQuiz } from "./actions";

export const dynamic = "force-dynamic";

export default async function QuizPage({ params }: { params: Promise<{ quizId: string }> }) {
  const { quizId } = await params;
  const ctx = await requireStudentSession(`/campus/assessments/quizzes/${quizId}`);
  if (!ctx.canAccessLearning) redirect("/campus/finance");
  const db = getDb();
  if (!db) redirect("/campus");
  const q = await db.quiz.findFirst({
    where: { id: quizId, status: "PUBLISHED" },
    include: {
      course: true,
      questions: { orderBy: { orderIndex: "asc" } },
      attempts: { where: { userId: ctx.user.id }, orderBy: { attemptNo: "desc" } },
    },
  });
  if (!q) notFound();

  let active = q.attempts.find((attempt) => attempt.status === "IN_PROGRESS");
  if (active && q.timeLimitMinutes && active.startedAt && Date.now() - active.startedAt.getTime() > q.timeLimitMinutes * 60_000) {
    await db.quizAttempt.update({ where: { id: active.id }, data: { status: "ABANDONED" } });
    active = undefined;
  }
  const used = q.attempts.filter((a) => a.status !== "ABANDONED").length;
  const completed = q.attempts.find((a) => ["AUTO_MARKED", "FINALIZED", "MANUAL_REVIEW", "SUBMITTED"].includes(a.status));

  return (
    <>
      <Header active="/campus" workspace="student" />
      <StudentNav active="/campus/assessments" />
      <main>
        <section className="page-hero"><div className="container">
          <div className="eyebrow">{q.course.code} · Quiz</div>
          <h1>{q.title}</h1>
          <p>{q.timeLimitMinutes ? `${q.timeLimitMinutes} minutes · ` : "Self-paced · "}{q.attemptsAllowed} attempt(s) · Pass mark {Number(q.passMarkPercent)}%</p>
        </div></section>
        <section className="section"><div className="container">
          {completed && !active ? (
            <div className="access-banner full"><strong>Latest attempt: {completed.score != null ? `${Number(completed.score).toFixed(1)}%` : "submitted"}.</strong> Start another attempt only if your allowed attempts have not been exhausted.</div>
          ) : null}
          {!active && used >= q.attemptsAllowed ? (
            <div className="panel"><h2>No attempts remaining</h2><p>You have used the allowed attempts. Contact your academic team if a review is required.</p></div>
          ) : !active ? (
            <div className="card" style={{ maxWidth: 760 }}>
              <div className="eyebrow">Ready when you are</div>
              <h2>Start the timed activity</h2>
              <p>Once you start, the server records the attempt start time. If a time limit is configured, it cannot be extended by refreshing the page or leaving the browser open.</p>
              <form action={startQuiz}><input type="hidden" name="quizId" value={q.id}/><button className="btn btn-primary" type="submit">Start quiz</button></form>
            </div>
          ) : (
            <form action={submitQuiz} className="stack">
              <input type="hidden" name="quizId" value={q.id} />
              {q.timeLimitMinutes ? <ExamTimer startedAt={active.startedAt!.toISOString()} timeLimit={q.timeLimitMinutes} /> : null}
              {q.questions.map((question, i) => {
                let options: string[] = [];
                try { options = question.optionsJson ? JSON.parse(question.optionsJson) : []; } catch {}
                return (
                  <div className="card" key={question.id}>
                    <span className="eyebrow">Question {i + 1} · {Number(question.marks)} mark(s)</span>
                    <h3 style={{ marginTop: 8 }}>{question.prompt}</h3>
                    {options.length ? options.map((option) => (
                      <label key={option} style={{ display: "block", padding: "8px 0" }}>
                        <input type="radio" name={`q_${question.id}`} value={option} /> {option}
                      </label>
                    )) : <textarea name={`q_${question.id}`} placeholder="Your answer" />}
                  </div>
                );
              })}
              <button className="btn btn-primary" type="submit">Submit quiz</button>
            </form>
          )}
          <div className="actions"><Link href="/campus/assessments" className="btn btn-outline-dark btn-sm">← Exams & Assessments</Link></div>
        </div></section>
      </main><Footer />
    </>
  );
}
