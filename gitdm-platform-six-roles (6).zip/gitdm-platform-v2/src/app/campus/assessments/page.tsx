import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { StudentNav } from "@/components/StudentNav";
import { GITDM } from "@/lib/branding";
import { requireStudentSession } from "@/lib/student";

export const metadata = { title: `Exams & Assessments | Campus | ${GITDM.shortName}` };
export const dynamic = "force-dynamic";

const cards = [
  { href: "/campus/assessments/course-work", title: "Course Work", text: "View and submit your course work assignments for all enrolled modules.", icon: "▤" },
  { href: "/campus/assessments/exams", title: "Examinations", text: "Access your scheduled examinations, check eligibility and submit your answers online.", icon: "⌛" },
  { href: "/campus/assessments/results", title: "Examination Results", text: "View your published examination results and examination record.", icon: "◇" },
];

export default async function AssessmentsPage() {
  await requireStudentSession("/campus/assessments");
  return <><Header active="/campus" workspace="student" /><StudentNav active="/campus/assessments" /><main>
    <section className="page-hero"><div className="container"><div className="eyebrow">Exams & Assessments</div><h1>Exams & Assessments</h1><p>Manage your course work, examinations, and view your results.</p></div></section>
    <section className="section"><div className="container">
      <div className="grid grid-3">{cards.map((card)=><Link href={card.href} className="card" key={card.href} style={{textDecoration:"none",display:"block",borderLeft:"6px solid var(--brand-blue, #2876bd)"}}>
        <div style={{display:"flex",justifyContent:"space-between",alignItems:"flex-start",gap:16}}><div><h2>{card.title}</h2><p style={{marginTop:12}}>{card.text}</p><div className="tile-meta" style={{marginTop:18}}>→</div></div><span aria-hidden="true" style={{fontSize:28,lineHeight:1,background:"#eef4f9",padding:"12px 15px",borderRadius:14}}>{card.icon}</span></div>
      </Link>)}</div>
    </div></section>
  </main><Footer /></>;
}
