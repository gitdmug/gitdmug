import Link from "next/link";
import { redirect } from "next/navigation";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { StudentNav } from "@/components/StudentNav";
import { GITDM } from "@/lib/branding";
import { requireStudentSession } from "@/lib/student";

export const dynamic = "force-dynamic";
export const metadata = { title: `Course Catalogue | Campus | ${GITDM.shortName}` };

/**
 * Enrolled learners do not use the public course catalogue. Their academic
 * courses are already available through My Learning. Keep this route as a
 * compatibility entry point for older bookmarks/links and redirect enrolled
 * learners to the canonical learning workspace.
 */
export default async function StudentCourseCatalogue() {
  const ctx = await requireStudentSession("/campus/courses");

  if (ctx.primaryEnrollment) {
    redirect("/campus/learning");
  }

  return (
    <>
      <Header active="/campus" workspace="student" />
      <StudentNav active="/campus/courses" />
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">GITDM course catalogue</div>
            <h1>Course catalogue</h1>
            <p>
              The course catalogue is available before institutional enrollment.
              Once you are enrolled, your assigned courses are managed from My
              Learning.
            </p>
          </div>
        </section>
        <section className="section">
          <div className="container">
            <div className="panel">
              <h2>Enrollment required</h2>
              <p>
                Your available academic courses will appear in My Learning once
                your institutional enrollment is active.
              </p>
              <div className="actions" style={{ marginTop: 20 }}>
                <Link href="/campus/learning" className="btn btn-primary btn-sm">
                  My Learning
                </Link>
                <Link href="/campus/timetable" className="btn btn-outline-dark btn-sm">
                  My Timetable
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
