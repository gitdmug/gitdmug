import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { StudentNav } from "@/components/StudentNav";
import { GITDM } from "@/lib/branding";
import { getAuthoritativeEnrollmentCourseIds, requireStudentSession } from "@/lib/student";
import { getDb } from "@/lib/db";
import { ACTIVE_COURSE_CODES } from "@/lib/current-catalogue";
import { courseDisplayTitle } from "@/lib/course-display";

export const metadata = { title: `My programme | Campus | ${GITDM.shortName}` };
export const dynamic = "force-dynamic";

/**
 * Student My Programme:
 * - Progress across modules and lessons (always visible for enrolled courses)
 * - Live class appears only within 24 hours of start (avoids congestion)
 * - Materials uploaded by lecturer become available when the class window opens
 */
export default async function LearningPage() {
  const ctx = await requireStudentSession("/campus/learning");
  const enr = ctx.primaryEnrollment;
  const db = getDb();
  const now = new Date();
  const in24h = new Date(now.getTime() + 24 * 60 * 60 * 1000);

  let courses: any[] = [];
  let nextClass: any = null;

  if (enr && ctx.canAccessLearning && db) {
    const selectedIds = await getAuthoritativeEnrollmentCourseIds(db, enr);
    if (selectedIds.length) {
      courses = await db.course.findMany({
        where: {
          id: { in: selectedIds },
          code: { in: [...ACTIVE_COURSE_CODES] },
          published: true,
        },
        orderBy: [{ orderIndex: "asc" }, { title: "asc" }],
        include: {
          facultyUnit: true,
          modules: {
            where: { published: true, approvalStatus: "APPROVED" },
            orderBy: { orderIndex: "asc" },
            include: {
              lessons: {
                where: { published: true },
                orderBy: { orderIndex: "asc" },
                include: { progress: { where: { userId: ctx.user.id } } },
              },
            },
          },
          assignments: { where: { status: "PUBLISHED" }, orderBy: { dueAt: "asc" } },
        },
      });

      nextClass = await db.timetableEvent.findFirst({
        where: {
          type: "CLASS",
          courseId: { in: selectedIds },
          startAt: { gte: now, lte: in24h },
          OR: [{ periodId: enr.periodId }, { periodId: null }],
        },
        include: { course: true, module: true },
        orderBy: { startAt: "asc" },
      });
    }
  }

  return (
    <>
      <Header active="/campus" workspace="student" />
      <StudentNav active="/campus/learning" />
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">My programme</div>
            <h1>Track your learning</h1>
            <p>
              Modules and lessons stay visible so you can track progress. Live classes appear only
              in the 24 hours before they start — with materials and the join link when the lecturer
              has set them.
            </p>
          </div>
        </section>

        <section className="section">
          <div className="container">
            {!enr ? (
              <div className="panel">
                <span className="badge warn">No enrolment</span>
                <p style={{ marginTop: 12 }}>
                  You are not enrolled yet. <Link href="/admissions">Start an application</Link>.
                </p>
              </div>
            ) : !ctx.canAccessLearning ? (
              <div className="access-banner">
                <strong>Learning is locked until fees are cleared.</strong>{" "}
                <Link href="/campus/finance">View finance</Link>
              </div>
            ) : (
              <>
                {/* Next class — only if within 24h */}
                {nextClass ? (
                  <div className="panel" style={{ marginBottom: 28, border: "2px solid var(--primary, #2563eb)" }}>
                    <div className="eyebrow">Next class (open now)</div>
                    <h2 style={{ margin: "4px 0 8px" }}>{nextClass.title || nextClass.course?.title}</h2>
                    <p className="muted" style={{ margin: 0 }}>
                      {nextClass.course?.code} ·{" "}
                      {new Date(nextClass.startAt).toLocaleString("en-UG", {
                        dateStyle: "medium",
                        timeStyle: "short",
                      })}{" "}
                      –{" "}
                      {new Date(nextClass.endAt).toLocaleTimeString("en-UG", {
                        hour: "2-digit",
                        minute: "2-digit",
                      })}
                    </p>
                    <div className="actions" style={{ marginTop: 14 }}>
                      {nextClass.googleMeetUrl || nextClass.joinUrl ? (
                        <a
                          className="btn btn-primary btn-sm"
                          href={nextClass.googleMeetUrl || nextClass.joinUrl}
                          target="_blank"
                          rel="noreferrer"
                        >
                          Join class
                        </a>
                      ) : (
                        <span className="badge">Join link pending from lecturer</span>
                      )}
                      <Link className="btn btn-outline-dark btn-sm" href="/campus/attendance">
                        Attendance
                      </Link>
                    </div>
                  </div>
                ) : (
                  <div className="panel" style={{ marginBottom: 28 }}>
                    <div className="eyebrow">Live classes</div>
                    <h2>No class in the next 24 hours</h2>
                    <p className="muted">
                      When your next session approaches, it will appear here with materials and the join link.
                    </p>
                  </div>
                )}

                {/* Programme progress — modules & lessons */}
                <h2 style={{ marginBottom: 16 }}>Programme modules & progress</h2>
                {courses.length === 0 ? (
                  <div className="panel">
                    <p>No published courses for your enrolment yet.</p>
                  </div>
                ) : (
                  <div className="stack">
                    {courses.map((course) => {
                      const allLessons = course.modules.flatMap((m: any) => m.lessons || []);
                      const done = allLessons.filter((l: any) => l.progress?.some((p: any) => p.completed)).length;
                      const pct = allLessons.length ? Math.round((done / allLessons.length) * 100) : 0;
                      return (
                        <article className="card" key={course.id}>
                          <div style={{ display: "flex", justifyContent: "space-between", gap: 16, flexWrap: "wrap" }}>
                            <div>
                              <span className="chip chip-accent">{course.code}</span>
                              <h2 style={{ marginTop: 8 }}>{courseDisplayTitle(course.code, course.title)}</h2>
                              <p className="muted">{course.modules.length} modules · {allLessons.length} lessons</p>
                            </div>
                            <div style={{ textAlign: "right" }}>
                              <div className="eyebrow">Progress</div>
                              <h2 style={{ margin: 0 }}>{pct}%</h2>
                              <p className="muted">{done}/{allLessons.length} lessons</p>
                            </div>
                          </div>

                          <div className="table-wrap" style={{ marginTop: 16 }}>
                            <table className="data">
                              <thead>
                                <tr>
                                  <th>Module</th>
                                  <th>Lessons</th>
                                  <th>Done</th>
                                  <th></th>
                                </tr>
                              </thead>
                              <tbody>
                                {course.modules.map((m: any) => {
                                  const mDone = (m.lessons || []).filter((l: any) =>
                                    l.progress?.some((p: any) => p.completed)
                                  ).length;
                                  return (
                                    <tr key={m.id}>
                                      <td><strong>{m.title}</strong></td>
                                      <td>{(m.lessons || []).length}</td>
                                      <td>{mDone}</td>
                                      <td>
                                        <Link
                                          className="btn btn-outline-dark btn-sm"
                                          href={`/campus/learning/${course.id}`}
                                        >
                                          Open
                                        </Link>
                                      </td>
                                    </tr>
                                  );
                                })}
                              </tbody>
                            </table>
                          </div>

                          {course.assignments?.length ? (
                            <div style={{ marginTop: 16 }}>
                              <div className="eyebrow">Coursework due</div>
                              <ul style={{ margin: "8px 0 0", paddingLeft: 18 }}>
                                {course.assignments.slice(0, 5).map((a: any) => (
                                  <li key={a.id}>
                                    <Link href={`/campus/assessments/assignments/${a.id}`}>{a.title}</Link>
                                    {a.dueAt ? ` · due ${new Date(a.dueAt).toLocaleDateString("en-UG")}` : ""}
                                  </li>
                                ))}
                              </ul>
                            </div>
                          ) : null}

                          <div className="actions" style={{ marginTop: 14 }}>
                            <Link className="btn btn-primary btn-sm" href={`/campus/learning/${course.id}`}>
                              Continue learning
                            </Link>
                            <Link className="btn btn-outline-dark btn-sm" href="/campus/assessments">
                              Assessments
                            </Link>
                          </div>
                        </article>
                      );
                    })}
                  </div>
                )}
              </>
            )}
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
