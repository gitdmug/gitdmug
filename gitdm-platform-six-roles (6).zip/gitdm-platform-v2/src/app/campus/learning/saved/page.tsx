import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { StudentNav } from "@/components/StudentNav";
import { requireStudentSession } from "@/lib/student";
import { SavedNotes } from "./saved-notes";
export const dynamic="force-dynamic";
export default async function SavedPage(){const ctx=await requireStudentSession("/campus/learning/saved");return <><Header workspace="student"/><StudentNav active="/campus/learning/saved"/><main><section className="page-hero"><div className="container"><div className="eyebrow">My Learning Journey</div><h1>Saved Content & Notes</h1><p>Keep personal study notes and return to saved learning materials from your own workspace.</p></div></section><section className="section"><div className="container"><div className="panel"><h2>My study notes</h2><p style={{marginBottom:18}}>Notes are stored in this browser on this device. They are not shared with instructors or other students.</p><SavedNotes/></div></div></section></main><Footer/></>}
