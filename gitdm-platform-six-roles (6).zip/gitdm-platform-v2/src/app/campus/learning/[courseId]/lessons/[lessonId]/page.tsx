import Link from "next/link";
import { notFound, redirect } from "next/navigation";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { StudentNav } from "@/components/StudentNav";
import { requireStudentSession } from "@/lib/student";
import { getDb } from "@/lib/db";
import { completeLesson } from "./actions";

export const dynamic = "force-dynamic";

export default async function LessonPage({ params }: { params: Promise<{courseId:string;lessonId:string}> }) {
  const {courseId,lessonId}=await params;
  const ctx=await requireStudentSession(`/campus/learning/${courseId}/lessons/${lessonId}`);
  if(!ctx.canAccessLearning) redirect("/campus/finance");
  const db=getDb(); if(!db) redirect("/campus?error=database-unavailable");
  const lesson=await db.lesson.findFirst({where:{id:lessonId,published:true,module:{courseId,published:true,approvalStatus:"APPROVED",course:{enrollments:{some:{enrollment:{userId:ctx.user.id,status:{in:["ACTIVE","REPEATING"]}}}}}}},include:{module:{include:{course:true,lessons:{where:{published:true},orderBy:{orderIndex:"asc"}}}},resources:true,progress:{where:{userId:ctx.user.id}}}});
  if(!lesson) notFound();
  const done=lesson.progress[0]?.completed ?? false;
  return <><Header active="/campus" workspace="student"/><StudentNav active="/campus/learning"/><main>
    <section className="page-hero"><div className="container"><div className="eyebrow">{lesson.module.course.code} · {lesson.module.title}</div><h1>{lesson.title}</h1><p>{lesson.type.replaceAll("_"," ")} {lesson.durationMinutes ? `· ${lesson.durationMinutes} minutes`:""}</p></div></section>
    <section className="section"><div className="container"><article className="card prose">
      {lesson.videoUrl ? <div style={{marginBottom:24}}><a className="btn btn-outline-dark btn-sm" href={lesson.videoUrl} target="_blank" rel="noreferrer">Open lesson video</a></div>:null}
      <div style={{whiteSpace:"pre-wrap"}}>{lesson.content || "This lesson has no written content yet."}</div>
      {lesson.resources.length ? <><h3>Resources</h3><ul>{lesson.resources.map(r=><li key={r.id}><span style={{display:"inline-flex",gap:8,alignItems:"center"}}><a href={r.url.startsWith("neonfile:") ? `/api/campus/files/learning-resource/${r.id}` : r.url} target="_blank" rel="noreferrer">{r.title}</a>{r.url.startsWith("neonfile:") ? <a href={`/api/campus/files/learning-resource/${r.id}?download=1`} className="btn btn-outline-dark btn-sm">Download</a> : null}{r.fileType ? ` · ${r.fileType}` : ""}</span></li>)}</ul></>:null}
      <form action={completeLesson}><input type="hidden" name="lessonId" value={lesson.id}/><input type="hidden" name="courseId" value={courseId}/><button className="btn btn-primary" type="submit">{done ? "Completed ✓" : "Mark lesson complete"}</button></form>
    </article><div className="actions"><Link href="/campus/learning" className="btn btn-outline-dark btn-sm">← My learning</Link><Link href="/campus/assessments" className="btn btn-outline-dark btn-sm">Assessments</Link></div></div></section>
  </main><Footer/></>;
}
