 "use server";
import { revalidatePath } from "next/cache";
import { getDb } from "@/lib/db"; import { notifyStudentChange } from "@/lib/student-email";
import { getCurrentUser } from "@/lib/access";
export async function completeLesson(formData:FormData){
 const user=await getCurrentUser(); const db=getDb(); if(!user||!db) throw new Error("Unauthorized");
 const lessonId=String(formData.get("lessonId")); const courseId=String(formData.get("courseId"));
 const lesson=await db.lesson.findFirst({where:{id:lessonId,module:{courseId,published:true,approvalStatus:"APPROVED",course:{enrollments:{some:{enrollment:{userId:user.id,status:{in:["ACTIVE","REPEATING"]}}}}}}},include:{module:{include:{course:{include:{enrollments:{where:{enrollment:{userId:user.id,status:{in:["ACTIVE","REPEATING"]}}}}}}}}}});
 if(!lesson) throw new Error("Lesson not available.");
 await db.lessonProgress.upsert({where:{userId_lessonId:{userId:user.id,lessonId}},update:{completed:true,completedAt:new Date()},create:{userId:user.id,lessonId,completed:true,completedAt:new Date()}});
 await db.auditLog.create({data:{userId:user.id,action:"LESSON_COMPLETED",entity:"Lesson",entityId:lessonId}}); await notifyStudentChange({email:user.email,firstName:user.firstName,title:"Lesson completed",body:`You marked a GITDM lesson as complete. Your learning progress has been updated.`,action:"LESSON_COMPLETED",href:`/campus/learning/${courseId}/lessons/${lessonId}`});
 revalidatePath(`/campus/learning/${courseId}/lessons/${lessonId}`); revalidatePath("/campus/learning");
}
