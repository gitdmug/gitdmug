import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { GITDM } from "@/lib/branding";
import { getDb } from "@/lib/db";
import { ACTIVE_COURSE_CODES } from "@/lib/current-catalogue";

export const dynamic = "force-dynamic";
export const metadata = {
  title: `Course Catalog | ${GITDM.shortName}`,
  description: "Explore GITDM faculty courses and start a free preview before enrolment.",
};

export default async function CampusCatalog() {
  const db = getDb();
  const courses = db
    ? await db.course.findMany({
        where: { code: { in: [...ACTIVE_COURSE_CODES] }, published: true, studentSelectable: true, facultyId: { not: null } },
        orderBy: [{ facultyUnit: { name: "asc" } }, { orderIndex: "asc" }, { title: "asc" }],
        include: {
          facultyUnit: true,
          faculty: { include: { user: true } },
          modules: { where: { published: true }, orderBy: { orderIndex: "asc" }, include: { lessons: { where: { published: true }, orderBy: { orderIndex: "asc" }, take: 1 } } },
          _count: { select: { modules: true } },
        },
      })
    : [];

  const publicCourses = courses.filter((course) => !course.code.startsWith("FFM-") || course.code === "FFM-101");
  const faculties = Array.from(new Map(publicCourses.map((course) => [course.facultyUnit?.id, course.facultyUnit])).values()).filter(Boolean);

  return (
    <>
      <Header active="/campus" />
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">GITDM learning catalogue</div>
            <h1>Explore before you enrol.</h1>
            <p>
              Browse the current GITDM programme courses, understand what each course teaches, and open a free preview lesson.
              Full learning, assessments and academic records remain protected inside the student campus.
            </p>
            <div className="actions">
              <Link href="/auth/signup?returnTo=/campus/catalog" className="btn btn-primary">Create free account</Link>
              <Link href="/admissions" className="btn btn-outline-dark">Explore admissions</Link>
            </div>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className="grid grid-2" style={{ marginBottom: 30 }}>
              {faculties.map((faculty) => (
                <article className="card" key={faculty!.id}>
                  <div className="eyebrow">{faculty!.code}</div>
                  <h2>{faculty!.name}</h2>
                  <p>{faculty!.description}</p>
                  <span className="chip">{publicCourses.filter((c) => c.facultyUnit?.id === faculty!.id).length} published course(s)</span>
                </article>
              ))}
            </div>

            <div className="section-header">
              <div>
                <div className="eyebrow">Course library</div>
                <h2>Start with a free preview</h2>
                <p className="section-intro">GITDM uses a preview-first model: visitors can sample published course content before committing to a programme or paid learning path.</p>
              </div>
            </div>

            <div className="grid grid-2">
              {publicCourses.map((course) => {
                const previewLesson = course.modules[0]?.lessons[0];
                const lecturer = course.faculty.find((item) => item.isLead)?.user || course.faculty[0]?.user;
                return (
                  <article className="card" key={course.id}>
                    <div style={{ display: "flex", justifyContent: "space-between", gap: 12, alignItems: "flex-start" }}>
                      <div>
                        <span className="chip chip-accent">{course.code}</span>
                        <span className="chip" style={{ marginLeft: 8 }}>{course.facultyUnit?.code}</span>
                      </div>
                      <span className="badge">Free preview</span>
                    </div>
                    <h3 style={{ marginTop: 14 }}>{course.code === "FFM-101" ? "Certificate in Financial Markets, Trading and Derivatives" : course.title}</h3>
                    <p>{course.code === "FFM-101" ? "A complete 12-month GITDM programme covering financial markets, trading and derivatives." : (course.description || "Practical financial-markets training delivered through structured modules and activities.")}</p>
                    <div className="meta">
                      <span className="chip">{course._count.modules} module(s)</span>
                      <span className="chip">{lecturer ? `Lecturer: ${[lecturer.firstName, lecturer.lastName].filter(Boolean).join(" ") || lecturer.email}` : "Lecturer being allocated"}</span>
                    </div>
                    <div className="actions">
                      <Link href={`/campus/catalog/${course.id}`} className="btn btn-primary btn-sm">View course &amp; preview</Link>
                    </div>
                    {previewLesson ? <p className="tile-meta">Preview lesson: {previewLesson.title}</p> : <p className="tile-meta">Course content is being prepared.</p>}
                  </article>
                );
              })}
              {!courses.length ? <div className="panel"><h3>No published courses yet</h3><p>The academic office is preparing the catalogue. Courses appear automatically when they are published.</p></div> : null}
            </div>

            <div className="access-banner full" style={{ marginTop: 28 }}>
              <strong>Free access is intentionally limited.</strong> Preview content lets you evaluate the teaching approach. Enrolled students receive the complete learning path, downloadable materials, assessments, timetable and academic records according to their access level.
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
