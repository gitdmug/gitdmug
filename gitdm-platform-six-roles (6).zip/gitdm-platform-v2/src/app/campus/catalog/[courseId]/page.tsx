import Link from "next/link";
import { notFound } from "next/navigation";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { GITDM } from "@/lib/branding";
import { getDb } from "@/lib/db";
import { ACTIVE_COURSE_CODES } from "@/lib/current-catalogue";
import { courseDisplayTitle } from "@/lib/course-display";

export const dynamic = "force-dynamic";

export default async function PublicCoursePreview({ params }: { params: Promise<{ courseId: string }> }) {
  const { courseId } = await params;
  const db = getDb();
  if (!db) notFound();
  const course = await db.course.findFirst({
    where: { id: courseId, code: { in: [...ACTIVE_COURSE_CODES] }, published: true, studentSelectable: true },
    include: {
      facultyUnit: true,
      faculty: { include: { user: true } },
      modules: {
        where: { published: true },
        orderBy: { orderIndex: "asc" },
        include: {
          lessons: { where: { published: true }, orderBy: { orderIndex: "asc" }, include: { resources: true } },
        },
      },
    },
  });
  if (!course) notFound();

  const previewModule = course.modules[0];
  const previewLesson = previewModule?.lessons[0];
  const lead = course.faculty.find((item) => item.isLead)?.user || course.faculty[0]?.user;

  return (
    <>
      <Header active="/campus" />
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">{course.facultyUnit?.code} · {course.code}</div>
            <h1>{courseDisplayTitle(course.code, course.title)}</h1>
            <p>{course.description || "Practical GITDM financial-markets training."}</p>
            <div className="actions">
              <Link href="/auth/signup?returnTo=/campus" className="btn btn-primary">Create account to learn</Link>
              <Link href="/campus/catalog" className="btn btn-outline-dark">← Course catalogue</Link>
            </div>
          </div>
        </section>

        <section className="section">
          <div className="container">
            <div className="grid grid-3">
              <div className="panel"><div className="eyebrow">Faculty</div><h3>{course.facultyUnit?.name || "GITDM Faculty"}</h3><p>{course.facultyUnit?.description}</p></div>
              <div className="panel"><div className="eyebrow">Lecturer</div><h3>{lead ? [lead.firstName, lead.lastName].filter(Boolean).join(" ") || lead.email : "Being allocated"}</h3><p>Faculty allocation is completed before student selection opens.</p></div>
              <div className="panel"><div className="eyebrow">Learning path</div><h3>{course.modules.length} module(s)</h3><p>Published modules and lessons unlock fully for enrolled students.</p></div>
            </div>

            <div className="grid grid-2" style={{ marginTop: 28, alignItems: "start" }}>
              <article className="card prose">
                <div className="eyebrow">Free preview</div>
                <h2>{previewLesson?.title || "Preview coming soon"}</h2>
                {previewLesson ? (
                  <>
                    <p>{previewModule?.title} · {previewLesson.type.replaceAll("_", " ")}{previewLesson.durationMinutes ? ` · ${previewLesson.durationMinutes} minutes` : ""}</p>
                    <div style={{ whiteSpace: "pre-wrap" }}>{previewLesson.content || "This preview lesson is ready. Create a GITDM account to continue into the full learning path."}</div>
                    {previewLesson.videoUrl ? <div className="actions"><a href={previewLesson.videoUrl} target="_blank" rel="noreferrer" className="btn btn-outline-dark btn-sm">Open preview video</a></div> : null}
                  </>
                ) : <p>The academic team has not published a preview lesson yet.</p>}
              </article>
              <div className="stack">
                <div className="card"><div className="eyebrow">What enrolled students receive</div><h3>One connected learning journey</h3><div className="stack" style={{ marginTop: 14 }}><div className="staff-notice"><strong>Lessons &amp; materials</strong><p>Structured modules, lecturer-uploaded documents, videos and links.</p></div><div className="staff-notice"><strong>Assessments</strong><p>Assignments, quizzes and formal examinations with defined deadlines and time controls.</p></div><div className="staff-notice"><strong>Live classes</strong><p>Scheduled cohort sessions, online meeting links and attendance records.</p></div><div className="staff-notice"><strong>Academic record</strong><p>Progress, attendance, grades and completion stay connected to the same student identity.</p></div></div></div>
                <div className="access-banner full"><strong>Preview first.</strong> The free experience is designed to help a prospective learner understand the course before applying or enrolling.</div>
              </div>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
