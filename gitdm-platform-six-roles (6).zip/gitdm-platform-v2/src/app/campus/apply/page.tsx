import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { StudentNav } from "@/components/StudentNav";
import { requireStudentSession } from "@/lib/student";
import { getDb } from "@/lib/db";
import { GITDM } from "@/lib/branding";
import { startApplication } from "@/app/admissions/apply/actions";
import { ACTIVE_PROGRAMME_CODES } from "@/lib/current-catalogue";

export const dynamic = "force-dynamic";
export const metadata = { title: `Admissions & Apply | ${GITDM.shortName}` };

export default async function CampusApply() {
  const ctx = await requireStudentSession("/campus/apply");
  const db = getDb();
  if (!db) throw new Error("Database unavailable.");

  const programmes = await db.programme.findMany({
    where: { status: "PUBLISHED", requiresApplication: true, applicationsOpen: true, code: { in: [...ACTIVE_PROGRAMME_CODES] } },
    orderBy: { name: "asc" },
    include: { rules: true, periods: { where: { status: "OPEN" }, orderBy: { sequence: "asc" } } },
  });

  const running = ctx.enrollments.filter((e) => ["ACTIVE", "REPEATING"].includes(e.status));
  const current = running[0] || null;
  const runningIds = running.map((e) => e.programme.id);
  const runningProgrammeDetails = runningIds.length ? await db.programme.findMany({ where: { id: { in: runningIds } }, select: { id: true, durationMonths: true } }) : [];
  const runningShort = runningProgrammeDetails.some((p) => p.durationMonths < 12);
  const longRunning = runningProgrammeDetails.some((p) => p.durationMonths >= 12);
  const hasShortApplication = longRunning ? await db.application.findFirst({
    where: {
      applicantId: ctx.user.id,
      programme: { durationMonths: 1 },
      status: { in: ["DRAFT", "SUBMITTED", "UNDER_REVIEW", "INTERVIEW_REQUIRED", "ADDITIONAL_INFORMATION", "ACCEPTED"] },
    },
    select: { id: true },
  }) : null;
  const canApply = !running.length || (longRunning && !runningShort && !hasShortApplication);

  return <>
    <Header active="/campus" workspace="student" />
    <StudentNav active="/campus/apply" />
    <main>
      <section className="page-hero"><div className="container"><div className="eyebrow">Admissions workspace</div><h1>Choose what you want to study.</h1><p>Your running programme stays your current student record. A new application does not replace it or create a new fee-unlock dashboard.</p></div></section>
      <section className="section"><div className="container">
        {running.length ? <div className={`access-banner ${canApply ? "full" : ""}`} style={{ marginBottom: 24 }}>
          <strong>Current programme: {current?.programme.name}</strong>
          <p style={{ margin: "8px 0 0" }}>{canApply ? "You are eligible for the one permitted short-course exception because your current programme is 12 months." : "You cannot start another programme while this programme is running. Complete it before applying again."}</p>
        </div> : <div className="access-banner full" style={{ marginBottom: 24 }}><strong>Signed in as {ctx.user.email}.</strong> Choose a published programme below.</div>}
        <div className="grid grid-2">
          {programmes.map((p) => {
            const allowed = !running.length || (longRunning && !runningShort && !hasShortApplication && p.durationMonths === 1);
            return <article className="card" key={p.id}><div className="eyebrow">{p.code}</div><h2>{p.name}</h2><p>{p.description || "GITDM programme."}</p><div className="meta"><span className="chip">{p.durationMonths} months</span><span className="chip">Application fee {p.currency} {Number(p.applicationFee).toLocaleString("en-UG")}</span>{p.rules?.minimumEducation ? <span className="chip">{p.rules.minimumEducation}</span> : null}</div><div className="actions" style={{ marginTop: 18 }}>
              {allowed ? <form action={startApplication}><input type="hidden" name="programmeId" value={p.id} /><button className="btn btn-primary">Start application</button></form> : <span className="btn btn-outline-dark" aria-disabled="true">Not available while enrolled</span>}
            </div></article>;
          })}
        </div>
        {!programmes.length ? <div className="panel"><h2>No published programmes yet</h2><p>Admissions will publish available programmes here.</p></div> : null}
        <div className="actions" style={{ marginTop: 28 }}><Link href="/campus/profile" className="btn btn-outline-dark">View my applications</Link><Link href="/campus" className="btn btn-outline-dark">Back to dashboard</Link></div>
      </div></section>
    </main><Footer />
  </>;
}
