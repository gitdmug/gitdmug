import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { StudentNav } from "@/components/StudentNav";
import { GITDM } from "@/lib/branding";
import { requireStudentSession } from "@/lib/student";
import { getDb } from "@/lib/db";
import { payInvoice, refreshPesapalPayment, requestOfflineInvoice } from "./actions";

export const metadata = {
  title: `Finance | Campus | ${GITDM.shortName}`,
};

export const dynamic = "force-dynamic";

function money(amount: unknown, currency: string) {
  return `${currency} ${Number(amount || 0).toLocaleString("en-UG", {
    minimumFractionDigits: 0,
    maximumFractionDigits: 2,
  })}`;
}

function statusLabel(status: string) {
  return status.replaceAll("_", " ");
}

export default async function FinancePage({
  searchParams,
}: {
  searchParams: Promise<{
    error?: string;
    payment?: string;
    reference?: string;
    request?: string;
  }>;
}) {
  const params = await searchParams;
  const ctx = await requireStudentSession("/campus/finance");
  const enr = ctx.primaryEnrollment;
  const financeEligible = Boolean(enr && ["ACTIVE", "REPEATING"].includes(enr.status));
  const primaryInvoices = enr?.invoices ?? [];
  const db = getDb();
  const openBillingPeriod = enr && !enr.period && db
    ? await db.academicPeriod.findFirst({
        where: { programmeId: enr.programme.id, status: "OPEN" },
        orderBy: { sequence: "asc" },
      })
    : null;
  const billingPeriod = enr?.period ?? openBillingPeriod;
  const activeInvoices = primaryInvoices.filter((invoice) => !["DRAFT", "VOID"].includes(invoice.status));
  const currentPeriodInvoices = activeInvoices.filter((invoice) => !billingPeriod?.id || invoice.periodId === billingPeriod.id);
  // A checkout left open indefinitely must never block a fresh payment.
  // We keep the transaction as an immutable historical record and classify stale
  // Pesapal checkouts as abandoned using the existing CANCELLED status.
  if (db) {
    const staleBefore = new Date(Date.now() - 20 * 60 * 1000);
    await db.payment.updateMany({
      where: { userId: ctx.user.id, provider: "PESAPAL", status: "PENDING", createdAt: { lt: staleBefore } },
      data: { status: "CANCELLED", providerStatus: "ABANDONED", providerDescription: "ABANDONED: checkout was not completed within the active payment window." },
    });
  }
  const [invoices, payments] = db ? await Promise.all([
    db.invoice.findMany({ where: { enrollment: { userId: ctx.user.id }, kind: "TUITION" }, orderBy: { dueAt: "desc" }, include: { enrollment: { include: { programme: true, period: true } } } }),
    db.payment.findMany({ where: { userId: ctx.user.id }, orderBy: { createdAt: "desc" }, include: { invoice: true, receipt: true } }),
  ]) : [primaryInvoices, []];

  const totalPaid = currentPeriodInvoices.reduce((sum, inv) => sum + Number(inv.amountPaid), 0);
  const totalInvoiced = currentPeriodInvoices.length
    ? currentPeriodInvoices.reduce((sum, inv) => sum + Number(inv.amount), 0)
    : Number(billingPeriod?.feeAmount || 0);
  const totalOutstanding = Math.max(0, totalInvoiced - totalPaid);
  const completedPayments = payments.filter((p) => p.status === "COMPLETED");
  const pendingPayments = payments.filter((p) => p.status === "PENDING");
  const recentPayments = payments.slice(0, 6);

  const notice =
    params.request === "received"
      ? "Your cash/bank invoice request has been sent to Finance. It will appear here when issued."
      : params.payment === "completed"
      ? "Payment confirmed. Your invoice, receipt and access status have been updated."
      : params.payment === "pending"
        ? "Pesapal is still processing the payment. Use Refresh status below; IPN will also update your account automatically."
        : params.payment === "failed"
          ? "Pesapal reported that the payment failed. No fee credit was applied."
          : params.payment === "cancelled"
            ? "The payment was cancelled before completion. No fee credit was applied."
            : params.payment === "abandoned"
              ? "Pesapal checkout was abandoned. The transaction remains in your history as Abandoned and you can start a new payment immediately."
            : params.error
              ? params.error
              : null;

  return (
    <>
      <Header active="/campus" workspace="student" />
      <StudentNav active="/campus/finance" />
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">Finance</div>
            <h1>Fees, invoices and payments</h1>
            <p>
Pay online immediately, or request an invoice if you intend to pay by cash or bank transfer. Every cleared payment is recorded and receipted.
            </p>
          </div>
        </section>

        <section className="section">
          <div className="container">
            {notice ? (
              <div
                className="panel"
                style={{ marginBottom: 20, borderColor: params.payment === "completed" ? "var(--success)" : "var(--accent)" }}
              >
                <span className="badge">{params.payment || "Finance update"}</span>
                <p style={{ margin: "10px 0 0" }}>{notice}</p>
                {params.error ? <div className="actions" style={{marginTop:14}}><form action={requestOfflineInvoice}><select name="paymentPreference" defaultValue="BANK_TRANSFER" aria-label="Fallback payment method"><option value="BANK_TRANSFER">Bank transfer</option><option value="CASH">Cash</option></select><button className="btn btn-outline-dark btn-sm" type="submit">Use offline payment instead</button></form></div> : null}
                {params.reference ? (
                  <p className="tile-meta" style={{ margin: "8px 0 0" }}>
                    Pesapal reference: {params.reference}
                  </p>
                ) : null}
              </div>
            ) : null}

            <div className="grid grid-3" style={{ marginBottom: 28 }}>
              <div className="panel">
                <div className="eyebrow">Current period fee</div>
                <h2 style={{ margin: "8px 0 0", fontSize: "1.5rem" }}>
                  {billingPeriod?.currency || "UGX"} {totalInvoiced.toLocaleString()}
                </h2>
              </div>
              <div className="panel">
                <div className="eyebrow">Total paid</div>
                <h2 style={{ margin: "8px 0 0", fontSize: "1.5rem" }}>
                  {billingPeriod?.currency || "UGX"} {totalPaid.toLocaleString()}
                </h2>
                <p style={{ margin: "6px 0 0", fontSize: 14 }}>{ctx.feePercentPaid}% cleared</p>
              </div>
              <div className="panel">
                <div className="eyebrow">Outstanding</div>
                <h2 style={{ margin: "8px 0 0", fontSize: "1.5rem" }}>
                  {billingPeriod?.currency || "UGX"} {totalOutstanding.toLocaleString()}
                </h2>
                <p style={{ margin: "6px 0 0", fontSize: 14 }}>
                  {pendingPayments.length} payment(s) processing
                </p>
              </div>
            </div>

            <div className="grid grid-3" style={{ marginBottom: 28 }}>
              <div className="panel">
                <div className="eyebrow">Paid progress</div>
                <h2 style={{ margin: "8px 0 0", fontSize: "1.75rem" }}>{ctx.feePercentPaid}%</h2>
                <div className="progress-bar">
                  <span style={{ width: `${Math.min(100, ctx.feePercentPaid)}%` }} />
                </div>
              </div>
              <div className="panel">
                <div className="eyebrow">Learning unlock</div>
                <h3 style={{ margin: "8px 0 4px" }}>
                  {ctx.feePercentPaid >= ctx.activationThreshold ? "Met" : "Pending"}
                </h3>
                <p style={{ margin: 0, fontSize: 14 }}>Threshold: {ctx.activationThreshold}%</p>
              </div>
              <div className="panel">
                <div className="eyebrow">Exam eligibility (fees)</div>
                <h3 style={{ margin: "8px 0 4px" }}>
                  {ctx.feePercentPaid >= 100 ? "Cleared" : "Requires 100%"}
                </h3>
                <p style={{ margin: 0, fontSize: 14 }}>Plus attendance &amp; academic rules</p>
              </div>
            </div>

            {!financeEligible ? (
              <div className="panel">
                <span className="badge warn">No enrolment</span>
                <p style={{ marginTop: 12, marginBottom: 0 }}>
                  Fee statements appear after admission and enrolment. Your application-stage fee is handled on the application page.{" "}
                  <Link href="/admissions">Apply for a programme</Link>.
                </p>
              </div>
            ) : (
              <>
                <div className="panel" style={{ marginBottom: 24 }}>
                  <h3 style={{ marginTop: 0 }}>{enr!.programme.name}</h3>
                  <p>
                    Period: {billingPeriod?.name || "—"}
                    {billingPeriod
                      ? ` · Period fee: ${billingPeriod.currency} ${Number(billingPeriod.feeAmount).toLocaleString()}`
                      : ""}
                  </p>
                  <p style={{ marginBottom: 0 }}>
                    Access level: <strong>{enr!.accessLevel}</strong>
                  </p>
                </div>

                <div className="eyebrow">Invoices</div>
                <h2>Statements</h2>
                <p className="tile-meta" style={{ marginTop: -8, marginBottom: 16 }}>For online payments, enter the amount you want to pay. It can be less than the outstanding balance; the remaining balance stays on your invoice.</p>
                {activeInvoices.length === 0 ? (
                  <div className="panel" style={{ marginTop: 16 }}>
                    <h3 style={{ marginTop: 0 }}>Your current-period fee</h3>
                    <p>Online payment does not require an invoice request. GITDM will create the internal accounting record when you start payment.</p>
                    <p><strong>{billingPeriod?.currency || "UGX"} {Number(billingPeriod?.feeAmount || 0).toLocaleString("en-UG")}</strong> · {billingPeriod?.name || "Current period"}</p>
                    <div className="actions" style={{ display: "flex", gap: 12, flexWrap: "wrap", margin: "18px 0 20px", alignItems: "end" }}>
                      {billingPeriod ? (
                        <form action={payInvoice} style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "end" }}>
                          <div>
                            <label htmlFor="new-payment-amount" style={{ display: "block", fontSize: 13, marginBottom: 5 }}>Amount to pay</label>
                            <input id="new-payment-amount" name="amount" type="number" min="1" max={Number(billingPeriod.feeAmount)} step={billingPeriod.currency === "UGX" ? "1" : "0.01"} placeholder="Enter amount" required style={{ maxWidth: 180 }} />
                          </div>
                          <button className="btn btn-primary" type="submit">Pay with Pesapal</button>
                        </form>
                      ) : null}
                      {billingPeriod ? (
                        <form action={requestOfflineInvoice} className="actions" style={{ display: "flex", gap: 8, alignItems: "center" }}>
                          <select name="paymentPreference" defaultValue="CASH" aria-label="Offline payment method" required>
                            <option value="CASH">Cash</option>
                            <option value="BANK_TRANSFER">Bank transfer</option>
                          </select>
                          <button className="btn btn-outline-dark" type="submit">Request an invoice</button>
                        </form>
                      ) : null}
                    </div>
                    {!billingPeriod ? (
                      <div className="panel" style={{ marginTop: 16 }}>
                        <strong>Payment setup is incomplete.</strong> Finance needs to open a billing period for this programme. No payment will be accepted against an undefined fee period.
                      </div>
                    ) : null}
                    {primaryInvoices.some((invoice) => invoice.status === "DRAFT") ? <p>Your offline invoice request <strong>{primaryInvoices.find((invoice) => invoice.status === "DRAFT")?.invoiceNo}</strong> is awaiting Finance. You can still choose online payment above.</p> : null}
                  </div>
                ) : (
                  <div className="table-wrap" style={{ marginTop: 16 }}>
                    <table className="data">
                      <thead>
                        <tr>
                          <th>Invoice</th>
                          <th>Description</th>
                          <th>Amount</th>
                          <th>Paid</th>
                          <th>Balance</th>
                          <th>Status / action</th>
                        </tr>
                      </thead>
                      <tbody>
                        {invoices.map((inv) => {
                          const balance = Math.max(0, Number(inv.amount) - Number(inv.amountPaid));
                          const pendingForInvoice = pendingPayments.find((p) => p.invoiceId === inv.id);
                          return (
                            <tr key={inv.id}>
                              <td>{inv.status !== "DRAFT" && inv.status !== "VOID" ? <Link href={`/campus/finance/invoices/${inv.id}`}><strong>{inv.invoiceNo}</strong><div className="tile-meta">View / print invoice</div></Link> : <strong>{inv.invoiceNo}</strong>}</td>
                              <td>{inv.description}</td>
                              <td>{money(inv.amount, inv.currency)}</td>
                              <td>{money(inv.amountPaid, inv.currency)}</td>
                              <td>{money(balance, inv.currency)}</td>
                              <td>
                                <span className="badge">{statusLabel(inv.status)}</span>
                                {inv.status === "DRAFT" ? <div className="tile-meta" style={{ marginTop: 8 }}>Invoice request submitted · awaiting Finance</div> : null}
                                {balance > 0 && inv.status !== "VOID" && inv.status !== "DRAFT" ? (
                                  <div className="payment-action-stack" style={{ marginTop: 8 }}>
                                    {pendingForInvoice ? (
                                      <form action={refreshPesapalPayment}>
                                        <input type="hidden" name="paymentId" value={pendingForInvoice.id} />
                                        <button className="btn btn-outline-dark btn-sm" type="submit">Check latest status</button>
                                      </form>
                                    ) : null}
                                    <form action={payInvoice} style={{ display: "flex", gap: 8, flexWrap: "wrap", alignItems: "end" }}>
                                      <input type="hidden" name="invoiceId" value={inv.id} />
                                      <div>
                                        <label htmlFor={`payment-amount-${inv.id}`} style={{ display: "block", fontSize: 12, marginBottom: 4 }}>Amount to pay</label>
                                        <input id={`payment-amount-${inv.id}`} name="amount" type="number" min="1" max={balance} step={inv.currency === "UGX" ? "1" : "0.01"} placeholder={String(Math.round(balance))} required style={{ width: 150 }} />
                                      </div>
                                      <button className="btn btn-primary btn-sm" type="submit">
                                        {pendingForInvoice ? "Start another Pesapal payment" : "Pay with Pesapal"}
                                      </button>
                                    </form>
                                    {pendingForInvoice ? <div className="tile-meta">A previous checkout is still processing. You can check it above or start another payment; abandoned checkouts remain in history.</div> : null}
                                  </div>
                                ) : null}
                              </td>
                            </tr>
                          );
                        })}
                      </tbody>
                    </table>
                  </div>
                )}

                {billingPeriod && primaryInvoices.every((inv) => inv.status === "VOID") ? (
                  <div className="panel" style={{ marginTop: 20 }}>
                    <h3 style={{ marginTop: 0 }}>Prefer cash or bank transfer?</h3>
                    <p>Request an invoice from Finance, then use it to clear your fees.</p>
                    <form action={requestOfflineInvoice} className="actions"><select name="paymentPreference" defaultValue="CASH" aria-label="Payment method"><option value="CASH">Cash</option><option value="BANK_TRANSFER">Bank transfer</option></select><button className="btn btn-outline-dark" type="submit">Request an invoice</button></form>
                  </div>
                ) : null}

                <div className="history-preview" style={{ marginTop: 40 }}>
                  <div className="section-header compact">
                    <div><div className="eyebrow">RECENT ACTIVITY</div><h2>Latest payments</h2><p className="section-intro">Your most recent 6 transactions are shown here. Open the full history to filter by status, date, provider or payment purpose.</p></div>
                    <Link href="/campus/finance/transactions" className="btn btn-outline-dark btn-sm">View full history →</Link>
                  </div>
                  <div className="table-wrap compact-table">
                    <table className="data"><thead><tr><th>Date</th><th>Purpose</th><th>Provider</th><th>Amount</th><th>Status</th><th>Receipt</th></tr></thead><tbody>
                      {recentPayments.length===0 ? <tr><td colSpan={6}>No payment transactions have been recorded yet.</td></tr> : recentPayments.map((payment) => <tr key={payment.id}>
                        <td>{payment.createdAt.toLocaleDateString("en-UG")}<div className="tile-meta">{payment.createdAt.toLocaleTimeString("en-UG",{hour:"2-digit",minute:"2-digit"})}</div></td>
                        <td><strong>{payment.invoice.description}</strong><div className="tile-meta">{payment.invoice.invoiceNo}</div></td>
                        <td>{payment.provider}</td><td>{money(payment.amount,payment.currency)}</td>
                        <td><span className={`badge ${payment.status==="COMPLETED"?"success":payment.status==="FAILED"||payment.status==="CANCELLED"?"danger":"pending"}`}>{payment.status==="CANCELLED" && payment.providerStatus==="ABANDONED" ? "ABANDONED" : statusLabel(payment.status)}</span>{payment.status==="PENDING" && payment.providerRef?<form action={refreshPesapalPayment} style={{marginTop:6}}><input type="hidden" name="paymentId" value={payment.id}/><button className="btn btn-outline-dark btn-sm" type="submit">Check status</button></form>:null}</td>
                        <td>{payment.receipt?<Link href={`/campus/finance/receipts/${payment.receipt.id}`}><strong>{payment.receipt.receiptNo}</strong></Link>:"—"}</td>
                      </tr>)}
                    </tbody></table>
                  </div>
                </div>

                {completedPayments.length > 0 ? (
                  <div className="panel" style={{ marginTop: 24 }}>
                    <h3 style={{ marginTop: 0 }}>Payment records</h3>
                    <p style={{ marginBottom: 0 }}>
                      {completedPayments.length} completed transaction(s) are permanently
                      linked to your account and invoice records. Receipts remain visible
                      here after you return to the portal.
                    </p>
                  </div>
                ) : null}

                <div className="panel" style={{ marginTop: 24 }}>
                  <h3 style={{ marginTop: 0 }}>How payment unlocks campus</h3>
                  <ol style={{ marginBottom: 0, paddingLeft: 20 }}>
                    <li>Admissions accepts your application.</li>
                    <li>You enter limited campus for profile, fees and support.</li>
                    <li>Pay at least 60% of the current period fee; the server verifies Pesapal.</li>
                    <li>Full learning access activates automatically once the programme threshold is met.</li>
                    <li>Clear 100% before the final examination window.</li>
                  </ol>
                </div>
              </>
            )}

            <div className="actions" style={{ marginTop: 28 }}>
              <Link href="/campus" className="btn btn-outline-dark btn-sm">
                ← Dashboard
              </Link>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
