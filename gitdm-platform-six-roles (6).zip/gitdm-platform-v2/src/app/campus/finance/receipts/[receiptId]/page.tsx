import Link from "next/link";
import { notFound } from "next/navigation";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { StudentNav } from "@/components/StudentNav";
import { PrintButton } from "@/components/PrintButton";
import { requireStudentSession } from "@/lib/student";
import { getDb } from "@/lib/db";
import { GITDM } from "@/lib/branding";

export const dynamic = "force-dynamic";
export const metadata = { title: `Receipt | ${GITDM.shortName}` };
const money = (amount: unknown, currency: string) => `${currency} ${Number(amount || 0).toLocaleString("en-UG", { maximumFractionDigits: 2 })}`;

export default async function StudentReceiptPage({ params }: { params: Promise<{ receiptId: string }> }) {
  const { receiptId } = await params;
  const ctx = await requireStudentSession("/campus/finance");
  const db = getDb();
  if (!db) notFound();
  const receipt = await db.receipt.findFirst({ where: { id: receiptId, userId: ctx.user.id }, include: { payment: true, invoice: { include: { enrollment: { include: { programme: true, period: true } } } }, user: true } });
  if (!receipt || receipt.payment.status !== "COMPLETED") notFound();
  return <><Header workspace="student"/><StudentNav active="/campus/finance"/><main><section className="section"><div className="container" style={{maxWidth:850}}><div className="actions" style={{justifyContent:"space-between",marginBottom:24}}><Link className="btn btn-outline-dark btn-sm" href="/campus/finance">← Back to Finance</Link><PrintButton/></div><article className="panel" style={{padding:32}}><div className="eyebrow">GITDM · Official payment receipt</div><h1>Receipt</h1><div className="grid grid-2"><div><div className="tile-meta">Receipt number</div><strong>{receipt.receiptNo}</strong><div className="tile-meta" style={{marginTop:12}}>Received from</div><strong>{[receipt.user.firstName,receipt.user.lastName].filter(Boolean).join(" ") || receipt.user.email}</strong><div>{receipt.user.email}</div></div><div><div className="tile-meta">Date received</div><strong>{receipt.issuedAt.toLocaleString("en-UG")}</strong><div className="tile-meta" style={{marginTop:12}}>Invoice</div><strong>{receipt.invoice.invoiceNo}</strong><div className="tile-meta" style={{marginTop:12}}>Payment method</div><strong>{receipt.payment.providerMethod || receipt.payment.provider}</strong></div></div><hr style={{margin:"24px 0",border:0,borderTop:"1px solid var(--border)"}}/><div className="table-wrap"><table className="data"><thead><tr><th>Payment for</th><th>Reference</th><th>Amount received</th></tr></thead><tbody><tr><td>{receipt.invoice.description}</td><td>{receipt.payment.providerConfirmationCode || receipt.payment.providerMerchantRef || receipt.payment.providerRef || "—"}</td><td>{money(receipt.payment.amount,receipt.payment.currency)}</td></tr></tbody></table></div><p style={{marginTop:24}}>This receipt confirms that GITDM recorded the payment shown above. Keep the receipt number for your records.</p></article></div></section></main><Footer/></>;
}
