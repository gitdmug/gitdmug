import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { StudentNav } from "@/components/StudentNav";
import { GITDM } from "@/lib/branding";
import { requireStudentSession } from "@/lib/student";
import { getDb } from "@/lib/db";

export const dynamic = "force-dynamic";
export const metadata = { title: `Transaction history | ${GITDM.shortName}` };

function money(amount: unknown, currency: string){return `${currency} ${Number(amount||0).toLocaleString("en-UG",{minimumFractionDigits:0,maximumFractionDigits:2})}`;}
function displayStatus(payment:any){return payment.status==="CANCELLED"&&payment.providerStatus==="ABANDONED"?"ABANDONED":payment.status.replaceAll("_"," ");}

export default async function TransactionsPage({searchParams}:{searchParams:Promise<Record<string,string|undefined>>}){
 const params=await searchParams; const ctx=await requireStudentSession("/campus/finance/transactions"); const db=getDb();
 const status=params.status||""; const provider=params.provider||""; const q=(params.q||"").trim(); const from=params.from||""; const to=params.to||"";
 let payments:any[]=[];
 if(db){
   payments=await db.payment.findMany({where:{userId:ctx.user.id,...(status==="ABANDONED"?{status:"CANCELLED",providerStatus:"ABANDONED"}:status?{status:status as any}:{}),...(provider?{provider}:{}),...(q?{OR:[{providerMerchantRef:{contains:q,mode:"insensitive"}},{providerRef:{contains:q,mode:"insensitive"}},{invoice:{invoiceNo:{contains:q,mode:"insensitive"}}},{invoice:{description:{contains:q,mode:"insensitive"}}}]}:{}),...(from||to?{createdAt:{...(from?{gte:new Date(`${from}T00:00:00`)}:{}),...(to?{lte:new Date(`${to}T23:59:59`)}:{})}}:{})},orderBy:{createdAt:"desc"},include:{invoice:true,receipt:true},take:200});
 }
 return <><Header active="/campus" workspace="student"/><StudentNav active="/campus/finance"/><main><section className="page-hero"><div className="container"><div className="eyebrow">Finance · History</div><h1>Transaction history</h1><p>Search and filter every payment recorded against your student account. Successful payments, failed attempts and abandoned checkouts remain traceable.</p></div></section><section className="section"><div className="container">
 <div className="history-toolbar"><form className="filter-grid" method="get"><div className="form-row"><label>Search reference or purpose</label><input name="q" defaultValue={q} placeholder="Invoice, reference, tuition..."/></div><div className="form-row"><label>Status</label><select name="status" defaultValue={status}><option value="">All statuses</option><option value="COMPLETED">Successful</option><option value="PENDING">Pending</option><option value="FAILED">Failed</option><option value="ABANDONED">Abandoned</option></select></div><div className="form-row"><label>Provider</label><select name="provider" defaultValue={provider}><option value="">All providers</option><option value="PESAPAL">Pesapal</option><option value="CASH">Cash</option><option value="BANK">Bank</option></select></div><div className="form-row"><label>From</label><input type="date" name="from" defaultValue={from}/></div><div className="form-row"><label>To</label><input type="date" name="to" defaultValue={to}/></div><div className="filter-actions"><button className="btn btn-primary" type="submit">Apply filters</button><Link className="btn btn-outline-dark" href="/campus/finance/transactions">Clear</Link></div></form></div>
 <div className="section-header compact" style={{marginTop:28}}><div><div className="eyebrow">RESULTS</div><h2>{payments.length} transaction{payments.length===1?"":"s"}</h2></div><Link href="/campus/finance" className="btn btn-outline-dark btn-sm">← Back to Finance</Link></div>
 <div className="table-wrap"><table className="data"><thead><tr><th>Date & time</th><th>Purpose</th><th>Invoice</th><th>Provider</th><th>Reference</th><th>Method</th><th>Amount</th><th>Status</th><th>Receipt</th></tr></thead><tbody>{payments.length?payments.map(p=><tr key={p.id}><td>{p.createdAt.toLocaleDateString("en-UG")}<div className="tile-meta">{p.createdAt.toLocaleTimeString("en-UG")}</div></td><td>{p.invoice.description}</td><td>{p.invoice.invoiceNo}</td><td>{p.provider}</td><td>{p.providerMerchantRef||p.providerRef||"—"}</td><td>{p.providerMethod||"—"}</td><td>{money(p.amount,p.currency)}</td><td><span className={`badge ${p.status==="COMPLETED"?"success":p.status==="FAILED"||p.status==="CANCELLED"?"danger":"pending"}`}>{displayStatus(p)}</span></td><td>{p.receipt?<Link href={`/campus/finance/receipts/${p.receipt.id}`}>View receipt</Link>:"—"}</td></tr>):<tr><td colSpan={9}>No transactions match the selected filters.</td></tr>}</tbody></table></div>
 </div></section></main><Footer/></>;
}
