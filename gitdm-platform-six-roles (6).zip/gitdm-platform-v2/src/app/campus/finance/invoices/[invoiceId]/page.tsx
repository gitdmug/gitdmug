import Link from "next/link";
import { notFound } from "next/navigation";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { StudentNav } from "@/components/StudentNav";
import { PrintButton } from "@/components/PrintButton";
import { requireStudentSession } from "@/lib/student";
import { getDb } from "@/lib/db";
import { GITDM } from "@/lib/branding";

export const dynamic = "force-dynamic";
export const metadata = { title: `Invoice | ${GITDM.shortName}` };
const money = (amount: unknown, currency: string) => `${currency} ${Number(amount || 0).toLocaleString("en-UG", { maximumFractionDigits: 2 })}`;

export default async function StudentInvoicePage({ params }: { params: Promise<{ invoiceId: string }> }) {
  const { invoiceId } = await params;
  const ctx = await requireStudentSession("/campus/finance");
  const db = getDb();
  if (!db) notFound();
  const invoice = await db.invoice.findFirst({ where: { id: invoiceId, enrollment: { userId: ctx.user.id } }, include: { enrollment: { include: { user: true, programme: true, period: true } } } });
  if (!invoice || invoice.status === "DRAFT" || invoice.status === "VOID") notFound();
  const balance = Math.max(0, Number(invoice.amount) - Number(invoice.amountPaid));
  return <><Header workspace="student"/><StudentNav active="/campus/finance"/><main><section className="section"><div className="container" style={{maxWidth:850}}><div className="actions" style={{justifyContent:"space-between",marginBottom:24}}><Link className="btn btn-outline-dark btn-sm" href="/campus/finance">← Back to Finance</Link><PrintButton/></div><article className="panel" style={{padding:32}}><div className="eyebrow">GITDM · Official student invoice</div><h1>Invoice</h1><div className="grid grid-2"><div><div className="tile-meta">Invoice number</div><strong>{invoice.invoiceNo}</strong><div className="tile-meta" style={{marginTop:12}}>Issued to</div><strong>{[invoice.enrollment.user.firstName,invoice.enrollment.user.lastName].filter(Boolean).join(" ") || invoice.enrollment.user.email}</strong><div>{invoice.enrollment.user.email}</div></div><div><div className="tile-meta">Academic period</div><strong>{invoice.enrollment.period?.name || "—"}</strong><div className="tile-meta" style={{marginTop:12}}>Due date</div><strong>{invoice.dueAt?.toLocaleDateString("en-UG") || "On request"}</strong><div className="tile-meta" style={{marginTop:12}}>Status</div><strong>{invoice.status.replaceAll("_"," ")}</strong></div></div><hr style={{margin:"24px 0",border:0,borderTop:"1px solid var(--border)"}}/><div className="table-wrap"><table className="data"><thead><tr><th>Description</th><th>Period</th><th>Amount</th></tr></thead><tbody><tr><td>{invoice.description}</td><td>{invoice.enrollment.period?.name || "—"}</td><td>{money(invoice.amount,invoice.currency)}</td></tr></tbody></table></div><div className="grid grid-3" style={{marginTop:24}}><div><div className="tile-meta">Total</div><strong>{money(invoice.amount,invoice.currency)}</strong></div><div><div className="tile-meta">Paid</div><strong>{money(invoice.amountPaid,invoice.currency)}</strong></div><div><div className="tile-meta">Balance due</div><strong>{money(balance,invoice.currency)}</strong></div></div><p style={{marginTop:24}}>For cash or bank transfer, quote the invoice number when making payment. A receipt will appear in your Finance page after Finance records the funds received.</p></article></div></section></main><Footer/></>;
}
