"use server";

import { randomUUID } from "node:crypto";
import { redirect } from "next/navigation";
import { revalidatePath } from "next/cache";
import { requireStudentSession } from "@/lib/student";
import { getDb } from "@/lib/db"; import { notifyStudentChange } from "@/lib/student-email";
import { getPublicAppUrl, settlePesapalPayment, submitPesapalOrder } from "@/lib/pesapal";

function invoiceNumber() {
  return `GITDM-INV-${new Date().getFullYear()}-${randomUUID().replaceAll("-", "").slice(0, 10).toUpperCase()}`;
}

async function startOnlinePayment(invoiceId: string | undefined, requestedAmount: number | undefined) {
  const ctx = await requireStudentSession("/campus/finance");
  const db = getDb();
  const enrollment = ctx.primaryEnrollment;
  if (!db) redirect("/campus/finance?error=Database%20unavailable.");
  if (!enrollment) {
    redirect("/campus/finance?error=No%20active%20enrolment%20is%20available.");
  }

  // A legacy enrolment may not have a period assigned. Resolve the programme's
  // currently OPEN billing period and attach it before creating any charge.
  let period = enrollment.period;
  if (!period) {
    period = await db.academicPeriod.findFirst({
      where: { programmeId: enrollment.programme.id, status: "OPEN" },
      orderBy: { sequence: "asc" },
    });
    if (!period) {
      redirect("/campus/finance?error=No%20open%20billing%20period%20is%20configured.%20Please%20contact%20Finance.");
      return;
    }
    await db.enrollment.update({ where: { id: enrollment.id }, data: { periodId: period.id } });
  }
  if (!period) return;

  let invoice = invoiceId
    ? await db.invoice.findFirst({
        where: { id: invoiceId, enrollment: { userId: ctx.user.id } },
      })
    : null;
  if (!invoiceId) {
    invoice = await db.invoice.findFirst({
      where: { enrollmentId: enrollment.id, periodId: period.id, status: { not: "VOID" } },
      orderBy: { dueAt: "desc" },
    });
  }

  // Choosing online payment supersedes a pending offline-invoice request.
  // Keep the same accounting record, issue it for the online transaction, and
  // clear the offline preference so no duplicate fee charge is created.
  if (invoice?.status === "DRAFT") {
    invoice = await db.invoice.update({
      where: { id: invoice.id },
      data: { status: "ISSUED", paymentPreference: null },
    });
  }

  // Online payment does not require the student to request an invoice. Create
  // the accounting charge automatically only when the student chooses to pay.
  if (!invoice) {
    invoice = await db.invoice.create({
      data: {
        enrollmentId: enrollment.id,
        periodId: period.id,
        invoiceNo: invoiceNumber(),
        description: `${enrollment.programme.name} — ${period.name}`,
        amount: Number(period.feeAmount),
        currency: period.currency,
        status: "ISSUED",
      },
    });
  }

  const outstanding = Number(invoice.amount) - Number(invoice.amountPaid);
  if (outstanding <= 0 || invoice.status === "VOID") {
    redirect("/campus/finance?error=There%20is%20no%20outstanding%20balance%20to%20pay.");
  }

  const amount = requestedAmount ?? outstanding;
  if (!Number.isFinite(amount) || amount <= 0) {
    redirect("/campus/finance?error=Enter%20a%20valid%20payment%20amount.");
  }
  if (amount > outstanding + 0.000001) {
    redirect(`/campus/finance?error=${encodeURIComponent(`Payment amount cannot exceed the outstanding balance of ${invoice.currency} ${outstanding.toLocaleString("en-UG")}.`)}`);
  }

  const merchantReference = `GITDM-${invoice.invoiceNo}-${Date.now()}`
    .slice(0, 50)
    .replace(/[^A-Za-z0-9._:-]/g, "-");
  const payment = await db.payment.create({
    data: {
      invoiceId: invoice.id,
      userId: ctx.user.id,
      provider: "PESAPAL",
      providerMerchantRef: merchantReference,
      amount,
      currency: invoice.currency.toUpperCase(),
      status: "PENDING",
    },
  });

  let response: Awaited<ReturnType<typeof submitPesapalOrder>>;
  try {
    // Vercel supplies a production URL automatically; APP_BASE_URL remains
    // the preferred explicit value for custom domains.
    const appUrl = getPublicAppUrl();
    response = await submitPesapalOrder({
      merchantReference,
      amount,
      currency: invoice.currency,
      description: invoice.description,
      callbackUrl: `${appUrl}/api/payments/pesapal/callback`,
      cancellationUrl: `${appUrl}/api/payments/pesapal/cancel?merchantReference=${encodeURIComponent(merchantReference)}`,
      email: ctx.user.email,
      firstName: ctx.user.firstName,
      lastName: ctx.user.lastName,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : "Payment start failed.";
    await db.payment.update({
      where: { id: payment.id },
      data: {
        status: "FAILED",
        providerDescription: message,
      },
    });
    revalidatePath("/campus/finance");
    redirect(`/campus/finance?error=${encodeURIComponent(message)}`);
  }

  if (!response.redirect_url || !response.order_tracking_id) {
    const message = response.message || "Pesapal did not return a payment URL.";
    await db.payment.update({
      where: { id: payment.id },
      data: {
        status: "FAILED",
        providerResponseJson: JSON.stringify(response),
        providerDescription: message,
      },
    });
    revalidatePath("/campus/finance");
    redirect(`/campus/finance?error=${encodeURIComponent(message)}`);
  }

  await db.payment.update({
    where: { id: payment.id },
    data: {
      providerRef: response.order_tracking_id,
      providerMerchantRef: response.merchant_reference || merchantReference,
      providerRedirectUrl: response.redirect_url,
      providerResponseJson: JSON.stringify(response),
      providerDescription: null,
      status: "PENDING",
    },
  });

  // Keep the external redirect outside the API-call try/catch. Next.js implements
  // redirect() by throwing a framework control-flow exception.
  redirect(response.redirect_url);
}

export async function payInvoice(formData: FormData) {
  const invoiceId = String(formData.get("invoiceId") || "").trim() || undefined;
  const rawAmount = String(formData.get("amount") || "").trim();
  const requestedAmount = rawAmount ? Number(rawAmount) : undefined;
  await startOnlinePayment(invoiceId, requestedAmount);
}

export async function requestOfflineInvoice(formData: FormData) {
  const method = String(formData.get("paymentPreference") || "").toUpperCase();
  if (!["CASH", "BANK_TRANSFER"].includes(method)) {
    redirect("/campus/finance?error=Choose%20cash%20or%20bank%20transfer.");
  }
  const ctx = await requireStudentSession("/campus/finance");
  const db = getDb();
  const enrollment = ctx.primaryEnrollment;
  if (!db) redirect("/campus/finance?error=account-unavailable");
  if (!enrollment) {
    redirect("/campus/finance?error=No%20active%20enrolment%20is%20available.");
  }

  // Offline billing follows the same period-resolution rule as online billing.
  // Students may request an invoice even when an older enrolment was created
  // without a period, but only against a configured OPEN period.
  let period = enrollment.period;
  if (!period) {
    period = await db.academicPeriod.findFirst({
      where: { programmeId: enrollment.programme.id, status: "OPEN" },
      orderBy: { sequence: "asc" },
    });
    if (!period) {
      redirect("/campus/finance?error=No%20open%20billing%20period%20is%20configured.");
      return;
    }
    await db.enrollment.update({ where: { id: enrollment.id }, data: { periodId: period.id } });
  }
  if (!period) return;
  const existing = await db.invoice.findFirst({
    where: { enrollmentId: enrollment.id, periodId: period.id, status: { not: "VOID" } },
  });
  if (existing) {
    redirect(`/campus/finance?error=${encodeURIComponent(existing.status === "DRAFT" ? "Your invoice request is already awaiting Finance." : "An invoice already exists. You can pay its balance or contact Finance.")}`);
  }
  const invoice = await db.invoice.create({
    data: {
      enrollmentId: enrollment.id,
      periodId: period.id,
      invoiceNo: invoiceNumber(),
      description: `${enrollment.programme.name} — ${period.name}`,
      amount: Number(period.feeAmount),
      currency: period.currency,
      status: "DRAFT",
      paymentPreference: method,
    },
  });
  const financeUsers = await db.user.findMany({ where: { roles: { some: { role: { code: "FINANCE" } } } }, select: { id: true } });
  await db.$transaction([
    db.notification.create({
      data: { userId: ctx.user.id, type: "FINANCE", title: "Invoice request received", body: `Your ${method === "CASH" ? "cash" : "bank transfer"} invoice request ${invoice.invoiceNo} has been sent to Finance for issuance.` },
    }),
    ...financeUsers.map((financeUser) => db.notification.create({
      data: { userId: financeUser.id, type: "FINANCE", title: "Offline invoice request", body: `${ctx.user.firstName || ctx.user.email} requested a ${method === "CASH" ? "cash" : "bank transfer"} invoice (${invoice.invoiceNo}). Review it in Finance → Invoices.` },
    })),
    db.auditLog.create({
      data: { userId: ctx.user.id, action: "OFFLINE_INVOICE_REQUESTED", entity: "Invoice", entityId: invoice.id, metadataJson: JSON.stringify({ method, invoiceNo: invoice.invoiceNo }) },
    }),
  ]);
  await notifyStudentChange({ email:ctx.user.email, firstName:ctx.user.firstName, title:"Invoice request received", body:`Your invoice request ${invoice.invoiceNo} has been sent to Finance for issuance.`, action:"OFFLINE_INVOICE_REQUESTED", href:"/campus/finance" });
  revalidatePath("/campus/finance");
  redirect("/campus/finance?request=received");
}

export async function refreshPesapalPayment(formData: FormData) {
  const paymentId = String(formData.get("paymentId") || "").trim();
  const ctx = await requireStudentSession("/campus/finance");
  const db = getDb();
  if (!db) redirect("/campus/finance?error=account-unavailable");
  const payment = await db.payment.findFirst({
    where: { id: paymentId, userId: ctx.user.id, provider: "PESAPAL" },
  });
  if (!payment) redirect("/campus/finance?error=payment-not-found");
  if (!payment.providerRef) redirect("/campus/finance?error=payment-reference-missing");
  try {
    const result = await settlePesapalPayment(payment.providerRef);
    revalidatePath("/campus/finance");
    redirect(`/campus/finance?payment=${result.status.toLowerCase()}`);
  } catch (error) {
    if (error && typeof error === "object" && "digest" in error) throw error;
    redirect(`/campus/finance?error=${encodeURIComponent(error instanceof Error ? error.message : "payment-status-check-failed")}`);
  }
}
