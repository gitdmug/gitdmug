import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { StudentNav } from "@/components/StudentNav";
import { GITDM } from "@/lib/branding";
import { requireStudentSession } from "@/lib/student";
import { getDb } from "@/lib/db";
import { humanStatus } from "@/lib/status";

export const metadata = { title: `Academic | Campus | ${GITDM.shortName}` };
export const dynamic = "force-dynamic";

export default async function AcademicPage() {
 const ctx=await requireStudentSession("/campus/academic"); const enr=ctx.primaryEnrollment; const db=getDb();
 let grades:any[]=[], attendance:any[]=[], classAttendance:any[]=[], certificates:any[]=[], modules:any[]=[], assignments:any[]=[], exams:any[]=[], nextClass:any=null;
 if(db){ [grades,attendance,classAttendance,certificates]=await Promise.all([
  db.grade.findMany({where:{userId:ctx.user.id,status:"FINAL",periodId:enr?.period?.id||undefined},include:{course:true},orderBy:{course:{orderIndex:"asc"}}}),
  db.attendanceRecord.findMany({where:{userId:ctx.user.id,periodId:enr?.period?.id||undefined},include:{course:true},orderBy:{date:"desc"}}),
  db.classAttendanceRecord.findMany({where:{userId:ctx.user.id,periodId:enr?.period?.id||undefined},include:{timetableEvent:true,course:true},orderBy:{date:"desc"}}),
  db.certificate.findMany({where:{userId:ctx.user.id},include:{programme:true},orderBy:{issuedAt:"desc"}})
 ]);
  if(enr){
    const courseLinks=await db.courseEnrollment.findMany({where:{enrollmentId:enr.id,status:{in:["ACTIVE","REPEATING"]}},select:{courseId:true}});
    const courseIds=courseLinks.map(x=>x.courseId);
    [modules,assignments,exams,nextClass]=await Promise.all([
      db.courseModule.findMany({where:{courseId:{in:courseIds},published:true,approvalStatus:"APPROVED"},include:{course:true,lessons:{where:{published:true},include:{progress:{where:{userId:ctx.user.id}}}}},orderBy:[{course:{orderIndex:"asc"}},{orderIndex:"asc"}]}),
      db.assignment.findMany({where:{courseId:{in:courseIds},status:"PUBLISHED",OR:[{dueAt:null},{dueAt:{gte:new Date()}}]},include:{course:true,submissions:{where:{userId:ctx.user.id}}},orderBy:{dueAt:"asc"},take:8}),
      db.exam.findMany({where:{courseId:{in:courseIds},status:"PUBLISHED",OR:[{closesAt:null},{closesAt:{gte:new Date()}}]},include:{course:true},orderBy:{opensAt:"asc"},take:8}),
      db.timetableEvent.findFirst({where:{courseId:{in:courseIds},startAt:{gte:new Date()},OR:[{periodId:enr.periodId},{periodId:null}]},include:{course:true,module:true},orderBy:{startAt:"asc"}})
    ]);
  }
 }
 const scheduledMinutes=classAttendance.reduce((sum,a)=>sum+Math.max(1,Math.round((new Date(a.timetableEvent.endAt).getTime()-new Date(a.timetableEvent.startAt).getTime())/60000)),0);
 const attendedMinutes=classAttendance.reduce((sum,a)=>sum+Number(a.minutesAttended||0),0);
 const attendancePct=classAttendance.length?Math.round(Math.min(100,attendedMinutes/Math.max(1,scheduledMinutes)*100)*10)/10:(attendance.length?Math.round(attendance.filter(a=>a.status!=="ABSENT").length/attendance.length*1000)/10:null);
 return <><Header active="/campus" workspace="student"/><StudentNav active="/campus/academic"/><main>
  <section className="page-hero"><div className="container"><div className="eyebrow">Academic record</div><h1>Your academic progress and credentials</h1><p>Published grades, attendance, transcript pathway and certificate status in one place.</p></div></section>
  <section className="section"><div className="container">
   {!enr?<div className="access-banner"><strong>No academic record yet.</strong> Records start after admission and enrolment.</div>:
   <><div className="grid grid-4" style={{marginBottom:28}}><div className="panel"><div className="eyebrow">Programme</div><h3 style={{marginTop:8}}>{enr.programme.shortName||enr.programme.name}</h3><p>{enr.period?.name||"Period pending"}</p></div><div className="panel"><div className="eyebrow">Grades</div><h2>{grades.length}</h2><p>Final published results</p></div><div className="panel"><div className="eyebrow">Attendance</div><h2>{attendancePct===null?"—":`${attendancePct}%`}</h2><p>Current period</p></div><div className="panel"><div className="eyebrow">Credentials</div><h2>{certificates.length}</h2><p>Certificate records</p></div></div>
   <div className="card" style={{marginBottom:28}}><div className="eyebrow">Your learning journey</div><h2>Where you are now</h2><p>Every academic action is reflected here. Academic Affairs controls the official timetable; lecturers cannot create an unannounced class on your calendar.</p><div className="table-wrap" style={{marginTop:18}}><table className="data"><thead><tr><th>Stage</th><th>Current status</th><th>What happens next</th></tr></thead><tbody>
    <tr><td><strong>1. Enrolment</strong></td><td><span className="badge">{enr.status}</span></td><td>Your programme period/cohort determines the courses, classes and assessments you can receive.</td></tr>
    <tr><td><strong>2. Learning</strong></td><td><span className="badge">{modules.length} published module(s)</span></td><td>Open My Learning, study the approved lessons/materials and mark lessons complete.</td></tr>
    <tr><td><strong>3. Classes</strong></td><td><span className="badge">{nextClass ? "Next class scheduled" : "No upcoming class"}</span></td><td>{nextClass ? `${nextClass.course?.code || "Course"} · ${nextClass.title} · ${new Date(nextClass.startAt).toLocaleString("en-UG")}` : "Your calendar updates when Academic Affairs publishes the next session."}</td></tr>
    <tr><td><strong>4. Coursework</strong></td><td><span className="badge">{assignments.length} open</span></td><td>Submit assignments/quizzes by their published deadlines; lecturers mark and return feedback.</td></tr>
    <tr><td><strong>5. Examination</strong></td><td><span className="badge">{exams.length} published</span></td><td>Check eligibility, date, format and venue/online instructions, then complete the approved exam window.</td></tr>
    <tr><td><strong>6. Results</strong></td><td><span className="badge">{grades.length} final result(s)</span></td><td>Academic/Exam staff moderate and publish results; published grades become part of your academic record.</td></tr>
    </tbody></table></div><div className="actions" style={{marginTop:18}}><Link href="/campus/learning" className="btn btn-primary btn-sm">My Learning</Link><Link href="/campus/timetable" className="btn btn-outline-dark btn-sm">My Timetable</Link><Link href="/campus/assessments" className="btn btn-outline-dark btn-sm">Assessments</Link></div></div>
   <div className="grid grid-2">
    <div><div className="eyebrow">Results</div><h2>Published grades</h2>{grades.length?<div className="table-wrap"><table className="data"><thead><tr><th>Course</th><th>Total</th><th>Status</th></tr></thead><tbody>{grades.map(g=><tr key={g.id}><td>{g.course.code} — {g.course.title}</td><td>{Number(g.totalPercent).toFixed(1)}%</td><td>{humanStatus(g.status)}</td></tr>)}</tbody></table></div>:<div className="panel"><p>Your Exam Officer has not published final results yet.</p></div>}</div>
    <div><div className="eyebrow">Attendance</div><h2>Attendance record</h2>{attendance.length?<div className="table-wrap"><table className="data"><thead><tr><th>Date</th><th>Course</th><th>Status</th></tr></thead><tbody>{attendance.slice(0,20).map(a=><tr key={a.id}><td>{a.date.toLocaleDateString("en-UG")}</td><td>{a.course.code}</td><td>{humanStatus(a.status)}</td></tr>)}</tbody></table></div>:<div className="panel"><p>No attendance has been recorded yet.</p></div>}</div>
   </div>
   <div style={{marginTop:36}}><div className="eyebrow">Credentials</div><h2>Certificates</h2>{certificates.length?<div className="stack">{certificates.map(c=><div className="card" key={c.id}><h3>{c.programme.name}</h3><p>Certificate number: <strong>{c.number}</strong></p><span className="badge">{humanStatus(c.status)}</span>{c.issuedAt?<p style={{marginTop:8}}>Issued {c.issuedAt.toLocaleDateString("en-UG")}</p>:null}</div>)}</div>:<div className="panel"><p>Certificate eligibility will appear here after programme completion and approval.</p></div>}</div>
   </>}
   <div className="actions"><Link href="/campus" className="btn btn-outline-dark btn-sm">← Dashboard</Link><Link href="/campus/assessments" className="btn btn-outline-dark btn-sm">Assessments</Link><Link href="/campus/academic/transcript" className="btn btn-outline-dark btn-sm">Transcript</Link></div>
  </div></section></main><Footer/></>;
}
