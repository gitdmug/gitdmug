import { requireStudentSession } from "@/lib/student";
import { getDb } from "@/lib/db";
import { GITDM } from "@/lib/branding";
import PrintButton from "./PrintButton";
export const dynamic="force-dynamic";
export const metadata={title:`Official Transcript | ${GITDM.shortName}`};
export default async function TranscriptPage(){
 const ctx=await requireStudentSession("/campus/academic/transcript"); const db=getDb();
 const official=db&&ctx.primaryEnrollment?await db.transcript.findFirst({where:{userId:ctx.user.id,programmeId:ctx.primaryEnrollment.programme.id},orderBy:{generatedAt:"desc"}}):null;
 const rows=db?await db.grade.findMany({where:{userId:ctx.user.id,status:"FINAL"},include:{course:true,period:true},orderBy:[{period:{sequence:"asc"}},{course:{orderIndex:"asc"}}]}):[];
 return <main style={{maxWidth:980,margin:"40px auto",padding:"0 24px"}}><div className="card"><div className="eyebrow">Official academic record</div><h1>Transcript</h1><p>{GITDM.name}</p>{official?<p><strong>Official transcript:</strong> {official.number} · Generated {official.generatedAt.toLocaleDateString("en-UG")}</p>:<p className="muted">Official transcript will appear here after Registry prepares it.</p>}<p><strong>{[ctx.user.firstName,ctx.user.lastName].filter(Boolean).join(" ")||ctx.user.email}</strong></p><div className="table-wrap" style={{marginTop:24}}><table className="data"><thead><tr><th>Period</th><th>Course</th><th>Score</th><th>Result</th></tr></thead><tbody>{rows.map(r=><tr key={r.id}><td>{r.period?.name||"—"}</td><td>{r.course.code} — {r.course.title}</td><td>{Number(r.totalPercent).toFixed(1)}%</td><td>{Number(r.totalPercent)>=50?"PASS":"FAIL"}</td></tr>)}</tbody></table></div><div className="actions" style={{marginTop:24}}><PrintButton /><a className="btn btn-outline-dark" href="/campus/academic">Back to Academic</a></div></div></main>
}
