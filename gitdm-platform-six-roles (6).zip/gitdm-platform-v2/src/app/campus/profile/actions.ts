"use server";
import { revalidatePath } from "next/cache"; import { redirect } from "next/navigation"; import { requireStudentSession } from "@/lib/student"; import { getDb } from "@/lib/db"; import { uploadPrivateFile } from "@/lib/file-storage"; import { notifyStudentChange } from "@/lib/student-email";
export async function saveProfile(formData:FormData){const ctx=await requireStudentSession("/campus/profile");const db=getDb();if(!db)throw new Error("Database unavailable.");const firstName=String(formData.get("firstName")||"").trim()||null;const lastName=String(formData.get("lastName")||"").trim()||null;const phone=String(formData.get("phone")||"").trim()||null;const dateOfBirth=String(formData.get("dateOfBirth")||"").trim();const data:{gender:string|null;nationality:string|null;address:string|null;city:string|null;country:string|null;emergencyName:string|null;emergencyPhone:string|null;dateOfBirth:Date|null;avatarUrl?:string}= {gender:String(formData.get("gender")||"").trim()||null,nationality:String(formData.get("nationality")||"").trim()||null,address:String(formData.get("address")||"").trim()||null,city:String(formData.get("city")||"").trim()||null,country:String(formData.get("country")||"").trim()||null,emergencyName:String(formData.get("emergencyName")||"").trim()||null,emergencyPhone:String(formData.get("emergencyPhone")||"").trim()||null,dateOfBirth:dateOfBirth?new Date(dateOfBirth):null};const avatar=formData.get("avatar");
if(avatar instanceof File&&avatar.size){
  if (!avatar.type.startsWith("image/")) throw new Error("Profile picture must be a PNG, JPEG, or WebP image.");
  if (avatar.size > 5 * 1024 * 1024) throw new Error("Profile picture must be 5 MB or smaller.");
  try {
    data.avatarUrl=await uploadPrivateFile(avatar,"gitdm/profile",ctx.user.id);
  } catch (error) {
    // Keep profile pictures functional even when object-storage credentials are
    // temporarily unavailable. Small profile images can safely be retained as
    // a data URL in the existing Profile.avatarUrl field; no other profile
    // storage or page behaviour is changed.
    const bytes=new Uint8Array(await avatar.arrayBuffer());
    data.avatarUrl=`data:${avatar.type};base64,${Buffer.from(bytes).toString("base64")}`;
    console.warn("Profile object storage upload failed; using database fallback:", error);
  }
}await db.user.update({where:{id:ctx.user.id},data:{firstName,lastName,phone}});await db.profile.upsert({where:{userId:ctx.user.id},update:data,create:{userId:ctx.user.id,...data}});await db.auditLog.create({data:{userId:ctx.user.id,action:"PROFILE_UPDATED",entity:"Profile",metadataJson:JSON.stringify({hasAvatar:Boolean(data.avatarUrl)})}}); await notifyStudentChange({email:ctx.user.email,firstName:firstName||ctx.user.firstName,title:"Your GITDM profile was updated",body:"Your personal profile changes have been saved successfully.",action:"PROFILE_UPDATED",href:"/campus/profile"});revalidatePath("/campus/profile");revalidatePath("/campus");redirect("/campus/profile?saved=1");}
