 "use server";

import { revalidatePath } from "next/cache";
import { getCurrentUser } from "@/lib/access";
import { getDb } from "@/lib/db"; import { notifyStudentChange } from "@/lib/student-email";

export async function createSupportTicket(formData: FormData) {
  const user = await getCurrentUser();
  const db = getDb();
  if (!user || !db) throw new Error("You must be signed in.");
  const subject = String(formData.get("subject") || "").trim();
  const description = String(formData.get("description") || "").trim();
  const priority = String(formData.get("priority") || "NORMAL");
  if (subject.length < 4 || description.length < 10) throw new Error("Please provide a useful subject and description.");
  const ticket = await db.supportTicket.create({
    data: { requesterId: user.id, subject, description, priority: ["LOW","NORMAL","HIGH"].includes(priority) ? priority : "NORMAL" },
  });
  await db.auditLog.create({
    data: { userId: user.id, action: "SUPPORT_TICKET_CREATED", entity: "SupportTicket", entityId: ticket.id, metadataJson: JSON.stringify({ subject }) },
  });
  await notifyStudentChange({ email:user.email, firstName:user.firstName, title:"Support request received", body:`Your support ticket “${subject}” has been created. GITDM Support will review it and respond through Campus.`, action:"SUPPORT_TICKET_CREATED", href:"/campus/support" });
  revalidatePath("/campus/support");
}
