import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { StudentNav } from "@/components/StudentNav";
import { GITDM } from "@/lib/branding";
import { requireStudentSession } from "@/lib/student";
import { getDb } from "@/lib/db";
import { humanStatus } from "@/lib/status";
import { createSupportTicket } from "./actions";

export const metadata = { title: `Support | Campus | ${GITDM.shortName}` };
export const dynamic = "force-dynamic";

export default async function SupportPage() {
  const ctx = await requireStudentSession("/campus/support");
  const db = getDb();
  const tickets = db ? await db.supportTicket.findMany({
    where: { requesterId: ctx.user.id }, orderBy: { createdAt: "desc" }, take: 20,
  }) : [];
  return <>
    <Header active="/campus" workspace="student" /><StudentNav active="/campus/support" />
    <main>
      <section className="page-hero"><div className="container"><div className="eyebrow">Student support</div>
        <h1>Get help and track your requests</h1><p>Open a request for Student Affairs, IT, academic, finance or partner-platform support.</p>
      </div></section>
      <section className="section"><div className="container">
        <div className="grid grid-2" style={{gap:24}}>
          <div className="panel">
            <div className="eyebrow">New request</div><h2 style={{marginTop:8}}>Contact the right team</h2>
            <form action={createSupportTicket} className="form-grid">
              <div className="form-row"><label>Subject</label><input name="subject" required minLength={4} placeholder="e.g. I cannot access my course" /></div>
              <div className="form-row"><label>Priority</label><select name="priority" defaultValue="NORMAL"><option value="LOW">Low</option><option value="NORMAL">Normal</option><option value="HIGH">High</option></select></div>
              <div className="form-row"><label>Description</label><textarea name="description" required minLength={10} placeholder="Describe what happened and what you need help with." /></div>
              <button className="btn btn-primary" type="submit">Submit support request</button>
            </form>
          </div>
          <div>
            <div className="eyebrow">Your tickets</div><h2>Recent requests</h2>
            {tickets.length === 0 ? <div className="panel"><p>No tickets yet. Use the form to open your first request.</p></div> :
              <div className="stack">{tickets.map(t=><div className="card" key={t.id}><div style={{display:"flex",justifyContent:"space-between",gap:12}}><h3>{t.subject}</h3><span className="badge">{humanStatus(t.status)}</span></div><p>{t.description}</p><div className="tile-meta">{t.priority} · {t.createdAt.toLocaleDateString("en-UG")}</div></div>)}</div>}
          </div>
        </div>
        <div className="actions"><Link href="/campus" className="btn btn-outline-dark btn-sm">← Dashboard</Link></div>
      </div></section>
    </main><Footer />
  </>;
}
