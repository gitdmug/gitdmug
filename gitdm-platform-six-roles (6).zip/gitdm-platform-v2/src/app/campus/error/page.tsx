import Link from "next/link";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { GITDM } from "@/lib/branding";

export const dynamic = "force-dynamic";

export default async function CampusErrorPage({
  searchParams,
}: {
  searchParams: Promise<{ code?: string }>;
}) {
  const params = await searchParams;
  const isAccount = params.code === "account-load";
  const isDatabase = params.code === "database-unavailable";

  return (
    <>
      <Header active="/campus" />
      <main>
        <section className="page-hero">
          <div className="container">
            <div className="eyebrow">GITDM Campus</div>
            <h1>We could not open your campus yet.</h1>
            <p>
              {isAccount
                ? "Your sign-in is valid, but the institutional account record could not be loaded. GITDM will attempt to repair the account link automatically on the next login."
                : isDatabase
                  ? "Campus could not reach the institutional database. Your authentication and records have not been changed."
                  : "The campus service is temporarily unavailable. Your records have not been changed."}
            </p>
          </div>
        </section>
        <section className="section">
          <div className="container" style={{ maxWidth: 760 }}>
            <div className="panel" style={{ padding: 32 }}>
              <div className="eyebrow">What to do</div>
              <h2 style={{ marginTop: 8 }}>Please try again</h2>
              <p>
                Try Campus again first. If the problem continues, sign in again so GITDM can
                re-check your institutional account link. If it still fails, contact GITDM support
                and include the time of the failed attempt.
              </p>
              <div className="actions" style={{ marginTop: 24 }}>
                <Link className="btn btn-primary" href="/campus">Try Campus again</Link>
                <Link className="btn btn-outline-dark" href="/auth/sign-in?returnTo=/campus">Sign in again</Link>
                <Link className="btn btn-outline-dark" href="/">Return home</Link>
              </div>
              <p className="tile-meta" style={{ marginTop: 24 }}>
                {GITDM.shortName} · Secure digital campus
              </p>
            </div>
          </div>
        </section>
      </main>
      <Footer />
    </>
  );
}
