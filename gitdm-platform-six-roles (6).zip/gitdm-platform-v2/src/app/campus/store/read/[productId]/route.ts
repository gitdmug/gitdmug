import { NextRequest, NextResponse } from "next/server";
import { readFile } from "node:fs/promises";
import path from "node:path";
import { getCurrentUser } from "@/lib/access";
import { getDb } from "@/lib/db";
import { databaseFileResponse } from "@/lib/file-delivery";

const PRIVATE_BOOKS: Record<string, { title: string; slug: string }> = {
  "financial-markets-handbook.pdf": { title: "Financial Markets Handbook", slug: "financial-markets-handbook" },
  "trading-derivatives-handbook.pdf": { title: "Trading & Derivatives Handbook", slug: "trading-derivatives-handbook" },
};
const htmlSafe = (value: string) => value.replace(/[&<>"']/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" } as Record<string, string>)[c] || c);

export async function GET(request: NextRequest, { params }: { params: Promise<{ productId: string }> }) {
  const user = await getCurrentUser();
  if (!user) return NextResponse.json({ error: "Unauthorized" }, { status: 401 });
  const { productId } = await params;
  const db = getDb();
  if (!db) return NextResponse.json({ error: "Database unavailable" }, { status: 503 });
  const download = request.nextUrl.searchParams.get("download") === "1";
  const fileMode = request.nextUrl.searchParams.get("file") === "1";
  const paid = await db.storeOrderItem.findFirst({ where: { productId, fulfillmentMode: "DIGITAL", order: { userId: user.id, paymentStatus: "COMPLETED" } }, include: { product: true } });
  if (!paid?.product.digitalUrl) return NextResponse.json({ error: "Digital file is not available for this paid order." }, { status: 404 });
  if (!download && !paid.product.onlineReadable) return NextResponse.json({ error: "Online reading is not enabled for this material. Use Download instead." }, { status: 403 });

  if (paid.product.digitalUrl.startsWith("gitdmbook:")) {
    const filename = paid.product.digitalUrl.slice("gitdmbook:".length);
    const book = PRIVATE_BOOKS[filename];
    if (!book) return NextResponse.json({ error: "Book file is not configured." }, { status: 404 });
    if (download || fileMode) {
      try {
        const bytes = await readFile(path.join(process.cwd(), "private", "books", filename));
        return new NextResponse(new Uint8Array(bytes), { status: 200, headers: {
          "Content-Type": "application/pdf",
          "Content-Length": String(bytes.byteLength),
          "Content-Disposition": `${download ? "attachment" : "inline"}; filename="GITDM-${filename}"`,
          "Cache-Control": "private, no-store, max-age=0",
          "X-Content-Type-Options": "nosniff",
        }});
      } catch {
        return NextResponse.json({ error: "The book file is not available on this deployment." }, { status: 503 });
      }
    }
    const title = htmlSafe(book.title);
    const baseUrl = request.nextUrl.pathname;
    const bookSlug = book.slug;
    const html = `<!doctype html><html lang="en"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>${title} | GITDM</title><style>*{box-sizing:border-box}body{margin:0;background:#f3f5fa;color:#182344;font:15px/1.5 Arial,sans-serif}.top{background:#101a45;color:white;padding:22px max(20px,calc((100vw - 1200px)/2));border-bottom:4px solid #b99445}.eyebrow{font-size:11px;letter-spacing:.15em;color:#d9bd7c;font-weight:800}.top h1{margin:7px 0;font-size:clamp(24px,4vw,38px)}.top p{margin:0;color:#e2e7f3}.bar{max-width:1200px;margin:16px auto;padding:0 18px;display:flex;gap:10px;align-items:center;justify-content:space-between;flex-wrap:wrap}.count{font-weight:700;color:#334269}.button{display:inline-block;padding:10px 15px;background:#b99445;color:#101a45;text-decoration:none;font-weight:800;border-radius:7px}.reader{max-width:1200px;margin:0 auto 28px;padding:0 18px;position:relative}.reader:after{content:'GITDM • LICENSED EDUCATIONAL COPY';position:absolute;z-index:2;pointer-events:none;left:50%;top:50%;transform:translate(-50%,-50%) rotate(-27deg);font-size:clamp(18px,3vw,42px);font-weight:900;white-space:nowrap;color:rgba(16,26,69,.07)}iframe{display:block;width:100%;height:calc(100vh - 210px);min-height:650px;border:1px solid #d7ddec;border-radius:10px;background:white}.foot{text-align:center;padding:16px;color:#66718a;font-size:12px}@media(max-width:600px){iframe{height:78vh;min-height:500px}.top{padding:20px}.bar{align-items:flex-start;flex-direction:column}}</style></head><body><header class="top"><div class="eyebrow">GITDM · OFFICIAL BRANDED EDITION</div><h1>${title}</h1><p>Paid learning resource · Personal licensed copy · Educational use only</p></header><div class="bar"><span id="reader-count" class="count">Reader count loading…</span><a class="button" href="${baseUrl}?download=1">Download watermarked PDF</a></div><main class="reader"><iframe title="${title}" src="${baseUrl}?file=1"></iframe></main><footer class="foot">© 2026 GITDM. Do not redistribute or resell. Financial education only; no financial advice or guaranteed outcomes.</footer><script>(function(){const slug=${JSON.stringify(bookSlug)};const key='gitdm-book-reader:'+slug;let visitorKey;try{visitorKey=localStorage.getItem(key);if(!visitorKey){visitorKey=(crypto.randomUUID?crypto.randomUUID():'reader-'+Date.now()+'-'+Math.random().toString(36).slice(2));localStorage.setItem(key,visitorKey)}}catch(e){visitorKey='reader-'+Date.now()+'-'+Math.random().toString(36).slice(2)}setTimeout(function(){fetch('/api/book-reads',{method:'POST',headers:{'Content-Type':'application/json'},cache:'no-store',body:JSON.stringify({bookSlug:slug,visitorKey})}).then(r=>r.json()).then(d=>{if(typeof d.count==='number')document.getElementById('reader-count').textContent=d.count.toLocaleString()+' readers have opened this book'}).catch(()=>{document.getElementById('reader-count').textContent='GITDM readers worldwide'})},10000)})();</script></body></html>`;
    return new NextResponse(html, { headers: { "Content-Type": "text/html; charset=utf-8", "Cache-Control": "private, no-store, max-age=0", "X-Content-Type-Options": "nosniff" } });
  }

  if (paid.product.digitalUrl.startsWith("neonfile:")) return (await databaseFileResponse(paid.product.digitalUrl, download ? "attachment" : "inline"))!;
  return NextResponse.redirect(new URL(paid.product.digitalUrl, request.url));
}
