"use server";
import { redirect } from "next/navigation"; import { revalidatePath } from "next/cache"; import { requireStudentSession } from "@/lib/student"; import { getDb } from "@/lib/db"; import { makeReference } from "@/lib/reference"; import { getPublicAppUrl, submitPesapalOrder } from "@/lib/pesapal"; import { notifyStudentChange } from "@/lib/student-email";
export async function addToCart(fd:FormData){
  const ctx=await requireStudentSession("/campus/store");
  const db=getDb();
  if(!db) redirect("/campus/store?error=Database%20unavailable.");

  const productId=String(fd.get("productId")||"").trim();
  const quantityRaw=Number(fd.get("quantity")||1);
  const quantity=Number.isFinite(quantityRaw)&&Number.isInteger(quantityRaw)&&quantityRaw>0?quantityRaw:1;
  const mode=String(fd.get("fulfillmentMode")||"") as "DIGITAL"|"HARD_COPY";

  try {
    const p=await db.storeProduct.findUnique({where:{id:productId}});
    if(!p||p.status!=="ACTIVE"||p.audience!=="STUDENT") throw new Error("This item belongs to the public catalogue or is no longer available.");
    if(mode!=="DIGITAL"&&mode!=="HARD_COPY") throw new Error("Please select a valid fulfilment format.");
    if(p.fulfillment!=="BOTH"&&p.fulfillment!==mode) throw new Error("The selected format is not available for this item.");

    const cart=await db.storeCart.upsert({
      where:{userId:ctx.user.id},
      update:{},
      create:{userId:ctx.user.id},
    });

    const existing=await db.storeCartItem.findFirst({
      where:{cartId:cart.id,productId,fulfillmentMode:mode},
    });

    if(mode==="HARD_COPY") {
      const requestedTotal=(existing?.quantity||0)+quantity;
      if(requestedTotal>p.stock) throw new Error(`Only ${p.stock} hard copies are currently available.`);
    }

    if(existing){
      await db.storeCartItem.update({
        where:{id:existing.id},
        data:{quantity:{increment:quantity}},
      });
    } else {
      await db.storeCartItem.create({
        data:{cartId:cart.id,productId,quantity,fulfillmentMode:mode},
      });
    }
  } catch(error) {
    const message=error instanceof Error?error.message:"The item could not be added to your cart.";
    redirect(`/campus/store?error=${encodeURIComponent(message)}`);
  }

  revalidatePath("/campus/store");
  redirect("/campus/store?cart=added");
}
export async function removeFromCart(fd:FormData){const ctx=await requireStudentSession("/campus/store");const db=getDb();if(!db)throw new Error("Database unavailable.");await db.storeCartItem.deleteMany({where:{id:String(fd.get("itemId")),cart:{userId:ctx.user.id}}});revalidatePath("/campus/store");redirect("/campus/store");}
export async function checkoutStore(fd:FormData){const ctx=await requireStudentSession("/campus/store/checkout");const db=getDb();if(!db)throw new Error("Database unavailable.");const cart=await db.storeCart.findUnique({where:{userId:ctx.user.id},include:{items:{include:{product:true}}}});if(!cart||!cart.items.length)redirect("/campus/store?error=Your%20cart%20is%20empty.");const name=String(fd.get("contactName")||"").trim();const email=String(fd.get("contactEmail")||ctx.user.email).trim();const phone=String(fd.get("contactPhone")||ctx.user.phone||"").trim();if(!name||!email||!phone)redirect("/campus/store/checkout?error=Provide%20your%20name%2C%20email%20and%20phone%20before%20checkout.");const modes=new Set(cart.items.map(i=>i.fulfillmentMode));if(modes.size>1)redirect("/campus/store/checkout?error=Checkout%20digital%20and%20hard-copy%20items%20as%20separate%20orders.");const mode=[...modes][0];const invalid=cart.items.find(i=>i.product.status!=="ACTIVE"||(mode==="HARD_COPY"&&i.quantity>i.product.stock));if(invalid)redirect("/campus/store?error=One%20or%20more%20cart%20items%20are%20no%20longer%20available.");const total=cart.items.reduce((sum,i)=>sum+Number(i.product.price)*i.quantity,0);const order=await db.storeOrder.create({data:{userId:ctx.user.id,orderNo:makeReference("ORD"),totalAmount:total,currency:cart.items[0].product.currency,fulfillmentMode:mode,contactName:name,contactEmail:email,contactPhone:phone,paymentStatus:"PENDING",items:{create:cart.items.map(i=>({productId:i.productId,quantity:i.quantity,unitPrice:i.product.price,fulfillmentMode:i.fulfillmentMode}))}}});await db.storeCartItem.deleteMany({where:{cartId:cart.id}});const merchantReference=`GITDM-STORE-${order.orderNo}-${Date.now()}`.slice(0,50);const payment=await db.storePayment.create({data:{orderId:order.id,userId:ctx.user.id,provider:"PESAPAL",providerMerchantRef:merchantReference,amount:total,currency:order.currency,status:"PENDING"}}); await notifyStudentChange({email:ctx.user.email,firstName:ctx.user.firstName,title:"GITDM Store order created",body:`Your store order ${order.orderNo} has been created for ${order.currency} ${total.toLocaleString("en-UG")}. Continue to the secure Pesapal checkout to complete payment.`,action:"STORE_ORDER_CREATED",href:"/campus/store"});try{const appUrl=getPublicAppUrl();const response=await submitPesapalOrder({merchantReference,amount:total,currency:order.currency,description:`GITDM Store order ${order.orderNo}`,callbackUrl:`${appUrl}/api/payments/pesapal/callback`,cancellationUrl:`${appUrl}/api/payments/pesapal/cancel?merchantReference=${encodeURIComponent(merchantReference)}`,email,phone,firstName:ctx.user.firstName,lastName:ctx.user.lastName});if(!response.redirect_url||!response.order_tracking_id)throw new Error(response.message||"Pesapal did not return a checkout URL.");await db.storePayment.update({where:{id:payment.id},data:{providerRef:response.order_tracking_id,providerMerchantRef:response.merchant_reference||merchantReference,providerRedirectUrl:response.redirect_url,providerResponseJson:JSON.stringify(response)}});redirect(response.redirect_url);}catch(error){if(error&&typeof error==="object"&&"digest" in error)throw error;await db.storePayment.update({where:{id:payment.id},data:{status:"FAILED",providerStatus:error instanceof Error?error.message:"Payment start failed"}});await db.storeOrder.update({where:{id:order.id},data:{paymentStatus:"FAILED"}});redirect(`/campus/store?error=${encodeURIComponent(error instanceof Error?error.message:"Payment could not be started")}`);}}
export async function retryStorePayment(fd:FormData){const ctx=await requireStudentSession("/campus/store");const db=getDb();if(!db)throw new Error("Database unavailable.");const order=await db.storeOrder.findFirst({where:{id:String(fd.get("orderId")),userId:ctx.user.id}});if(!order||["COMPLETED"].includes(order.paymentStatus))redirect("/campus/store");const merchantReference=`GITDM-STORE-${order.orderNo}-${Date.now()}`.slice(0,50);const payment=await db.storePayment.create({data:{orderId:order.id,userId:ctx.user.id,provider:"PESAPAL",providerMerchantRef:merchantReference,amount:order.totalAmount,currency:order.currency,status:"PENDING"}});try{const appUrl=getPublicAppUrl();const response=await submitPesapalOrder({merchantReference,amount:Number(order.totalAmount),currency:order.currency,description:`GITDM Store order ${order.orderNo}`,callbackUrl:`${appUrl}/api/payments/pesapal/callback`,cancellationUrl:`${appUrl}/api/payments/pesapal/cancel?merchantReference=${encodeURIComponent(merchantReference)}`,email:order.contactEmail||ctx.user.email,phone:order.contactPhone||ctx.user.phone,firstName:ctx.user.firstName,lastName:ctx.user.lastName});if(!response.redirect_url||!response.order_tracking_id)throw new Error(response.message||"Pesapal did not return a checkout URL.");await db.storePayment.update({where:{id:payment.id},data:{providerRef:response.order_tracking_id,providerMerchantRef:response.merchant_reference||merchantReference,providerRedirectUrl:response.redirect_url,providerResponseJson:JSON.stringify(response)}});redirect(response.redirect_url);}catch(error){if(error&&typeof error==="object"&&"digest" in error)throw error;await db.storePayment.update({where:{id:payment.id},data:{status:"FAILED",providerStatus:error instanceof Error?error.message:"Payment start failed"}});redirect(`/campus/store?error=${encodeURIComponent(error instanceof Error?error.message:"Payment could not be started")}`);}}
