"use server";
import { revalidatePath } from "next/cache"; import { redirect } from "next/navigation"; import { getCurrentUser } from "@/lib/access"; import { getDb } from "@/lib/db";
export async function markNotificationRead(formData:FormData){const user=await getCurrentUser();const db=getDb();if(!user||!db)redirect("/auth/login");const id=String(formData.get("id")||"");await db.notification.updateMany({where:{id,userId:user.id},data:{readAt:new Date()}});revalidatePath("/campus/notifications");}
export async function markAllNotificationsRead(){const user=await getCurrentUser();const db=getDb();if(!user||!db)redirect("/auth/login");await db.notification.updateMany({where:{userId:user.id,readAt:null},data:{readAt:new Date()}});revalidatePath("/campus/notifications");}
