import { redirect } from "next/navigation";

export default function LecturesRedirect(){
  redirect("/campus/learning");
}
