"use client";

import { useEffect } from "react";

export default function CampusError({
  error,
  reset,
}: {
  error: Error & { digest?: string };
  reset: () => void;
}) {
  useEffect(() => {
    console.error("[GITDM campus] workspace render error", error);
  }, [error]);

  return (
    <main className="workspace-error-page">
      <section className="workspace-error-card">
        <span className="eyebrow">GITDM Campus</span>
        <h1>We couldn’t open your Campus workspace.</h1>
        <p>
          Your account has not been lost. The Campus workspace encountered a temporary
          problem while loading your institutional data.
        </p>
        <div className="workspace-error-actions">
          <button type="button" className="btn btn-primary" onClick={() => reset()}>Try again</button>
          <a className="btn btn-outline-dark" href="/">Return to GITDM</a>
        </div>
        {error?.digest ? <small>Reference: {error.digest}</small> : null}
      </section>
    </main>
  );
}
