import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { GITDM } from "@/lib/branding";

export const metadata = {
  title: `Trading & Education Disclaimer | ${GITDM.shortName}`,
  description: "Important educational, financial-risk and third-party-link disclosures for GITDM visitors and learners.",
};

export default function DisclaimerPage() {
  return <><Header active="/disclaimer" /><main>
    <section className="page-hero"><div className="container"><div className="eyebrow">Important information</div><h1>Trading &amp; Education Disclaimer</h1><p>Please read this information before relying on content published by GITDM or using third-party trading services.</p></div></section>
    <section className="section"><div className="container"><div className="card stack">
      <h2>Educational purposes only</h2><p>All content provided by the Global Institute of Trading and Derivatives Markets (GITDM), including lessons, articles, examples, demonstrations and learning materials, is for general educational and informational purposes only. It does not constitute financial, investment, tax or legal advice, and it is not a recommendation to buy, sell or hold any financial instrument.</p>
      <h2>Trading involves substantial risk</h2><p>Forex, contracts for difference (CFDs), derivatives and other leveraged products are high-risk. You can lose some or all of your invested capital, and leverage can magnify losses. These products may not be suitable for everyone. Do not trade with money you cannot afford to lose. Consider whether you understand the risks and seek independent advice where appropriate.</p>
      <h2>No promise of results</h2><p>Past performance, simulated examples, case studies and individual experiences do not guarantee future results. Outcomes vary between individuals and depend on many factors, including knowledge, experience, market conditions, costs and risk management. GITDM does not promise profits, employment, funding or a particular trading outcome.</p>
      <h2>Do your own research</h2><p>Information may be simplified for teaching and can become outdated as markets, products and regulations change. Verify information independently before making financial decisions. You remain responsible for your own decisions and actions.</p>
      <h2>Partners and third-party services</h2><p>Links to brokers, platforms, education providers and other third parties are provided for convenience or to explain industry relationships. Third-party services have their own terms, fees, eligibility rules and risks. GITDM is not responsible for their services or content. Some links may be referral or affiliate links, meaning GITDM may receive a benefit if you use them; this does not change the risks of trading and is not an endorsement of a trading decision.</p>
      <h2>Testimonials and examples</h2><p>Any testimonials or examples reflect the individual circumstances described and should not be understood as typical or guaranteed results. They are provided for context and educational discussion, not as a promise of future performance.</p>
      <p><strong>By using this website or its learning materials, you acknowledge that you are responsible for evaluating the information and the risks involved.</strong></p>
    </div></div></section>
  </main><Footer /></>;
}
