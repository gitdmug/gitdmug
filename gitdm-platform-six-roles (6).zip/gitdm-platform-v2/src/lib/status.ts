export function humanStatus(value: string) {
  return value
    .toLowerCase()
    .replaceAll("_", " ")
    .replace(/\b\w/g, (m) => m.toUpperCase());
}
export function money(value: unknown, currency = "UGX") {
  return `${currency} ${Number(value || 0).toLocaleString()}`;
}
