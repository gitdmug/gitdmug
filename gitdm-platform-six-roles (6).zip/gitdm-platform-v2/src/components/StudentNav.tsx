import Link from "next/link";
import { GITDM } from "@/lib/branding";

type NavItem={href:string;label:string;icon:string};
const items:NavItem[]=[
 {href:"/campus",label:"Dashboard",icon:"⌂"},
 {href:"/campus/profile",label:"My Profile",icon:"◎"},
 {href:"/campus/academic",label:"My Programme",icon:"▤"},
 {href:"/campus/learning",label:"My Learning",icon:"▦"},
 {href:"/campus/timetable",label:"My Timetable",icon:"▤"},
 {href:"/campus/assessments",label:"Exams & Assessments",icon:"✎"},
 {href:"/campus/academic",label:"Academic Record",icon:"✓"},
 {href:"/campus/finance",label:"Finance",icon:"▣"},
 {href:"/campus/requests",label:"Documents, Messages & Support",icon:"□"},
 {href:"/campus/store",label:"Student Store",icon:"◫"},
 {href:"/campus/alumni",label:"Alumni",icon:"◇"},
];

const limitedItems:NavItem[]=[
 {href:"/campus",label:"Dashboard",icon:"⌂"},
 {href:"/campus/profile",label:"My Profile",icon:"◎"},
 {href:"/campus/courses",label:"Course Catalogue",icon:"＋"},
];

export function StudentNav({active,fullAccess=true}:{active:string;fullAccess?:boolean}){
 return <aside className="student-nav" aria-label="Student workspace">
      <label htmlFor="workspace-nav-toggle" className="workspace-sidebar-close" aria-label="Close navigation">×</label>
   <Link href="/campus" className="student-sidebar-brand"><img src="/gitdm-brand.jpeg" alt="GITDM"/><span><strong>GITDM</strong><small>Member Workspace</small></span></Link>
   <div className="student-nav-heading"><span>MEMBER PORTAL</span><small>{fullAccess ? "Full institutional access" : "Limited public access"}</small></div>
   <nav className="student-nav-inner">
    {(fullAccess ? items : limitedItems).map((item)=>{const base=item.href.split('#')[0];const selected=active===base||(base!=="/campus"&&active.startsWith(base+"/"));return <div key={item.href} className="student-nav-item"><Link href={item.href} className={selected?"student-nav-link active":"student-nav-link"}><span className="student-nav-icon" aria-hidden="true">{item.icon}</span><span>{item.label}</span></Link></div>})}
   </nav>
   <div className="student-sidebar-footer"><div className="student-support-pill"><span className="status-dot"/> Support available</div><span>{GITDM.shortName} · Member Services</span></div>
 </aside>
}
