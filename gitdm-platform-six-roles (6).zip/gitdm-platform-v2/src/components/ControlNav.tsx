import Link from "next/link";
import { requireStaffUser } from "@/lib/control-centre";

const PRINCIPAL_NAV = [
  {
    label: "COMMAND",
    items: [
      { href: "/control-centre", label: "Overview" },
      { href: "/control-centre/users", label: "People & departments" },
      { href: "/control-centre/staff", label: "Staff register" },
      { href: "/control-centre/insights", label: "Trader insights" },
    ],
  },
  {
    label: "DEPARTMENTS",
    items: [
      { href: "/control-centre/admissions", label: "Admissions" },
      { href: "/control-centre/finance", label: "Finance" },
      { href: "/control-centre/academic", label: "Academic" },
      { href: "/control-centre/exams", label: "Exam Office" },
      { href: "/control-centre/results", label: "Results" },
      { href: "/staff/registrar/students", label: "Registrar · students" },
    ],
  },
  {
    label: "CATALOGUE",
    items: [
      { href: "/control-centre/programmes", label: "Programmes" },
      { href: "/control-centre/courses", label: "Courses" },
      { href: "/control-centre/timetable", label: "Timetable" },
    ],
  },
];

export async function ControlNav({ active }: { active: string }) {
  await requireStaffUser();

  return (
    <aside className="control-nav" aria-label="Principal navigation">
      <label htmlFor="workspace-nav-toggle" className="workspace-sidebar-close" aria-label="Close navigation">
        ×
      </label>
      <div className="control-nav-brand">
        <strong>Principal</strong>
        <span>Control Centre</span>
      </div>
      <nav className="staff-nav">
        {PRINCIPAL_NAV.map((group) => (
          <div key={group.label}>
            <div className="staff-nav-label">{group.label}</div>
            {group.items.map((item) => (
              <Link
                key={item.href}
                href={item.href}
                className={active === item.href || active.startsWith(item.href + "/") ? "active" : undefined}
              >
                {item.label}
              </Link>
            ))}
          </div>
        ))}
      </nav>
      <div className="staff-sidebar-footer">
        <span className="staff-status-dot" /> Six departments only
      </div>
    </aside>
  );
}
