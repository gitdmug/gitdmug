"use client";
import { useEffect, useState } from "react";

export function LocalGreeting({ name }: { name: string }) {
  const [greeting, setGreeting] = useState("Welcome");
  useEffect(() => {
    const hour = new Date().getHours();
    setGreeting(hour < 12 ? "Good morning" : hour < 17 ? "Good afternoon" : "Good evening");
  }, []);
  return <>{greeting}, {name}.</>;
}
