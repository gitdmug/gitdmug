import { GITDM } from "@/lib/branding";

/** Visible only when printing — logo + optional principal signature. */
export function PrintLetterhead({ showSignature = false }: { showSignature?: boolean }) {
  return (
    <div className="print-letterhead">
      {/* eslint-disable-next-line @next/next/no-img-element */}
      <img src="/gitdm-brand.jpeg" alt={GITDM.shortName} />
      <div>
        <strong>{GITDM.name}</strong>
        <div style={{ fontSize: 12 }}>{GITDM.tagline}</div>
      </div>
      {showSignature ? (
        <div className="print-signature" style={{ marginLeft: "auto" }}>
          {/* Place principal signature at /public/principal-signature.png when available */}
          {/* eslint-disable-next-line @next/next/no-img-element */}
          <img src="/principal-signature.png" alt="Principal signature" onError={() => {}} />
          <div style={{ fontSize: 11, marginTop: 4 }}>Principal</div>
        </div>
      ) : null}
    </div>
  );
}
