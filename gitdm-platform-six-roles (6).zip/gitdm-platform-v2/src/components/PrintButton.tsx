"use client";
export function PrintButton({children="Print / Save as PDF"}:{children?:React.ReactNode}){return <button className="btn btn-primary" type="button" onClick={()=>window.print()}>{children}</button>}
