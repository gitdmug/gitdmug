import Link from "next/link";
import { getCurrentUser } from "@/lib/access";
import { getDb } from "@/lib/db";
import { acceptStaffRole, chooseStaffRole } from "@/app/staff/actions";

export async function RoleSwitchPanel() {
  const user = await getCurrentUser();
  if (!user) return null;
  const db = getDb();
  if (!db) return null;
  const [pending, current, memberEnrollment] = await Promise.all([
    db.staffRoleAssignment.findMany({ where: { userId: user.id, status: "PENDING" }, include: { role: true, department: true }, orderBy: { createdAt: "desc" } }),
    db.userRole.findMany({ where: { userId: user.id, role: { isActive: true } }, include: { role: { include: { department: true } } }, orderBy: { role: { name: "asc" } } }),
    db.enrollment.findFirst({ where: { userId: user.id, status: { in: ["ACTIVE", "REPEATING"] }, accessLevel: "FULL" }, select: { id: true } }),
  ]);
  return <>
    {pending.map((p) => <div className="access-banner full" style={{ marginBottom: 18 }} key={p.id}>
      <strong>New departmental role assigned</strong>
      <div style={{ marginTop: 4 }}>{p.role.name} · {p.department.name}. The Principal has assigned you this role. Accept it to activate the additional responsibility.</div>
      <form action={acceptStaffRole} style={{ marginTop: 12 }}><input type="hidden" name="assignmentId" value={p.id}/><button className="btn btn-primary btn-sm">Accept role &amp; change workspace</button></form>
    </div>)}
    {current.filter((r) => !["STUDENT","PARENT_GUARDIAN","ALUMNI"].includes(r.role.code)).length > 1 || memberEnrollment ? <div className="panel" style={{ marginBottom: 22 }}>
      <div className="eyebrow">My staff roles</div><h3 style={{ marginTop: 6 }}>Change role</h3><p>Switch the active staff workspace without removing any of your other roles.</p>
      <form action={chooseStaffRole} className="actions"><select name="roleCode" defaultValue={current.find((r) => !["STUDENT","PARENT_GUARDIAN","ALUMNI"].includes(r.role.code))?.role.code}><option value="">Choose role…</option>{current.filter((r) => !["STUDENT","PARENT_GUARDIAN","ALUMNI"].includes(r.role.code)).map((r) => <option key={r.role.code} value={r.role.code}>{r.role.department?.name || "Department"} · {r.role.name}</option>)}</select>{current.filter((r) => !["STUDENT","PARENT_GUARDIAN","ALUMNI"].includes(r.role.code)).length > 1 ? <button className="btn btn-outline-dark btn-sm">Change role</button> : null}</form>
      {memberEnrollment ? <Link href="/campus" className="btn btn-outline-dark btn-sm">Open Member Portal</Link> : null}
    </div> : null}
  </>;
}
