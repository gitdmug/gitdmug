import Link from "next/link";
import { ACTIVE_COURSE_CODES } from "@/lib/current-catalogue";

import { redirect } from "next/navigation";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { getCurrentUser } from "@/lib/access";
import { getDb } from "@/lib/db";
import { getStaffNav } from "@/lib/staff-workspaces";
import { RoleSwitchPanel } from "@/components/staff/RoleSwitchPanel";
import type { RoleCode } from "@/lib/permissions";

type Metric = { label: string; value: number | string; tone?: "default" | "accent" | "success" | "warning" };
type WorkspaceLink = { title: string; description: string; href: string };

type WorkspaceConfig = {
  title: string;
  shortTitle: string;
  description: string;
  links: WorkspaceLink[];
  metrics: (db: NonNullable<ReturnType<typeof getDb>>, userId: string) => Promise<Metric[]>;
};

const WORKSPACES: Record<string, WorkspaceConfig> = {
  PRINCIPAL: {
    title: "Principal's Office",
    shortTitle: "Principal",
    description: "Institution-wide leadership, oversight, and decision-making.",
    metrics: async (db) => {
      const [users, activeStudents, applications, outstandingTickets] = await Promise.all([
        db.user.count(),
        db.enrollment.count({ where: { status: "ACTIVE" } }),
        db.application.count({ where: { status: { in: ["SUBMITTED", "UNDER_REVIEW", "INTERVIEW_REQUIRED", "ADDITIONAL_INFORMATION"] } } }),
        db.supportTicket.count({ where: { status: { in: ["OPEN", "IN_PROGRESS", "WAITING"] } } }),
      ]);
      return [
        { label: "People in system", value: users },
        { label: "Active students", value: activeStudents, tone: "success" },
        { label: "Applications awaiting action", value: applications, tone: "warning" },
        { label: "Open institutional cases", value: outstandingTickets },
      ];
    },
    links: [
      { title: "Institution overview", description: "Institutional metrics, programmes, operations, and overall status.", href: "/control-centre" },
      { title: "People & departments", description: "Review accounts and assign staff to departments; roles are not assigned individually.", href: "/control-centre/users" },
      { title: "Admissions oversight", description: "Review applications, interviews, and admission decisions.", href: "/control-centre/admissions" },
      { title: "Finance oversight", description: "Review invoices, payments, and fee clearance.", href: "/control-centre/finance" },
      { title: "Academic oversight", description: "Review programmes, academic delivery, and results.", href: "/control-centre/academic" },
      { title: "Support oversight", description: "Review institutional support cases and operational issues.", href: "/control-centre/support" },
      { title: "Department oversight", description: "Review department operations without entering or impersonating a departmental role.", href: "/control-centre/access-staff-roles" },
    ],
  },
  REGISTRAR: {
    title: "Registrar's Office",
    shortTitle: "Registrar",
    description: "Admissions, student records, registration, and academic administration.",
    metrics: async (db) => {
      const [applications, activeStudents, certificates, pendingCases] = await Promise.all([
        db.application.count({ where: { status: { in: ["SUBMITTED", "UNDER_REVIEW", "INTERVIEW_REQUIRED", "ADDITIONAL_INFORMATION"] } } }),
        db.enrollment.count({ where: { status: "ACTIVE" } }),
        db.certificate.count({ where: { status: "ISSUED" } }),
        db.supportTicket.count({ where: { status: { in: ["OPEN", "IN_PROGRESS", "WAITING"] } } }),
      ]);
      return [
        { label: "Applications awaiting action", value: applications, tone: "warning" },
        { label: "Active student records", value: activeStudents, tone: "success" },
        { label: "Certificates issued", value: certificates },
        { label: "Open cases", value: pendingCases },
      ];
    },
    links: [
      { title: "Academic records desk", description: "Maintain the official student record, results and certificate trail.", href: "/staff/registrar/records" },
      { title: "Results & transcripts", description: "Review the controlled results publication pipeline.", href: "/staff/registrar/records/results" },
      { title: "Programmes & courses", description: "Review the academic structures attached to student records.", href: "/staff/academic-director" },
    ],
  },
  ACADEMIC_DIRECTOR: {
    title: "Academic Director's Office",
    shortTitle: "Academic Director",
    description: "Academic quality, curriculum, teaching, assessment, and results oversight.",
    metrics: async (db) => {
      const [programmes, courses, activeStudents, finalGrades] = await Promise.all([
        db.programme.count(),
        db.course.count({ where: { code: { in: [...ACTIVE_COURSE_CODES] } } }),
        db.enrollment.count({ where: { status: "ACTIVE" } }),
        db.grade.count({ where: { status: "FINAL" } }),
      ]);
      return [
        { label: "Programmes", value: programmes },
        { label: "Courses", value: courses },
        { label: "Active students", value: activeStudents, tone: "success" },
        { label: "Final grades", value: finalGrades },
      ];
    },
    links: [
      { title: "Academic operations", description: "Review programme and academic delivery data.", href: "/staff/academic-director" },
      { title: "Programmes & curriculum", description: "Review programmes and curriculum structures.", href: "/staff/academic-director" },
      { title: "Student register", description: "View institutional student and enrolment records.", href: "/staff/registrar/students" },
    ],
  },
  ADMISSIONS: {
    title: "Admissions Workspace",
    shortTitle: "Admissions",
    description: "Application review, applicant processing, interviews, and admission decisions.",
    metrics: async (db) => {
      const [review, interviews, accepted, applicants] = await Promise.all([
        db.application.count({ where: { status: { in: ["SUBMITTED", "UNDER_REVIEW", "ADDITIONAL_INFORMATION"] } } }),
        db.interview.count({ where: { status: "SCHEDULED" } }),
        db.application.count({ where: { status: "ACCEPTED" } }),
        db.application.count(),
      ]);
      return [
        { label: "Applications awaiting review", value: review, tone: "warning" },
        { label: "Scheduled interviews", value: interviews },
        { label: "Accepted applications", value: accepted, tone: "success" },
        { label: "Applications received", value: applicants },
      ];
    },
    links: [
      { title: "Applications queue", description: "Review applications, documents, interviews, and decisions.", href: "/staff/admissions/applications" },
      { title: "Applicant register", description: "View applicants and their institutional accounts.", href: "/staff/admissions/applications" },
    ],
  },
  FINANCE: {
    title: "Finance Workspace",
    shortTitle: "Finance",
    description: "Invoices, payments, fee clearance, receipts, and reconciliation.",
    metrics: async (db) => {
      const [invoices, pendingPayments, paidInvoices, limitedAccess] = await Promise.all([
        db.invoice.count(),
        db.payment.count({ where: { status: "PENDING" } }),
        db.invoice.count({ where: { status: { in: ["PAID", "PARTIALLY_PAID"] } } }),
        db.enrollment.count({ where: { accessLevel: "LIMITED" } }),
      ]);
      return [
        { label: "Invoices", value: invoices },
        { label: "Payments awaiting verification", value: pendingPayments, tone: "warning" },
        { label: "Paid / partially paid", value: paidInvoices, tone: "success" },
        { label: "Limited-access students", value: limitedAccess },
      ];
    },
    links: [
      { title: "Finance dashboard", description: "Review invoices, balances, payments, and verification.", href: "/staff/finance" },
      { title: "Bank reconciliation", description: "Import bank transactions, auto-match references, and resolve exceptions.", href: "/staff/finance/reconciliation" },
      { title: "Staff claims", description: "Review departmental claims through budget and payout controls.", href: "/staff/finance/claims" },
      { title: "Vendor invoices", description: "Register supplier expenditure and retain payout references.", href: "/staff/finance/vendors" },
      { title: "Budgets", description: "Monitor departmental allocations and approved spend.", href: "/staff/finance/budgets" },
      { title: "Financial aid", description: "Review student aid requests and awards.", href: "/staff/finance/aid" },
    ],
  },
  FACULTY: {
    title: "Faculty Workspace",
    shortTitle: "Faculty",
    description: "Teaching, course delivery, student progress, grading, and academic support.",
    metrics: async (db, userId) => {
      const [courses, submissions, students, attendance] = await Promise.all([
        db.courseFaculty.count({ where: { userId } }),
        db.assignmentSubmission.count({ where: { status: { in: ["SUBMITTED", "LATE"] } } }),
        db.enrollment.count({ where: { status: "ACTIVE" } }),
        db.attendanceRecord.count({ where: { userId } }),
      ]);
      return [
        { label: "My assigned courses", value: courses },
        { label: "Submissions awaiting grading", value: submissions, tone: "warning" },
        { label: "Active students", value: students, tone: "success" },
        { label: "My attendance records", value: attendance },
      ];
    },
    links: [
      { title: "Academic workspace", description: "View assigned teaching, curriculum and student learning operations.", href: "/staff/lecturer/courses" },
      { title: "Programmes & courses", description: "Review programme and course information.", href: "/staff/lecturer/courses" },
    ],
  },
  LECTURER: {
    title: "Lecturer Workspace",
    shortTitle: "Lecturer",
    description: "Prepare approved course delivery, modules, lessons, learning materials, classes, and student progress.",
    metrics: async (db, userId) => {
      const [courses, modules, pending, classes] = await Promise.all([
        db.courseFaculty.count({ where: { userId } }),
        db.courseModule.count({ where: { course: { faculty: { some: { userId } } } } }),
        db.courseModule.count({ where: { approvalStatus: "PENDING_APPROVAL", course: { faculty: { some: { userId } } } } }),
        db.timetableEvent.count({ where: { lecturerUserId: userId, startAt: { gte: new Date() } } }),
      ]);
      return [
        { label: "My assigned courses", value: courses, tone: "accent" },
        { label: "Course modules", value: modules },
        { label: "Awaiting academic approval", value: pending, tone: pending ? "warning" : "success" },
        { label: "Upcoming classes", value: classes },
      ];
    },
    links: [
      { title: "My teaching courses", description: "Open only the courses allocated to you and prepare their delivery plans.", href: "/staff/lecturer/courses" },
      { title: "Class timetable", description: "Schedule teaching sessions for your assigned courses and manage live classes.", href: "/staff/lecturer/classes" },
      { title: "Academic delivery approvals", description: "See how submitted teaching plans move through Academic Director approval.", href: "/staff/academic-director/delivery" },
      { title: "Student progress", description: "Use your assigned course workspace to review enrolled learners and teaching activity.", href: "/staff/registrar/students" },
    ],
  },
  EXAM_OFFICER: {
    title: "Examinations Office",
    shortTitle: "Examinations",
    description: "Examination administration, eligibility, attempts, marking, and results processing.",
    metrics: async (db) => {
      const [exams, activeAttempts, submittedAttempts, finalGrades] = await Promise.all([
        db.exam.count(),
        db.examAttempt.count({ where: { status: "IN_PROGRESS" } }),
        db.examAttempt.count({ where: { status: { in: ["SUBMITTED", "MANUAL_REVIEW"] } } }),
        db.grade.count({ where: { status: "FINAL" } }),
      ]);
      return [
        { label: "Examinations", value: exams },
        { label: "Active attempts", value: activeAttempts },
        { label: "Attempts awaiting processing", value: submittedAttempts, tone: "warning" },
        { label: "Final grades", value: finalGrades, tone: "success" },
      ];
    },
    links: [
      { title: "Academic & exams", description: "Open examination operations and assessment oversight.", href: "/staff/exam-officer/exams" },
      { title: "Student records", description: "Look up institutional student records.", href: "/staff/registrar/students" },
    ],
  },
  STUDENT_AFFAIRS: {
    title: "Student Affairs Office",
    shortTitle: "Student Affairs",
    description: "Student support, welfare, communication, and case coordination.",
    metrics: async (db) => {
      const [openCases, activeStudents, notifications, groups] = await Promise.all([
        db.supportTicket.count({ where: { status: { in: ["OPEN", "IN_PROGRESS", "WAITING"] } } }),
        db.enrollment.count({ where: { status: "ACTIVE" } }),
        db.notification.count({ where: { readAt: null } }),
        db.group.count({ where: { status: "ACTIVE" } }),
      ]);
      return [
        { label: "Open support cases", value: openCases, tone: "warning" },
        { label: "Active students", value: activeStudents, tone: "success" },
        { label: "Unread notifications", value: notifications },
        { label: "Active groups", value: groups },
      ];
    },
    links: [
      { title: "Support queue", description: "Review and coordinate student support cases.", href: "/staff/student-affairs/support" },
      { title: "Student register", description: "Look up student accounts when authorized.", href: "/staff/registrar/students" },
    ],
  },
  LIBRARY: {
    title: "Library Workspace",
    shortTitle: "Library",
    description: "Digital resources, lending services, and student resource support.",
    metrics: async (db) => {
      const [resources, available, loans, overdue] = await Promise.all([
        db.libraryResource.count(),
        db.libraryResource.count({ where: { available: true } }),
        db.libraryLoan.count({ where: { returnedAt: null } }),
        db.libraryLoan.count({ where: { returnedAt: null, dueAt: { lt: new Date() } } }),
      ]);
      return [
        { label: "Library resources", value: resources },
        { label: "Available resources", value: available, tone: "success" },
        { label: "Active loans", value: loans },
        { label: "Overdue loans", value: overdue, tone: "warning" },
      ];
    },
    links: [
      { title: "Library resources", description: "Manage the academic resource catalogue and active loans.", href: "/staff/library/resources" },
    ],
  },
  IT: {
    title: "IT Services Workspace",
    shortTitle: "IT Services",
    description: "Technical support, account assistance, system access, and operational security.",
    metrics: async (db) => {
      const [users, activeUsers, openCases, auditEvents] = await Promise.all([
        db.user.count(),
        db.user.count({ where: { status: "ACTIVE" } }),
        db.supportTicket.count({ where: { status: { in: ["OPEN", "IN_PROGRESS", "WAITING"] } } }),
        db.auditLog.count(),
      ]);
      return [
        { label: "User accounts", value: users },
        { label: "Active accounts", value: activeUsers, tone: "success" },
        { label: "Open technical cases", value: openCases, tone: "warning" },
        { label: "Audit events", value: auditEvents },
      ];
    },
    links: [
      { title: "Support queue", description: "Review and manage technical support cases.", href: "/staff/it/support" },
      { title: "Users & access", description: "Review institutional accounts and access assignments.", href: "/staff/it/users" },
    ],
  },
  MARKETING: {
    title: "Marketing Workspace",
    shortTitle: "Marketing",
    description: "Outreach, communications, institutional visibility, programmes, and partner-facing information.",
    metrics: async (db) => {
      const [publishedProgrammes, partners, announcements, users] = await Promise.all([
        db.programme.count({ where: { status: "PUBLISHED" } }),
        db.partner.count({ where: { status: "ACTIVE" } }),
        db.announcement.count(),
        db.user.count({ where: { status: "ACTIVE" } }),
      ]);
      return [
        { label: "Published programmes", value: publishedProgrammes, tone: "success" },
        { label: "Active partners", value: partners },
        { label: "Announcements", value: announcements },
        { label: "Active accounts", value: users },
      ];
    },
    links: [
      { title: "Campaign workspace", description: "Monitor active institutional partners and communications records.", href: "/staff/marketing/campaigns" },
    ],
  },
  PARTNER_SUPPORT: {
    title: "Partner Support Workspace",
    shortTitle: "Partner Support",
    description: "Partner coordination, student support, and industry-partner service requests.",
    metrics: async (db) => {
      const [partners, openCases, activeStudents, groups] = await Promise.all([
        db.partner.count({ where: { status: "ACTIVE" } }),
        db.supportTicket.count({ where: { status: { in: ["OPEN", "IN_PROGRESS", "WAITING"] } } }),
        db.enrollment.count({ where: { status: "ACTIVE" } }),
        db.group.count({ where: { status: "ACTIVE" } }),
      ]);
      return [
        { label: "Active partners", value: partners, tone: "success" },
        { label: "Open support cases", value: openCases, tone: "warning" },
        { label: "Active students", value: activeStudents },
        { label: "Active groups", value: groups },
      ];
    },
    links: [
      { title: "Support queue", description: "Review and coordinate partner and student support requests.", href: "/staff/partner-support/support" },
    ],
  },
};

const ROUTE_ROLE: Record<string, string> = {
  principal: "PRINCIPAL", registrar: "REGISTRAR", "academic-director": "ACADEMIC_DIRECTOR",
  admissions: "ADMISSIONS", finance: "FINANCE", faculty: "FACULTY", lecturer: "LECTURER", "exam-officer": "EXAM_OFFICER",
  "student-affairs": "STUDENT_AFFAIRS", library: "LIBRARY", it: "IT", marketing: "MARKETING",
  "partner-support": "PARTNER_SUPPORT",
};
const ROLE_ALIASES: Record<string,string[]> = {
  ADMISSIONS: ["ADMISSIONS"],
  FACULTY: ["CURRICULUM_DEVELOPER"], LECTURER: ["ONLINE_INSTRUCTOR"], "ACADEMIC_DIRECTOR": ["DIFFERENTIATED_LEARNING_COORDINATOR"],
  "STUDENT_AFFAIRS": ["STUDENT_SUCCESS_COACH","SCHOOL_COUNSELOR"], REGISTRAR: ["ACADEMIC_ADVISOR_REGISTRAR"],
  IT: ["CTO_IT_DIRECTOR","LMS_ADMINISTRATOR","HELPDESK_TECHNICIAN"], FINANCE: ["BURSAR_BILLING_SPECIALIST"], PRINCIPAL: [],
};

function formatRole(role: string) {
  return role.replaceAll("_", " ").toLowerCase().replace(/(^|\s)\S/g, (char) => char.toUpperCase());
}

export async function StaffWorkspace({ workspace }: { workspace: string }) {
  const user = await getCurrentUser();
  if (!user) redirect(`/auth/login?returnTo=/staff/${workspace}`);
  const roleCodes = user.roles.map((r) => r.role.code);
  const expectedRole = ROUTE_ROLE[workspace];
  const acceptedRoles = expectedRole ? [expectedRole, ...(ROLE_ALIASES[expectedRole] || [])] : [];
  if (!expectedRole || !roleCodes.some((role) => acceptedRoles.includes(role))) redirect("/staff");

  const config = WORKSPACES[expectedRole];
  const visibleLinks = config.links.filter((link) => roleCodes.includes("PRINCIPAL") || !link.href.startsWith("/control-centre"));
  const db = getDb();
  let metrics: Metric[];
  if (!db) {
    metrics = config.links.slice(0, 4).map(() => ({
      label: "Data unavailable",
      value: "—",
      tone: "default",
    }));
  } else {
    try {
      metrics = await config.metrics(db, user.id);
    } catch (error) {
      // A dashboard metric must never take down the whole staff workspace.
      // Keep the existing layout and links visible while the failed data
      // source is repaired.
      console.error(`[GITDM staff] ${expectedRole} metrics failed:`, error);
      metrics = config.links.slice(0, 4).map(() => ({
        label: "Data temporarily unavailable",
        value: "—",
        tone: "default" as const,
      }));
    }
  }
  const name = [user.firstName, user.lastName].filter(Boolean).join(" ") || user.email;

  return (
    <div className="staff-app">
      <Header workspace="staff" />
      <div className="staff-shell">
        {!roleCodes.includes("PRINCIPAL") ? <div style={{ gridColumn: "1 / -1" }}><RoleSwitchPanel /></div> : null}
        <aside className="staff-sidebar" aria-label="Staff navigation">
          <label htmlFor="workspace-nav-toggle" className="workspace-sidebar-close" aria-label="Close navigation">×</label>
          <div className="staff-sidebar-head">
            <div className="staff-role-mark">G</div>
            <div><strong>{config.shortTitle}</strong><span>Staff workspace</span></div>
          </div>
          <nav className="staff-nav">
            <Link href={`/staff/${workspace}`} className="active">My workspace</Link>
            {getStaffNav(roleCodes as RoleCode[], user.departments.map((d) => d.department.name)).map((group) => (
              <div key={group.label}>
                <div className="staff-nav-label">{group.label}</div>
                {group.items.map((item) => <Link key={item.href + item.label} href={item.href}>{item.label}</Link>)}
              </div>
            ))}
          </nav>
          <div className="staff-sidebar-footer">
            <span className="staff-status-dot" /> Server-side access control active
          </div>
        </aside>

        <main className="staff-main">
          <div className="staff-page-head">
            <div>
              <div className="eyebrow">GITDM · Staff Portal</div>
              <h1>{config.title}</h1>
              <p>Welcome, {name}. You are signed in with the {formatRole(expectedRole)} role.</p>
            </div>
            <div className="staff-user-card">
              <strong>{name}</strong>
              <span>{user.email}</span>
            </div>
          </div>

          <section className="staff-metrics" aria-label="Workspace metrics">
            {metrics.map((metric, index) => (
              <div className={`staff-metric ${metric.tone ?? "default"}`} key={`${metric.label}-${index}`}>
                <span>{metric.label}</span>
                <strong>{metric.value}</strong>
              </div>
            ))}
          </section>

          <section className="staff-section-head">
            <div>
              <div className="eyebrow">Your workspace</div>
              <h2>{config.description}</h2>
            </div>
          </section>

          <section className="staff-work-grid">
            {visibleLinks.map((link) => (
              <Link href={link.href} className="staff-work-card" key={link.href + link.title}>
                <div className="staff-card-arrow">↗</div>
                <h3>{link.title}</h3>
                <p>{link.description}</p>
                <span>Open workspace</span>
              </Link>
            ))}
          </section>

          <section className="staff-notice">
            <div><strong>Role-based access is active.</strong><p>Your navigation and operational views are determined by your GITDM role and server-side permissions. The institutional Control Centre is restricted to the Principal.</p></div>
            <Link href="/campus/support" className="btn btn-outline-dark btn-sm">Get support</Link>
          </section>
        </main>
      </div>
      <Footer />
    </div>
  );
}

export function routeForRoles(roleCodes: string[]) {
  const priority = ["PRINCIPAL", "ADMISSIONS", "CURRICULUM_DEVELOPER", "ONLINE_INSTRUCTOR", "EXAM_OFFICER", "ACADEMIC_ADVISOR_REGISTRAR", "STUDENT_SUCCESS_COACH", "SCHOOL_COUNSELOR", "CTO_IT_DIRECTOR", "LMS_ADMINISTRATOR", "HELPDESK_TECHNICIAN", "OPERATIONS_COMPLIANCE_MANAGER", "FINANCE", "ACADEMIC_DIRECTOR", "REGISTRAR", "ADMISSIONS", "FACULTY", "LECTURER", "STUDENT_AFFAIRS", "LIBRARY", "IT", "MARKETING", "PARTNER_SUPPORT", "DIFFERENTIATED_LEARNING_COORDINATOR", "BURSAR_BILLING_SPECIALIST"];
  const role = priority.find((r) => roleCodes.includes(r));
  const routes: Record<string, string> = {
    PRINCIPAL:"/staff/principal", REGISTRAR:"/staff/registrar", ACADEMIC_DIRECTOR:"/staff/academic-director",
    ADMISSIONS:"/staff/admissions", FINANCE:"/staff/finance", FACULTY:"/staff/faculty", LECTURER:"/staff/lecturer", EXAM_OFFICER:"/staff/exam-officer",
    STUDENT_AFFAIRS:"/staff/student-affairs", LIBRARY:"/staff/library", IT:"/staff/it", MARKETING:"/staff/marketing", PARTNER_SUPPORT:"/staff/partner-support",
  };
  const aliases: Record<string,string> = { CURRICULUM_DEVELOPER:"/staff/faculty", ONLINE_INSTRUCTOR:"/staff/lecturer", DIFFERENTIATED_LEARNING_COORDINATOR:"/staff/academic-director", STUDENT_SUCCESS_COACH:"/staff/student-affairs", ACADEMIC_ADVISOR_REGISTRAR:"/staff/registrar", SCHOOL_COUNSELOR:"/staff/student-affairs", CTO_IT_DIRECTOR:"/staff/it", LMS_ADMINISTRATOR:"/staff/it", HELPDESK_TECHNICIAN:"/staff/it", OPERATIONS_COMPLIANCE_MANAGER:"/staff/operations", BURSAR_BILLING_SPECIALIST:"/staff/finance" };
  return role ? (routes[role] || aliases[role] || null) : null;
}
