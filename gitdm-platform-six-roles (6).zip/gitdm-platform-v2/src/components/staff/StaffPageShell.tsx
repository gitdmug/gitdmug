import type { ReactNode } from "react";
import Link from "next/link";
import { redirect } from "next/navigation";
import { Header } from "@/components/Header";
import { Footer } from "@/components/Footer";
import { getCurrentUser } from "@/lib/access";
import { getStaffNav } from "@/lib/staff-workspaces";
import { RoleSwitchPanel } from "@/components/staff/RoleSwitchPanel";
import type { RoleCode } from "@/lib/permissions";

export async function StaffPageShell({
  title,
  eyebrow = "GITDM · Staff Portal",
  description,
  activeHref,
  children,
}: {
  title: string;
  eyebrow?: string;
  description?: string;
  activeHref?: string;
  children: ReactNode;
}) {
  const user = await getCurrentUser();
  if (!user) redirect(`/auth/login?returnTo=${encodeURIComponent(activeHref || "/staff")}`);
  const roleCodes = user.roles.map((r) => r.role.code) as RoleCode[];
  const name = [user.firstName, user.lastName].filter(Boolean).join(" ") || user.email;
  return <div className="staff-app">
    <Header workspace="staff" />
    <div className="staff-shell">
      <div style={{ gridColumn: "1 / -1" }}><RoleSwitchPanel /></div>
      <aside className="staff-sidebar" aria-label="Staff navigation">
        <label htmlFor="workspace-nav-toggle" className="workspace-sidebar-close" aria-label="Close navigation">×</label>
        <div className="staff-sidebar-head"><div className="staff-role-mark">G</div><div><strong>{name}</strong><span>Staff workspace</span></div></div>
        <nav className="staff-nav">
          <Link href="/staff">My workspace</Link>
          {getStaffNav(roleCodes, user.departments.map((d) => d.department.name)).map((group) => <details key={group.label} className="staff-nav-group" open={group.items.some((item) => activeHref === item.href)}>
            <summary>{group.label}</summary>
            <div className="staff-nav-group-links">{group.items.map((item) => <Link key={item.href + item.label} href={item.href} className={activeHref === item.href ? "active" : ""}>{item.label}</Link>)}</div>
          </details>)}
        </nav>
        <div className="staff-sidebar-footer"><span className="staff-status-dot" /> Server-side access control active</div>
      </aside>
      <main className="staff-main">
        <div className="staff-page-head"><div><div className="eyebrow">{eyebrow}</div><h1>{title}</h1>{description ? <p>{description}</p> : null}</div><div className="staff-user-card"><strong>{name}</strong><span>{user.email}</span></div></div>
        {children}
      </main>
    </div>
    <Footer />
  </div>;
}
