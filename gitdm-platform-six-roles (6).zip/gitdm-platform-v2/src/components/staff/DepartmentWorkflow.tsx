import React from "react";

type WorkflowStep = {
  stage: string;
  owner: string;
  receives: string;
  action: string;
  sendsTo: string;
  problemSolved?: string;
};

type Props = {
  title: string;
  description: string;
  steps: WorkflowStep[];
  finalOutcomes: { outcome: string; destination: string; problem: string }[];
};

export function DepartmentWorkflow({ title, description, steps, finalOutcomes }: Props) {
  return (
    <section className="card" style={{ marginTop: 28 }}>
      <div className="eyebrow">Department workflow</div>
      <h2>{title}</h2>
      <p>{description}</p>
      <div className="stack" style={{ marginTop: 20 }}>
        {steps.map((step, index) => (
          <div className="staff-notice" key={`${step.stage}-${index}`} style={{ display: "block" }}>
            <div style={{ display: "flex", justifyContent: "space-between", gap: 16, flexWrap: "wrap" }}>
              <strong>{index + 1}. {step.stage}</strong>
              <span className="chip">Owner: {step.owner}</span>
            </div>
            <div className="grid grid-2" style={{ marginTop: 14 }}>
              <div><strong>Receives</strong><p>{step.receives}</p></div>
              <div><strong>Action</strong><p>{step.action}</p></div>
              <div><strong>Then sends to</strong><p>{step.sendsTo}</p></div>
              {step.problemSolved ? <div><strong>Problem addressed</strong><p>{step.problemSolved}</p></div> : null}
            </div>
          </div>
        ))}
      </div>

      <div style={{ marginTop: 22 }}>
        <div className="eyebrow">End of department workflow</div>
        <div className="grid grid-2" style={{ marginTop: 12 }}>
          {finalOutcomes.map((item) => (
            <div className="panel" key={item.outcome}>
              <strong>{item.outcome}</strong>
              <p><strong>Goes to:</strong> {item.destination}</p>
              <p><strong>Problem solved:</strong> {item.problem}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
