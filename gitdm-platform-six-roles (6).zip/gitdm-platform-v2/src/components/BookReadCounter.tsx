"use client";

import { useEffect, useState } from "react";

type Props = { bookSlug: string; label?: string; trackOnMount?: boolean };

/** Counts one reader per browser and book, without collecting names, emails, or IP addresses. */
export function BookReadCounter({ bookSlug, label = "readers", trackOnMount = true }: Props) {
  const [count, setCount] = useState<number | null>(null);

  useEffect(() => {
    let active = true;
    const key = `gitdm-book-reader:${bookSlug}`;
    let visitorKey = "";
    try {
      visitorKey = window.localStorage.getItem(key) || "";
      if (!visitorKey) {
        visitorKey = window.crypto?.randomUUID?.() || `r-${Date.now()}-${Math.random().toString(36).slice(2)}`;
        window.localStorage.setItem(key, visitorKey);
      }
    } catch {
      visitorKey = `session-${Date.now()}-${Math.random().toString(36).slice(2)}`;
    }

    const updateCount = async () => {
      try {
        const response = trackOnMount
          ? await fetch("/api/book-reads", { method: "POST", headers: { "Content-Type": "application/json" }, cache: "no-store", body: JSON.stringify({ bookSlug, visitorKey }) })
          : await fetch(`/api/book-reads?bookSlug=${encodeURIComponent(bookSlug)}`, { cache: "no-store" });
        if (!response.ok) return;
        const data = (await response.json()) as { count?: number };
        if (active && typeof data.count === "number") setCount(data.count);
      } catch {
        // Reading should continue if analytics is temporarily unavailable.
      }
    };
    const timer = trackOnMount ? window.setTimeout(() => { void updateCount(); }, 10_000) : null;
    if (!trackOnMount) void updateCount();
    return () => { active = false; if (timer !== null) window.clearTimeout(timer); };
  }, [bookSlug, trackOnMount]);

  return <span className="book-read-count" aria-live="polite">{count === null ? "Reader count loading…" : `${count.toLocaleString()} ${label}`}</span>;
}
